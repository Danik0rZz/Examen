import { Arrow, Box, C, Chip, Mark, Particle, Svg, T, cx, dim, show, toneColors } from './kit'
import type { VisualRegistry } from './types'

/* ——— 1. Capas de fuente: Path → Concepts → How-to → Reference ——— */
const scopeLayers = [
  { name: 'Path', question: '¿Qué dominios entran?', how: 'Usarlo como índice y alcance' },
  { name: 'Concepts', question: '¿Qué significa el producto?', how: 'Construir modelo mental' },
  { name: 'How-to', question: '¿Cómo se habilita o usa?', how: 'Practicar pasos y prerequisitos' },
  { name: 'Reference', question: '¿Qué campos, comandos o límites existen?', how: 'Memorizar matices verificables' },
]

function OfficialScope({ step }: { step: number }) {
  const rowY = (i: number) => 22 + i * 66
  return (
    <Svg h={330} label="Capas de estudio: Path, Concepts, How-to y Reference, cada una con su pregunta y forma de estudio">
      {/* Agrupación de fuentes */}
      <T x={62} y={rowY(0) + 24} size={11} weight={800} tone="navy">Learning Plan</T>
      <T x={62} y={rowY(0) + 39} size={10} tone="muted">PDF del path</T>
      <path d={`M116,${rowY(1) + 4} L108,${rowY(1) + 4} L108,${rowY(3) + 52} L116,${rowY(3) + 52}`} fill="none" stroke={C.teal} strokeWidth={2} />
      <T x={58} y={rowY(2) + 14} size={12} weight={800} tone="teal">Dynatrace</T>
      <T x={58} y={rowY(2) + 30} size={12} weight={800} tone="teal">Docs</T>
      <T x={58} y={rowY(2) + 46} size={10} tone="muted">autoridad</T>
      <T x={58} y={rowY(2) + 59} size={10} tone="muted">técnica</T>
      {scopeLayers.map((layer, i) => {
        const y = rowY(i)
        const active = i === step
        const seen = i <= step
        return (
          <g key={layer.name} className={dim(seen)}>
            <rect x={126} y={y} width={614} height={56} rx={10} fill={active ? toneColors.teal.fill : '#fff'} stroke={active ? C.teal : C.line} strokeWidth={1.5} />
            <Box x={134} y={y + 8} w={120} h={40} label={layer.name} tone={i === 0 ? 'navy' : 'teal'} solid={active} size={13} rx={20} />
            <T x={274} y={y + 24} size={13} weight={750} anchor="start">{layer.question}</T>
            <T x={274} y={y + 43} size={11} anchor="start" tone="muted">Cómo estudiarla: {layer.how}</T>
            {active && <circle cx={722} cy={y + 28} r={6} fill={C.teal} className="sv-pulse" />}
          </g>
        )
      })}
      {/* Nota sobre fuentes secundarias */}
      <g>
        <rect x={126} y={290} width={614} height={30} rx={8} fill={toneColors.amber.fill} stroke={C.amber} strokeWidth={1.2} />
        <T x={140} y={309} size={11} anchor="start" tone="amber" weight={700}>Página de comunidad: ayuda a localizar el path, no justifica un hecho técnico si existe fuente oficial.</T>
      </g>
    </Svg>
  )
}

/* ——— 2. Rutina de estudio comprobable ——— */
const routine = [
  { label: 'Lectura profunda', sub: '30–60 min por módulo' },
  { label: 'Recuperación', sub: 'explicar sin mirar' },
  { label: 'Quiz rápido', sub: 'detectar huecos' },
  { label: 'Banco', sub: 'precisión y escenarios' },
  { label: 'Repaso', sub: 'corregir la causa' },
]
const routineDetail = [
  'Lee el capítulo y sus fuentes internas.',
  'Cierra la documentación y escribe de memoria las diferencias importantes.',
  'Ocho preguntas. Si fallas una de precisión: vuelve a la fila de hechos y al bloque fuente.',
  'Con una base estable, completa el banco: precisión y escenarios.',
  'No repitas la opción: corrige la causa del error (y termina explicando el razonamiento).',
]

function StudyRoutine({ step }: { step: number }) {
  const bx = (i: number) => 20 + i * 146
  const loop = 'M672,98 C672,138 88,138 88,98'
  return (
    <Svg h={330} label="Rutina de estudio: lectura, recuperación libre, quiz rápido, banco y repaso en ciclo">
      {/* Vuelta atrás desde el quiz */}
      <g className={show(step === 2)}>
        <Arrow d="M380,44 C380,14 88,14 88,42" tone="coral" dashed />
        <T x={234} y={12} size={10.5} tone="coral" weight={700}>fallo de precisión → vuelve al bloque fuente</T>
      </g>
      {routine.map((node, i) => {
        const active = i === step
        return (
          <g key={node.label} className={dim(i <= step)}>
            <Box x={bx(i)} y={46} w={136} h={52} label={node.label} sub={node.sub} tone={active ? 'teal' : 'navy'} solid={active} size={12} />
            {i < routine.length - 1 && <Arrow from={[bx(i) + 137, 72]} to={[bx(i) + 145, 72]} tone="navy" />}
          </g>
        )
      })}
      {/* Ciclo */}
      <path d={loop} fill="none" stroke={C.line} strokeWidth={2} strokeDasharray="4 6" />
      <Particle path={loop} dur={4} tone="teal" r={5} />
      <T x={380} y={152} size={10.5} tone="muted" weight={700}>el repaso alimenta la siguiente sesión</T>
      {/* Detalle del paso */}
      <Box x={20} y={166} w={720} h={40} tone="teal" label={routineDetail[step]} size={12} />
      {/* Confianza frente a corrección */}
      <g className={dim(step === 4)}>
        <T x={20} y={232} size={10} tone="muted" anchor="start" weight={800}>LA CONFIANZA ES UNA SEÑAL SEPARADA DE LA CORRECCIÓN</T>
        <rect x={20} y={244} width={352} height={70} rx={10} fill={toneColors.amber.fill} stroke={C.amber} strokeWidth={1.4} />
        <Mark x={44} y={266} ok r={10} />
        <T x={62} y={270} size={12} weight={750} anchor="start" tone="amber">Acierto + confianza baja</T>
        <T x={36} y={298} size={11} anchor="start">Merece revisión: aún no es conocimiento estable.</T>
        <rect x={388} y={244} width={352} height={70} rx={10} fill={toneColors.coral.fill} stroke={C.coral} strokeWidth={1.4} className={cx(step === 4 && 'sv-pulse')} />
        <Mark x={412} y={266} ok={false} r={10} />
        <T x={430} y={270} size={12} weight={750} anchor="start" tone="coral">Fallo + confianza alta</T>
        <T x={404} y={298} size={11} anchor="start">Falsa seguridad: tiene prioridad en el repaso.</T>
      </g>
    </Svg>
  )
}

/* ——— 3. Estrategia de examen: eliminar distractores ——— */
const options = [
  { letter: 'A', text: 'Reinstalar siempre todos los agentes', reason: 'Absoluto no soportado', tone: 'coral' as const },
  { letter: 'B', text: 'Activar la función recomendada, porque es obligatoria', reason: '“Recomendado” ≠ “obligatorio”', tone: 'coral' as const },
  { letter: 'C', text: 'Que el usuario modifique la configuración del entorno', reason: 'Asume permiso de escritura', tone: 'coral' as const },
  { letter: 'D', text: 'Comprobar timeframe, filtros y permiso de lectura', reason: 'Mejor siguiente paso', tone: 'teal' as const },
]

function ExamStrategy({ step }: { step: number }) {
  return (
    <Svg h={320} label="Eliminación de opciones en una pregunta de ejemplo: se descartan absolutos, recomendaciones convertidas en obligación y permisos asumidos">
      {/* Enunciado */}
      <rect x={20} y={14} width={720} height={66} rx={10} fill={C.paperSoft} stroke={C.line} />
      <Chip x={92} y={32} text="EJEMPLO GENÉRICO" tone="neutral" w={130} size={10} />
      <T x={36} y={62} size={12.5} anchor="start">
        Un usuario con acceso de{' '}
        <tspan fontWeight={800} fill={step === 0 || step === 3 ? toneColors.amber.text : C.ink}>solo lectura</tspan>
        {' '}ve un dashboard vacío. ¿Cuál es el{' '}
        <tspan fontWeight={800} fill={step === 0 || step === 4 ? toneColors.amber.text : C.ink}>mejor siguiente paso</tspan>?
      </T>
      <g className={show(step === 0)}>
        <Chip x={620} y={32} text="Subraya las palabras de alcance" tone="amber" size={10.5} />
      </g>
      {options.map((opt, i) => {
        const y = 96 + i * 52
        const eliminated = opt.tone === 'coral' && step >= i + 1
        const winner = opt.tone === 'teal' && step >= 4
        const judged = step >= i + 1
        return (
          <g key={opt.letter}>
            <g className={eliminated ? 'sv-dim' : 'sv-in'}>
              <rect x={20} y={y} width={480} height={42} rx={8} fill={winner ? toneColors.teal.fill : '#fff'} stroke={winner ? C.teal : C.line} strokeWidth={winner ? 2 : 1.5} />
              <circle cx={44} cy={y + 21} r={12} fill={winner ? C.teal : C.paperSoft} stroke={winner ? C.teal : C.line} />
              <T x={44} y={y + 25.5} size={12} weight={800} tone={winner ? 'white' : 'navy'}>{opt.letter}</T>
              <T x={66} y={y + 26} size={12.5} anchor="start">{opt.text}</T>
            </g>
            {/* Tachado */}
            <line x1={62} x2={eliminated ? 490 : 62} y1={y + 21} y2={y + 21} stroke={C.coral} strokeWidth={2.2} className={show(eliminated)} style={{ transition: 'opacity .5s ease' }} />
            <g className={show(judged)}>
              <Mark x={518} y={y + 21} ok={opt.tone === 'teal'} r={10} />
              <Chip x={638} y={y + 21} text={opt.reason} tone={opt.tone} solid={winner} w={206} size={10.5} />
            </g>
          </g>
        )
      })}
      <T x={380} y={308} size={10.5} tone="muted" className={show(step === 4)}>Si dos opciones parecen válidas, decide por el criterio exacto del enunciado.</T>
    </Svg>
  )
}

/* ——— 4. Red outbound-only y mapping de Kubernetes ——— */
function ExamReadiness({ step }: { step: number }) {
  return (
    <Svg h={350} label="OneAgent comunica solo de forma saliente por HTTPS 443, opcionalmente mediante proxy o ActiveGate; los puertos inbound no son necesarios">
      {/* Red corporativa */}
      <rect x={14} y={30} width={456} height={306} rx={14} fill="#f8fbfa" stroke={C.slate} strokeWidth={1.4} strokeDasharray="6 5" />
      <T x={28} y={22} size={10} tone="muted" anchor="start" weight={800}>RED CORPORATIVA</T>
      {/* Firewall */}
      <T x={498} y={22} size={10} tone="navy" weight={800}>FIREWALL</T>
      <rect x={486} y={30} width={24} height={306} rx={3} fill="#e4ecee" stroke={C.navy} strokeWidth={1.4} />
      {Array.from({ length: 16 }, (_, i) => (
        <line key={i} x1={486} x2={510} y1={48 + i * 18} y2={48 + i * 18} stroke={C.navy} strokeOpacity={0.35} />
      ))}
      {/* Cluster */}
      <Box x={560} y={60} w={180} h={176} tone="teal" solid rx={14} />
      <T x={650} y={140} size={15} weight={800} tone="white">Dynatrace</T>
      <T x={650} y={160} size={12} tone="white" opacity={0.85}>cluster SaaS</T>

      {/* Carril A: host con salida directa */}
      <g className={dim(step !== 3)}>
        <Box x={34} y={60} w={150} h={62} label="Host" sub="con OneAgent" tone="navy" />
        <Arrow from={[186, 91]} to={[556, 91]} tone="teal" flow width={2.2} />
        <Particle path="M186,91 L556,91" dur={2.4} tone="teal" r={4.5} />
        <Chip x={330} y={72} text="HTTPS 443 · saliente" tone="teal" size={10.5} />
        <Mark x={532} y={72} ok r={9} />
      </g>

      {/* Carril B: host aislado vía proxy / ActiveGate */}
      <g className={step === 0 ? 'sv-dim' : step === 3 ? 'sv-dim' : 'sv-in'}>
        <Box x={34} y={160} w={150} h={62} label="Host aislado" sub="sin internet directo" tone="navy" />
        <rect x={232} y={160} width={196} height={62} rx={8} fill={toneColors.amber.fill} stroke={C.amber} strokeWidth={1.5} strokeDasharray="5 4" />
        <T x={330} y={186} size={12.5} weight={750} tone="amber">Proxy / PAC o ActiveGate</T>
        <T x={330} y={204} size={10.5} tone="muted">intermediario opcional</T>
        <Arrow from={[186, 191]} to={[230, 191]} tone="teal" flow width={2.2} />
        <Arrow from={[430, 191]} to={[556, 191]} tone="teal" flow width={2.2} />
        <Particle path="M186,191 L230,191" dur={1.2} tone="teal" r={4.5} />
        <Particle path="M430,191 L556,191" dur={1.8} begin={0.6} tone="teal" r={4.5} />
        <Mark x={532} y={172} ok r={9} />
      </g>

      {/* Puertos inbound: no se requieren */}
      <g className={show(step === 2)}>
        <T x={630} y={262} size={10.5} tone="coral" weight={800}>Entrante desde fuera</T>
        {[':8020', ':9999'].map((port, i) => (
          <g key={port}>
            <Arrow from={[736, 282 + i * 30]} to={[518, 282 + i * 30]} tone="coral" dashed />
            <Chip x={640} y={282 + i * 30} text={`${port} inbound`} tone="coral" w={110} mono size={10.5} />
            <Mark x={530} y={282 + i * 30} ok={false} r={10} />
          </g>
        ))}
        <rect x={34} y={244} width={420} height={78} rx={10} fill={toneColors.coral.fill} stroke={C.coral} strokeWidth={1.3} />
        <T x={244} y={272} size={12} weight={800} tone="coral">No hace falta abrir puertos inbound</T>
        <T x={244} y={292} size={11} tone="muted">Una opción que propone abrir 8020 o 9999</T>
        <T x={244} y={308} size={11} tone="muted">en el firewall es un distractor.</T>
      </g>

      {/* Kubernetes: Pod = PGI en un Node */}
      <g className={show(step === 3)}>
        <rect x={34} y={244} width={420} height={78} rx={10} fill={toneColors.violet.fill} stroke={C.violet} strokeWidth={1.5} />
        <T x={48} y={264} size={11.5} weight={800} tone="violet" anchor="start">Node = Host monitorizado</T>
        {[0, 1, 2].map((i) => (
          <Chip key={i} x={112 + i * 134} y={298} text="Pod = PGI" tone="violet" solid w={116} size={11} />
        ))}
        <T x={446} y={264} size={10.5} tone="muted" anchor="end">PGI: Process Group Instance</T>
      </g>
    </Svg>
  )
}

export const instructionsVisuals: VisualRegistry = {
  'deep-official-scope': {
    kind: 'animation',
    title: 'Cuatro capas de fuente, cuatro preguntas',
    caption: 'El path fija qué entra en el examen; Dynatrace Docs aporta la profundidad. Baja capa a capa: primero el alcance, luego el modelo mental (Concepts), los pasos y prerequisitos (How-to) y, por último, los matices verificables (Reference).',
    steps: ['Path: alcance e índice', 'Concepts: modelo mental', 'How-to: pasos y prerequisitos', 'Reference: campos, comandos, límites'],
    stepMs: 2800,
    render: ({ step }) => <OfficialScope step={step} />,
  },
  'deep-study-routine': {
    kind: 'animation',
    title: 'Una sesión de estudio que deja evidencia',
    caption: 'Sigue el ciclo: leer, recuperar sin mirar, detectar huecos con el quiz, practicar en el banco y repasar corrigiendo la causa del error. En el repaso, un fallo con confianza alta tiene prioridad sobre un acierto dudoso.',
    steps: ['Lectura profunda', 'Recuperación libre', 'Quiz rápido', 'Banco', 'Repaso: corregir la causa'],
    stepMs: 2800,
    render: ({ step }) => <StudyRoutine step={step} />,
  },
  'exam-strategy': {
    kind: 'animation',
    title: 'Eliminar distractores por su condición exacta',
    caption: 'Ejemplo genérico, no un hecho de producto. Primero localiza las palabras de alcance (“solo lectura”, “mejor siguiente paso”); después descarta los absolutos no soportados, lo recomendado convertido en obligatorio y los permisos que el escenario no concede.',
    steps: ['Lee el enunciado: palabras de alcance', 'A: absoluto no soportado', 'B: recomendado ≠ obligatorio', 'C: permiso no concedido', 'D: mejor siguiente paso'],
    stepMs: 2600,
    render: ({ step }) => <ExamStrategy step={step} />,
  },
  'deep-exam-readiness': {
    kind: 'animation',
    title: 'OneAgent solo abre conexiones salientes por 443',
    caption: 'La comunicación va siempre de dentro hacia fuera por HTTPS 443, directa o a través de un proxy/PAC o ActiveGate si el host no tiene internet directo. Abrir puertos inbound no es un requisito. En Kubernetes, cada Pod es una Process Group Instance que corre en un Node (Host).',
    steps: ['Saliente por HTTPS 443', 'Host aislado: proxy, PAC o ActiveGate', 'Puertos inbound: no se requieren', 'Kubernetes: Pod = PGI en un Node'],
    stepMs: 3000,
    render: ({ step }) => <ExamReadiness step={step} />,
  },
}
