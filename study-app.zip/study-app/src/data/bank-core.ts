import type { Difficulty, Question, QuestionBucket, QuestionStimulus, SourceRef } from './types'

type SourceEntry = { moduleId: string; chapterId: string; title: string; url: string; variant?: Question['classicOrLatest'] }

export const evidenceSources = {
  platform: { moduleId: 'platform', chapterId: 'deep-grail-records', title: 'Grail data model', url: 'https://docs.dynatrace.com/docs/platform/grail/organize-data' },
  permissions: { moduleId: 'platform', chapterId: 'deep-grail-records', title: 'Permissions in Grail', url: 'https://docs.dynatrace.com/docs/platform/grail/organize-data/assign-permissions-in-grail' },
  problems: { moduleId: 'platform', chapterId: 'deep-problems-platform', title: 'Problems app', url: 'https://docs.dynatrace.com/docs/dynatrace-intelligence/problems-app' },
  sharing: { moduleId: 'platform', chapterId: 'deep-documents-permissions', title: 'Share documents', url: 'https://docs.dynatrace.com/docs/discover-dynatrace/get-started/dynatrace-ui/share' },
  platformsearch: { moduleId: 'platform', chapterId: 'deep-hub-lifecycle', title: 'Platform search', url: 'https://docs.dynatrace.com/docs/discover-dynatrace/get-started/dynatrace-ui/search' },
  hub: { moduleId: 'platform', chapterId: 'deep-hub-lifecycle', title: 'Dynatrace Hub', url: 'https://docs.dynatrace.com/docs/manage/hub' },
  grailpartition: { moduleId: 'platform', chapterId: 'deep-grail-records', title: 'Partition data in Grail', url: 'https://docs.dynatrace.com/docs/platform/grail/organize-data/partition-data' },
  modes: { moduleId: 'observability', chapterId: 'deep-oneagent-modes', title: 'OneAgent monitoring modes', url: 'https://docs.dynatrace.com/docs/platform/oneagent/monitoring-modes/monitoring-modes' },
  agent: { moduleId: 'observability', chapterId: 'deep-oneagent-architecture', title: 'How OneAgent works', url: 'https://docs.dynatrace.com/docs/platform/oneagent/how-one-agent-works' },
  agentcapabilities: { moduleId: 'observability', chapterId: 'deep-oneagent-capabilities', title: 'OneAgent monitoring capabilities', url: 'https://docs.dynatrace.com/docs/platform/oneagent/supported-monitoring-types' },
  agentcli: { moduleId: 'observability', chapterId: 'deep-oneagent-change-control', title: 'OneAgent CLI configuration', url: 'https://docs.dynatrace.com/docs/ingest-from/dynatrace-oneagent/oneagent-configuration-via-command-line-interface' },
  kubernetes: { moduleId: 'observability', chapterId: 'deep-infrastructure-connectors', title: 'Kubernetes app', url: 'https://docs.dynatrace.com/docs/observe/infrastructure-observability/kubernetes-app' },
  kubemetrics: { moduleId: 'observability', chapterId: 'deep-infrastructure-connectors', title: 'Monitor Kubernetes metrics', url: 'https://docs.dynatrace.com/docs/observe/infrastructure-observability/container-platform-monitoring/kubernetes-monitoring/monitor-metrics-kubernetes' },
  kubeevents: { moduleId: 'observability', chapterId: 'deep-infrastructure-connectors', title: 'Monitor Kubernetes events', url: 'https://docs.dynatrace.com/docs/observe/infrastructure-observability/container-platform-monitoring/kubernetes-monitoring/monitor-events-kubernetes' },
  dashboards: { moduleId: 'notebooks', chapterId: 'deep-dashboard-model', title: 'Dashboards', url: 'https://docs.dynatrace.com/docs/analyze-explore-automate/dashboards-and-notebooks/dashboards-new' },
  notebooks: { moduleId: 'notebooks', chapterId: 'deep-notebook-sections', title: 'Notebooks', url: 'https://docs.dynatrace.com/docs/analyze-explore-automate/dashboards-and-notebooks/notebooks' },
  drilldowns: { moduleId: 'notebooks', chapterId: 'deep-dashboard-model', title: 'Drilldowns and navigation', url: 'https://docs.dynatrace.com/docs/analyze-explore-automate/dashboards-and-notebooks/drilldowns-and-navigation' },
  dashboardstructure: { moduleId: 'notebooks', chapterId: 'deep-dashboard-model', title: 'Dashboard document structure', url: 'https://docs.dynatrace.com/docs/analyze-explore-automate/dashboards-and-notebooks/document-api/document-structure-dashboards' },
  annotations: { moduleId: 'notebooks', chapterId: 'deep-dashboard-model', title: 'Add annotations to dashboards', url: 'https://docs.dynatrace.com/docs/analyze-explore-automate/dashboards-and-notebooks/dashboards-new/components/dashboard-component-annotation' },
  rum: { moduleId: 'business-dem', chapterId: 'deep-rum-session-semantics', title: 'RUM data model', url: 'https://docs.dynatrace.com/docs/observe/digital-experience/new-rum-experience/concepts/data-model' },
  rumsessions: { moduleId: 'business-dem', chapterId: 'deep-rum-session-semantics', title: 'User sessions in web frontends', url: 'https://docs.dynatrace.com/docs/observe/digital-experience/new-rum-experience/web-frontends/concepts/user-sessions-web' },
  synthetic: { moduleId: 'business-dem', chapterId: 'deep-synthetic-semantics', title: 'Browser clickpath steps', url: 'https://docs.dynatrace.com/docs/observe/digital-experience/synthetic/synthetic-app/create-configure-browser-monitors/browser-clickpath-steps' },
  rumclassic: { moduleId: 'business-dem', chapterId: 'deep-rum-session-semantics', title: 'User actions in RUM Classic', url: 'https://docs.dynatrace.com/docs/observe/digital-experience/rum-classic/rum-concepts/user-actions', variant: 'classic' },
  bizevents: { moduleId: 'business-dem', chapterId: 'deep-business-event-model', title: 'Business event enrichment', url: 'https://docs.dynatrace.com/docs/observe/business-observability/bo-events-enrichment' },
  businessbasic: { moduleId: 'business-dem', chapterId: 'deep-business-event-model', title: 'Business Observability concepts', url: 'https://docs.dynatrace.com/docs/observe/business-observability/bo-basic-concepts' },
  businesscapture: { moduleId: 'business-dem', chapterId: 'deep-business-capture', title: 'Business event capture', url: 'https://docs.dynatrace.com/docs/observe/business-observability/bo-events-capturing' },
  businessflow: { moduleId: 'business-dem', chapterId: 'deep-business-event-model', title: 'Set up Business Flow', url: 'https://docs.dynatrace.com/docs/observe/business-observability/business-flow/set-up-business-flow' },
  syntheticapp: { moduleId: 'business-dem', chapterId: 'deep-synthetic-semantics', title: 'Synthetic Monitoring', url: 'https://docs.dynatrace.com/docs/observe/digital-experience/synthetic' },
  retention: { moduleId: 'data-analysis', chapterId: 'deep-retention-reference', title: 'Organize data in Grail', url: 'https://docs.dynatrace.com/docs/platform/grail/organize-data' },
  metricanalysis: { moduleId: 'data-analysis', chapterId: 'deep-metric-design', title: 'DQL metric commands', url: 'https://docs.dynatrace.com/docs/platform/grail/dynatrace-query-language/commands/metric-commands' },
  metricexploration: { moduleId: 'data-analysis', chapterId: 'deep-reporting-analysis', title: 'DQL metric commands', url: 'https://docs.dynatrace.com/docs/platform/grail/dynatrace-query-language/commands/metric-commands' },
  metricsfaq: { moduleId: 'data-analysis', chapterId: 'deep-metric-design', title: 'Metrics FAQ', url: 'https://docs.dynatrace.com/docs/analyze-explore-automate/metrics/faq' },
  metricslimits: { moduleId: 'data-analysis', chapterId: 'deep-metric-design', title: 'Metrics limits', url: 'https://docs.dynatrace.com/docs/analyze-explore-automate/metrics/limits' },
  metriccost: { moduleId: 'data-analysis', chapterId: 'deep-metric-design', title: 'Optimize metrics cost', url: 'https://docs.dynatrace.com/docs/analyze-explore-automate/metrics/best-practices-metrics' },
  dql: { moduleId: 'dql', chapterId: 'deep-dql-command-contract', title: 'DQL language reference', url: 'https://docs.dynatrace.com/docs/platform/grail/dynatrace-query-language/dql-reference' },
  dqlcommands: { moduleId: 'dql', chapterId: 'deep-dql-pipeline', title: 'DQL commands', url: 'https://docs.dynatrace.com/docs/platform/grail/dynatrace-query-language/commands' },
  dqlfilter: { moduleId: 'dql', chapterId: 'deep-dql-command-contract', title: 'DQL filter and search', url: 'https://docs.dynatrace.com/docs/platform/grail/dynatrace-query-language/commands/filtering-commands' },
  dqlbest: { moduleId: 'dql', chapterId: 'deep-dql-performance', title: 'DQL best practices', url: 'https://docs.dynatrace.com/docs/platform/grail/dynatrace-query-language/dql-best-practices' },
  dqlmetrics: { moduleId: 'dql', chapterId: 'deep-dql-aggregation', title: 'DQL metric commands', url: 'https://docs.dynatrace.com/docs/platform/grail/dynatrace-query-language/commands/metric-commands' },
  smartscapecommands: { moduleId: 'dql', chapterId: 'deep-dql-command-contract', title: 'DQL Smartscape commands', url: 'https://docs.dynatrace.com/docs/platform/grail/dynatrace-query-language/commands/smartscape-commands' },
  dqltypes: { moduleId: 'dql', chapterId: 'deep-dql-types-records', title: 'DQL data types', url: 'https://docs.dynatrace.com/docs/platform/grail/dynatrace-query-language/data-types' },
  dqljoins: { moduleId: 'dql', chapterId: 'deep-dql-command-contract', title: 'DQL correlation and join commands', url: 'https://docs.dynatrace.com/docs/platform/grail/dynatrace-query-language/commands/correlation-and-join-commands' },
  security: { moduleId: 'security', chapterId: 'deep-third-party-code-level', title: 'Runtime Vulnerability Analytics', url: 'https://docs.dynatrace.com/docs/secure/application-security/vulnerability-analytics' },
  seceval: { moduleId: 'security', chapterId: 'deep-security-prioritization', title: 'Vulnerability evaluation', url: 'https://docs.dynatrace.com/docs/secure/application-security/vulnerability-analytics/vulnerability-evaluation' },
  vulnapp: { moduleId: 'security', chapterId: 'deep-security-prioritization', title: 'Vulnerabilities app', url: 'https://docs.dynatrace.com/docs/secure/vulnerabilities' },
  vulnconcepts: { moduleId: 'security', chapterId: 'deep-security-prioritization', title: 'Vulnerabilities concepts', url: 'https://docs.dynatrace.com/docs/secure/vulnerabilities/concepts' },
  thirdparty: { moduleId: 'security', chapterId: 'deep-third-party-code-level', title: 'Third-party vulnerabilities', url: 'https://docs.dynatrace.com/docs/secure/application-security/vulnerability-analytics/third-party-vulnerabilities' },
  codelevel: { moduleId: 'security', chapterId: 'deep-third-party-code-level', title: 'Code-level vulnerabilities', url: 'https://docs.dynatrace.com/docs/secure/application-security/vulnerability-analytics/code-level-vulnerabilities' },
  investigationconcepts: { moduleId: 'security', chapterId: 'deep-security-capabilities', title: 'Investigations concepts', url: 'https://docs.dynatrace.com/docs/secure/investigations/concepts' },
  investigationtime: { moduleId: 'security', chapterId: 'deep-security-capabilities', title: 'Manage investigation time', url: 'https://docs.dynatrace.com/docs/secure/investigations/define-timeframes' },
  codelevelrules: { moduleId: 'security', chapterId: 'deep-third-party-code-level', title: 'Code-level monitoring rules', url: 'https://docs.dynatrace.com/docs/secure/application-security/vulnerability-analytics/code-level-vulnerabilities/define-monitoring-rules-clv' },
  investigations: { moduleId: 'security', chapterId: 'deep-security-capabilities', title: 'Investigations app', url: 'https://docs.dynatrace.com/docs/secure/investigations' },
  automation: { moduleId: 'automation', chapterId: 'deep-workflow-anatomy', title: 'AutomationEngine', url: 'https://docs.dynatrace.com/docs/platform/automationengine' },
  workflowsecurity: { moduleId: 'automation', chapterId: 'deep-actor-permissions', title: 'Manage workflow permissions', url: 'https://docs.dynatrace.com/docs/analyze-explore-automate/workflows/security' },
  workflowtriggers: { moduleId: 'automation', chapterId: 'deep-workflow-anatomy', title: 'Workflow triggers', url: 'https://docs.dynatrace.com/docs/analyze-explore-automate/workflows/build/trigger' },
  workflowrun: { moduleId: 'automation', chapterId: 'deep-workflow-limits', title: 'Monitor workflow executions', url: 'https://docs.dynatrace.com/docs/analyze-explore-automate/workflows/running' },
  workflowevents: { moduleId: 'automation', chapterId: 'deep-workflow-anatomy', title: 'Event triggers for workflows', url: 'https://docs.dynatrace.com/docs/analyze-explore-automate/workflows/build/trigger/event-trigger' },
  workflowdql: { moduleId: 'automation', chapterId: 'deep-workflow-anatomy', title: 'Execute DQL Query workflow action', url: 'https://docs.dynatrace.com/docs/analyze-explore-automate/workflows/default-workflow-actions/dql-query-workflow-action' },
  workflowjs: { moduleId: 'automation', chapterId: 'deep-workflow-anatomy', title: 'Run JavaScript workflow action', url: 'https://docs.dynatrace.com/docs/analyze-explore-automate/workflows/default-workflow-actions/run-javascript-workflow-action' },
  workflowsimple: { moduleId: 'automation', chapterId: 'deep-workflow-anatomy', title: 'Create a simple workflow', url: 'https://docs.dynatrace.com/docs/analyze-explore-automate/workflows/build/simple-workflow' },
  workflowchild: { moduleId: 'automation', chapterId: 'deep-workflow-anatomy', title: 'Run workflow action', url: 'https://docs.dynatrace.com/docs/analyze-explore-automate/workflows/default-workflow-actions/run-workflow-action' },
  openpipeline: { moduleId: 'ingestion', chapterId: 'deep-openpipeline', title: 'Processing in OpenPipeline', url: 'https://docs.dynatrace.com/docs/platform/openpipeline/concepts/processing' },
  openflow: { moduleId: 'ingestion', chapterId: 'deep-ingestion-lifecycle', title: 'Data flow in OpenPipeline', url: 'https://docs.dynatrace.com/docs/platform/openpipeline/concepts/data-flow' },
  openstage: { moduleId: 'ingestion', chapterId: 'deep-openpipeline', title: 'Processing stage in OpenPipeline', url: 'https://docs.dynatrace.com/docs/platform/openpipeline/concepts/processing-stage' },
  logprocessing: { moduleId: 'ingestion', chapterId: 'deep-openpipeline', title: 'Log processing with OpenPipeline', url: 'https://docs.dynatrace.com/docs/analyze-explore-automate/logs/lma-log-processing/lma-openpipeline' },
  logingest: { moduleId: 'ingestion', chapterId: 'deep-log-ingestion', title: 'Log ingestion', url: 'https://docs.dynatrace.com/docs/analyze-explore-automate/logs/lma-log-ingestion' },
  logapi: { moduleId: 'ingestion', chapterId: 'deep-log-ingestion', title: 'Log ingestion API', url: 'https://docs.dynatrace.com/docs/analyze-explore-automate/logs/lma-log-ingestion/lma-log-ingestion-via-api' },
  logoa: { moduleId: 'ingestion', chapterId: 'deep-log-ingestion', title: 'Log ingestion via OneAgent', url: 'https://docs.dynatrace.com/docs/analyze-explore-automate/logs/lma-log-ingestion/lma-log-ingestion-via-oa' },
  otel: { moduleId: 'ingestion', chapterId: 'deep-ingestion-lifecycle', title: 'OpenTelemetry and Dynatrace', url: 'https://docs.dynatrace.com/docs/ingest-from/opentelemetry' },
  pipelinegroups: { moduleId: 'ingestion', chapterId: 'deep-openpipeline', title: 'OpenPipeline pipeline groups', url: 'https://docs.dynatrace.com/docs/platform/openpipeline/concepts/pipeline-groups' },
  pipelineaccess: { moduleId: 'ingestion', chapterId: 'deep-openpipeline', title: 'Owner-based access control in OpenPipeline', url: 'https://docs.dynatrace.com/docs/platform/openpipeline/concepts/access-control' },
  otlpendpoints: { moduleId: 'ingestion', chapterId: 'deep-ingestion-lifecycle', title: 'Dynatrace OTLP API endpoints', url: 'https://docs.dynatrace.com/docs/ingest-from/opentelemetry/otlp-api' },
  logautodiscovery: { moduleId: 'ingestion', chapterId: 'deep-log-ingestion', title: 'Log content autodiscovery', url: 'https://docs.dynatrace.com/docs/analyze-explore-automate/logs/lma-log-ingestion/lma-log-ingestion-via-oa/lma-autodiscovery' },
  logrules: { moduleId: 'ingestion', chapterId: 'deep-log-ingestion', title: 'Log ingest rules', url: 'https://docs.dynatrace.com/docs/analyze-explore-automate/logs/lma-log-ingestion/lma-log-ingestion-via-oa/lma-log-storage-configuration' },
  pipelineforward: { moduleId: 'ingestion', chapterId: 'deep-ingestion-lifecycle', title: 'Forwarding data via OpenPipeline', url: 'https://docs.dynatrace.com/docs/platform/openpipeline/concepts/forwarding' },
  logs: { moduleId: 'other', chapterId: 'deep-log-investigation', title: 'Log Analytics', url: 'https://docs.dynatrace.com/docs/analyze-explore-automate/logs' },
  smartscape: { moduleId: 'other', chapterId: 'deep-smartscape-graph', title: 'Smartscape concepts', url: 'https://docs.dynatrace.com/docs/analyze-explore-automate/smartscape/smartscape-concepts' },
  problemgraph: { moduleId: 'other', chapterId: 'deep-smartscape-graph', title: 'Problem graph', url: 'https://docs.dynatrace.com/docs/analyze-explore-automate/smartscape/smartscape-views/problem-graph' },
  entityquery: { moduleId: 'other', chapterId: 'deep-smartscape-graph', title: 'Query monitored entities in Grail (Classic)', url: 'https://docs.dynatrace.com/docs/platform/grail/querying-monitored-entities', variant: 'classic' },
  smartscapeongrail: { moduleId: 'other', chapterId: 'deep-smartscape-graph', title: 'Smartscape on Grail', url: 'https://docs.dynatrace.com/docs/platform/grail/smartscape-on-grail' },
  logsapp: { moduleId: 'other', chapterId: 'deep-log-investigation', title: 'Logs app', url: 'https://docs.dynatrace.com/docs/analyze-explore-automate/logs/lma-logs-app' },
  logfacets: { moduleId: 'other', chapterId: 'deep-log-investigation', title: 'Filter logs with facets', url: 'https://docs.dynatrace.com/docs/analyze-explore-automate/logs/lma-logs-app/facets' },
  logfilters: { moduleId: 'other', chapterId: 'deep-log-investigation', title: 'Query and filter logs', url: 'https://docs.dynatrace.com/docs/analyze-explore-automate/logs/lma-logs-app/query-and-filter' },
  topologyview: { moduleId: 'other', chapterId: 'deep-smartscape-graph', title: 'View topology', url: 'https://docs.dynatrace.com/docs/analyze-explore-automate/smartscape/smartscape-in-context-views/smartscape-view-topology' },
  hubextensions: { moduleId: 'other', chapterId: 'deep-hub-extensions', title: 'Extensions in Hub', url: 'https://www.dynatrace.com/hub/' },
  welcome101: { moduleId: 'welcome', chapterId: 'deep-dynatrace-101', title: 'What is Dynatrace', url: 'https://docs.dynatrace.com/docs/discover-dynatrace/what-is-dynatrace' },
  welcomemelt: { moduleId: 'welcome', chapterId: 'deep-dynatrace-101', title: 'Grail data lakehouse', url: 'https://docs.dynatrace.com/docs/platform/grail' },
  welcomedavis: { moduleId: 'welcome', chapterId: 'deep-problem-davis', title: 'Davis AI engine', url: 'https://docs.dynatrace.com/docs/dynatrace-intelligence' },
  welcomesmartscape: { moduleId: 'welcome', chapterId: 'deep-dynatrace-101', title: 'Smartscape topology', url: 'https://docs.dynatrace.com/docs/shortlink/smartscape' },
  welcomedps: { moduleId: 'welcome', chapterId: 'deep-dynatrace-101', title: 'Platform Subscription', url: 'https://docs.dynatrace.com/docs/manage/subscriptions-and-licensing/dynatrace-platform-subscription' },
  instructionsnetworking: { moduleId: 'instructions', chapterId: 'deep-exam-readiness', title: 'How OneAgent works', url: 'https://docs.dynatrace.com/docs/platform/oneagent/how-one-agent-works' },
  instructionsproctoru: { moduleId: 'instructions', chapterId: 'deep-exam-readiness', title: 'ProctorU Equipment Requirements', url: 'https://support.proctoru.com/hc/en-us/articles/24692181239309-Equipment-Requirements' },
  instructionsstrategy: { moduleId: 'instructions', chapterId: 'deep-question-reading', title: 'Associate Learning Plan', url: 'https://university.dynatrace.com/learn/public/learning_plan/view/47/dynatrace-associate-certification-learning-plan' },
  instructionsk8s: { moduleId: 'instructions', chapterId: 'deep-exam-readiness', title: 'Kubernetes monitoring', url: 'https://docs.dynatrace.com/docs/observe/infrastructure-observability/container-platform-monitoring/kubernetes-monitoring' },
} as const satisfies Record<string, SourceEntry>

export type SourceKey = keyof typeof evidenceSources
export type RawQuestion = {
  id: string
  source: SourceKey
  objective: string
  bucket: QuestionBucket
  difficulty: Difficulty
  prompt: string
  choices: string[]
  correct: number[]
  explanation: string
  stimulus?: QuestionStimulus
}

export type Draft = RawQuestion

export const buildQuestion = (draft: RawQuestion): Question => {
  const source = evidenceSources[draft.source]
  const sourceRef: SourceRef = { title: source.title, url: source.url, kind: 'official-docs' }
  return {
    id: draft.id,
    form: draft.id[0] as Question['form'],
    moduleId: source.moduleId,
    chapterId: source.chapterId,
    objectiveId: `${source.moduleId}:${draft.objective}`,
    bucket: draft.bucket,
    difficulty: draft.difficulty,
    cognitiveLevel: draft.bucket === 'knowledge' ? 'understand' : draft.bucket === 'scenario' || draft.bucket === 'practical' ? 'apply' : 'analyze',
    promptEs: draft.prompt,
    stimulus: draft.stimulus,
    type: draft.correct.length > 1 ? 'multiple' : 'single',
    options: draft.choices.map((text, index) => ({ id: String.fromCharCode(65 + index), text })),
    correctOptionIds: draft.correct.map((index) => String.fromCharCode(65 + index)),
    explanationEs: draft.explanation,
    sourceRefs: [sourceRef],
    classicOrLatest: 'variant' in source ? source.variant : 'latest',
    versionNote: draft.source === 'entityquery'
      ? 'Referencia Classic: Dynatrace recomienda migrar las consultas de entidades al modelo Smartscape on Grail.'
      : draft.id === 'A-028' || draft.id === 'B-028'
      ? 'La captura de user interactions figura como Early Access en la documentación Latest; requiere habilitarla.'
      : draft.source === 'modes' && /A-00[7]|A-01[2-5]/.test(draft.id)
        ? 'Discovery requiere Dynatrace Platform Subscription y OneAgent 1.281 o posterior.'
        : 'Consulta la fuente enlazada para confirmar la variante vigente.',
    lastVerified: draft.id.startsWith('F') ? '2026-09-29' : draft.id.startsWith('W') || draft.id.startsWith('I') || draft.id.startsWith('G') ? '2026-09-30' : '2026-09-28',
  }
}
