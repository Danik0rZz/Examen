/**
 * Trazabilidad pregunta → guía de estudio.
 * `section`: id del apartado de la lección del mismo módulo, o 'precision-facts' para la ficha de hechos de precisión.
 * `evidence`: fragmento literal (≥ 25 caracteres) de ese apartado que contiene el dato que la pregunta evalúa.
 */
export type CoverageEntry = { section: string; evidence: string }
export type CoverageMap = Record<string, CoverageEntry>
