import type { CoverageMap } from './types'

export const instructionsCoverage: CoverageMap = {
  // Conectividad de OneAgent y ActiveGate
  'I-001': { section: 'deep-exam-readiness', evidence: 'Sin ningún ActiveGate intermedio, OneAgent conecta directamente con el clúster SaaS por el puerto 443.' },
  'R-INS-01': { section: 'deep-exam-readiness', evidence: 'Con un Environment ActiveGate, los OneAgents se conectan a él por el puerto 9999' },
  'R-INS-02': { section: 'deep-exam-readiness', evidence: 'es posible la conexión simultánea a través de varios ActiveGates. La regla de preferencia es clara: OneAgent se conecta a un Environment ActiveGate si existe uno, y solo conecta directamente con el clúster SaaS si no es posible ninguna conexión con un Environment ActiveGate.' },
  'R-INS-03': { section: 'deep-exam-readiness', evidence: 'Environment ActiveGate → clúster SaaS: el ActiveGate abre la conexión de salida hacia el clúster, que recibe conexiones en el puerto 443.' },
  'I-005': { section: 'deep-exam-readiness', evidence: 'pero una conexión TCP a la IP del endpoint por el puerto 443 se establece, la ruta y el puerto funcionan: el problema está en la resolución DNS del FQDN.' },
  'I-026': { section: 'deep-exam-readiness', evidence: 'Entre las capacidades de routing del ActiveGate están el enrutado del tráfico de OneAgent hacia Dynatrace, el buffering y la compresión' },
  'I-048': { section: 'sup-proxy-config', evidence: 'si un Environment ActiveGate de la DMZ solo puede salir a internet por un proxy corporativo, el proxy se configura en el `custom.properties` del ActiveGate: los OneAgents internos siguen conectándose al ActiveGate por el puerto 9999 y no necesitan `--set-proxy`.' },
  'R-INS-38': { section: 'deep-exam-readiness', evidence: 'routing y monitorización (enrutar el tráfico de OneAgent, monitorizar entornos cloud o tecnologías remotas con extensions), ejecutar monitores synthetic desde una private location y el módulo zRemote para z/OS. Los módulos no se deben mezclar entre propósitos' },

  // Proxies
  'I-003': { section: 'sup-proxy-config', evidence: 'si el proxy exige autenticación, `username:password@host:puerto`, con el usuario y la contraseña URL-encoded' },
  'R-INS-08': { section: 'sup-proxy-config', evidence: 'oneagentctl está en `<INSTALL_PATH>/agent/tools`, por defecto `/opt/dynatrace/oneagent/agent/tools` en Linux, y requiere privilegios de root' },
  'R-INS-09': { section: 'sup-proxy-config', evidence: 'Después de usar parámetros set hay que reiniciar el servicio de OneAgent para aplicar los cambios, por ejemplo añadiendo `--restart-service`.' },
  'R-INS-37': { section: 'sup-proxy-config', evidence: 'Un HTTP 407 (Proxy Authentication Required) lo devuelve el propio proxy cuando la petición no trae credenciales válidas' },
  'R-INS-43': { section: 'sup-proxy-config', evidence: 'una contraseña `P@ss:2026` debe escribirse `P%40ss%3A2026`: sin codificar, la "@" y los ":" de la contraseña se confunden con los separadores.' },
  'R-INS-44': { section: 'sup-proxy-config', evidence: 'En un ActiveGate, el proxy se configura en `custom.properties`, sección `[http.client]`, con `proxy-server`, `proxy-port`, `proxy-user` y `proxy-password`; si se omite `proxy-port`, el valor por defecto es 8080. Hay que reiniciar el servicio principal del ActiveGate y, al hacerlo, la contraseña en claro se cifra y se guarda en la propiedad `proxy-password-encr`.' },
  'R-INS-58': { section: 'sup-proxy-config', evidence: 'Para que OneAgent deje de usar el proxy se ejecuta `--set-proxy=` con el valor vacío.' },

  // Certificados
  'I-006': { section: 'sup-tls-trust', evidence: 'si el entorno usa un proxy con certificado propio (por ejemplo, un proxy con inspección TLS firmado por una CA interna), se guardan como `custom-proxy.pem`' },
  'R-INS-10': { section: 'sup-tls-trust', evidence: 'OneAgent solo lee `custom-proxy.pem` si se ha configurado explícitamente para usar un proxy. Con un proxy transparente y sin `--set-proxy`, el fichero se ignora' },
  'R-INS-11': { section: 'sup-tls-trust', evidence: 'Si un Environment ActiveGate usa un certificado propio, sus CA se guardan como `custom.pem`' },
  'R-INS-12': { section: 'sup-tls-trust', evidence: 'se configura `trustedstore` (con `trustedstore-password` y `trustedstore-type`) en la sección `[collector]` de `custom.properties`, se coloca el keystore en el directorio SSL del ActiveGate (`/var/lib/dynatrace/gateway/ssl` en Linux) y se reinicia el servicio principal.' },
  'R-INS-48': { section: 'sup-tls-trust', evidence: 'Si un Environment ActiveGate usa un certificado propio, sus CA se guardan como `custom.pem`; si el entorno usa un proxy con certificado propio (por ejemplo, un proxy con inspección TLS firmado por una CA interna), se guardan como `custom-proxy.pem`. Si existen ambos casos, hay que proporcionar los dos ficheros.' },
  'R-INS-49': { section: 'sup-tls-trust', evidence: 'En Linux, el directorio customkeys de OneAgent es `/var/lib/dynatrace/oneagent/agent/customkeys`' },

  // Network zones y ActiveGate groups
  'R-INS-04': { section: 'sup-network-zones', evidence: 'Los nombres no distinguen mayúsculas y minúsculas (Dynatrace los guarda en minúsculas), admiten caracteres alfanuméricos, guiones y guiones bajos, usan el punto como separador (sin empezar por punto) y tienen un máximo de 256 caracteres. El patrón recomendado es `provider.region.availability-zone.datacenter.tier`.' },
  'R-INS-05': { section: 'sup-network-zones', evidence: '"None" mantiene el aislamiento de zona, sin salto a otras zonas, y si los ActiveGates de la zona y de la alternativa fallan, los datos se descartan.' },
  'R-INS-06': { section: 'sup-network-zones', evidence: 'grupo 1, ActiveGates de la misma network zone; grupo 2, de la zona alternativa; grupo 3, de la zona default; grupo 4, todos los demás.' },
  'R-INS-07': { section: 'sup-network-zones', evidence: 'Las ActiveGate groups son otra cosa: permiten acciones en bloque sobre ActiveGates, como gestionar las extensions que se ejecutan en ellos' },
  'I-059': { section: 'sup-network-zones', evidence: 'Reparto y failover de OneAgent entre varios ActiveGates de un centro de datos: misma network zone para ActiveGates y OneAgents.' },
  'I-063': { section: 'sup-network-zones', evidence: 'Un único ActiveGate central para todas las regiones añade latencia y es un punto único de fallo.' },
  'I-052': { section: 'sup-network-zones', evidence: 'Organización multirregión: un único entorno, ActiveGates en cada ubicación y network zones por ubicación.' },
  'R-INS-45': { section: 'sup-network-zones', evidence: 'Un OneAgent se asigna a una zona con `oneagentctl --set-network-zone=<your.network.zone>` (y reinicio del servicio).' },
  'R-INS-46': { section: 'sup-network-zones', evidence: 'Los OneAgents sin network zone configurada funcionan como si las zonas no existieran y se conectan a cualquier Environment ActiveGate que responda, en orden aleatorio.' },
  'R-INS-47': { section: 'sup-network-zones', evidence: 'comprueban periódicamente en segundo plano si vuelven a estar disponibles ActiveGates con un índice menor, para regresar a ellos.' },
  'R-INS-57': { section: 'sup-network-zones', evidence: 'se asigna con `--set-group` al instalar o, después, con la propiedad `group` de la sección `[collector]` de `custom.properties`.' },

  // Procesos y services
  'I-008': { section: 'sup-processes-services', evidence: 'los procesos de los contenedores de un Pod aparecen como PGI en el host que representa al Node, y el Pod no se convierte en un host propio.' },
  'R-INS-13': { section: 'sup-processes-services', evidence: 'La monitorización profunda (deep monitoring) de los process groups detectados empieza después de reiniciar todos los procesos que ya se estaban ejecutando durante la instalación de OneAgent.' },
  'R-INS-14': { section: 'sup-processes-services', evidence: 'Un process group es un clúster lógico de procesos con la misma función en varios hosts, y el mismo service en process groups distintos cuenta como services separados.' },
  'R-INS-15': { section: 'sup-processes-services', evidence: 'Para Tomcat, Dynatrace usa `CATALINA_HOME` y `CATALINA_BASE` para distinguir clústeres Tomcat distintos.' },

  // Kubernetes y Operator
  'I-007': { section: 'sup-k8s-operator', evidence: 'La organización lógica de Kubernetes es Cluster → Namespace → Workload → Pod → Container.' },
  'I-009': { section: 'sup-k8s-operator', evidence: 'Dynatrace Operator gestiona el rollout automatizado, la configuración y el ciclo de vida de los componentes de Dynatrace a partir de custom resources (DynaKube y EdgeConnect).' },
  'I-027': { section: 'sup-k8s-operator', evidence: 'muta los Pods al crearse, añadiendo un init container que configura los code modules, sin reconstruir las imágenes' },
  'I-031': { section: 'sup-k8s-operator', evidence: 'El Namespace es una partición lógica de todo el clúster para aislar recursos y equipos' },
  'I-038': { section: 'sup-k8s-operator', evidence: 'En un despliegue cloudNativeFullStack, OneAgent se ejecuta como DaemonSet y recoge las métricas de los Nodes' },
  'R-INS-16': { section: 'sup-k8s-operator', evidence: 'muta los Pods al crearse, añadiendo un init container que configura los code modules, sin reconstruir las imágenes; y el CSI driver, desplegado como DaemonSet con una réplica por Node, proporciona los code modules' },
  'R-INS-17': { section: 'sup-k8s-operator', evidence: 'descargándolos una vez por Node en lugar de una vez por Pod, lo que reduce almacenamiento y carga.' },
  'R-INS-18': { section: 'sup-k8s-operator', evidence: 'el ActiveGate enruta los datos de observabilidad hacia el clúster de Dynatrace y monitoriza la API de Kubernetes' },
  'R-INS-19': { section: 'sup-k8s-operator', evidence: 'kubectl -n dynatrace create secret generic dynakube --from-literal="apiToken=<OPERATOR_TOKEN>" --from-literal="dataIngestToken=<DATA_INGEST_TOKEN>"' },
  'R-INS-20': { section: 'sup-k8s-operator', evidence: 'los Pods que ya estaban en ejecución antes del despliegue no pasaron por el webhook y hay que reiniciar esos workloads (por ejemplo, con un rollout restart).' },
  'R-INS-52': { section: 'sup-k8s-operator', evidence: 'Para excluir un Pod concreto se usa la anotación `dynatrace.com/inject: "false"`' },
  'R-INS-53': { section: 'sup-k8s-operator', evidence: 'Para limitar la inyección a ciertos namespaces se usa `namespaceSelector` en el DynaKube, con `matchLabels` para incluir namespaces etiquetados' },

  // Salud de Kubernetes
  'I-033': { section: 'sup-k8s-health', evidence: 'Si un contenedor alcanza su CPU limit, no se termina: se limita (throttling) y responde más lento, lo que refleja "Detect high CPU throttling".' },
  'I-053': { section: 'sup-k8s-health', evidence: 'en la pestaña Events verás `OOMKilled` seguido de `Created` y `Started`, porque el contenedor superó su memory limit, `kubelet` lo terminó y Kubernetes lo recreó automáticamente.' },
  'I-056': { section: 'sup-k8s-health', evidence: 'Si falla el Readiness probe, el Pod deja de estar listo y se retira de los endpoints del Service, sin reiniciarse.' },
  'I-064': { section: 'sup-k8s-health', evidence: '`CrashLoopBackOff` significa que el contenedor arranca, falla y Kubernetes lo reinicia con esperas crecientes; la causa está en los logs del contenedor y en los eventos del Pod.' },
  'R-INS-40': { section: 'sup-k8s-health', evidence: 'el scheduler no encuentra un Node con memoria asignable suficiente para los requests del Pod.' },
  'R-INS-56': { section: 'sup-k8s-health', evidence: 'health alerts, para situaciones críticas que desencadenan una investigación de Problems, y warning signals, que informan de un posible problema en situaciones no críticas.' },

  // HTTP y spans
  'I-032': { section: 'sup-http-web', evidence: 'La failure detection por defecto interpreta los códigos HTTP 500-599 como errores en el lado servidor' },
  'I-034': { section: 'sup-http-web', evidence: 'Si todas las sesiones de RUM muestran la misma IP y ubicación, identifica la cabecera en la que el balanceador pasa la IP original y configúrala ahí.' },
  'R-INS-54': { section: 'sup-http-web', evidence: 'el modelo de spans define `http.request.method` (GET, POST…) y `http.response.status_code` (por ejemplo, 200 o 503).' },

  // Traces
  'R-INS-28': { section: 'sup-traces', evidence: 'el modelo de spans usa `trace.id` y `span.id`, mientras que el modelo de logs define `trace_id` y `span_id`.' },
  'R-INS-29': { section: 'sup-traces', evidence: '`trace.id` es un identificador de 16 bytes codificado en hexadecimal; `span.id` y `span.parent_id` son identificadores de 8 bytes en hexadecimal.' },
  'R-INS-30': { section: 'sup-traces', evidence: '`span.parent_id` contiene el `span.id` del span padre, y así se reconstruye el árbol de llamadas dentro del trace.' },
  'R-INS-31': { section: 'sup-traces', evidence: 'una llamada síncrona saliente es un span `client` en quien llama y la misma petición es un span `server` en quien la recibe' },
  'R-INS-32': { section: 'sup-traces', evidence: '`duration` es la diferencia entre `start_time` y `end_time` en nanosegundos' },
  'R-INS-39': { section: 'sup-traces', evidence: 'lo que permite ver qué llamada downstream consume el tiempo de una petición concreta. Las métricas muestran la tendencia agregada, pero no el desglose de una petición' },

  // Ingesta
  'R-INS-21': { section: 'sup-ingest-formats', evidence: 'el campo `timestamp` es el momento (UNIX epoch en nanosegundos) en que se originó el evento.' },
  'R-INS-22': { section: 'sup-ingest-formats', evidence: 'Si el registro no tiene una clave de timestamp admitida, se usa la hora actual.' },
  'R-INS-23': { section: 'sup-ingest-formats', evidence: 'Los timestamps más de 10 minutos en el futuro se sustituyen por la hora actual.' },
  'R-INS-24': { section: 'sup-ingest-formats', evidence: 'espera el timestamp en milisegundos UTC y acepta valores entre 1 hora en el pasado y 10 minutos en el futuro' },
  'R-INS-25': { section: 'sup-ingest-formats', evidence: 'la metric key de un contador recibe automáticamente el sufijo `.count` salvo que ya termine en `.count` (y un gauge cuya clave termina en `.count` recibe `.gauge`); las métricas en Grail no aplican los sufijos `.count` ni `.gauge`.' },
  'R-INS-26': { section: 'sup-ingest-formats', evidence: 'un gauge se envía con un único valor o pre-agregado como `gauge,min=…,max=…,sum=…,count=…`' },
  'R-INS-27': { section: 'sup-ingest-formats', evidence: 'El contenido se busca en este orden: `content`, `message`, `payload`, `body`, `log`. El nivel se detecta, sin distinguir mayúsculas, de `loglevel`, `status`, `severity`, `level` o `syslog.severity`' },
  'R-INS-36': { section: 'sup-ingest-formats', evidence: '`parse content, "JSON:payload"` crea un record `payload` y `fieldsFlatten payload` extrae los campos de ese record anidado a campos de primer nivel' },
  'R-INS-41': { section: 'sup-ingest-formats', evidence: 'Timestamp en el metric ingestion protocol: milisegundos UTC; en la Log ingestion API: Unix epoch en UTC, RFC3339 o RFC3164.' },
  'R-INS-50': { section: 'sup-ingest-formats', evidence: 'Si el formato no es compatible, se usa la hora actual y el valor original se mueve al atributo `unparsed_timestamp`.' },
  'R-INS-55': { section: 'sup-ingest-formats', evidence: '`status` es la importancia global derivada del nivel de log y solo admite INFO, WARN, ERROR y NONE.' },

  // OTLP
  'R-INS-33': { section: 'sup-otlp', evidence: 'El endpoint OTLP de Dynatrace no admite gRPC: las llamadas deben usar HTTP con codificación binaria de Protocol Buffers (`http/protobuf`)' },
  'R-INS-34': { section: 'sup-otlp', evidence: 'A través de un Environment ActiveGate es `https://{your-activegate-domain}:9999/e/{your-environment-id}/api/v2/otlp`' },
  'R-INS-35': { section: 'sup-otlp', evidence: 'Con un classic access token, los scopes son `openTelemetryTrace.ingest` (trazas), `metrics.ingest` (métricas) y `logs.ingest` (logs).' },
  'R-INS-51': { section: 'sup-otlp', evidence: 'Cada señal añade su sufijo: `/v1/traces`, `/v1/metrics` o `/v1/logs`.' },
}
