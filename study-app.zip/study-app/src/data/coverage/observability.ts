import type { CoverageMap } from './types'

export const observabilityCoverage: CoverageMap = {
  // ── Modos de monitorización ──
  'A-007': { section: 'monitoring-modes', evidence: 'está disponible solo con Dynatrace Platform Subscription (DPS) y que el consumo se realiza mediante Foundation & Discovery' },
  'A-012': { section: 'monitoring-modes', evidence: 'Host process details, Detailed disk analysis, Network analysis y Memory analysis son GA en Full-Stack e Infrastructure y no figuran en Discovery' },
  'A-013': { section: 'monitoring-modes', evidence: 'Log Management, Application Security y Live Debugger son opt-in en los tres modos' },
  'A-014': { section: 'monitoring-modes', evidence: 'En Full-Stack, el límite de custom metrics es 15 por cada 256 MiB de memoria del host, y Discovery no incluye custom metrics' },
  'FO-001': { section: 'monitoring-modes', evidence: 'Tracing and profiling solo figura en Full-Stack.' },
  'FO-002': { section: 'monitoring-modes', evidence: 'Host process details, Detailed disk analysis, Network analysis y Memory analysis son GA en Full-Stack e Infrastructure y no figuran en Discovery. Tracing and profiling solo figura en Full-Stack.' },
  'FO-005': { section: 'monitoring-modes', evidence: 'Log Management, Application Security y Live Debugger son opt-in en los tres modos' },
  'R-OBS-01': { section: 'monitoring-modes', evidence: 'En Infrastructure, OneAgent inyecta automáticamente en procesos para monitorizar backing services Java y runtime metrics de los lenguajes soportados (process injection opt-out, es decir, activa salvo que se desactive) y admite custom metrics con un límite de 100 por host' },
  'R-OBS-24': { section: 'monitoring-modes', evidence: 'Discovery monitoring mode ofrece métricas básicas para descubrir hosts y procesos y valorar dónde extender la cobertura. La documentación actual indica que está disponible solo con Dynatrace Platform Subscription (DPS) y que el consumo se realiza mediante Foundation & Discovery' },
  'R-OBS-37': { section: 'monitoring-modes', evidence: 'Extensions es opt-in en Full-Stack e Infrastructure y no figura en Discovery.' },
  'R-OBS-38': { section: 'monitoring-modes', evidence: 'Topology discovery, Host criticality (detección de external services y app dependencies) y Basic monitoring (host health, filesystem, OS Services) son GA en los tres modos' },
  'R-OBS-27': { section: 'sup-mode-licensing', evidence: 'Full-Stack Monitoring se mide en GiB-hours (memory-gibibyte-hours) según la memoria del host: la RAM se redondea al siguiente múltiplo de 0,25 GiB (256 MiB) y se aplica un mínimo de 4 GiB a hosts físicos y virtuales. Infrastructure Monitoring se mide en host hours, con independencia de la memoria del host' },

  // ── Activación, inyección y reinicios ──
  'A-009': { section: 'injection', evidence: 'En todos los modos, la inyección ya realizada permanece enlazada hasta que se reinicia el proceso.' },
  'A-015': { section: 'injection', evidence: 'Para que Application Security y Live Debugger funcionen en Discovery, se debe habilitar code-module injection en el host y reiniciar los procesos.' },
  'R-OBS-10': { section: 'injection', evidence: 'Disabled on installation (se desactivó durante la instalación de OneAgent)' },
  'R-OBS-31': { section: 'injection', evidence: 'Si OneAgent se ejecuta como container con Infrastructure mode, la inyección de procesos no se realiza según la guía de activación.' },
  'R-OBS-39': { section: 'injection', evidence: 'las custom process monitoring rules dan control fino sobre en qué procesos inyecta OneAgent, sin desactivar la auto-injection de todo el host' },
  'R-OBS-42': { section: 'injection', evidence: 'aporta runtime metrics para Java, .NET, Node.js, Go, PHP y web servers como Apache HTTP, NGINX o Microsoft IIS' },
  'A-010': { section: 'enable-modes', evidence: 'Infrastructure mode puede activarse durante la instalación con --set-monitoring-mode=infra-only' },
  'R-OBS-13': { section: 'enable-modes', evidence: 'o con --set-auto-injection-enabled=false): ese host deja de inyectar aunque el resto del entorno siga inyectando' },
  'R-OBS-22': { section: 'enable-modes', evidence: 'puedes definir un default monitoring mode en Latest Dynatrace desde Settings > Fleet management > Default mode' },
  'R-OBS-32': { section: 'enable-modes', evidence: 'la vía documentada es la Settings API: se descarga el schema con GET a schema usando builtin:host.monitoring como schemaId y se crea la configuración con POST an object' },
  'G-024': { section: 'deep-oneagent-architecture', evidence: 'si se modifica la configuración de auto-injection o se desactiva un code module, los procesos monitorizados deben ser reiniciados para que el cambio surta efecto' },
  'G-031': { section: 'deep-oneagent-change-control', evidence: '--get-monitoring-mode permite verificar el valor local' },

  // ── oneagentctl ──
  'A-016': { section: 'sup-oneagentctl', evidence: 'Cambiar el modo con --set-monitoring-mode requiere reiniciar OneAgent y también todos los services monitorizados' },
  'R-OBS-07': { section: 'sup-oneagentctl', evidence: 'Cambiar el modo con --set-monitoring-mode requiere reiniciar OneAgent y también todos los services monitorizados, igual que --set-host-group' },
  'G-037': { section: 'sup-oneagentctl', evidence: '--set-proxy configura el proxy (con valor vacío lo elimina) y requiere reiniciar OneAgent' },
  'R-OBS-09': { section: 'sup-oneagentctl', evidence: '--set-auto-injection-enabled=true o false activa o desactiva la auto-injection; tras activarla hay que reiniciar los procesos monitorizados para que carguen el code module' },
  'R-OBS-12': { section: 'sup-oneagentctl', evidence: 'alfanuméricos, guiones, guiones bajos y puntos, sin empezar por dt. y con un máximo de 100 caracteres' },
  'R-OBS-23': { section: 'sup-oneagentctl', evidence: 'por defecto /opt/dynatrace/oneagent/agent/tools en Linux y AIX, donde necesitas privilegios de root' },

  // ── Arquitectura y comunicación ──
  'A-011': { section: 'oneagent-architecture', evidence: 'La comunicación de OneAgent hacia Dynatrace es outbound-only: el agente informa mediante HTTP/S al Cluster o a ActiveGate.' },
  'B-010': { section: 'oneagent-architecture', evidence: 'OneAgent puede conectarse simultáneamente a través de varios ActiveGates y decide por cuáles comunicarse según la información que recibe del Cluster' },
  'B-016': { section: 'oneagent-architecture', evidence: 'según configuración, los logs pueden conservarse en Dynatrace aunque el almacenamiento original sea volátil o tenga poca retención' },
  'C-005': { section: 'oneagent-architecture', evidence: 'si Live Debugger está habilitado OneAgent crea una sesión WebSocket saliente hacia los ActiveGates o el Cluster para la información en tiempo real' },
  'FO-009': { section: 'oneagent-architecture', evidence: 'puede inyectar módulos de deep monitoring en tecnologías soportadas como Java, Node.js, .NET y otras' },
  'G-038': { section: 'oneagent-architecture', evidence: 'Dynatrace OneAgent Watchdog arranca y ejecuta todos los demás procesos de OneAgent bajo un usuario sin privilegios' },
  'R-OBS-29': { section: 'oneagent-architecture', evidence: 'En Linux, OneAgent se instala por defecto en non-privileged mode: los privilegios de superusuario solo se usan para iniciar la instalación' },
  'G-028': { section: 'sup-activegate-routing', evidence: 'el Environment ActiveGate recibe conexiones en el puerto 9999 y el SaaS Cluster en el 443' },
  'R-OBS-21': { section: 'sup-activegate-routing', evidence: 'se conecta directamente al SaaS Cluster si no es posible ninguna conexión con un Environment ActiveGate' },
  'R-OBS-02': { section: 'sup-activegate-routing', evidence: 'OneAgent prefiere los ActiveGates de su propia zona; si no hay ninguno disponible, prueba las alternative zones configuradas' },
  'R-OBS-25': { section: 'sup-activegate-routing', evidence: 'None (el tráfico permanece dentro de la zona principal y las alternative zones)' },
  'R-OBS-18': { section: 'sup-activegate-routing', evidence: 'puede realizar tareas de monitorización usando API para consultar y monitorizar tecnologías donde no se instala OneAgent' },
  'R-OBS-33': { section: 'sup-activegate-routing', evidence: 'en SaaS solo se necesita un Environment ActiveGate' },
  'R-OBS-04': { section: 'sup-activegate-routing', evidence: 'usando un Environment ActiveGate con acceso de solo lectura a vCenter o a un host ESXi standalone; no se instala OneAgent en el hipervisor. OneAgent en cada máquina virtual aporta datos complementarios' },

  // ── Capacidades ──
  'C-006': { section: 'oneagent-capabilities', evidence: 'En web, OneAgent puede insertar el JavaScript de RUM en las páginas servidas y observar la experiencia del navegador.' },
  'E-008': { section: 'oneagent-capabilities', evidence: 'la librería se integra, compila, empaqueta y distribuye dentro de la aplicación Android o iOS' },
  'E-007': { section: 'oneagent-capabilities', evidence: 'basta con instalar OneAgent en los hosts que sirven las aplicaciones en contenedores: detecta la creación y terminación de contenedores y no hace falta modificar las imágenes Docker ni los comandos de arranque' },
  'E-009': { section: 'oneagent-capabilities', evidence: 'OneAgent informa de qué aplicaciones o services usan qué otros services y de si un service hace llamadas a otros services o a bases de datos' },
  'E-010': { section: 'oneagent-capabilities', evidence: 'Dynatrace aprende automáticamente el baseline de response time y failure rate de todas las requests y evalúa las desviaciones frente a ese baseline' },
  'E-012': { section: 'oneagent-capabilities', evidence: 'aporta qué procesos se ejecutan en qué hosts y cómo se conectan entre sí' },
  'D-008': { section: 'oneagent-capabilities', evidence: 'OneAgent obtiene métricas de red a nivel de proceso gracias a la monitorización proceso a proceso de las comunicaciones' },
  'R-OBS-40': { section: 'oneagent-capabilities', evidence: 'Preview (no está lista para producción y no tiene soporte oficial)' },

  // ── Entidades, host groups y Problems ──
  'R-OBS-03': { section: 'sup-process-groups', evidence: 'Cada host pertenece como máximo a un host group.' },
  'R-OBS-15': { section: 'sup-process-groups', evidence: 'para aislar el nodo que consume más memoria se analiza su PGI, no el process group' },
  'R-OBS-14': { section: 'sup-process-groups', evidence: 'Las reglas y ajustes de process group detection requieren reiniciar los procesos para afectar a cómo se identifican y agrupan' },
  'R-OBS-26': { section: 'sup-process-groups', evidence: 'con DT_NODE_ID indicas qué procesos deben tratarse como process group instances separadas' },
  'R-OBS-16': { section: 'sup-davis-problems', evidence: 'Dynatrace correlaciona todos los Davis events con la misma root cause en un único Problem' },
  'R-OBS-34': { section: 'sup-davis-problems', evidence: 'si un Problem dura más de 90 minutos, no se fusionan más Davis events después de ese punto y se abre un nuevo Problem' },
  'R-OBS-35': { section: 'sup-davis-problems', evidence: 'El impact analysis identifica qué entry-point services de las aplicaciones se ven afectados y el tamaño del blast radius' },
  'R-OBS-36': { section: 'sup-davis-problems', evidence: 'La vertical va del service al proceso y al host que lo ejecuta; la horizontal sigue las llamadas entre services.' },

  // ── Kubernetes ──
  'R-OBS-06': { section: 'sup-dynakube-modes', evidence: 'ActiveGate, que enruta los datos de observabilidad al cluster de Dynatrace y monitoriza la Kubernetes API' },
  'R-OBS-19': { section: 'sup-dynakube-modes', evidence: 'classicFullStack requiere acceso de escritura desde el Pod de OneAgent al sistema de archivos del nodo y no está soportado cuando se usa un platform token' },
  'R-OBS-20': { section: 'sup-dynakube-modes', evidence: 'pero no monitoriza métricas de host y, sin Kubernetes platform monitoring, la topología se limita a Pods y contenedores' },
  'R-OBS-30': { section: 'sup-dynakube-modes', evidence: 'hostMonitoring recoge métricas de host y datos de procesos de los nodos con OneAgent, sin monitorización a nivel de aplicación' },
  'G-039': { section: 'sup-dynakube-modes', evidence: 'Kubernetes platform monitoring usa la Kubernetes API y cAdvisor para obtener métricas de nodos y contenedores y eventos de Kubernetes; no incluye OneAgent ni monitorización de aplicación por defecto' },
  'FO-010': { section: 'sup-kubernetes-app', evidence: 'La nueva experiencia no está disponible para Managed ni para SaaS sin Grail; en esos entornos se sigue usando Kubernetes Classic.' },
  'B-015': { section: 'sup-kubernetes-app', evidence: 'Como las métricas, eventos y logs están en Grail, el mismo análisis puede hacerse con DQL y reutilizarse en Notebooks, Dashboards o Workflows.' },
  'D-007': { section: 'sup-kubernetes-app', evidence: 'añade objetos como Ingress, NetworkPolicies, CRDs, PVCs, PVs y ConfigMaps, da acceso a sus definiciones YAML para depurar y validar configuraciones en tiempo real' },
  'FO-014': { section: 'sup-kubernetes-app', evidence: 'permite consultar los YAML de todos los clusters y namespaces con DQL para detectar misconfigurations' },
  'G-034': { section: 'sup-kubernetes-app', evidence: 'Requiere ActiveGate 1.327 o superior. Con ActiveGates anteriores, el cluster funciona en modo de compatibilidad y aparece una pestaña adicional Explorer (Classic)' },
  'C-007': { section: 'sup-kubernetes-app', evidence: 'para eventos críticos se genera un Health alert, que inicia una investigación de Problems; para situaciones no críticas, un Warning signal informa de un posible problema' },
  'D-006': { section: 'sup-kubernetes-app', evidence: 'se considera unhealthy si cualquiera de sus custom alert configurations asociadas está unhealthy' },
  'FO-012': { section: 'sup-kubernetes-app', evidence: 'presenta alertas de buenas prácticas para clusters, nodes, namespaces, persistent volume claims y workloads, y resalta cuáles están active, partially active o inactive' },
  'FO-011': { section: 'sup-kubernetes-app', evidence: 'se abre una vista de detalle con pestañas de health y utilization, logs, events, ownership y vulnerabilities' },

  // ── Apps de infraestructura ──
  'R-OBS-05': { section: 'sup-infra-apps', evidence: 'asignar uno o varios ActiveGate groups que conecten remotamente con los servidores de base de datos, instalar los componentes necesarios, como drivers JDBC, en esos ActiveGates' },
  'R-OBS-11': { section: 'sup-infra-apps', evidence: 'crear un usuario de monitorización con permisos sobre system views y schemas. Así se monitoriza también una base de datos gestionada en la que no se pueden instalar agentes.' },
  'R-OBS-41': { section: 'sup-infra-apps', evidence: 'La app Databases ofrece un health score compuesto que resume la salud de cada instancia de base de datos' },
  'R-OBS-17': { section: 'sup-infra-apps', evidence: 'Infrastructure & Operations simplifica la monitorización de salud de la infraestructura y facilita el root cause analysis de Problems, con vistas de Hosts, Containers, Processes y Network Devices y un Explorer' },
  'R-OBS-08': { section: 'sup-infra-apps', evidence: 'Install OneAgents (con prioridad según el tamaño del hueco de observabilidad; con filtros, el botón indica cuántos OneAgents se instalarán). En Service coverage, la columna Enable Full-Stack permite pasar a Full-Stack monitoring mode los OneAgents de los hosts descubiertos' },
  'R-OBS-28': { section: 'sup-infra-apps', evidence: 'eBPF Discovery module (componente de OneAgent de bajo overhead que determina qué URLs se envían a un proceso, con qué frecuencia y si el origen es público)' },
}
