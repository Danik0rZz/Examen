import type { CoverageMap } from './types'
import { welcomeCoverage } from './welcome'
import { instructionsCoverage } from './instructions'
import { platformCoverage } from './platform'
import { observabilityCoverage } from './observability'
import { notebooksCoverage } from './notebooks'
import { businessCoverage } from './business'
import { dataCoverage } from './data'
import { dqlCoverage } from './dql'
import { securityCoverage } from './security'
import { automationCoverage } from './automation'
import { ingestionCoverage } from './ingestion'
import { otherCoverage } from './other'

/** Cobertura por módulo: cada pregunta apunta al apartado de la guía que la respalda. */
export const coverageByModule: Record<string, CoverageMap> = {
  'welcome': welcomeCoverage,
  'instructions': instructionsCoverage,
  'platform': platformCoverage,
  'observability': observabilityCoverage,
  'notebooks': notebooksCoverage,
  'business-dem': businessCoverage,
  'data-analysis': dataCoverage,
  'dql': dqlCoverage,
  'security': securityCoverage,
  'automation': automationCoverage,
  'ingestion': ingestionCoverage,
  'other': otherCoverage,
}
