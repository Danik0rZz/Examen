export type QuestionBucket = 'knowledge' | 'precision' | 'scenario' | 'troubleshooting' | 'practical'
export type Difficulty = 'basic' | 'intermediate' | 'advanced'
export type CognitiveLevel = 'remember' | 'understand' | 'apply' | 'analyze'
export type QuestionStimulus =
  | { kind: 'code'; title: string; content: string }
  | { kind: 'table'; title: string; columns: string[]; rows: string[][] }
  | { kind: 'case'; title: string; content: string }

export type SourceRef = {
  title: string
  url: string
  kind: 'official-docs' | 'official-training' | 'support'
}

export type ModuleBlueprint = {
  id: string
  order: number
  title: string
  eyebrow: string
  summary: string
  objectives: string[]
  keyTerms: string[]
  sources: SourceRef[]
  focus: string
}

export type Question = {
  id: string
  moduleId: string
  objectiveId: string
  chapterId: string
  bucket: QuestionBucket
  cognitiveLevel: CognitiveLevel
  difficulty: Difficulty
  promptEs: string
  stimulus?: QuestionStimulus
  type: 'single' | 'multiple'
  options: { id: string; text: string }[]
  correctOptionIds: string[]
  explanationEs: string
  sourceRefs: SourceRef[]
  classicOrLatest: 'latest' | 'classic' | 'both' | 'mixed'
  versionNote?: string
  lastVerified: string
  form: 'A' | 'B' | 'C' | 'D' | 'E' | 'F' | 'W' | 'I' | 'G'
}

export type Module = ModuleBlueprint & {
  questionIds: string[]
}

export type Attempt = {
  questionId: string
  selectedOptionIds: string[]
  score: number
  correct: boolean
  confidence: 1 | 2 | 3 | 4 | 5
  timestamp: string
}

export type StoredProgress = {
  version: 3
  attempts: Record<string, Attempt[]>
  completedModules: string[]
  activeQuestionId?: string
}
