import type { Draft } from './bank-core'
import { finalQuestion } from './bank-final-core'

const q = (n: number, source: 'welcome101' | 'welcomemelt' | 'welcomedavis' | 'welcomesmartscape' | 'welcomedps',
  objective: string, bucket: 'knowledge' | 'precision' | 'scenario' | 'troubleshooting' | 'practical',
  prompt: string, choices: [string, string, string, string], correct: number | number[], explanation: string): Draft =>
  finalQuestion('W', n, source, objective, bucket, prompt, choices, correct, explanation)

export const bankWelcome: Draft[] = [
  // 1-10: Fundamentos de la Plataforma y Arquitectura 101
  q(1, 'welcome101', 'purpose', 'knowledge',
    '¿Cuál es el objetivo principal de la certificación Dynatrace Associate?',
    [
      'Validar conocimientos avanzados de administración de infraestructura física y soporte de hardware on-premises.',
      'Demostrar competencia transversal para navegar la plataforma, analizar telemetría, investigar problemas y aplicar decisiones operativas fundamentadas.',
      'Acreditar habilidades de programación exclusiva en scripts de Python para desarrollar plugins personalizados de OneAgent.',
      'Certificar experiencia en ventas y tarificación comercial de contratos corporativos de software SaaS.',
    ], 1,
    'La certificación Dynatrace Associate valida una comprensión integral y transversal de la plataforma Dynatrace: arquitectura, observabilidad, análisis de rendimiento, DQL, automatización y seguridad.'),

  q(2, 'welcomemelt', 'melt', 'knowledge',
    '¿Cómo unifica Dynatrace los pilares clásicos de telemetría (Metrics, Events, Logs, Traces - MELT)?',
    [
      'Almacenándolos en bases de datos relacionales SQL separadas con réplicas nocturnas sincronizadas.',
      'Indexando de forma masiva todos los campos de texto en clústeres elásticos antes de permitir cualquier consulta.',
      'Centralizándolos en Grail, un data lakehouse columnar sin esquemas rígidos (schema-on-read) que preserva el contexto de entidades y topología.',
      'Delegando la retención de métricas en archivos CSV locales dentro de cada host monitorizado.',
    ], 2,
    'Grail funciona como el data lakehouse unificado donde métricas, eventos, logs y trazas conviven en almacenamiento columnar con evaluación schema-on-read.'),

  q(3, 'welcomedavis', 'davis-nature', 'precision',
    '¿En qué se diferencia fundamentalmente Davis AI de un modelo de machine learning probabilístico tradicional de tipo caja negra?',
    [
      'Davis utiliza exclusivamente reglas estáticas de umbrales fijos configuradas manualmente por los operadores de TI.',
      'Davis analiza la topología viva de Smartscape mediante análisis causal determinista y baselines automáticos para identificar la causa raíz exacta.',
      'Davis predice incidencias futuras sin basarse en dependencias reales ni en la secuencia temporal de las anomalías.',
      'Davis reemplaza por completo la necesidad de recopilar logs y métricas de infraestructura en producción.',
    ], 1,
    'Davis AI es un motor causal determinista que evalúa dependencias topológicas en el grafo Smartscape y líneas base dinámicas para señalar la causa raíz real sin especulaciones probabilísticas.'),

  q(4, 'welcomesmartscape', 'layers', 'knowledge',
    '¿Cuáles son las 5 capas que componen la jerarquía vertical de la topología Smartscape?',
    [
      'Data Center → Host → Process Group → Service → Application.',
      'Hardware → Hypervisor → Virtual Machine → Container → User.',
      'Cluster → Namespace → Pod → Container → Ingress.',
      'Network → Operating System → Middleware → Database → Firewall.',
    ], 0,
    'La jerarquía estricta de 5 capas en Smartscape fluye verticalmente desde Data Center, pasando por Host, Process Group y Service, hasta la cúspide en Application.'),

  q(5, 'welcomedps', 'model', 'knowledge',
    '¿Cuál es la premisa operativa del modelo Dynatrace Platform Subscription (DPS)?',
    [
      'Adquirir licencias perpetuas estáticas separadas e inmutables para cada tecnología que se desee monitorizar.',
      'Un compromiso de consumo unificado basado en valor donde las capacidades de la plataforma se tarifican según el uso real sin silos de licencias.',
      'Obligar al despliegue obligatorio de clústeres Managed autogestionados en centros de datos locales.',
      'Limitar el acceso a DQL y AutomationEngine a contratos de soporte técnico externo prémium.',
    ], 1,
    'DPS es un modelo de suscripción basado en el consumo donde todas las capacidades de la plataforma (observabilidad, seguridad, automatización) se consumen de forma flexible contra un crédito unificado.'),

  q(6, 'welcome101', 'entity-hierarchy', 'precision',
    'En el modelo de entidades de Dynatrace, ¿cuál es la diferencia entre un Process Group (PG) y una Process Group Instance (PGI)?',
    [
      'Process Group es el hardware físico y PGI es el sistema operativo instalado.',
      'Process Group representa la agrupación lógica de procesos que cumplen la misma función; PGI es la ejecución concreta de ese proceso en un host o contenedor específico.',
      'Process Group se aplica únicamente a bases de datos relacionales y PGI a servidores web Apache.',
      'Process Group es una entidad clásica en desuso sustituida íntegramente por etiquetas de Kubernetes.',
    ], 1,
    'Un Process Group (PG) agrupa lógicamente procesos homogéneos (ej. cluster Tomcat), mientras que una Process Group Instance (PGI) es la instancia física de ejecución en un Host determinado.'),

  q(7, 'welcomedavis', 'event-vs-problem', 'precision',
    '¿Cuál es la diferencia conceptual entre un Davis event y un Problem?',
    [
      'Davis event es un error en el código fuente; Problem es una avería en la fuente de alimentación del servidor.',
      'Davis event representa una anomalía o cambio individual en una entidad; Problem es un incidente correlacionado que agrupa múltiples eventos causalmente vinculados.',
      'No existe diferencia: ambos términos son sinónimos intercambiables en la documentación oficial.',
      'Davis event solo se genera en pruebas sintéticas y Problem solo en usuarios reales de RUM.',
    ], 1,
    'Un Davis event es una señal o anomalía individual (ej. saturación de CPU o degradación de tiempo de respuesta); un Problem es el incidente global que Davis abre correlacionando todos los eventos relacionados.'),

  q(8, 'welcome101', 'investigation-flow', 'scenario',
    'Un usuario reporta que una aplicación web de comercio electrónico está respondiendo con lentitud extrema. ¿Cuál es el orden metódico recomendado para investigar el incidente?',
    [
      'Reiniciar todos los hosts de la infraestructura inmediatamente y comprobar si el problema persiste.',
      'Formular la pregunta, verificar el timeframe e impacto en la aplicación, examinar el Problem correlacionado por Davis, revisar trazas de servicios y analizar la causa raíz en infraestructura.',
      'Eliminar los filtros de retención de logs y escribir una consulta masiva sin acotar ventana temporal.',
      'Cambiar el modo de monitorización de OneAgent a Discovery en todos los servidores de producción.',
    ], 1,
    'La investigación profesional sigue un bucle reproducible: acotar timeframe e impacto en la experiencia de usuario, seguir el análisis causal de Davis en el Problem, inspeccionar servicios y verificar métricas/logs de la causa raíz.'),

  q(9, 'welcomemelt', 'schema-on-read', 'precision',
    '¿Qué ventaja técnica fundamental proporciona el modelo "schema-on-read" de Grail frente al almacenamiento tradicional con esquemas rígidos?',
    [
      'Permite ingestar datos estructurados y no estructurados inmediatamente a alta velocidad sin requerir definición de índices ni esquemas previos en el momento de carga.',
      'Impide que los usuarios puedan utilizar expresiones regulares o filtros de texto en sus consultas.',
      'Exige que cada log sea transformado manualmente a formato XML antes de ser transmitido por la red.',
      'Garantiza que ningún dato pueda consultarse después de transcurridas 24 horas desde su ingestión.',
    ], 0,
    'Schema-on-read procesa la estructura, tipos y campos en el momento de ejecutar la consulta DQL, evitando cuellos de botella de indexación previa y adaptándose a cualquier formato.'),

  q(10, 'welcome101', 'dql-role', 'knowledge',
    '¿Cuál es el rol de DQL (Dynatrace Query Language) dentro del ecosistema de la plataforma?',
    [
      'Es un lenguaje de scripting para instalar OneAgent en servidores Linux de forma desatendida.',
      'Es el lenguaje de consulta declarativo y canalizado (pipeline) para explorar, filtrar, transformar y agregar datos almacenados en Grail.',
      'Es un compilador interno que convierte código Java en bytecode compatible con Kubernetes.',
      'Es la herramienta gráfica de diseño de interfaces web dentro de Dynatrace Hub.',
    ], 1,
    'DQL es el lenguaje de consulta estructurado por pipelines (`|`) diseñado para interrogar Grail en Notebooks, Dashboards y Workflows.'),

  // 11-20: Davis AI, Smartscape y Contexto Operativo
  q(11, 'welcomedavis', 'root-cause', 'scenario',
    'Durante un incidente, la aplicación Problems de Dynatrace muestra múltiples servicios degradados y señala un Process Group de base de datos como "Root Cause". ¿Qué significa esto?',
    [
      'Que la base de datos es la única entidad que ha sufrido errores en todo el entorno.',
      'Que Davis ha recorrido el grafo topológico y determinado que la saturación de conexiones en la base de datos es la causa que originó la degradación en cascada de los servicios dependientes.',
      'Que el administrador debe borrar inmediatamente los registros de la base de datos para solucionar el problema.',
      'Que OneAgent ha detenido los procesos de la base de datos de forma preventiva.',
    ], 1,
    'Root cause identifica el componente específico cuya falla o degradación desencadenó el impacto en las entidades aguas arriba según el modelo topológico de dependencias.'),

  q(12, 'welcomesmartscape', 'horizontal-deps', 'precision',
    '¿Qué tipo de relación representan las dependencias horizontales en la vista de Smartscape?',
    [
      'La relación de alojamiento físico entre un Host y el Data Center.',
      'Comunicaciones entre entidades del mismo nivel jerárquico, como llamadas HTTP/RPC entre Servicios o tráfico de red entre Hosts.',
      'La asignación de permisos de usuario a grupos de administración en IAM.',
      'La retención de almacenamiento asignada a diferentes buckets en Grail.',
    ], 1,
    'Las relaciones horizontales en Smartscape muestran flujos de comunicación entre pares (Service-to-Service calls o Host-to-Host network traffic), mientras que las verticales muestran contención/hospedaje.'),

  q(13, 'welcome101', 'oneagent-basics', 'knowledge',
    '¿Cómo recopila OneAgent la telemetría en un sistema operativo anfitrión compatible?',
    [
      'Instalando múltiples agentes independientes de diferentes fabricantes que envían datos por protocolos no estándar.',
      'Mediante un único binario que detecta procesos, recopila métricas de host/red e inyecta módulos de instrumentación en runtimes compatibles.',
      'Exigiendo la modificación y recompilación manual del código fuente de cada microservicio en la empresa.',
      'Conectándose periódicamente mediante SSH con credenciales de root para leer archivos de texto.',
    ], 1,
    'OneAgent es un agente todo-en-uno: un único binario por host que descubre procesos, inyecta módulos de monitoreo en tiempo de ejecución y transmite telemetría automáticamente.'),

  q(14, 'welcomedps', 'capabilities', 'precision',
    'En el marco de Dynatrace Platform Subscription (DPS), ¿cómo se gestionan las capabilities como Application Security o Workflows?',
    [
      'Requieren contratos de software totalmente independientes y servidores de gestión separados.',
      'Pueden activarse bajo demanda en el tenant y consumen créditos del compromiso unificado según su uso medido.',
      'Están disponibles únicamente en entornos de laboratorio y no en producción.',
      'Se desactivan permanentemente si el entorno supera las 100 consultas DQL diarias.',
    ], 1,
    'Bajo DPS, las distintas capabilities (AppSec, AutomationEngine, RUM, Log Management) se activan de forma flexible y consumen créditos según el volumen de datos o ejecuciones utilizadas.'),

  q(15, 'welcome101', 'context-value', 'knowledge',
    '¿Por qué una métrica de uso de memoria al 95% en un servidor no es, por sí sola, una prueba concluyente de un fallo de aplicación?',
    [
      'Porque Dynatrace ignora las métricas de memoria en sistemas operativos modernos.',
      'Porque muchos sistemas operativos y motores como Java o Linux gestionan la memoria caché manteniéndola ocupada sin que signifique saturación anómala o degradación de servicio.',
      'Porque la memoria RAM nunca influye en los tiempos de respuesta de una base de datos.',
      'Porque solo las alertas configuradas con umbrales fijos son válidas en la plataforma.',
    ], 1,
    'El contexto es clave: una alta utilización de memoria puede ser comportamiento normal de buffer/caché de la JVM o del SO; solo con contexto de transacciones, garbage collection y fallos se diagnostica un problema real.'),

  q(16, 'welcomemelt', 'unification-grail', 'scenario',
    'Un equipo de soporte está investigando un error HTTP 500. ¿Cómo facilita Grail la correlación entre logs y trazas?',
    [
      'Exige que el operador descargue los ficheros de log a su máquina y busque visualmente la hora del incidente.',
      'Asocia el `trace_id` inyectado automáticamente en los logs con los spans de distributed tracing, permitiendo saltar del registro de log a la traza exacta en DQL.',
      'Convierte los logs en imágenes PNG para visualizarlos en la galería de fotos del sistema operativo.',
      'Elimina los logs anteriores al incidente para que no interfieran en el análisis.',
    ], 1,
    'Grail unifica trazas y logs correlacionándolos mediante identificadores universales como `trace_id` y `span_id` propagados de forma nativa por OneAgent u OpenTelemetry.'),

  q(17, 'welcomedavis', 'baselines', 'precision',
    '¿Cómo establece Davis AI las líneas base dinámicas (dynamic baselines) para la detección de anomalías de rendimiento?',
    [
      'Calculando una única media fija aritmética basada en el primer día de instalación del agente.',
      'Analizando percentiles estadísticos multidimensionales considerando la estacionalidad horaria, diaria y semanal del tráfico.',
      'Esperando a que el administrador introduzca los límites de milisegundos aceptables en un formulario.',
      'Comparando el rendimiento con servidores de demostración públicos en la nube.',
    ], 1,
    'Davis aprende automáticamente el comportamiento normal calculando baselines dinámicos multidimensionales que consideran patrones estacionales (día de la semana, horas punta y valles).'),

  q(18, 'welcome101', 'launcher-nav', 'knowledge',
    '¿Qué función cumple el Dynatrace Launcher en la interfaz Latest de la plataforma?',
    [
      'Es un instalador ejecutable de Windows para actualizar la tarjeta gráfica del ordenador cliente.',
      'Es el punto de acceso central y menú de navegación unificado para abrir aplicaciones de observabilidad, análisis, seguridad y extensiones de Hub.',
      'Es una consola de comandos exclusiva para compilar código C++.',
      'Es un plugin de navegador obsoleto de la versión Classic.',
    ], 1,
    'El Launcher es el menú principal de Latest Dynatrace desde el cual los usuarios acceden a todas las aplicaciones modulares instaladas en el tenant.'),

  q(19, 'welcomedps', 'overage-control', 'troubleshooting',
    'Si una organización con contrato DPS incrementa temporalmente su volumen de ingestión de logs durante un evento comercial como Black Friday, ¿qué sucede?',
    [
      'Dynatrace bloquea inmediatamente el acceso a la plataforma y apaga los servidores monitorizados.',
      'La plataforma continúa ingiriendo y monitorizando sin interrupción, consumiendo el saldo de compromiso de DPS con tarificación de uso transparente.',
      'Todos los datos recopilados durante ese día se borran de forma irreversible al medianoche.',
      'Se requiere reiniciar OneAgent manualmente en cada host para solicitar una licencia temporal.',
    ], 1,
    'DPS está diseñado para la elasticidad de negocio: absorbe picos de demanda consumiendo créditos del fondo global contratado sin interrumpir la observabilidad.'),

  q(20, 'welcomesmartscape', 'vertical-impact', 'scenario',
    'Un fallo de hardware provoca la caída súbita de un Host físico. ¿Cómo refleja Smartscape este impacto en la jerarquía?',
    [
      'El impacto se propaga verticalmente hacia arriba: los Process Groups alojados en ese Host se degradan o caen, afectando a los Services correspondientes y a las Applications que dependen de ellos.',
      'El impacto solo se refleja en el Data Center pero los servicios continúan mostrándose en verde.',
      'Smartscape desconecta la interfaz web para evitar que el usuario vea el fallo.',
      'Dynatrace crea automáticamente un Host virtual nuevo sin consultar al hipervisor.',
    ], 0,
    'La topología vertical de Smartscape refleja el blast radius: una falla en la infraestructura base (Host) impacta a los procesos, servicios y aplicaciones alojadas aguas arriba.'),

  // 21-35: Precisión y Distractores Frecuentes
  q(21, 'welcome101', 'ui-vs-storage', 'precision',
    '¿Por qué una consulta DQL válida ejecutada por un usuario puede devolver 0 resultados mientras que otro usuario ve miles de registros en la misma tabla?',
    [
      'Porque DQL solo puede ejecutarse una vez al día por empresa.',
      'Porque las políticas de autorización de Grail (IAM y ABAC) restringen el acceso a buckets o campos específicos según el usuario o grupo.',
      'Porque los datos en Grail se borran automáticamente cada vez que un usuario cierra la sesión en el navegador.',
      'Porque DQL requiere pagar una tarifa adicional en efectivo antes de cada consulta.',
    ], 1,
    'En Grail, el almacenamiento y la autorización son independientes de la sintaxis: las políticas de IAM y control de acceso basado en atributos (ABAC) determinan qué registros son visibles para cada identidad.'),

  q(22, 'welcomemelt', 'events-vs-metrics', 'knowledge',
    '¿En qué se diferencia una métrica de un evento en el modelo de datos de telemetría?',
    [
      'Las métricas son valores numéricos medidos en intervalos regulares de tiempo; los eventos son registros puntuales con timestamp que describen un hecho discreto.',
      'Las métricas solo contienen texto alfanumérico y los eventos solo contienen números enteros.',
      'Las métricas se descartan a los 5 minutos y los eventos se conservan durante 50 años obligatoriamente.',
      'No hay diferencia: en Dynatrace todos los datos se denominan exclusivamente logs.',
    ], 0,
    'Una métrica es una serie temporal numérica (ej. uso de CPU cada 10s); un evento es una ocurrencia atómica con metadatos contextuales (ej. despliegue, reinicio de proceso o alerta de threshold).'),

  q(23, 'welcomedavis', 'alert-storm', 'scenario',
    'Durante una caída de red mayor en un centro de datos, se producen cientos de fallos en cientos de servicios y hosts. ¿Cómo evita Davis AI la saturación por alertas ("alert storm")?',
    [
      'Enviando un correo electrónico individual separado por cada proceso afectado en la red.',
      'Silenciando todas las alertas durante 24 horas para que el equipo de guardia descanse.',
      'Correlacionando automáticamente los cientos de eventos individuales en un único Problem principal señalando el fallo de red como causa raíz común.',
      'Apagando los servidores para evitar que sigan generando tráfico de error.',
    ], 2,
    'Una de las grandes ventajas de Davis AI es la deduplicación y correlación causal: en lugar de enviar 500 notificaciones inconexas, abre un único Problem consolidado con todo el árbol de impacto.'),

  q(24, 'welcomesmartscape', 'pg-vs-service', 'precision',
    'En la arquitectura de Smartscape, ¿por qué los Services se sitúan en una capa superior a los Process Groups?',
    [
      'Porque un Service representa la interfaz lógica de comunicación observable (ej. peticiones web o llamadas gRPC) servida por uno o varios procesos subyacentes.',
      'Porque los servicios son hardware físico y los procesos son cables de fibra óptica.',
      'Porque los Process Groups solo existen en ordenadores portátiles de desarrollo.',
      'Porque la documentación oficial prohíbe tener más de un servicio por clúster.',
    ], 0,
    'Un Service es una abstracción de software: expone una API o funcionalidad que es ejecutada en runtime por las instancias de un Process Group en uno o más hosts.'),

  q(25, 'welcomedps', 'commit-flexibility', 'knowledge',
    '¿Cuál es la principal ventaja de DPS frente a los antiguos modelos de licenciamiento por "licencias de servidor" fijas?',
    [
      'Que permite reasignar el consumo de crédito entre diferentes tecnologías (cloud, Kubernetes, logs, seguridad) sin tener que renegociar contratos ante cambios de arquitectura.',
      'Que proporciona servidores físicos gratuitos entregados en la sede de la empresa.',
      'Que exime a la empresa de utilizar contraseñas en los inicios de sesión de los administradores.',
      'Que limita la monitorización únicamente al sistema operativo Windows Server.',
    ], 0,
    'DPS proporciona agilidad y flexibilidad total: el crédito contratado se consume dinámicamente según la combinación de capacidades que la empresa necesite en cada momento.'),

  q(26, 'welcome101', 'notebooks-vs-dashboards', 'precision',
    'Al plantear una solución de visualización en Dynatrace, ¿cuándo se debe recomendar un Notebook frente a un Dashboard?',
    [
      'Cuando se necesita una pantalla de televisión en el centro de operaciones (NOC) para monitorización visual continua 24/7.',
      'Cuando se requiere construir una investigación analítica interactiva, combinando Markdown explicativo, consultas DQL exploratorias y notas reproducibles.',
      'Cuando no se dispone de conexión a internet y se trabaja de modo offline.',
      'Cuando solo se van a consultar métricas de servidores físicos sin procesos.',
    ], 1,
    'Notebooks es el espacio para la exploración colaborativa, análisis forense ad-hoc y documentación reproducible con narrativa; Dashboards está optimizado para monitorización continua de KPIs.'),

  q(27, 'welcomemelt', 'traces-distributed', 'knowledge',
    '¿Qué información aporta fundamentalmente el rastreo distribuido (distributed tracing) en una arquitectura de microservicios?',
    [
      'El consumo eléctrico en vatios de la fuente de alimentación del servidor.',
      'El recorrido de extremo a extremo de una petición a través de múltiples servicios, incluyendo tiempos de ejecución individuales y llamadas a bases de datos.',
      'La lista de todos los empleados que tienen acceso al repositorio de código fuente.',
      'El coste financiero por minuto del proveedor de servicios de internet.',
    ], 1,
    'Distributed tracing desglosa una transacción en spans: muestra la ruta completa de una petición desde el navegador hasta la base de datos con los tiempos invertidos en cada salto de red.'),

  q(28, 'welcomedavis', 'causality-vs-correlation', 'precision',
    'En términos de diagnóstico de incidentes, ¿por qué la correlación estadística simple suele inducir a conclusiones falsas en entornos de microservicios?',
    [
      'Porque dos métricas pueden degradarse al mismo tiempo por pura casualidad sin que exista una relación de dependencia técnica entre ellas.',
      'Porque las estadísticas nunca se aplican a los ordenadores digitales.',
      'Porque los microservicios nunca sufren incidentes concurrentes.',
      'Porque Dynatrace solo admite números primos en sus cálculos matemáticos.',
    ], 0,
    'Correlación no implica causalidad: dos servicios independientes pueden saturar CPU simultáneamente durante una hora punta sin que uno cause el fallo del otro; Davis valida la causalidad real mediante el grafo Smartscape.'),

  q(29, 'welcome101', 'openpipeline-place', 'knowledge',
    '¿En qué punto de la arquitectura de la plataforma actúa OpenPipeline?',
    [
      'Después de que los datos han sido archivados durante 5 años en cintas magnéticas.',
      'En el flujo de entrada de telemetría, procesando, enriqueciendo, enmascarando y enrutando los datos antes de persistirlos en los buckets de Grail.',
      'Dentro del navegador web del usuario final para renderizar gráficos CSS.',
      'Exclusivamente en los servidores de ActiveGate para reiniciar servicios caídos.',
    ], 1,
    'OpenPipeline es el pipeline de streaming que intercepta la telemetría en tiempo de ingestión para aplicar reglas de transformación, privacidad y asignación de buckets antes del almacenamiento.'),

  q(30, 'welcomesmartscape', 'automatic-mapping', 'precision',
    '¿Cómo descubre y mantiene Smartscape las relaciones entre servicios y procesos?',
    [
      'Exige que los desarrolladores dibujen manualmente diagramas de arquitectura en Visio y los suban a la plataforma cada semana.',
      'Analiza automáticamente las llamadas de red reales, cabeceras de peticiones y sockets TCP abiertos interceptados por OneAgent en tiempo de ejecución.',
      'Realiza escaneos periódicos de puertos de forma destructiva que interrumpen la producción.',
      'Lee la documentación interna escrita en las wikis de la empresa.',
    ], 1,
    'Smartscape es 100% automático: OneAgent analiza las conexiones de red y llamadas a nivel de socket y protocolo para trazar las dependencias vivas sin intervención humana.'),

  // 31-45: Escenarios de Troubleshooting y Aplicación
  q(31, 'welcome101', 'empty-query-trouble', 'troubleshooting',
    'Un ingeniero ejecuta `fetch logs` en un Notebook y el resultado está completamente vacío. ¿Cuál es la primera comprobación diagnóstica que debe realizar antes de afirmar que los servidores no generan logs?',
    [
      'Reinstalar el sistema operativo del servidor que hospeda Dynatrace SaaS.',
      'Verificar el timeframe seleccionado en la consulta o interfaz y comprobar si el usuario tiene permisos de lectura sobre el bucket de logs correspondiente.',
      'Eliminar todos los dashboards de la cuenta corporativa.',
      'Apagar el cortafuegos principal de la sede corporativa.',
    ], 1,
    'Ante una consulta vacía, la regla de oro de troubleshooting es revisar primero el timeframe (ventana temporal) y los permisos IAM de lectura sobre el bucket o tabla consultada.'),

  q(32, 'welcomedavis', 'maintenance-window', 'scenario',
    'Un equipo de operaciones va a desplegar una actualización planificada en un clúster de servidores que causará caídas temporales de procesos. ¿Qué mecanismo oficial de Dynatrace debe configurarse para evitar falsas alarmas?',
    [
      'Desinstalar OneAgent de todos los servidores y volver a instalarlo tras el despliegue.',
      'Configurar una Maintenance Window (ventana de mantenimiento) para las entidades afectadas con supresión de detección de problemas y alertas.',
      'Desconectar la tarjeta de red de los servidores durante la actualización.',
      'Cambiar la contraseña del tenant para que nadie pueda entrar a mirar alertas.',
    ], 1,
    'Las Maintenance Windows permiten planificar tareas de mantenimiento programadas, evitando que Davis AI abra Problems o envíe alertas innecesarias durante la ventana autorizada.'),

  q(33, 'welcomemelt', 'high-cardinality', 'scenario',
    'Un equipo de desarrollo desea incorporar el número de tarjeta de crédito de cada cliente como una dimensión en una métrica de rendimiento. ¿Por qué esto es una pésima práctica según los principios de Dynatrace?',
    [
      'Porque las tarjetas de crédito tienen baja entropía y no aportan valor.',
      'Porque vulnera normativas de seguridad/privacidad de datos (PII/PCI-DSS) y genera alta cardinalidad explosiva que degrada el rendimiento de las consultas y dispara costes.',
      'Porque Dynatrace solo admite nombres de animales como dimensiones de métricas.',
      'Porque los números de tarjeta de crédito solo pueden guardarse en formato de audio.',
    ], 1,
    'La alta cardinalidad (millones de valores únicos) en métricas degrada el rendimiento y multiplica series; además, almacenar información confidencial como tarjetas viola normativas de cumplimiento legal.'),

  q(34, 'welcomedps', 'custom-metrics-cost', 'knowledge',
    'En el modelo de consumo de Dynatrace, ¿qué factor técnico determina principalmente el coste de monitorización de métricas personalizadas (custom metrics)?',
    [
      'La marca de los monitores LCD utilizados por los administradores del sistema.',
      'El número de metric data points ingeridos y la cardinalidad de las dimensiones asociadas.',
      'La longitud en caracteres del nombre de la empresa titular de la suscripción.',
      'La velocidad en gigabits de la conexión de fibra óptica del proveedor de internet.',
    ], 1,
    'El consumo de métricas se rige por el volumen de data points ingeridos y la cantidad de series temporales creadas por dimensiones de alta cardinalidad.'),

  q(35, 'welcome101', 'classic-vs-latest', 'precision',
    '¿Cuál es una distinción operativa crucial entre la experiencia Classic de Dynatrace y la experiencia Latest (Platform on Grail)?',
    [
      'Classic no permitía monitorizar servidores Linux y Latest solo monitoriza Windows.',
      'Classic utilizaba repositorios de datos indexados separados para métricas y logs; Latest utiliza Grail como data lakehouse unificado con consultas DQL y aplicaciones basadas en AppEngine.',
      'Classic era un producto gratuito de código abierto y Latest es un servicio de pago sin agentes.',
      'Latest prohíbe el uso de OneAgent en infraestructuras cloud públicas.',
    ], 1,
    'Latest Dynatrace corre sobre la arquitectura Grail y AppEngine, unificando toda la telemetría en un único lago columnar analizable con DQL, superando la arquitectura compartimentada de Classic.'),

  q(36, 'welcomesmartscape', 'host-monitoring-mode', 'troubleshooting',
    'En un servidor con OneAgent configurado en modo "Infrastructure Monitoring", el administrador nota que no se visualizan transacciones de servicios Java en Smartscape. ¿Por qué ocurre esto?',
    [
      'Porque OneAgent no es compatible con el lenguaje de programación Java.',
      'Porque el modo Infrastructure Monitoring proporciona métricas de sistema operativo y procesos, pero desactiva la inyección profunda de código para distributed tracing y servicios.',
      'Porque el servidor tiene demasiada memoria RAM instalada.',
      'Porque Smartscape solo funciona en modo Discovery.',
    ], 1,
    'El modo Infrastructure Monitoring no incluye deep code-level tracing ni mapeo completo de servicios de aplicación; para obtener visibilidad profunda de servicios Java se requiere el modo Full-Stack.'),

  q(37, 'welcomedavis', 'alerting-profiles', 'precision',
    '¿Qué rol desempeñan los Alerting Profiles en la gestión de incidentes con Davis AI?',
    [
      'Controlan qué usuarios pueden iniciar sesión con autenticación de doble factor en la consola.',
      'Filtran y enrutan los Problems detectados por Davis hacia destinatarios o integraciones según severidad, management zones, tags y tiempo de demora.',
      'Configuran la velocidad de rotación de los ventiladores en los servidores físicos.',
      'Establecen el precio en dólares que cuesta cada notificación por correo electrónico.',
    ], 1,
    'Los Alerting Profiles permiten filtrar qué incidentes se notifican a qué equipos (ej. notificar solo Problems de severidad Availability en producción que duren más de 5 minutos).'),

  q(38, 'welcomemelt', 'trace-sampling', 'knowledge',
    '¿Qué significa el término "Trace Sampling" (muestreo de trazas) en observabilidad de aplicaciones?',
    [
      'La técnica de almacenar únicamente un porcentaje representativo de transacciones completas para optimizar almacenamiento y costes en escenarios de altísimo volumen.',
      'La acción de reiniciar los procesos de la aplicación cada 100 transacciones.',
      'El procedimiento de encriptar el disco duro del servidor con una clave RSA de 4096 bits.',
      'La obligación de escribir las trazas a mano en una hoja de cálculo cada noche.',
    ], 0,
    'Sampling es la selección controlada de transacciones para no saturar el almacenamiento en entornos que procesan cientos de miles de peticiones por segundo, preservando muestras estadísticamente sólidas.'),

  q(39, 'welcome101', 'automation-engine', 'knowledge',
    '¿Cuál es la función principal de AutomationEngine dentro de la plataforma Dynatrace?',
    [
      'Permite diseñar y ejecutar flujos de trabajo (Workflows) automatizados que reaccionan a Problems, eventos o programaciones para remediación y operaciones.',
      'Es un procesador de texto para redactar contratos laborales de los ingenieros de sistemas.',
      'Es un emulador de videojuegos retro integrado en la consola de administración.',
      'Es un servicio que formatea automáticamente los discos duros que superan el 80% de ocupación.',
    ], 0,
    'AutomationEngine es el motor de orquestación de Dynatrace que ejecuta Workflows basados en eventos, problemas o calendarios para automatizar respuestas operativas y remediaciones.'),

  q(40, 'welcomedps', 'dps-benefits', 'scenario',
    'Una empresa adopta una estrategia de migración a la nube donde apagará cientos de servidores on-premises y desplegará clústeres de Kubernetes en AWS. ¿Cómo ayuda el modelo DPS en esta transición?',
    [
      'Obliga a pagar multas por apagar los servidores antiguos antes del vencimiento del contrato.',
      'Permite transferir el consumo de forma automática: los créditos que se consumían en monitorización de hosts físicos pasan a utilizarse en Kubernetes Platform Monitoring sin penalizaciones.',
      'Exige que todos los clústeres de AWS sean gestionados exclusivamente por empleados de Dynatrace.',
      'Suspende la monitorización durante 6 meses hasta que la migración concluya al 100%.',
    ], 1,
    'DPS es ideal para transformaciones cloud: el presupuesto comprometido no está atado a máquinas fijas, por lo que el gasto se desplaza fluidamente hacia los nuevos workloads cloud.'),

  // 41-55: Escenarios Avanzados y Preguntas de Razonamiento Práctico
  q(41, 'welcomedavis', 'frequent-issue-detection', 'knowledge',
    '¿Cómo trata Davis AI un evento anómalo que se repite de forma idéntica cada día a la misma hora exacta debido a una tarea programada conocida?',
    [
      'Abre un Problem de severidad crítica cada día y bloquea el servidor.',
      'Aprende la estacionalidad periódica mediante sus baselines dinámicos y no abre falsos problemas si el comportamiento coincide con el patrón habitual previsto.',
      'Apaga el proceso programado para evitar que consuma recursos del sistema.',
      'Envía un informe de error al fabricante del sistema operativo.',
    ], 1,
    'Davis distingue anomalías reales de patrones estacionales habituales: si una tarea batch se ejecuta siempre a las 02:00 AM, el baseline se ajusta dinámicamente para no generar alertas falsas.'),

  q(42, 'welcome101', 'activegate-purposes', 'precision',
    '¿Cuáles son dos funciones operativas primarias de un Environment ActiveGate?',
    [
      'Actuar como proxy/concentrador de comunicaciones para OneAgents en redes privadas y ejecutar monitorización remota sin agente de cloud o VMware.',
      'Reemplazar el sistema operativo del host y formatear discos duros.',
      'Compilar aplicaciones Java en archivos ejecutables de Windows.',
      'Impedir que los usuarios puedan utilizar contraseñas en sus cuentas.',
    ], 0,
    'Un ActiveGate actúa como gateway seguro para enrutar telemetría de OneAgents aislados hacia el SaaS y ejecuta monitorizaciones remotas de infraestructura (ej. vCenter, AWS, Azure, GCP).'),

  q(43, 'welcomesmartscape', 'blast-radius', 'scenario',
    'En un Problem activo, la vista de Smartscape resalta en rojo una base de datos PostgreSQL, tres servicios backend en naranja y dos aplicaciones frontend en amarillo. ¿Qué representa este código de colores?',
    [
      'Rojo indica la entidad raíz del problema (Root Cause), naranja los servicios con impacto intermedio por dependencias, y amarillo las aplicaciones de cara al usuario afectadas (Blast Radius).',
      'Rojo indica que la entidad está funcionando bien y amarillo que está apagada.',
      'Es un mapa de calor puramente decorativo sin relación con la topología ni el incidente.',
      'Indica la versión de OneAgent instalada en cada uno de los servidores.',
    ], 0,
    'En la visualización de incidentes de Dynatrace, la codificación visual señala claramente la causa raíz (origen del fallo en rojo) y la propagación del impacto aguas arriba hacia los servicios y frontends.'),

  q(44, 'welcomemelt', 'bizevents-concept', 'knowledge',
    '¿Qué diferencia a un Business Event (`bizevent`) de un simple evento técnico de infraestructura en Grail?',
    [
      'Un Business Event transporta datos de negocio precisos (ej. importe de compra, ID de producto, tipo de póliza) sin muestreo estadístico, permitiendo análisis de conversión y facturación.',
      'Un Business Event solo puede generarse manualmente por el director general de la empresa.',
      'Un Business Event se borra a los 10 minutos de ser recibido en Grail.',
      'No hay diferencia: se almacenan en la misma tabla de logs sin campos adicionales.',
    ], 0,
    'Los Business Events aportan observabilidad de negocio con datos de nivel empresarial (business-grade) sin muestreo para alimentar dashboards ejecutivos y métricas de ingresos.'),

  q(45, 'welcome101', 'tagging-purpose', 'precision',
    '¿Cuál es la utilidad de aplicar Tags y Management Zones a las entidades monitorizadas en Dynatrace?',
    [
      'Aumentar la velocidad de reloj de los procesadores en un 15%.',
      'Organizar las entidades en grupos lógicos para delegar control de acceso granular, segmentar cuadros de mando y filtrar reglas de alertas por equipo responsable.',
      'Evitar que los servidores consuman memoria RAM durante los fines de semana.',
      'Impedir que OneAgent transmita trazas al clúster de Dynatrace.',
    ], 1,
    'Tags y Management Zones son fundamentales para la gobernanza multi-equipo: permiten aislar vistas, conceder permisos de acceso restringidos y dirigir alertas a los responsables de cada servicio.'),

  q(46, 'welcomedps', 'dps-custom-apps', 'knowledge',
    'Bajo el modelo DPS, ¿pueden las organizaciones desarrollar e instalar aplicaciones personalizadas sobre Dynatrace AppEngine?',
    [
      'No, está terminantemente prohibido instalar software que no haya sido programado por Dynatrace.',
      'Sí, las organizaciones pueden desarrollar aplicaciones a medida con Dynatrace AppEngine SDK e instalarlas en su tenant consumiendo recursos de plataforma de su suscripción DPS.',
      'Solo si la empresa entrega los derechos de autor de su código al registro mercantil de Austria.',
      'Solo se permite si las aplicaciones están escritas en lenguaje ensamblador x86.',
    ], 1,
    'AppEngine permite construir aplicaciones personalizadas interactivas que consumen datos de Grail y APIs de la plataforma, integrándose en el ciclo de vida de la suscripción DPS.'),

  q(47, 'welcomemelt', 'log-enrichment', 'precision',
    'Cuando OneAgent captura logs de un proceso monitorizado, ¿qué valor añadido proporciona respecto a un recolector de logs tradicional?',
    [
      'Traduce automáticamente todos los mensajes de error al idioma latín clásico.',
      'Enriquece automáticamente cada registro de log con metadatos contextuales de la entidad: `host.name`, `process.name`, `dt.entity.service` y `trace_id`.',
      'Elimina las líneas de log que contienen errores para que los informes salgan limpios.',
      'Comprime los logs de tal manera que nadie puede volver a leerlos con DQL.',
    ], 1,
    'El valor diferencial de OneAgent es el enriquecimiento contextual automático: cada línea de log se vincula inmediatamente con la entidad Smartscape y el trace context del proceso generador.'),

  q(48, 'welcome101', 'synthetic-vs-rum', 'knowledge',
    '¿Cuál es la diferencia complementaria entre Real User Monitoring (RUM) y Synthetic Monitoring?',
    [
      'RUM monitoriza a los usuarios reales en tiempo real; Synthetic ejecuta robots programados que simulan navegaciones periódicas para detectar caídas antes de que afecten a usuarios reales.',
      'RUM solo funciona en teléfonos inteligentes y Synthetic solo en relojes inteligentes.',
      'Synthetic es para usuarios reales de pago y RUM es para usuarios que utilizan software pirata.',
      'RUM se ejecuta únicamente una vez al mes y Synthetic cada milisegundo.',
    ], 0,
    'RUM y Synthetic forman los dos pilares de Digital Experience Monitoring (DEM): RUM mide la experiencia real diversa de clientes y Synthetic aporta una sonda de disponibilidad sintética 24/7.'),

  q(49, 'welcomedavis', 'root-cause-drilldown', 'scenario',
    'Un Problem de Davis indica que un servicio web tiene un tiempo de respuesta degradado y señala un método Java específico en un servidor como causante. ¿Qué vista de Dynatrace permite confirmar este hallazgo al nivel de código?',
    [
      'El panel de configuración de tarjetas de crédito del cliente.',
      'El análisis de trazas distribuidas y el desglose a nivel de método (Method hotspots / Service execution breakdown).',
      'El manual de usuario impreso en papel de la aplicación.',
      'La papelera de reciclaje del sistema operativo del ordenador cliente.',
    ], 1,
    'El desglose de ejecución de servicio y Method Hotspots permite inspeccionar los métodos Java, consultas SQL o llamadas de red exactas que consumen tiempo dentro de una transacción.'),

  q(50, 'welcomesmartscape', 'data-center-layer', 'knowledge',
    'En la capa más inferior de Smartscape (Data Center), ¿qué tipo de entidades se representan?',
    [
      'Las zonas de disponibilidad cloud (ej. AWS Availability Zone), centros de datos físicos o regiones cloud donde se ubican los hosts.',
      'Las aplicaciones móviles instaladas en los teléfonos de los clientes.',
      'Las tablas de bases de datos relacionales SQL.',
      'Los dashboards compartidos con usuarios externos de solo lectura.',
    ], 0,
    'La capa Data Center representa la ubicación física o lógica de infraestructura: regiones de nube pública (AWS, Azure, GCP) o centros de datos on-premises donde residen los servidores.'),

  // 51-68: Cierre y Maestría de Conceptos Fundamentales
  q(51, 'welcome101', 'support-center', 'knowledge',
    '¿Cuál es la función del Dynatrace Support Center accesible desde la plataforma?',
    [
      'Permite abrir tickets de soporte técnico, consultar documentación oficial, acceder a la comunidad y verificar el estado operativo de los servicios SaaS.',
      'Es una tienda para comprar ordenadores y servidores de segunda mano con descuento.',
      'Es un foro público para debatir sobre política y deportes.',
      'Es un servicio para solicitar el reembolso económico de facturas de luz del centro de datos.',
    ], 0,
    'El Support Center integra el acceso a tickets con expertos de Dynatrace, la comunidad de usuarios, base de conocimiento y el portal de estado de la plataforma.'),

  q(52, 'welcomedps', 'dps-transparency', 'precision',
    '¿Dónde puede un administrador monitorizar el consumo acumulado de créditos de su suscripción DPS en tiempo real?',
    [
      'En la aplicación Account Management / Subscription dentro de la plataforma Dynatrace.',
      'Enviando una carta postal certificada a la sede central de Dynatrace cada trimestre.',
      'Consultando el historial de navegación de Google Chrome en su ordenador portátil.',
      'El consumo de DPS es secreto y no puede ser consultado por los clientes.',
    ], 0,
    'Dynatrace Account Management proporciona visibilidad en tiempo real del consumo de crédito DPS desglosado por capability, entorno y mes.'),

  q(53, 'welcomemelt', 'grail-benefits', 'scenario',
    'Una empresa experimenta un ciberataque y necesita buscar un indicador de compromiso (IoC) en 50 TB de logs generados durante las últimas dos semanas. ¿Por qué Grail permite esta investigación de forma inmediata?',
    [
      'Porque Grail requiere indexar previamente cada palabra en una base de datos que tarda semanas en procesarse.',
      'Porque Grail realiza consultas paralelas masivas sobre datos columnares sin necesidad de reindexar, permitiendo que DQL filtre petabytes en segundos con schema-on-read.',
      'Porque Grail solo guarda logs de servidores que no han sufrido ataques cibernéticos.',
      'Porque Dynatrace borra automáticamente los logs que contienen ataques de seguridad.',
    ], 1,
    'La arquitectura masivamente paralela y columnar de Grail con schema-on-read permite realizar análisis forenses sobre petabytes de datos en segundos sin esperar procesos de reindexación.'),

  q(54, 'welcomedavis', 'event-types', 'knowledge',
    '¿Cuáles son ejemplos de tipos de Davis events que pueden asociarse a una entidad monitorizada?',
    [
      'Availability events, Error events, Slowdown events y Resource saturation events.',
      'Eventos de cumpleaños, eventos deportivos y eventos musicales.',
      'Eventos de encendido de luces de oficina y control de climatización.',
      'Eventos de cobro de comisiones bancarias mensuales.',
    ], 0,
    'Davis clasifica las anomalías por severidad y tipo: Availability (caída completa), Error (aumento de tasa de fallos), Slowdown (degradación de latencia) y Resource (saturación de CPU/disco).'),

  q(55, 'welcome101', 'open-standards', 'knowledge',
    '¿Qué postura mantiene Dynatrace respecto a estándares abiertos de la industria como OpenTelemetry y W3C Trace Context?',
    [
      'Prohíbe totalmente el uso de estándares abiertos para obligar a usar protocolos propietarios.',
      'Es compatible de forma nativa: soporta ingestión directa de datos OTLP (OpenTelemetry Protocol) y propaga estándares W3C en distributed tracing.',
      'Solo permite OpenTelemetry si el cliente paga una sanción económica por no usar OneAgent.',
      'Convierte los datos de OpenTelemetry en archivos de texto ilegibles.',
    ], 1,
    'Dynatrace abraza los estándares abiertos: ingesta de forma nativa telemetría OTLP (logs, métricas, trazas) y enriquece los datos de OpenTelemetry con el contexto de Grail y Smartscape.'),

  q(56, 'welcomesmartscape', 'cross-tier-analysis', 'scenario',
    'Un arquitecto observa que un servicio de backend `PaymentService` realiza 500 llamadas por segundo a una base de datos Oracle. ¿En qué vista de Dynatrace puede ver este flujo de transacciones reflejado visualmente?',
    [
      'En el Service Flow o en la vista de dependencias horizontales de Smartscape.',
      'En la papelera de reciclaje de Windows.',
      'En el visor de eventos local de la impresora de red.',
      'En una hoja de cálculo Excel sin conexión.',
    ], 0,
    'Service Flow y las vistas de relaciones de Smartscape ilustran de forma gráfica la secuencia completa de llamadas y el volumen de tráfico que fluye entre servicios y bases de datos.'),

  q(57, 'welcomedps', 'dps-scalability', 'knowledge',
    '¿Qué ocurre en DPS si una empresa despliega 500 nuevos microservicios en un clúster de Kubernetes en cuestión de minutos?',
    [
      'La plataforma los detecta e instrumenta automáticamente, registrando el consumo de crédito correspondiente sin necesidad de solicitar licencias previas.',
      'OneAgent bloquea los contenedores hasta que el director financiero firme un nuevo contrato comercial.',
      'El clúster de Kubernetes se apaga automáticamente por exceso de microservicios.',
      'Dynatrace envía una notificación judicial al proveedor de internet.',
    ], 0,
    'La gran ventaja operativa de DPS es la autoescalabilidad: OneAgent monitoriza los nuevos pods al instante y la facturación computa el consumo real sin fricciones de aprovisionamiento de licencias.'),

  q(58, 'welcome101', 'security-analytics-intro', 'knowledge',
    '¿Qué valor aporta la integración nativa de Application Security en la plataforma Dynatrace?',
    [
      'Permite detectar vulnerabilidades en tiempo de ejecución (runtime) en librerías y código propio usando la misma instrumentación de OneAgent sin agentes de seguridad adicionales.',
      'Obliga a los programadores a escribir código exclusivamente en lenguaje Pascal.',
      'Instala un antivirus tradicional que ralentiza los servidores de bases de datos.',
      'Elimina automáticamente el código fuente de los servidores que sufren escaneos de puertos.',
    ], 0,
    'Application Security aprovecha la presencia de OneAgent para detectar vulnerabilidades en memoria durante la ejecución real, correlacionándolas con la topología Smartscape y el Davis Security Score.'),

  q(59, 'welcomedavis', 'davis-co-pilot', 'knowledge',
    '¿Cuál es el rol de Davis CoPilot en la experiencia Latest de Dynatrace?',
    [
      'Es un asistente de inteligencia artificial generativa que ayuda a los usuarios a escribir consultas DQL, generar visualizaciones y automatizar tareas mediante lenguaje natural.',
      'Es un sistema de piloto automático para conducir vehículos de empresa autónomos.',
      'Es un robot físico que se instala en el centro de datos para cambiar discos duros estropeados.',
      'Es un protector de pantalla que muestra fotografías aéreas del paisaje de Austria.',
    ], 0,
    'Davis CoPilot es la IA generativa de Dynatrace que traduce preguntas en lenguaje natural a código DQL preciso, diseña dashboards y asiste en la investigación de incidencias.'),

  q(60, 'welcomemelt', 'cardinality-control', 'precision',
    'En el diseño de métricas para Grail, ¿cuál es el impacto de incluir identificadores únicos por transacción (como `order_id` o `user_id`) como dimensiones de métricas?',
    [
      'Mejora la velocidad de respuesta de las consultas DQL en un 200%.',
      'Provoca una explosión de cardinalidad que multiplica artificialmente el número de series temporales; esos datos deben enviarse como atributos de logs o Business Events, no como dimensiones de métricas.',
      'No tiene ningún impacto técnico ni financiero en la plataforma.',
      'Está bloqueado físicamente por el hardware de los servidores.',
    ], 1,
    'Regla de diseño de telemetría: los identificadores únicos con cardinalidad infinita pertenecen a trazas, logs o Business Events; utilizarlos en métricas colapsa los índices temporales.'),

  q(61, 'welcome101', 'hub-install-concept', 'precision',
    'Cuando un administrador localiza una nueva extensión para monitorizar un servicio cloud en Dynatrace Hub, ¿qué paso es indispensable antes de ver datos en el tenant?',
    [
      'La presencia en Hub solo indica disponibilidad en catálogo; se requiere instalar la extensión, configurar credenciales, asignar permisos y verificar la conectividad de red.',
      'Basta con mirar la tarjeta en Hub durante 10 segundos para que los datos aparezcan automáticamente.',
      'Es obligatorio reiniciar todos los servidores de la empresa.',
      'Se debe pagar una factura en metálico directamente en el banco.',
    ], 0,
    'Descubrir una solución en Hub no implica que esté activa: se debe realizar el ciclo completo de instalación, configuración de endpoints/credenciales y validación de ingestión.'),

  q(62, 'welcomedavis', 'problem-lifecycle', 'scenario',
    'Un Problem se abre en Dynatrace por saturación de CPU en un host. Veinte minutos después, el proceso causante finaliza y la CPU regresa a valores normales. ¿Qué acción realiza Davis AI automáticamente?',
    [
      'El Problem permanece abierto de por vida hasta que un operador lo borre manualmente.',
      'Davis detecta que la anomalía ha desaparecido, actualiza el estado del Problem a "Closed / Resolved" y registra la duración total del incidente.',
      'Davis reinicia el host para comprobar si la CPU vuelve a subir.',
      'Dynatrace cancela la suscripción del cliente por haber tenido un problema técnico.',
    ], 1,
    'Davis gestiona el ciclo de vida completo de forma autónoma: detecta el inicio, correlaciona eventos, evalúa la recuperación contra baselines y cierra el Problem cuando el sistema se estabiliza.'),

  q(63, 'welcomesmartscape', 'service-instance-mapping', 'precision',
    'Si un microservicio `OrderService` se despliega en 10 pods de Kubernetes distribuidos en 3 nodos diferentes, ¿cómo se representa en Smartscape?',
    [
      'Smartscape crea 10 servicios totalmente independientes con nombres aleatorios.',
      'Smartscape unifica las 10 instancias en un único Service lógico `OrderService`, mapeando sus 10 Process Group Instances (PGIs) a los 3 Hosts correspondientes.',
      'Smartscape no puede monitorizar más de un pod al mismo tiempo.',
      'Smartscape apaga 9 pods para simplificar la visualización del mapa.',
    ], 1,
    'Smartscape consolida la vista lógica: un único Service que agrupa las múltiples instancias de ejecución (PGIs) que corren en los distintos nodos del clúster de Kubernetes.'),

  q(64, 'welcomedps', 'commit-drawdown', 'knowledge',
    'En un contrato DPS, ¿cómo se deduce el consumo de la bolsa anual de compromiso (commitment)?',
    [
      'Mediante una cuota mensual fija inmutable sin importar el uso real de la plataforma.',
      'De forma diaria en función de la telemetría real procesada y las capacidades utilizadas (Host Units, gigabytes de logs, ejecuciones de workflows, etc.).',
      'Únicamente al final del contrato mediante una auditoría externa presencial.',
      'Solo se cobra si la empresa tiene más de 100 empleados registrados en nómina.',
    ], 1,
    'El consumo en DPS es transparente y continuo: cada día se descuenta del crédito global el volumen exacto de telemetría y servicios utilizados según el catálogo de precios unitarios.'),

  q(65, 'welcome101', 'investigation-reproducible', 'scenario',
    'Un analista concluye que un problema fue causado por una fuga de memoria en un servicio basándose únicamente en una captura de pantalla de un gráfico. ¿Por qué esta evidencia es insuficiente para una investigación formal?',
    [
      'Porque una captura de pantalla no es reproducible; se requiere documentar la consulta DQL exacta, la ventana temporal (timeframe), los filtros de entidad y los datos en Grail que sustentan la hipótesis.',
      'Porque las capturas de pantalla están prohibidas por la legislación europea de protección de datos.',
      'Porque Dynatrace no permite tomar capturas de pantalla de su interfaz web.',
      'Porque solo los vídeos en resolución 4K son aceptados como prueba de diagnóstico.',
    ], 0,
    'Una investigación técnica profesional exige reproducibilidad científica: registrar la consulta DQL, los parámetros de filtro, el timeframe UTC y los identificadores de entidad evaluados.'),

  q(66, 'welcomemelt', 'log-retention-control', 'knowledge',
    'En Grail, ¿dónde se define el tiempo que permanecerán almacenados los diferentes tipos de logs antes de ser purgados?',
    [
      'En la configuración de retención del bucket de almacenamiento donde son enrutados por OpenPipeline.',
      'En la memoria RAM del ordenador del usuario que lee los logs.',
      'En el cable de red que conecta el servidor con el router de internet.',
      'En el manual de instrucciones del servidor físico.',
    ], 0,
    'La retención de logs en Grail se administra a nivel de bucket: cada bucket tiene asignada una política de días de retención (ej. 35 días para `default_logs`, 365 días para auditoría).'),

  q(67, 'welcomedavis', 'impact-blast-radius', 'scenario',
    '¿Cuál es la diferencia entre la causa raíz (Root Cause) y el radio de impacto (Blast Radius) en un informe de incidencia de Davis?',
    [
      'Root Cause es el componente inicial donde se originó la avería técnica; Blast Radius es el conjunto total de servicios, aplicaciones y usuarios que sufren degradación como consecuencia.',
      'Root Cause es el coste económico de la reparación y Blast Radius es el nombre de la empresa proveedora de hardware.',
      'Root Cause es el número de teléfono del guardia de seguridad del centro de datos.',
      'No existe diferencia: son dos palabras inglesas que significan exactamente lo mismo.',
    ], 0,
    'Diferencia fundamental de arquitectura: Root Cause es el punto de falla de origen; Blast Radius es la amplitud del impacto que se extiende a través de la topología hacia los usuarios finales.'),

  q(68, 'welcome101', 'summary-mastery', 'knowledge',
    'En conclusión, ¿cuál es la ventaja estratégica de adoptar una plataforma de observabilidad unificada como Dynatrace frente a herramientas de nicho aisladas?',
    [
      'Permite reemplazar todas las bases de datos de clientes de la empresa por hojas de cálculo.',
      'Elimina los silos de información al unir métricas, logs, trazas, experiencia digital, seguridad y automatización sobre un modelo topológico común analizable en tiempo real.',
      'Garantiza que ningún ordenador de la empresa volverá a necesitar actualizaciones de seguridad.',
      'Reduce a cero el consumo de energía eléctrica de todos los centros de datos del mundo.',
    ], 1,
    'El valor supremo de Dynatrace radica en el contexto unificado: al integrar telemetría, topología Smartscape, IA causal Davis y almacenamiento en Grail, erradica los silos operativos y automatiza la remediación.'),
]
