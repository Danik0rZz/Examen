import type { StudyChapter, StudySection } from './study-content'
import { studyContent } from './study-content'
import { sourceCatalog } from './source-catalog'

const pickSources = (moduleId: string, offset: number, count = 3) => {
  const sources = sourceCatalog[moduleId] ?? []
  if (!sources.length) return []
  return Array.from({ length: Math.min(count, sources.length) }, (_, index) => sources[(offset + index) % sources.length])
}

const section = (moduleId: string, offset: number, value: Omit<StudySection, 'sourceRefs'>): StudySection => ({
  ...value,
  sourceRefs: pickSources(moduleId, offset),
})

const deepSections: Record<string, StudySection[]> = {
  welcome: [
    section('welcome', 0, {
      id: 'deep-dynatrace-101',
      title: '5. Dynatrace 101: Arquitectura y Fundamentos de la Plataforma',
      lead: 'Comprende los 5 pilares arquitectónicos transversales que sustentan la observabilidad unificada.',
      paragraphs: [
        'Dynatrace unifica los pilares de telemetría clásicos MELT (Metrics, Events, Logs, Traces) junto con datos de negocio (Business Events), seguridad en runtime (vulnerabilidades) y topología viva en un único almacenamiento: Grail. A diferencia de las soluciones fragmentadas que conectan bases de datos dispares con identificadores incoherentes, la plataforma mantiene un contexto continuo donde cada dato sabe a qué entidad pertenece, qué dependencias tiene y qué impacto produce en los usuarios.',
        'La jerarquía de entidades se estructura verticalmente: Host (máquina virtual o física) → Process Group (agrupación lógica de procesos) → Process Group Instance / PGI (ejecución concreta de un proceso o contenedor) → Service (interfaz lógica de llamadas y endpoints) → Application (interfaz web, móvil o servicio consumido por el usuario final). Smartscape mapea estas entidades en 5 capas y mantiene sus conexiones horizontales de tráfico de red y llamadas entre servicios.',
      ],
      comparison: {
        headers: ['Componente Arquitectónico', 'Propósito Principal', 'Diferencia Crítica de Examen'],
        rows: [
          ['Grail Data Lakehouse', 'Almacenamiento columnar sin esquemas rígidos (schema-on-read)', 'No requiere indexación previa ni bases de datos de series temporales separadas.'],
          ['Davis AI Causal Engine', 'Detección de anomalías y análisis de causa raíz determinista', 'Opera sobre el grafo topológico Smartscape, no mediante machine learning probabilístico tipo caja negra.'],
          ['Smartscape Topology', 'Grafo vivo y automático de dependencias en 5 capas', 'Conecta infraestructura con servicios y aplicaciones sin configuración manual de mapas de red.'],
          ['OneAgent & OpenPipeline', 'Ingestión automatizada de contexto profundo y control de flujo', 'Inyecta telemetría sin código y OpenPipeline transforma y enruta datos antes de persistir.'],
          ['DPS (Platform Subscription)', 'Modelo de consumo flexible basado en valor unificado', 'Permite utilizar cualquier capability de la plataforma sin licencias perpetuas rígidas.'],
        ],
      },
    }),
    section('welcome', 1, {
      id: 'deep-data-to-decision',
      title: '6. De la telemetría a una decisión operativa',
      lead: 'La plataforma adquiere valor cuando puedes explicar qué ocurrió, a quién afecta y qué acción está autorizada.',
      paragraphs: [
        'Una métrica, un log, un trace, un user event o un security finding son señales con formas y semánticas diferentes. La investigación Associate consiste en reconocer la señal, ubicarla en una entidad o record type, buscar relaciones y decidir qué aplicación o consulta reduce la incertidumbre. Una respuesta técnicamente correcta debe conservar el contexto: qué dato se observó, en qué ventana, con qué permisos y con qué limitación.',
        'El camino habitual no es lineal. Un Problem puede llevarte a un servicio; el servicio puede abrir una traza; la traza puede explicar un error de frontend; el frontend puede relacionarse con un journey o Business Event; y una acción de Workflow puede notificar o remediar. El examen evalúa que sepas elegir el siguiente paso con mayor valor diagnóstico, no que abras todas las aplicaciones disponibles.',
      ],
      bullets: [
        'Señal: el hecho observable y su timestamp.',
        'Contexto: entidad, topología, atributos, usuario o negocio.',
        'Hipótesis: explicación que todavía debe contrastarse.',
        'Evidencia: consulta, detalle, gráfico o configuración reproducible.',
        'Acción: comunicación, corrección o automatización dentro del permiso disponible.',
      ],
    }),
    section('welcome', 3, {
      id: 'deep-problem-davis',
      title: '7. Davis event, Problem, root cause e impact',
      lead: 'Estos conceptos están relacionados, pero no son sinónimos.',
      paragraphs: [
        'Un Davis event representa una anomalía o evento individual: una métrica que se desvía, un proceso que se cae, una degradación o un cambio informativo. Dynatrace Intelligence correlaciona eventos relacionados usando contexto temporal y topológico y presenta un Problem como situación agregada con causa e impacto. Por eso una pregunta que pide “cada anomalía individual” apunta a Davis events, mientras que una pregunta que pide “la situación correlacionada y su blast radius” apunta a Problem.',
        'Root cause identifica el candidato que mejor explica el incidente; impact muestra las entidades y posibles usuarios o aplicaciones afectados. El orden importa: no conviertas la primera entidad roja en una certeza sin revisar el árbol de causa, las dependencias y la evidencia temporal. Las correlaciones son una ayuda de investigación y deben leerse junto con el dato original.',
      ],
      comparison: {
        headers: ['Concepto', 'Qué representa', 'Uso en investigación'],
        rows: [
          ['Davis event', 'Anomalía o evento individual', 'Consultar señal y momento concreto'],
          ['Problem', 'Situación correlacionada', 'Priorizar incidente y ver conjunto afectado'],
          ['Root cause', 'Candidato causal principal', 'Empezar el drill-down técnico'],
          ['Impact', 'Alcance del efecto', 'Estimar blast radius y prioridad'],
        ],
      },
    }),
    section('welcome', 6, {
      id: 'deep-evidence-quality',
      title: '8. Calidad de evidencia y límites',
      lead: 'Un resultado vacío, una recomendación de AI o un gráfico bonito no son conclusiones por sí solos.',
      paragraphs: [
        'Antes de interpretar, pregunta si el dato pudo existir: ¿la tecnología está soportada?, ¿el agente o integración está habilitado?, ¿el pipeline aceptó y persistió la señal?, ¿la consulta usa el record type correcto?, ¿el timeframe contiene el evento?, ¿la identidad puede leerlo? Esta secuencia evita responder que “no hay problemas” cuando en realidad falta una fuente o un permiso.',
        'La documentación oficial delimita el comportamiento, pero el tenant puede tener una versión, licencia, configuración o política de acceso distinta. En la aplicación, cada explicación indica estas condiciones y la fuente asociada. Estudia el principio estable y después practica el matiz que convierte una afirmación verdadera en una respuesta incorrecta cuando se omite el contexto.',
      ],
      bullets: [
        'Dato no observado no significa necesariamente dato inexistente.',
        'Una capability listada en Hub no implica instalación ni ingestión activa.',
        'Una recomendación de Davis no sustituye la evidencia del entorno.',
        'La retención, el sampling y los permisos condicionan lo que puedes recuperar.',
      ],
    }),
    section('welcome', 8, {
      id: 'deep-associate-transfer',
      title: '9. Cómo convertir el path en dominio',
      lead: 'Cada apartado debe terminar en una explicación, una decisión y una práctica.',
      paragraphs: [
        'Para cada objetivo, estudia primero una definición con vocabulario oficial; después reconstruye el flujo de datos; luego compara el concepto con su vecino más parecido; finalmente resuelve un escenario con una restricción. Por ejemplo, OneAgent no se domina sabiendo que “monitoriza”: hay que distinguir qué recopila en cada modo, cuándo inyecta, cómo comunica y qué debes revisar si falta un dato.',
        'El banco de preguntas usa esa misma progresión. Las preguntas de conocimiento recuperan hechos; las de precisión detectan condiciones omitidas; las de escenario obligan a elegir; las de troubleshooting ordenan comprobaciones; y las mini-prácticas interpretan consultas o configuraciones. Un acierto sin poder justificar la fuente se considera dominio frágil.',
      ],
      bullets: [
        'Explica el concepto sin mirar.',
        'Diferéncialo de dos distractores cercanos.',
        'Aplica el concepto con una restricción realista.',
        'Revisa fuente, variante, permisos y fecha si es un dato sensible.',
      ],
    }),
  ],
  instructions: [
    section('instructions', 0, {
      id: 'deep-exam-readiness',
      title: '5. Prerrequisitos Técnicos y Reglas del Examen Supervisado',
      lead: 'Asegura la base técnica de redes, contenedores y la logística obligatoria de proctoring.',
      paragraphs: [
        'El examen Associate asume conocimientos consolidados de infraestructura de red y arquitectura de software. Toda la comunicación de OneAgent y ActiveGate hacia Dynatrace SaaS se realiza mediante conexiones salientes (outbound-only) por el puerto HTTPS 443; no se requieren puertos entrantes (inbound) en los firewalls perimetrales. Si la red corporativa exige proxies HTTP/HTTPS o archivos PAC (Proxy Auto-Configuration), OneAgent y ActiveGate pueden configurarse para respetarlos. Asimismo, debes comprender la resolución DNS, la terminación TLS y las arquitecturas de microservicios distribuidos que se ejecutan sobre plataformas de contenedores como Docker y Kubernetes (Nodes, Namespaces, Pods y Services).',
        'En el ámbito logístico, el examen es supervisado en remoto mediante el software ProctorU Guardian Browser. Los requisitos técnicos indispensables incluyen ordenador con permisos de administrador, cámara web activa con visión de 360 grados de la estancia, micrófono operativo, conexión a internet estable y estancia privada sin terceras personas ni monitores secundarios. El incumplimiento de cualquiera de estas condiciones puede suponer la cancelación inmediata de la sesión.',
      ],
      comparison: {
        headers: ['Área de Prerrequisito', 'Concepto Técnico Clave', 'Comportamiento en Examen'],
        rows: [
          ['Comunicaciones de Red', 'Outbound-only en puerto HTTPS 443', 'Los distractores que sugieren abrir puertos inbound (ej. 8020, 9999) en firewalls son siempre incorrectos.'],
          ['Proxies y Gateways', 'Proxy HTTP/HTTPS, PAC y ActiveGate', 'Permiten que hosts aislados sin internet directo alcancen el cluster Dynatrace.'],
          ['Kubernetes Mapping', 'Pod = Process Group Instance (PGI)', 'Un Pod es una instancia de ejecución que corre en un Node (Host) monitorizado.'],
          ['Guardian Browser', 'Navegador seguro de proctoring', 'Bloquea máquinas virtuales, software de escritorio remoto y extensiones del navegador no autorizadas.'],
        ],
      },
    }),
    section('instructions', 1, {
      id: 'deep-official-scope',
      title: '6. Qué es fuente de examen y qué es ampliación',
      lead: 'El path marca el alcance; la documentación vigente aporta la profundidad operativa.',
      paragraphs: [
        'El Learning Plan actual publica el Study Guide, el Exam Preparation Guide y las Practice Simulations como recursos de preparación. El PDF del path proporciona los doce apartados y sus objetivos. Dynatrace Docs es la autoridad para conceptos, procedimientos, permisos, límites y cambios de producto; una página de comunidad puede ayudar a localizar el path, pero no debe utilizarse para justificar un hecho técnico si existe una fuente oficial de producto.',
        'La guía interna traduce el contenido al español y conserva en inglés nombres de aplicaciones, permisos, entidades, campos y comandos. “Traducido” significa explicado con claridad, no sustituir `Process Group`, `Business Event`, `ActiveGate`, `Grail` o `timeseries` por palabras que ya no coincidan con la UI o la documentación.',
      ],
      comparison: {
        headers: ['Capa', 'Pregunta que responde', 'Cómo estudiarla'],
        rows: [
          ['Path', '¿Qué dominios entran?', 'Usarlo como índice y alcance'],
          ['Concepts', '¿Qué significa el producto?', 'Construir modelo mental'],
          ['How-to', '¿Cómo se habilita o usa?', 'Practicar pasos y prerequisitos'],
          ['Reference', '¿Qué campos, comandos o límites existen?', 'Memorizar matices verificables'],
        ],
      },
    }),
    section('instructions', 3, {
      id: 'deep-prerequisite-map',
      title: '7. Prerrequisitos técnicos que debes activar',
      lead: 'El examen presupone que entiendes el entorno donde viven las capacidades.',
      paragraphs: [
        'El path menciona SOA, application servers, arquitecturas web y móviles, bases de datos, redes, procesos, sistemas operativos y tecnologías cloud como Azure, Docker, Kubernetes, Cloud Foundry u OpenStack. No necesitas convertirse en administrador de cada tecnología, pero sí saber qué capa representa un host, un proceso, un service, un contenedor, una base de datos o un ActiveGate.',
        'Si una pregunta habla de una integración remota, tradúcela mentalmente a conectividad, credenciales, componente intermediario, permisos, datos producidos y consulta. Si habla de una aplicación distribuida, piensa en frontend, requests, services, procesos, dependencias y storage. Esta base evita elegir una respuesta de UI cuando el problema real pertenece a la arquitectura.',
      ],
      bullets: [
        'Repasa HTTP, TLS, DNS, proxies y comunicación outbound.',
        'Repasa proceso, process group, host, container y service.',
        'Repasa bases de datos, colas y dependencias remotas.',
        'Repasa JSON, timestamps, métricas, logs, traces y sampling.',
      ],
    }),
    section('instructions', 6, {
      id: 'deep-study-routine',
      title: '8. Rutina de estudio comprobable',
      lead: 'La app debe ayudarte a cerrar cada objetivo con evidencia de aprendizaje.',
      paragraphs: [
        'Una sesión eficaz comienza con la lectura del capítulo y sus fuentes internas. Después cierra la documentación y escribe de memoria las diferencias importantes. Resuelve ocho preguntas del quiz rápido; si fallas una pregunta de precisión, vuelve a la fila de hechos y al bloque fuente antes de intentar otra vez. Cuando consigas una base estable, completa el banco y termina con una práctica que obligue a explicar el razonamiento.',
        'Usa la confianza como una señal separada de la corrección. Un acierto con confianza baja merece revisión; un fallo con confianza alta revela una falsa seguridad y debe tener prioridad. La aplicación conserva el intento, la respuesta elegida, la explicación del distractor, la fuente y el capítulo relacionado para que el repaso no sea una lista anónima de letras.',
      ],
      bullets: [
        'Lectura profunda: 30–60 minutos según módulo.',
        'Recuperación libre: explicar sin mirar y comparar términos.',
        'Quiz rápido: detectar huecos iniciales.',
        'Banco: practicar precisión y escenarios.',
        'Repaso: corregir la causa del error, no solo repetir la opción.',
      ],
    }),
    section('instructions', 8, {
      id: 'deep-question-reading',
      title: '9. Lectura adversarial del enunciado y tácticas de búsqueda',
      lead: 'La precisión comienza antes de leer las opciones y al buscar en la documentación.',
      paragraphs: [
        'Subraya mentalmente el sujeto, la acción, la condición y el resultado pedido. “¿Qué permite?” no es lo mismo que “¿qué garantiza?”; “¿cuál es el primer paso?” no es lo mismo que “¿qué solución final?”; “Latest Dynatrace” no es lo mismo que Classic. Las palabras `only`, `always`, `best`, `first`, `read`, `write`, `actor`, `retention` y `injection` suelen cambiar el criterio.',
        'En un examen con acceso a documentación oficial abierta, la táctica de búsqueda debe ser extremadamente precisa: busca nombres de permisos exactos (`app-engine:apps:install`, `storage:bucket-definitions:write`), tablas de Grail (`dt.system.buckets`, `dt.entity.host`) o cláusulas DQL (`timeseries`, `summarize`). Comprueba siempre el banner superior de la documentación para verificar si el artículo aplica a Dynatrace Latest o Classic.',
      ],
      bullets: [
        'Identifica la variante y la capability.',
        'Distingue recomendación, requisito y límite.',
        'Comprueba si la respuesta requiere lectura, escritura o administración.',
        'Descarta absolutos no respaldados por documentación.',
      ],
    }),
  ],
  platform: [
    section('platform', 0, {
      id: 'deep-grail-records',
      title: '8. Grail como modelo de datos, no como palabra comodín',
      lead: 'Compartir almacenamiento no elimina las diferencias de esquema, retención o permisos.',
      paragraphs: [
        'Grail funciona como el almacenamiento unificado para logs, métricas, trazas, eventos, datos de negocio y otros record types. La consulta se realiza con DQL, pero cada objeto conserva campos, tipos, políticas de acceso y condiciones de ingestión. `fetch logs`, `fetch bizevents`, `fetch dt.davis.problems` y `timeseries` no son intercambiables: parten de fuentes y contratos diferentes.',
        'Los buckets organizan almacenamiento y permiten asociar retención y acceso. La tabla de sistema `dt.system.buckets` permite inspeccionar todos los buckets creados en el entorno, sus record types asociados y sus días de retención. ABAC y políticas pueden restringir records o campos. Por eso una consulta válida puede devolver menos datos que otra identidad, o una aplicación puede ocultar una propiedad sensible aunque el record exista. En el examen, separa siempre “está almacenado”, “puedo consultarlo” y “puedo modificarlo”.',
      ],
      bullets: [
        'Record type: estructura lógica consultable.',
        'Bucket: destino de almacenamiento, retención y gobierno.',
        'dt.system.buckets: tabla para auditar buckets y retenciones del tenant.',
        'DQL: lenguaje que lee y transforma el resultado.',
        'Permiso: condición de acceso de usuario, grupo, app o actor.',
        'Timeframe: ventana de análisis, no política de retención.',
      ],
    }),
    section('platform', 3, {
      id: 'deep-hub-lifecycle',
      title: '9. Dynatrace Hub, permisos IAM y ciclo de una capacidad',
      lead: 'Descubrir, instalar, autorizar y producir datos son estados distintos.',
      paragraphs: [
        'Dynatrace Hub es el catálogo central de apps, extensiones y soluciones. Cada ficha en Hub contiene tres pestañas principales: `Overview` (descripción funcional y casos de uso), `Contents` (artefactos empaquetados listos para usar: dashboards preconfigurados, notebooks de investigación y flujos de automatización) y `Technical information` (permisos IAM requeridos y requisitos de infraestructura).',
        'Para instalar una app desde el Hub se requiere el permiso IAM específico `app-engine:apps:install`, mientras que para desinstalarla se requiere `app-engine:apps:delete`. Visualizar la ficha de una aplicación no concede automáticamente privilegios para desplegarla en el entorno.',
      ],
      comparison: {
        headers: ['Pestaña / Estado', 'Qué contiene / Requisito', 'Distractor frecuente en examen'],
        rows: [
          ['Pestaña Overview', 'Descripción general, arquitectura y casos de uso', 'Creer que aquí se configuran las credenciales'],
          ['Pestaña Contents', 'Dashboards, Notebooks y Workflows preconfigurados', 'Buscar los artefactos en Settings o Administration'],
          ['Pestaña Technical info', 'Permisos requeridos (`app-engine:*`, `storage:*`)', 'Asumir que las apps se instalan sin permisos IAM'],
          ['app-engine:apps:install', 'Permiso IAM obligatorio para desplegar la app', 'Confundirlo con permisos de lectura o administración global'],
          ['app-engine:apps:delete', 'Permiso IAM obligatorio para retirar la app', 'Creer que cualquier editor de dashboard puede borrar la app'],
        ],
      },
    }),
    section('platform', 6, {
      id: 'deep-documents-permissions',
      title: '10. Documents, ownership y sharing controls',
      lead: 'Dashboards, Notebooks y Launchpads son documentos gestionados con control de acceso granular.',
      paragraphs: [
        'Quien crea un documento es su owner. En el panel de compartición, el propietario puede conceder acceso a usuarios y grupos específicos con permisos `Can view` o `Can edit`. Adicionalmente, existen controles avanzados como la casilla `Allow editors to share` (que autoriza a usuarios con rol de edición a compartir el documento con terceros) y la opción `Visible to anyone in your environment` (que permite que cualquier usuario autenticado en el tenant pueda ver el documento sin publicarlo en internet).',
        'En un escenario de colaboración, elige el nivel mínimo que permite el trabajo. Si el documento contiene queries sensibles, revisa el acceso a los datos subyacentes: compartir la vista no convierte automáticamente todos los datos en públicos ni elimina las reglas de storage. Los permisos del documento y los permisos de la aplicación o de Grail son capas distintas.',
      ],
      bullets: [
        'Can view vs Can edit: lectura o modificación del layout y tiles.',
        'Allow editors to share: delega la capacidad de compartir a colaboradores editores.',
        'Visible to anyone in your environment: visibilidad interna para todo el tenant sin exposición pública.',
        'Transfer ownership: transfiere la propiedad del documento a otro usuario.',
      ],
    }),
    section('platform', 9, {
      id: 'deep-problems-platform',
      title: '11. Problems como experiencia transversal y estructura de registros',
      lead: 'Problems une detección, topología, impacto y siguientes pasos en Grail.',
      paragraphs: [
        'La aplicación Problems presenta la situación correlacionada, sus entidades afectadas, root cause, impacto, severidad, timeline y resolución visual. En el modelo de datos de Grail, cada Problem se almacena con atributos específicos: el array `dt.davis.event_ids` contiene los identificadores de todos los Davis events correlacionados que componen el incidente. Además, los campos personalizados que se propagan o asocian a un Problem solo admiten valores de tipo string (texto); no admiten estructuras anidadas ni números flotantes sin parsear.',
        'La severidad orienta prioridad, pero no explica causa. Un problema crítico puede tener una root cause diferente de la entidad más visible para el usuario. Lee el grafo, la evidencia temporal y el impacto de negocio antes de comunicar una conclusión. Esta distinción alimenta preguntas trampa que presentan severity como si fuera root cause.',
      ],
      comparison: {
        headers: ['Campo / Atributo', 'Estructura en Grail', 'Implicación Práctica en Análisis'],
        rows: [
          ['dt.davis.event_ids', 'Array de strings con IDs de eventos', 'Permite unir el Problem con cada anomalía individual que lo disparó.'],
          ['Problem custom fields', 'Solo cadenas de texto (string values)', 'No se pueden enviar payloads JSON complejos en propiedades directas del Problem.'],
          ['Root cause entity', 'Identificador de la entidad causante', 'Punto de partida del análisis causal en Smartscape.'],
          ['Affected entities', 'Lista de entidades con impacto degradado', 'Determina el blast radius del incidente.'],
        ],
      },
    }),
  ],
  observability: [
    section('observability', 0, {
      id: 'deep-oneagent-capabilities',
      title: '8. OneAgent: qué puede observar y desde dónde',
      lead: 'La presencia del agente no equivale a cobertura completa.',
      paragraphs: [
        'OneAgent recopila métricas del sistema operativo, detecta procesos, observa tecnologías soportadas mediante code modules, puede inyectar RUM en páginas web, monitorizar logs y construir relaciones de red proceso-a-proceso. La cobertura concreta depende de plataforma, versión, tecnología, modo, configuración y capacidad habilitada. En móvil, la instrumentación usa bibliotecas compiladas para Android/iOS; no es el mismo mecanismo que inyectar JavaScript en un frontend web.',
        'Para servicios server-side, la cobertura puede incluir web services, web containers, database requests, custom services y relaciones entre componentes. En infraestructura, host, filesystem, disk, network, memory, OS services, process details y extensiones tienen condiciones diferentes. Host Monitoring mode proporciona métricas de infraestructura pero prescinde de inyección profunda en procesos.',
      ],
      comparison: {
        headers: ['Área', 'Ejemplos de cobertura', 'Condición que debes verificar'],
        rows: [
          ['Host', 'OS, CPU, memoria, disco, red', 'OneAgent, modo y soporte de plataforma'],
          ['Process', 'detección, runtime y detalles', 'proceso soportado e inyección'],
          ['Service', 'requests, llamadas, errores', 'tecnología y code module'],
          ['Frontend', 'RUM web y experiencia', 'inyección/configuración RUM'],
          ['Log', 'archivos de host o process group', 'descubrimiento y reglas de ingestión'],
        ],
      },
    }),
    section('observability', 2, {
      id: 'deep-oneagent-architecture',
      title: '9. Cómo funciona OneAgent internamente y CLI oneagentctl',
      lead: 'El agente combina procesos especializados, detección e instrumentación local.',
      paragraphs: [
        'OneAgent tiene procesos que recopilan métricas del sistema y detectan qué procesos se están ejecutando. Para tecnologías como Java, Node.js o .NET puede inyectar módulos y observar desde dentro del proceso. La herramienta de línea de comandos `oneagentctl` permite a los administradores del sistema interactuar directamente con la instalación local de OneAgent: consultar el estado del servicio, configurar endpoints de comunicación, definir proxy settings y ajustar el modo de monitorización localmente.',
        'La comunicación desde OneAgent hacia Dynatrace es exclusivamente saliente (outbound-only) por el puerto HTTPS 443. El agente puede conectarse directamente al Cluster SaaS o a través de uno o varios ActiveGates. La inyección de código dinámico enlaza librerías en memoria: si se modifica la configuración de auto-injection o se desactiva un code module, los procesos monitorizados deben ser reiniciados para que el cambio surta efecto.',
      ],
      bullets: [
        'oneagentctl: herramienta CLI para inspeccionar y configurar OneAgent en el host.',
        'Outbound-only por puerto 443: sin puertos de entrada requeridos en firewalls.',
        'Reinicio de procesos: obligatorio tras modificar reglas de code-module injection.',
        'RUM injection: añade el agente JavaScript a páginas web cuando corresponde.',
        'Log monitoring: descubre y almacena archivos según configuración.',
      ],
    }),
    section('observability', 4, {
      id: 'deep-oneagent-modes',
      title: '10. Full Stack, Infrastructure y Discovery',
      lead: 'Los modos son perfiles de cobertura y coste, no simples etiquetas de instalación.',
      paragraphs: [
        'Full-Stack es la opción de mayor profundidad para aplicaciones críticas: incluye tracing y profiling, detalles de proceso, análisis de disco, red y memoria, además de topology y basic monitoring. Infrastructure está orientado a salud de infraestructura y backing services; mantiene métricas de host y determinados runtime metrics mediante auto-injection, pero no ofrece la misma trazabilidad de aplicaciones. Discovery proporciona una huella ligera para descubrir hosts y procesos y está disponible bajo Foundation & Discovery del modelo DPS.',
        'Los tres modos comparten topology discovery, host criticality y basic monitoring. La tabla oficial distingue también extensions, custom metrics, Log Management, Application Security, Live Debugger, process injection, tracing y profiling. Una pregunta precisa puede preguntar qué se mantiene, qué es opt-in, qué está ausente o qué requiere activar code-module injection. Responde con la matriz y no con una frase genérica como “Discovery monitoriza menos”.',
      ],
      comparison: {
        headers: ['Capability', 'Full-Stack', 'Infrastructure', 'Discovery'],
        rows: [
          ['Topology/basic monitoring', 'GA', 'GA', 'GA'],
          ['Host process/details', 'profundo', 'disponible', 'no indicado en la matriz'],
          ['Tracing/profiling', 'GA', 'no disponible', 'no disponible'],
          ['Process injection', 'GA', 'opt-out', 'no estándar'],
          ['Application Security/Live Debugger', 'opt-in', 'opt-in', 'opt-in con requisitos'],
          ['Licensing focus', 'Full Stack', 'Infrastructure', 'Foundation & Discovery'],
        ],
      },
    }),
    section('observability', 6, {
      id: 'deep-oneagent-change-control',
      title: '11. Activación, cambio de modo e inyección',
      lead: 'Cambiar un modo es una operación de configuración con efectos observables.',
      paragraphs: [
        'El modo por defecto se puede definir antes de instalar OneAgent. Infrastructure puede establecerse durante o después de la instalación mediante `--set-monitoring-mode=infra-only`, UI o Settings API; Discovery usa `--set-monitoring-mode=discovery`. `--get-monitoring-mode` permite verificar el valor local. La respuesta no debe asumir que cambiar el selector de la UI ha modificado ya la profundidad de una aplicación que necesita reinicio o reinstrumentación.',
        'Desactivar auto-injection puede impedir que Application Security o Live Debugger descubran lo que dependía de esa instrumentación. Infrastructure puede inyectar runtime metrics para Java, .NET, Node.js, Go, PHP y algunos web servers, mientras que una instalación del agente como container tiene condiciones distintas. Discovery requiere habilitar code-module injection para ciertos usos de AppSec y Live Debugger y reiniciar procesos.',
      ],
      bullets: [
        'Verifica el modo después del cambio.',
        'Comprueba si el proceso necesita reinicio.',
        'Distingue auto-injection de code-module injection.',
        'Comprueba la precedencia de host settings frente a environment settings.',
        'Revisa el soporte de la tecnología concreta en la matriz oficial.',
      ],
    }),
    section('observability', 9, {
      id: 'deep-infrastructure-connectors',
      title: '12. Bases de datos, Kubernetes y ActiveGate 1.327+',
      lead: 'Infrastructure Observability combina OneAgent, ActiveGate, APIs y extensiones.',
      paragraphs: [
        'Las bases de datos monitorizadas remotamente requieren un ActiveGate group, conectividad directa hacia el servidor de base de datos, permisos y componentes adicionales como drivers cuando la extensión los necesita. OneAgent en el host puede aportar contexto complementario. La aplicación Databases separa fleet, instances, logical databases y host dependencies; no respondas que “Database monitoring” significa únicamente instalar OneAgent.',
        'Kubernetes utiliza ActiveGate para monitorizar la API de control del cluster y OneAgent para pods, contenedores y procesos. Para disponer de Enhanced Object Visibility (visibilidad avanzada de objetos de Kubernetes), la versión de ActiveGate debe ser 1.327 o superior. Versiones anteriores no recopilan la metadata completa requerida por la experiencia moderna de Kubernetes Platform Monitoring en Latest Dynatrace.',
      ],
      comparison: {
        headers: ['Escenario', 'Componente que suele intervenir', 'Qué validar'],
        rows: [
          ['Base de datos remota', 'Environment ActiveGate + extensión', 'driver, red, credenciales y permisos'],
          ['Kubernetes API', 'ActiveGate (versión 1.327+)', 'Enhanced Object Visibility, RBAC y cluster connection'],
          ['Kubernetes workload/process', 'OneAgent / Dynatrace Operator', 'modo Full-Stack, auto-injection en pods y namespace'],
          ['VMware vSphere', 'ActiveGate', 'vCenter/ESXi, lectura, red y grupo'],
        ],
      },
    }),
    section('observability', 12, {
      id: 'deep-observability-troubleshooting',
      title: '13. Árbol de troubleshooting de OneAgent',
      lead: 'Diagnostica por capas antes de concluir que falta soporte.',
      paragraphs: [
        'Cuando no ves una service o una métrica esperada, comienza por Deployment Status, versión y estado de conexión. Continúa con el modo de monitorización, auto-injection, proceso reiniciado, tecnología soportada y configuración de la capability. Si el dato debería venir de un ActiveGate o extensión, comprueba el grupo, endpoint, permisos y salud del gateway. Solo después revisa la UI, timeframe, management zone y query.',
        'Si el host aparece pero el servicio no, la causa puede estar en inyección, proceso no reiniciado, tecnología no soportada o reglas de process monitoring. Si el servicio aparece pero faltan logs, el problema está en descubrimiento, path, permisos de lectura de archivo, regla de ingestión, OpenPipeline, bucket o query. Si el problema solo afecta a un usuario, añade la capa de permisos y scope.',
      ],
      bullets: [
        'Conectividad y versión.',
        'Modo y capacidad habilitada.',
        'Proceso, reinicio e inyección.',
        'ActiveGate, extensión o integración.',
        'Ingestión, procesamiento y retención.',
        'Consulta, timeframe y permisos.',
      ],
    }),
  ],
  notebooks: [
    section('notebooks', 0, {
      id: 'deep-notebook-sections',
      title: '8. Anatomía de un Notebook y tipos de secciones',
      lead: 'Un Notebook combina exploración, consulta, código y narrativa.',
      paragraphs: [
        'Las secciones Explore permiten analizar logs, métricas, business events y otros datos con una interfaz point-and-click. Query escribe DQL contra Grail y ofrece autocomplete y timeframe; Code devuelve datos mediante Dynatrace functions en JavaScript/TypeScript; Markdown aporta contexto, fórmulas, enlaces, imágenes y conclusiones. Un Notebook grande se organiza con el panel de secciones, duplicación, ocultación, ejecución parcial o ejecución de todo el documento.',
        'El valor pedagógico de un Notebook está en dejar visible la pregunta, los filtros, la consulta, la visualización y la interpretación. Las variables reactivas (`$variable`) permiten parametrizar consultas de modo que cambiar un menú desplegable actualice instantáneamente todos los bloques DQL vinculados.',
      ],
      bullets: [
        'Explore: descubrimiento guiado visual.',
        'Query: consulta DQL directa y visualización sobre Grail.',
        'Code: lógica avanzada en JavaScript con Dynatrace AppEngine SDK.',
        'Markdown: explicación, anotaciones y documentación reproducible.',
        'Variables ($var): parámetros interactivos para filtrar consultas DQL.',
      ],
    }),
    section('notebooks', 2, {
      id: 'deep-dashboard-model',
      title: '9. Anatomía de un Dashboard, tiles y variables',
      lead: 'El Dashboard convierte análisis en seguimiento operativo o comunicación continua.',
      paragraphs: [
        'Los Dashboards en Latest Dynatrace soportan diversos tipos de tiles: Query tiles (ejecutan DQL y renderizan gráficos de barras, líneas, tablas o single values), Markdown tiles (para añadir títulos, notas explicativas y anotaciones operativas) y componentes especializados. El documento completo se almacena como una estructura JSON declarativa accesible y editable mediante la Document API.',
        'Las variables permiten dinamizar el Dashboard. Se referencian en DQL mediante la sintaxis `$variable`. Una variable puede ser de tipo DQL, Code, List o Free Text. Las variables pueden depender jerárquicamente de otras (por ejemplo, filtrar Procesos según el Host seleccionado), pero las dependencias circulares están prohibidas. El nombre de una variable no puede comenzar por el prefijo reservado de sistema `dt_`.',
      ],
      comparison: {
        headers: ['Elemento', 'Propósito en Dashboards', 'Regla Técnica / Restricción'],
        rows: [
          ['Query Tile', 'Ejecuta DQL contra Grail', 'Requiere permisos de lectura sobre las tablas consultadas'],
          ['Markdown Tile', 'Anotaciones y texto enriquecido', 'No ejecuta código dinámico; admite Markdown estándar'],
          ['Variable ($var)', 'Filtro reactivo interactivo', 'No puede comenzar con prefijo reservado `dt_`'],
          ['Document API JSON', 'Estructura declarativa del cuadro', 'Permite exportar y sincronizar dashboards con GitOps'],
          ['Drilldown Action', 'Enlace con contexto hacia Notebook/App', 'Transmite timeframe, entity IDs y filtros activos'],
        ],
      },
    }),
    section('notebooks', 4, {
      id: 'deep-document-sharing',
      title: '10. Sharing, ownership y acceso a datos',
      lead: 'Compartir el documento no elimina los permisos sobre las funciones o los datos.',
      paragraphs: [
        'El owner puede conceder acceso para todo el environment, seleccionar usuarios o grupos y crear share links. El acceso puede ser `Can view` o `Can edit`; un viewer puede leer la investigación, pero no debe asumirse que puede ejecutar todas las funciones, guardar cambios o consultar campos restringidos. Los permisos de documentos, AppEngine y Grail pueden interactuar.',
        'Cambiar el owner es una transferencia, no una copia: el owner anterior puede perder acceso inmediatamente. Cuando una pregunta pide un documento colaborativo, elige el nivel que satisface la necesidad sin añadir capacidad de escritura. Si un Notebook se abre como read-only pero la consulta base no devuelve datos, diagnostica document permission y data permission por separado.',
      ],
      bullets: [
        'Can view: lectura del documento.',
        'Can edit: cambios y ejecución dentro del alcance autorizado.',
        'Share link: acceso según el permiso del enlace.',
        'Owner: controla sharing y ownership.',
        'Data permissions: siguen aplicando al contenido subyacente.',
      ],
    }),
    section('notebooks', 6, {
      id: 'deep-analysis-recipe',
      title: '11. Receta de análisis reproducible',
      lead: 'Construye el documento desde la hipótesis y no desde una visualización al azar.',
      paragraphs: [
        'Primero escribe la pregunta en Markdown: disponibilidad, tendencia, causa, comportamiento, negocio o seguridad. Después elige el record type y timeframe. Empieza con una consulta pequeña para confirmar campos y tipos; añade filtros; selecciona campos; agrega o crea una serie temporal; visualiza y documenta la lectura. Conserva un ejemplo de resultado y la limitación conocida.',
        'Un Dashboard puede reutilizar un tile de Notebook, pero la transferencia debe mantener la consulta, la visualización y el contexto. Una tabla útil para operaciones no siempre es la mejor visualización para un stakeholder. El criterio no es “qué gráfico queda mejor”, sino qué forma evita una interpretación errónea.',
      ],
      bullets: [
        'Pregunta y audiencia.',
        'Fuente, timeframe y scope.',
        'Query mínima validada.',
        'Reducción, agregación y visualización.',
        'Conclusión, limitación y enlace a la fuente.',
      ],
    }),
  ],
  'business-dem': [
    section('business-dem', 0, {
      id: 'deep-business-event-model',
      title: '8. Business Events y business-grade data',
      lead: 'Un hecho se convierte en Business Event cuando aporta precisión útil para el negocio.',
      paragraphs: [
        'Business Observability usa Business Events para representar acciones u ocurrencias con datos de negocio. El modelo exige metadatos consistentes como `event.provider` y `event.type`; `event.category` puede clasificar el hecho. Los eventos se capturan, procesan y analizan. Processing puede filtrar, parsear, enriquecer, transformar, extraer métricas, asignar seguridad y fijar retención antes de consultar con DQL.',
        'Business-grade data se caracteriza por completitud, accesibilidad, disponibilidad en tiempo real, granularidad, contexto de topología y retención larga según la configuración. Esto no significa que cualquier user event sea Business Event ni que la ausencia de sampling elimine duplicados, errores de modelado o problemas de captura. La pregunta de negocio debe definir qué hecho, identificador y dimensión necesita.',
      ],
      comparison: {
        headers: ['Concepto', 'Significado', 'Error frecuente'],
        rows: [
          ['User event', 'Evento del comportamiento del usuario', 'Llamarlo Business Event automáticamente'],
          ['Business Event', 'Hecho con datos business-grade', 'Confundirlo con una métrica técnica'],
          ['Business KPI', 'Indicador derivado para una decisión', 'Consultar un único evento como tendencia'],
          ['Journey', 'Secuencia de acciones/eventos', 'Inferirlo de una sola métrica'],
        ],
      },
    }),
    section('business-dem', 3, {
      id: 'deep-business-capture',
      title: '9. Captura, ingestión y enriquecimiento',
      lead: 'El origen determina qué campos se generan automáticamente y qué debes configurar.',
      paragraphs: [
        'Business Events pueden venir de OneAgent, RUM JavaScript API, OneAgent for Mobile, OpenKit, fuentes externas mediante `/bizevents/ingest`, logs y spans mediante OpenPipeline o acciones de Workflows. OneAgent puede capturar payloads en vuelo según reglas; las fuentes externas necesitan enviar el formato y metadatos requeridos. El API admite JSON y CloudEvents y tiene límites de payload y autenticación específicos.',
        'Dynatrace puede enriquecer eventos con información de aplicación, geolocalización, dispositivo y otros contextos, pero la forma exacta depende del origen. Cuando el evento nace en un API externo, no asumas que tiene los mismos campos automáticos que uno capturado por RUM o OneAgent. Revisa `event.provider`, `event.type`, timestamp, identificador de usuario y gobierno de datos antes de construir KPIs.',
      ],
      bullets: [
        'OneAgent: captura contextual desde servicios instrumentados.',
        'RUM/Mobile/OpenKit: eventos ligados a experiencia digital.',
        'API: control explícito del payload y autenticación.',
        'OpenPipeline: procesamiento de logs/spans y rutas.',
        'Workflow: generación de eventos desde automatización.',
      ],
    }),
    section('business-dem', 6, {
      id: 'deep-rum-session-semantics',
      title: '10. RUM en Grail: tablas user.events vs user.sessions y lifecycle',
      lead: 'RUM describe usuarios reales; comprende las tablas en Grail y el ciclo de vida de sesión.',
      paragraphs: [
        'En Latest Dynatrace, la telemetría de Digital Experience se organiza en dos tablas principales en Grail: `user.events` (que contiene cada evento de interacción atómico: clics, navegaciones, errores de JavaScript y cargas de página) y `user.sessions` (que almacena el registro consolidado de la sesión de usuario, su duración total y propiedades agregadas).',
        'El ciclo de vida de una sesión web RUM se rige por reglas estrictas de finalización: se cierra tras 30 minutos continuados de inactividad del usuario, al cerrar el navegador o pestaña, al alcanzar un tiempo máximo absoluto de 6 horas continuas, o de forma programática mediante la llamada a `dtrum.endSession()` en la JavaScript API.',
      ],
      comparison: {
        headers: ['Dimensión / Tabla', 'Qué contiene / Regla', 'Distractor común de examen'],
        rows: [
          ['Tabla user.events', 'Eventos atómicos (clicks, web requests, errors)', 'Intentar calcular visitas únicas consultando solo esta tabla'],
          ['Tabla user.sessions', 'Sesión agregada, duración, bounce y properties', 'Buscar eventos de clic detallados en la tabla de sesiones'],
          ['Inactividad: 30 minutos', 'Cierre automático si no hay nuevas interacciones', 'Confundir con la duración máxima total'],
          ['Límite máximo: 6 horas', 'Cierre forzado de sesiones muy prolongadas', 'Creer que una sesión puede durar días ininterrumpidamente'],
          ['dtrum.endSession()', 'Cierre programático explícito de la sesión', 'Creer que cerrar sesión en la app web siempre cierra la sesión RUM'],
        ],
      },
    }),
    section('business-dem', 9, {
      id: 'deep-synthetic-semantics',
      title: '11. Synthetic Monitoring y scripting con api.fail()',
      lead: 'Synthetic comprueba recorridos bajo condiciones controladas y valida aserciones de negocio.',
      paragraphs: [
        'Synthetic Monitoring ejecuta monitores HTTP y browser clickpaths desde localizaciones públicas gestionadas o privadas (mediante ActiveGate). A diferencia de RUM, que refleja el tráfico real y variado de usuarios, Synthetic ofrece una línea base de disponibilidad y tiempo de respuesta repetible bajo demanda o en un horario programado.',
        'En los pasos JavaScript avanzados de un browser clickpath, los ingenieros pueden interactuar con el DOM de la página y evaluar condiciones lógicas. Si una aserción de negocio falla (por ejemplo, el carrito muestra un importe incorrecto o falta un elemento crítico), se puede invocar el método `api.fail("mensaje de error descriptivo")`. Esto detiene el monitor inmediatamente y marca la ejecución como fallida con la causa documentada en el reporte.',
      ],
      bullets: [
        'api.fail("mensaje"): detiene y marca el test sintético como fallido en código JavaScript.',
        'HTTP Monitors: validación de disponibilidad y tiempos de respuesta de endpoints REST.',
        'Browser Clickpaths: simulación de flujos de interacción completos de usuario en navegador.',
        'Private Synthetic Locations: ejecución de pruebas sintéticas tras cortafuegos internos corporativos.',
      ],
    }),
    section('business-dem', 12, {
      id: 'deep-business-journeys',
      title: '12. Journeys, Business Flow y KPIs',
      lead: 'Un journey convierte eventos y acciones en una secuencia que puede medirse.',
      paragraphs: [
        'Analizar un journey implica identificar la secuencia de pasos, unir eventos con identificadores consistentes, segmentar por atributos y localizar abandono, fricción o conversión. Business Flow permite seguir procesos y KPIs en contexto, pero la calidad depende de que los eventos tengan `event.type`, provider, timestamp y claves de correlación coherentes. Una métrica técnica de latencia puede explicar fricción, pero no es automáticamente el KPI de conversión.',
        'Una pregunta de negocio bien definida incluye población, periodo, evento de inicio, evento de éxito, evento de abandono, dimensiones de segmentación y criterio de atribución. Después se comprueba que la fuente capture todos los hechos necesarios y que la retención del bucket cubra el horizonte de análisis. La aplicación tratará estas decisiones como mini-prácticas, no como vocabulario aislado.',
      ],
      bullets: [
        'Define start y success events.',
        'Valida identificadores y timestamps.',
        'Separa conteo de eventos, usuarios y sesiones.',
        'Segmenta por atributos business-grade.',
        'Comprueba retención y duplicados antes de concluir.',
      ],
    }),
  ],
  'data-analysis': [
    section('data-analysis', 0, {
      id: 'deep-signal-semantics',
      title: '8. Métricas, logs, trazas, eventos y sesiones',
      lead: 'La unidad de dato condiciona qué afirmación puedes hacer.',
      paragraphs: [
        'Una métrica es una serie numérica agregable con timestamp, key, dimensiones y resolución; un log es un registro de contenido que puede estructurarse mediante parsing; una traza está formada por spans que describen una ejecución distribuida; un Davis event representa una anomalía o cambio; una sesión agrupa eventos de experiencia. Pueden relacionarse por entidad, timestamp y trace context, pero no tienen el mismo muestreo, retención ni semántica.',
        'Antes de crear un gráfico, decide si necesitas una distribución, una tendencia, un conteo exacto, una tasa, una latencia, una secuencia o un caso individual. `summarize` puede producir una tabla de agregados; `timeseries` crea series temporales; una consulta de logs puede requerir `parse`; un Problem puede necesitar root-cause context. La forma de resultado no es un detalle visual: cambia la interpretación.',
      ],
      comparison: {
        headers: ['Señal', 'Mejor para', 'Cuidado'],
        rows: [
          ['Metric', 'tendencias, ratios y baselines', 'dimensiones, cardinalidad y agregación'],
          ['Log', 'detalle textual y contexto puntual', 'volumen, parsing y sensibilidad'],
          ['Trace/span', 'camino de una ejecución', 'sampling y propagación'],
          ['Davis event/Problem', 'anomalía correlacionada', 'evento individual frente a situación'],
          ['RUM session', 'comportamiento de usuario', 'lifecycle y variante Classic/Latest'],
        ],
      },
    }),
    section('data-analysis', 3, {
      id: 'deep-retention-reference',
      title: '9. Retención en Grail, buckets del sistema y permisos de retención',
      lead: 'Las cifras son memorizables solo si conservas el tipo de dato y la arquitectura.',
      paragraphs: [
        'En Grail, la retención se configura a nivel de bucket de almacenamiento. Para crear buckets nuevos o alterar la retención de un bucket existente se requiere el permiso IAM explícito `storage:bucket-definitions:write`. El bucket `default_logs` tiene una retención por defecto de 35 días (ampliable según el plan de DPS hasta 10 años), mientras que buckets del sistema como `security.events` y los eventos de Davis tienen retenciones estándar de 14 meses a 3 años.',
        'En cuanto a métricas, Metrics powered by Grail cuentan con 15 meses de retención incluidos con granularidad de 1 minuto por defecto (ampliables hasta 10 años). Esto contrasta con Metrics Classic (que históricamente almacenaba 5 años agregados). Distributed traces en Grail (`default_spans`) se configuran desde 10 días hasta 10 años. Diferencia siempre la retención del almacenamiento de la ventana temporal de la consulta.',
      ],
      comparison: {
        headers: ['Dato / Bucket', 'Retención por Defecto en Grail', 'Requisito para Modificar'],
        rows: [
          ['default_logs', '35 días por defecto (hasta 10 años)', 'storage:bucket-definitions:write'],
          ['Metrics powered by Grail', '15 meses incluidos (1 min resolución)', 'storage:bucket-definitions:write'],
          ['security.events', '365 días (1 año) a 3 años según tipo', 'Bucket de sistema gobernado'],
          ['Davis Problems / Events', '14 meses de retención', 'No vinculado a retención de logs origen'],
          ['default_spans (Distributed Traces)', '10 días por defecto (hasta 10 años)', 'Configuración de bucket de spans'],
        ],
      },
      warning: 'Estas cifras son referencias oficiales de Latest Dynatrace. Modificar la retención hacia un valor menor purga de forma permanente los datos más antiguos que el nuevo límite.',
    }),
    section('data-analysis', 6, {
      id: 'deep-metric-design',
      title: '10. Métricas, series temporales y timeseries default:0',
      lead: 'Una métrica útil necesita una definición que mantenga significado y coste controlado.',
      paragraphs: [
        'La key identifica qué se mide; el valor y la unidad definen la magnitud; las dimensiones permiten segmentar; el timestamp y la resolución determinan la serie temporal. Al consultar métricas con DQL mediante el comando `timeseries`, los intervalos de tiempo en los que no se han registrado muestras se devuelven por defecto como `null`.',
        'Para rellenar estos vacíos con ceros y evitar saltos abruptos o líneas discontinuas en los gráficos, se utiliza el modificador `default:0` (por ejemplo: `timeseries cpu = avg(dt.host.cpu.usage), default:0, interval:5m`). Esto asegura que cada intervalo temporal tenga un valor numérico definido.',
      ],
      code: 'timeseries requests = sum(dt.service.request.count), default:0, interval:1m, by:{dt.entity.service}',
      codeNote: 'El parámetro default:0 rellena los minutos sin peticiones con el valor 0 en lugar de dejar huecos null en la gráfica.',
    }),
    section('data-analysis', 8, {
      id: 'deep-reporting-analysis',
      title: '11. Reporting, exportación y reproducibilidad',
      lead: 'Un reporte útil comunica evidencia y límites, no solo un número.',
      paragraphs: [
        'Un report debe declarar periodo, timezone, filtros, población, origen, unidad y timestamp de actualización. Si un Dashboard se distribuye a stakeholders, conserva la definición del KPI y una nota de interpretación. Si exportas a otra plataforma, comprueba API, permisos, paginación, formato, límites y si el resultado es una copia puntual o una consulta que se recalcula.',
        'La exportación no corrige retención ni permisos. Si un registro ya no está disponible, un endpoint de consulta no lo recupera mágicamente; si el usuario no tiene acceso, el reporte no debe elevar privilegios. Los datos exportados pueden tener sensibilidad propia y requieren el mismo gobierno que el origen.',
      ],
      bullets: [
        'Report: contexto y decisión para una audiencia.',
        'Dashboard: seguimiento persistente.',
        'Notebook: análisis reproducible.',
        'API/export: integración externa con contrato explícito.',
      ],
    }),
    section('data-analysis', 10, {
      id: 'deep-baselines-impact',
      title: '12. Baselines, anomalías e impacto',
      lead: 'La AI contextualiza, pero debes entender qué evidencia utiliza.',
      paragraphs: [
        'Dynatrace Intelligence puede comparar comportamiento con baselines, generar Davis events y correlacionar dependencias en Problems. La línea base, el timeframe, la estacionalidad, el tipo de métrica y la calidad de ingestión condicionan la detección. Una anomalía detectada no es automáticamente una causa; puede ser un síntoma o un evento informativo.',
        'Impact analysis recorre la topología para identificar aplicaciones de entrada, servicios afectados, entidades, SLOs y posibles usuarios. Usa esta información para priorizar, pero conserva la distinción entre impacto observado y causalidad. En preguntas de análisis, la respuesta más precisa suele combinar señal, contexto topológico y evidencia del usuario o negocio.',
      ],
      comparison: {
        headers: ['Pregunta', 'Evidencia principal'],
        rows: [
          ['¿Qué cambió?', 'métrica, log, trace o event en timeframe'],
          ['¿Por qué?', 'root-cause candidate y dependencias'],
          ['¿A quién afecta?', 'impact, entry points, RUM y SLO'],
          ['¿Qué hago?', 'siguiente comprobación o Workflow autorizado'],
        ],
      },
    }),
  ],
  dql: [
    section('dql', 0, {
      id: 'deep-dql-pipeline',
      title: '8. Modelo mental de DQL y filtros temporales explícitos',
      lead: 'DQL es una tubería de records y fields; el orden y el timeframe son fundamentales.',
      paragraphs: [
        'Una consulta DQL contiene comandos separados por `|`. El primer comando carga o genera datos; los siguientes filtran, seleccionan, transforman, agrupan, ordenan o limitan. Cada paso recibe la salida anterior. Para que una consulta sea determinista y reproducible independientemente del selector de la UI, se debe fijar el timeframe de forma explícita en el primer comando mediante `from:now()-2h`, `from:now()-7d` o `to:now()`.',
        'La consulta correcta debe producir la forma que necesita la aplicación. Para una tabla de top hosts, `fetch` + `filter` + `summarize` + `sort` + `limit` es apropiado. Para una gráfica de CPU, `timeseries` define la serie y el intervalo. Para investigar logs de contenedores, se filtran atributos semánticos estándar como `k8s.container.name` y `k8s.pod.name`.',
      ],
      code: 'fetch logs, from:now()-2h, to:now()\n| filter k8s.namespace.name == "production"\n| filter loglevel == "ERROR"\n| summarize error_count = count(), by:{k8s.container.name}\n| sort error_count desc\n| limit 10',
      codeNote: 'El timeframe explícito asegura que la query devuelva exactamente las últimas 2 horas en cualquier contexto de ejecución.',
    }),
    section('dql', 2, {
      id: 'deep-dql-command-contract',
      title: '9. Contrato de los comandos esenciales y arrays en DQL',
      lead: 'Comprende el manejo de estructuras anidadas y manipulación de listas en DQL.',
      paragraphs: [
        'DQL cuenta con funciones nativas para inspeccionar y transformar arrays: `arraySize(array)` devuelve la cantidad de elementos, `arrayContains(array, value)` evalúa si un elemento está presente, y el comando `expand` desanida un array creando una fila independiente para cada elemento de la lista.',
        'Un error frecuente es usar `limit` antes de una agregación: puedes contar solo la muestra limitada, no el conjunto completo. Otro es filtrar un campo después de eliminarlo con `fields`, o intentar aplicar una función de string a un record. Lee la forma de salida tras cada pipe y comprueba el tipo antes de seguir.',
      ],
      comparison: {
        headers: ['Operación sobre Array', 'Sintaxis DQL', 'Efecto en el Pipeline'],
        rows: [
          ['Contar elementos', 'fieldsAdd n = arraySize(items)', 'Agrega una columna numérica con la longitud del array'],
          ['Verificar existencia', 'filter arrayContains(tags, "critical")', 'Conserva solo las filas donde el array contiene el valor'],
          ['Aplanar lista (unwind)', '| expand item = items', 'Multiplica las filas del dataset: una fila por cada elemento del array'],
          ['Acceso por índice', 'fields first_item = items[0]', 'Extrae el elemento en la posición 0'],
        ],
      },
    }),
    section('dql', 4, {
      id: 'deep-dql-aggregation',
      title: '10. `summarize` frente a `timeseries`',
      lead: 'La elección depende de la forma temporal y de la pregunta.',
      paragraphs: [
        '`summarize` produce una salida tabular agrupada por expresiones en `by:{...}` y acepta agregaciones como `count()`, `avg()`, `sum()` o `countDistinct()`. Es adecuado para top lists, conteos por servicio, errores por nivel o una tabla de resultados. Para incluir tiempo en una tabla, puedes agrupar por un bin temporal, pero el resultado sigue siendo tabular.',
        '`timeseries` está diseñado para métricas y devuelve una estructura de series con timeframe e interval. Es la opción natural para evolución de CPU, latencia o throughput y permite visualizaciones temporales. No uses `summarize` o `timeseries` por costumbre: pregunta si necesitas filas agrupadas o una serie homogénea con puntos temporales.',
      ],
      code: 'timeseries avg(dt.host.cpu.usage), interval:1h, by:{dt.entity.host}, from:now()-3d\n\nfetch logs, from:now()-3d\n| summarize errors = count(), by:{loglevel}',
      codeNote: 'La primera consulta devuelve series temporales para gráficas; la segunda devuelve filas tabulares agrupadas.',
    }),
    section('dql', 7, {
      id: 'deep-dql-types-records',
      title: '11. Tipos, arrays y records',
      lead: 'DQL es strongly typed: el tipo limita las funciones y operadores válidos.',
      paragraphs: [
        'Los tipos primitivos incluyen boolean, string, long, double, timestamp y duration. Los tipos complejos incluyen array y record. Un record contiene pares clave-valor y se accede con índices o claves; un array se indexa por posición. JSON y KVP parseados suelen producir records. Si comparas un número como string, o tratas un array como un escalar, la consulta puede fallar o tener semántica distinta.',
        'Usa funciones de conversión cuando la fuente sea flexible y valida nulls o campos ausentes. `fieldsAdd` puede construir campos calculados; `parse` puede extraer un record; después puedes leer `record[field]` o anidar acceso. Las mini-prácticas de este módulo muestran el resultado esperado para que aprendas a predecir la forma, no solo a reconocer sintaxis.',
      ],
      code: 'data record(payload="{\"status\":\"ok\",\"count\":3}")\n| parse payload, "JSON:json"\n| fields json[status], json[count]',
      codeNote: 'El parsing JSON crea un record cuyos campos se pueden leer por clave.',
    }),
    section('dql', 9, {
      id: 'deep-dql-dpl',
      title: '12. DQL y DPL no son el mismo lenguaje',
      lead: 'DQL orquesta la consulta; DPL describe cómo reconocer patrones.',
      paragraphs: [
        'DPL es un lenguaje de patrones basado en matchers como `INTEGER`, `IPADDR`, `TIMESTAMP`, `STRING`, `DATA` y otros. Se utiliza con `parse` para extraer campos desde contenido y en OpenPipeline para procesar datos. DQL utiliza ese resultado para filtrar, agregar, ordenar o visualizar. Si una pregunta pide “qué lenguaje define el patrón”, la respuesta es DPL; si pide “cómo encadeno filtros y agregaciones”, es DQL.',
        'Un parser debe probarse con muestras reales y con casos que no coinciden. Un patrón demasiado amplio extrae datos incorrectos; uno demasiado estricto devuelve null o pierde registros. Estudia también escapes, JSON, KVP, contenido multilínea y la diferencia entre parsear en ingestión y parsear al consultar.',
      ],
      comparison: {
        headers: ['Tecnología', 'Responsabilidad', 'Momento'],
        rows: [
          ['DQL', 'consultar, filtrar, agregar y visualizar', 'query time y apps'],
          ['DPL', 'describir patrones y matchers', 'parse/query u OpenPipeline'],
          ['OpenPipeline', 'procesar, enrutar, enmascarar y extraer', 'ingestión/procesamiento'],
        ],
      },
    }),
    section('dql', 11, {
      id: 'deep-dql-performance',
      title: '13. Buenas prácticas, coste y límites',
      lead: 'Una consulta correcta también debe ser operable.',
      paragraphs: [
        'Reduce pronto el dataset con filtros sobre campos directos, selecciona campos temprano y evita joins o lookups innecesarios. Coloca `sort` cerca del final y no uses `limit` antes de una agregación salvo que esa muestra sea intencionada. El timeframe y las opciones de `fetch`, como bucket o scan limits documentados, controlan cuánto se procesa, pero no convierten una consulta en gratis ni sustituyen la política de acceso.',
        'La consulta ejecutada desde un Notebook puede tener comportamiento de timezone y timeframe distinto de una acción DQL en Workflows. La API o el Workflow puede usar UTC, un timeframe por defecto y límites de records distintos. Cuando una práctica se ejecuta fuera de la UI, documenta explícitamente `from`, `to`, timezone, permisos y forma del resultado.',
      ],
      bullets: [
        'Filtra por campos directos y temprano.',
        'Selecciona campos antes de transformaciones costosas.',
        'Agrega antes de ordenar grandes volúmenes.',
        'Define timeframe explícito en automatizaciones.',
        'Comprueba tipos, permisos, scanned records y límites de salida.',
      ],
    }),
  ],
  security: [
    section('security', 0, {
      id: 'deep-security-capabilities',
      title: '8. Mapa de Application Security y tabla dt.security.vulnerabilities',
      lead: 'La seguridad se entiende por tipo de riesgo, evidencia y consulta en Grail.',
      paragraphs: [
        'Application Security en Latest Dynatrace centraliza la gestión de riesgos en tiempo de ejecución. En Grail, la tabla `dt.security.vulnerabilities` permite consultar mediante DQL el inventario completo de vulnerabilidades activas, su estado de resolución, entidades afectadas y severidad calculada.',
        'La profundidad depende de OneAgent, tecnología, versión, modo de monitorización, capability, licencia y permisos. Una vulnerabilidad visible no significa que la aplicación esté explotada; una recomendación de Security Advisor no significa que la actualización se haya aplicado. El razonamiento debe separar detección, evaluación, priorización, remediación y verificación.',
      ],
      code: 'fetch dt.security.vulnerabilities\n| filter vulnerability.risk.level == "CRITICAL"\n| fields vulnerability.id, vulnerability.title, affected_entities\n| limit 20',
      codeNote: 'La tabla dt.security.vulnerabilities permite auditar de forma automatizada las vulnerabilidades críticas en Grail.',
    }),
    section('security', 2, {
      id: 'deep-third-party-code-level',
      title: '9. Third-party vs Code-level vulnerabilities',
      lead: 'El componente afectado determina el método de detección y la respuesta.',
      paragraphs: [
        'Third-party vulnerability analysis detecta librerías y dependencias externas de código abierto o comerciales vulnerables (asociadas a CVEs conocidos) cuando un proceso monitorizado las carga en memoria de ejecución. Si una librería vulnerable está en el disco pero nunca es invocada por el runtime, no se emite el hallazgo de riesgo activo.',
        'Code-level vulnerability analysis examina el código fuente propio desarrollado por la organización. Analiza cómo fluyen los datos de entrada del usuario a través de la aplicación en busca de fallos como SQL Injection, Command Injection o Cross-Site Scripting (CWEs) producidos por falta de validación o saneamiento de inputs.',
      ],
      comparison: {
        headers: ['Tipo de Vulnerabilidad', 'Origen del Fallo', 'Mecanismo de Detección en OneAgent'],
        rows: [
          ['Third-party Vulnerability', 'Librería o framework externo (CVE)', 'Detección de binarios/JARs cargados en memoria por el proceso'],
          ['Code-level Vulnerability', 'Código propio de la aplicación (CWE)', 'Análisis del flujo de entrada y sinks vulnerables en runtime'],
          ['Runtime Attack Analysis', 'Ataque activo en ejecución', 'Detección de payloads maliciosos intentando explotar el servicio'],
          ['Mute Rule (Silenciado)', 'Riesgo evaluado o falso positivo', 'Regla de gestión en la UI para suprimir alertas sin borrar código'],
        ],
      },
    }),
    section('security', 5, {
      id: 'deep-security-prioritization',
      title: '10. Priorización contextual con Davis Security Score (DSS)',
      lead: 'La prioridad es contextual: severidad CVSS y riesgo real no son idénticos.',
      paragraphs: [
        'El cálculo del Davis Security Score (DSS) pondera la puntuación base teórica de CVSS considerando tres factores determinantes del entorno de producción: 1) Public internet exposure (si el proceso o servicio es accesible directamente desde internet), 2) Reachable data assets (si el servicio afectado tiene acceso a bases de datos o almacenes de datos confidenciales), y 3) Public exploit availability (si existe código de explotación funcional documentado públicamente).',
        'Gracias a esta ponderación contextual, una vulnerabilidad con CVSS 9.8 en un servicio interno aislado puede recibir un DSS moderado, permitiendo a los equipos de seguridad priorizar incidentes con impacto real sobre activos expuestos.',
      ],
      bullets: [
        'Public internet exposure: incrementa drásticamente el DSS si el host tiene IP pública.',
        'Reachable data assets: incrementa el riesgo si el servicio se conecta a bases de datos.',
        'Public exploit availability: máxima prioridad si existen exploits funcionales en circulación.',
        'Mute rules: permiten documentar excepciones de seguridad y silenciar alertas aprobadas.',
      ],
    }),
    section('security', 8, {
      id: 'deep-security-modes',
      title: '11. Application Security y modos de OneAgent',
      lead: 'La cobertura de seguridad depende de la instrumentación disponible.',
      paragraphs: [
        'La tabla de monitoring modes marca Application Security como opt-in en Full Stack, Infrastructure y Discovery, pero las condiciones y la profundidad no son idénticas. En Discovery, code-module injection está deshabilitado por defecto y debe habilitarse para ciertos usos de Application Security y Live Debugger. En Infrastructure, auto-injection puede aportar runtime metrics de backing services, pero no convierte el modo en trazabilidad Full Stack.',
        'Si se desactiva auto-injection o se modifica la configuración de un módulo, pueden desaparecer descubrimiento de vulnerabilidades o Live Debugger aunque la capability aparezca habilitada. Comprueba versión, soporte de tecnología, modo, injection, reinicio de procesos, permisos y licencia antes de concluir que AppSec está roto.',
      ],
      bullets: [
        'Capability habilitada no significa code module cargado.',
        'Code-module injection puede requerir reinicio.',
        'Discovery tiene cobertura ligera y condiciones específicas.',
        'Infrastructure no equivale a Full Stack tracing.',
      ],
    }),
    section('security', 10, {
      id: 'deep-investigations',
      title: '12. Investigations como flujo de evidencia',
      lead: 'Investigar seguridad y operaciones comparte DQL, DPL y una cadena de evidencia.',
      paragraphs: [
        'Investigations permite crear un escenario, ejecutar queries, filtrar logs, extraer campos con DPL Architect, controlar timeframe, administrar query tree y conservar evidence. Puedes navegar desde resultados hacia entidades, traces, Notebooks u otras aplicaciones. La investigación no es un log viewer: conserva el camino de razonamiento para repetirlo o compartirlo.',
        'Para resolver un incidente, empieza por una señal o indicador, reduce la población, extrae los campos que permiten correlación, busca conexiones temporales y topológicas y adjunta la evidencia relevante. Los límites documentados de nodos y tamaño, el acceso al dato y la necesidad de log ingestion son parte de la evaluación. Un resultado sin contexto no prueba una hipótesis.',
      ],
      bullets: [
        'DQL para consultar.',
        'DPL para extraer estructura.',
        'Query tree para conservar evolución.',
        'Evidence para fijar hallazgos.',
        'Sharing controlado para colaborar.',
      ],
    }),
  ],
  automation: [
    section('automation', 0, {
      id: 'deep-workflow-anatomy',
      title: '8. Anatomía de un Workflow y tipos de acciones',
      lead: 'Un workflow es un grafo de trigger, tasks, actions, condiciones y resultados.',
      paragraphs: [
        'Un workflow puede arrancar on demand, por event, por schedule o mediante llamada API externa. Sus tasks ejecutan acciones nativas: Execute DQL Query (para recuperar registros de Grail), Run JavaScript (para ejecutar lógica de negocio algorítmica y llamar a APIs externas con fetch), HTTP Request, y notificaciones (Slack, Jira, ServiceNow, Email).',
        'Draft y live son estados distintos: los triggers automáticos solo arrancan la versión live publicada, aunque ambos estados pueden ser ejecutados de forma manual durante el desarrollo.',
      ],
      comparison: {
        headers: ['Tipo de Tarea en Workflow', 'Capacidad Técnica', 'Restricción de Seguridad'],
        rows: [
          ['Execute DQL Query', 'Consulta Grail y expone `records` y `metadata`', 'Sujeto a permisos de lectura de storage del actor'],
          ['Run JavaScript', 'Lógica en Node.js/TS con AppEngine SDK', 'No admite templating Jinja en input por seguridad'],
          ['HTTP Request', 'Llamadas a webhooks y servicios externos', 'Requiere endpoints y credenciales autorizados'],
          ['Run Workflow', 'Invocación de sub-workflows hijos', 'Comparte o delega contexto de ejecución'],
        ],
      },
    }),
    section('automation', 3, {
      id: 'deep-actor-permissions',
      title: '9. Actor, Service Users y permisos IAM en Workflows',
      lead: 'El servicio de automatización nunca supera los permisos del actor configurado.',
      paragraphs: [
        'Cada ejecución de un flujo ocurre en el contexto de un actor. En entornos de producción colaborativos, es una mala práctica dejar al creador personal como actor, ya que si el usuario pierde privilegios o abandona la empresa, el workflow fallará con errores 403. Para solucionar esto, se configuran Service Users (usuarios de servicio desatendidos), lo cual requiere el permiso IAM `iam:service-users:use`.',
        'Asimismo, la gestión del ciclo de vida del flujo se controla mediante permisos específicos de la capability de Automation: para crear, editar triggers o modificar tasks de un workflow se exige el permiso `automation:workflows:write`. Para ejecutarlo manualmente se requiere `automation:workflows:run`.',
      ],
      bullets: [
        'iam:service-users:use: autoriza a vincular un Service User como actor de ejecución.',
        'automation:workflows:write: permiso para crear, modificar y eliminar workflows.',
        'automation:workflows:run: permiso para iniciar ejecuciones bajo demanda o por API.',
        'Principio de mínimo privilegio: otorgar solo lectura de las tablas estrictamente consultadas.',
      ],
    }),
    section('automation', 6, {
      id: 'deep-execution-states',
      title: '10. Ejecución, tasks, retries y loops',
      lead: 'El estado final del workflow depende de la ejecución de sus tasks y actions.',
      paragraphs: [
        'Una workflow execution instancia el workflow; una task execution instancia una task; una action execution es la invocación concreta. Una ejecución puede estar Running, Success, Error o Canceled. Una task puede estar Idle, Running, Success, Error, Skipped, Discarded, Canceled o Waiting for approval. Entender esta jerarquía permite localizar si el fallo ocurrió antes de ejecutar, durante la acción o al evaluar una condición.',
        'Retries generan múltiples action executions dentro de una task; loops generan una ejecución por iteración y el resultado es una lista. Las condiciones de sucesores determinan si una task continúa tras error, cancelación o skip. El execution monitor conserva logs, input, params y result para revisar el camino real. No confundas “action returned successfully” con “query returned records”.',
      ],
      comparison: {
        headers: ['Objeto', 'Qué representa', 'Diagnóstico'],
        rows: [
          ['Workflow execution', 'una ejecución completa', 'estado global y trigger'],
          ['Task execution', 'una task dentro de una ejecución', 'condiciones, retries y sucesores'],
          ['Action execution', 'una invocación concreta', 'input, output, timeout y error'],
          ['Workflow result', 'resultado final evaluado', 'JSON válido y tamaño permitido'],
        ],
      },
    }),
    section('automation', 8, {
      id: 'deep-jinja-dql',
      title: '11. Jinja, DQL y datos entre tasks',
      lead: 'Las expresiones dinámicas tienen contexto, límites y reglas de seguridad.',
      paragraphs: [
        'Workflows usa Jinja con `{{ ... }}` para expresiones y `{% ... %}` para statements y estructuras de control. Puedes acceder a resultados de tareas predecesoras, event context, execution, calendarios y funciones, siempre en el contexto del actor. El Run JavaScript action es una excepción importante: no admite expresiones Jinja en su input para evitar code injection; usa sus SDKs y contexto nativo.',
        'La acción Execute DQL Query devuelve `records`, `types` y `metadata`. Puede tener timezone UTC, timeframe por defecto y límite de records diferente al Notebook. Si una query no devuelve records, la action puede estar en Success salvo que actives Fail on empty result. Pasa datos pequeños y estructurados entre tasks; no conviertas Workflows en pipeline de datos masivo.',
      ],
      code: '{{ result("query_task")["records"] | length > 0 }}\n\ndata json:"""{{ event()|to_json }}"""\n| fields timestamp, event.name, event.id',
      codeNote: 'Comprueba existencia antes de acceder al primer record y fija timezone/timeframe cuando la decisión dependa del calendario.',
    }),
    section('automation', 10, {
      id: 'deep-workflow-limits',
      title: '12. Event Triggers: límites de 1.000 caracteres y Simple Workflows',
      lead: 'Conoce las restricciones operativas y límites de ejecución de AutomationEngine.',
      paragraphs: [
        'Los Event Triggers permiten activar workflows automáticamente cuando entra un evento (Problems, Davis events, Business events o eventos de sistema). La expresión compilada de filtrado DQL en la configuración del Event Trigger tiene un límite máximo estricto de 1.000 caracteres. Además, existe un límite de 1.000 ejecuciones automáticas por hora por trigger para prevenir bucles descontrolados.',
        'Un Simple Workflow está compuesto por un único trigger y una única acción directa (por ejemplo, enviar un correo al detectar un problema). No consume horas de workflow directamente. Sin embargo, en el momento en que se agrega una segunda tarea al diseño, el flujo se convierte en un Workflow estándar.',
      ],
      bullets: [
        'Filtro DQL en Event Trigger: máximo 1.000 caracteres compilados.',
        'Límite horario de Event Trigger: hasta 1.000 ejecuciones por hora.',
        'Simple Workflow: exactamente 1 trigger y 1 task; no consume horas de workflow.',
        'Action result limit: máximo 6 MB por salida de acción.',
        'Workflow result limit: máximo 10 MB para el resultado global consolidado.',
      ],
    }),
  ],
  ingestion: [
    section('ingestion', 0, {
      id: 'deep-ingestion-lifecycle',
      title: '8. El ciclo completo de ingestión y Log Ingest API',
      lead: 'Aceptar un payload es solo una etapa del camino hacia una consulta útil.',
      paragraphs: [
        'Un dato recorre origen, instrumentación o exporter, transporte, autenticación, endpoint, OpenPipeline/procesamiento, bucket, retención, permisos y query. Cada etapa puede producir un síntoma parecido: “no veo datos”. Una respuesta profesional identifica el punto exacto con evidencia en lugar de culpar a la visualización.',
        'Para la ingestión de logs vía API HTTP REST, el endpoint oficial acepta payloads JSON con hasta 1.000 registros por solicitud HTTP POST. Se recomienda el uso de compresión `gzip` y autenticación mediante API Token con el scope `logs.ingest`. Enviar lotes mayores produce errores HTTP 413 (Payload Too Large).',
      ],
      bullets: [
        'Log Ingest API: límite de 1.000 registros por payload HTTP POST.',
        'Compresión recomendada: Content-Encoding: gzip.',
        'Bearer Token: requiere token con scope logs.ingest.',
        'Syslog en ActiveGate: puerto UDP/TCP 514 para recibir syslog de red.',
      ],
    }),
    section('ingestion', 2, {
      id: 'deep-log-ingestion',
      title: '9. Logs: OneAgent, API, ActiveGate y cloud',
      lead: 'Los logs tienen canales complementarios y una fase de procesamiento explícita.',
      paragraphs: [
        'OneAgent descubre y recopila logs de hosts y process groups cuando la configuración, permisos del sistema y reglas permiten leerlos. Log Ingestion API recibe logs de sistemas externos y serverless; Syslog puede entrar vía ActiveGate en el puerto 514; Kubernetes puede usar OneAgent, Fluent Bit, Collector, Logstash o Fluentd; cloud forwarding entrega logs desde servicios cloud. Extensions pueden recolectar y enviar logs junto con otras señales.',
        'Los logs se almacenan en Grail y pueden pasar por OpenPipeline para parse, extraction, masking, filtering, routing y métricas derivadas. Schema-on-read permite consultar contenido sin imponer un esquema rígido en el momento de entrada, pero una investigación de calidad todavía necesita conocer fields, tipos, timestamp y sensibilidad.',
      ],
      comparison: {
        headers: ['Origen/limitación', 'Mecanismo a evaluar', 'Matiz'],
        rows: [
          ['Host compatible', 'OneAgent', 'contexto automático y reglas'],
          ['Serverless/external', 'Log Ingestion API', 'endpoint, payload y token'],
          ['Syslog/private network', 'ActiveGate (puerto 514)', 'red, grupo y certificado'],
          ['Kubernetes', 'OneAgent/Collector/Fluent Bit', 'metadata y masking'],
          ['Cloud platform', 'forwarding/integration', 'región, servicio y permisos'],
        ],
      },
    }),
    section('ingestion', 5, {
      id: 'deep-openpipeline',
      title: '10. OpenPipeline: etapas Ingest, Process y Route',
      lead: 'OpenPipeline estructura el procesamiento de datos en tres fases secuenciales.',
      paragraphs: [
        'OpenPipeline es el motor de procesamiento en streaming de la plataforma Dynatrace. Opera sobre datos entrantes organizando el flujo en tres etapas obligatorias: 1) Ingest (recepción, validación inicial y asignación de metadatos de origen `dt.openpipeline.source.*`), 2) Process (transformaciones, extracción DPL, enriquecimiento y enmascaramiento de datos sensibles), y 3) Route (decisión de persistencia y asignación del bucket de destino).',
        'Durante el tránsito de la telemetría, OpenPipeline inyecta metadatos de auditoría como `dt.openpipeline.stage` y `dt.openpipeline.source.type`. Esto permite crear reglas condicionales avanzadas basadas en el canal de procedencia del dato.',
      ],
      comparison: {
        headers: ['Etapa OpenPipeline', 'Responsabilidad Principal', 'Reglas Aplicables'],
        rows: [
          ['Etapa 1: Ingest', 'Validación de formato y autenticación', 'Asignación de atributos `dt.openpipeline.source.*`'],
          ['Etapa 2: Process', 'Transformación y saneamiento de datos', 'Extracción con patrones DPL, masking de PII y descartes (drop)'],
          ['Etapa 3: Route', 'Destino final y particionado', 'Asignación a buckets (`default_logs` o buckets custom)'],
        ],
      },
    }),
    section('ingestion', 8, {
      id: 'deep-otel-signals',
      title: '11. OpenTelemetry para logs, métricas y traces',
      lead: 'OTLP aporta portabilidad, pero no elimina las decisiones de contexto y operación.',
      paragraphs: [
        'OpenTelemetry usa SDKs, auto-instrumentation y Collectors para producir o transportar logs, metrics y traces mediante OTLP. Dynatrace ofrece endpoints nativos para SaaS, ActiveGate y OneAgent según la arquitectura. El Collector puede batch, transformar o enmascarar antes de enviar. La configuración debe preservar resource attributes, service.name, trace context, timestamps y TLS.',
        'Cuando logs, metrics y traces no se correlacionan, comprueba propagación de trace IDs, naming de services, reloj, exporter, protocol HTTP/gRPC, endpoint y sampling. OTLP aceptado no significa que el campo sea útil en la UI; valida el record type en Grail, la entidad vinculada y la query mínima.',
      ],
      comparison: {
        headers: ['Componente', 'Función', 'Fallo típico'],
        rows: [
          ['SDK/agent', 'instrumentar y crear señales', 'no instrumenta la librería esperada'],
          ['Collector', 'batch, procesar y exportar', 'resource attributes o endpoint incorrectos'],
          ['OTLP endpoint', 'recibir señales', 'token, protocolo o TLS'],
          ['Grail/OpenPipeline', 'procesar y almacenar', 'bucket, masking o permisos'],
        ],
      },
    }),
    section('ingestion', 11, {
      id: 'deep-activegate-integrations',
      title: '12. ActiveGate, cloud y VMware',
      lead: 'ActiveGate es un componente de conectividad e integración, no un sustituto universal de OneAgent.',
      paragraphs: [
        'ActiveGate puede actuar como gateway entre agentes y Dynatrace, ejecutar monitorización remota, recibir o reenviar datos y alojar extensiones según el caso. Bases de datos, VMware y Kubernetes pueden necesitar grupos de ActiveGate con conectividad hacia la API o sistema de origen. Valida versión, endpoint, firewall, certificados, credenciales, permisos de lectura y distribución del grupo.',
        'En VMware, ActiveGate consulta la capa vCenter/ESXi y OneAgent en VMs aporta observabilidad complementaria del sistema operativo y procesos. En cloud, el alcance depende del servicio, región, permisos de API y feature set. Si la integración está instalada pero no hay datos, el troubleshooting debe separar autenticación, conectividad, descubrimiento, ingestión y consulta.',
      ],
      bullets: [
        'ActiveGate group correcto.',
        'Conectividad desde el gateway al origen.',
        'Permisos de lectura en cloud/vCenter/database.',
        'Versión compatible y extensión instalada.',
        'Entidades y métricas realmente producidas.',
      ],
    }),
    section('ingestion', 13, {
      id: 'deep-ingestion-governance',
      title: '13. Buckets, retención, seguridad y coste',
      lead: 'La ingesta termina en una política de almacenamiento que debes poder explicar.',
      paragraphs: [
        'El bucket define dónde se guardan records y qué políticas de retención y acceso se aplican. `default_logs` no es sinónimo de toda la retención de logs: puede existir una configuración custom y rutas que asignen otros buckets. Cambiar retención puede hacer que datos antiguos dejen de estar disponibles; limitar una query por timeframe no cambia el storage.',
        'La cardinalidad, el volumen, el enriquecimiento y la retención afectan consumo. Mide el valor de cada campo y dimensión antes de ingestar sin control. El masking debe ocurrir en la etapa adecuada para reducir exposición y el acceso debe usar permisos de bucket, table y record. Una respuesta técnicamente completa menciona utilidad, seguridad, coste y posibilidad de consulta posterior.',
      ],
      bullets: [
        'Define el dato que necesitas conservar.',
        'Asigna bucket y retención con intención.',
        'Enmascara o elimina PII en el punto correcto.',
        'Controla cardinalidad y volumen.',
        'Verifica permisos y query posterior.',
      ],
    }),
  ],
  other: [
    section('other', 0, {
      id: 'deep-smartscape-graph',
      title: '5. Smartscape como grafo de entidades y jerarquía de 5 capas',
      lead: 'La topología responde cómo se relacionan componentes en el modelo de datos de Grail.',
      paragraphs: [
        'La topología de Smartscape modela el entorno monitorizado en una jerarquía estricta de 5 capas: Data Center → Host → Process Group → Service → Application. Las relaciones verticales indican alojamiento (`runs on`), mientras que las relaciones horizontales representan comunicaciones de red o llamadas de servicio (`calls`).',
        'En Grail, las entidades se consultan con comandos dedicados como `fetch dt.entity.host` o `fetch dt.entity.service`. Las relaciones topológicas entre entidades se modelan en atributos de tipo array como `runs[dt.entity.service_instance]` o `is_instance_of`. Para poder consultar el inventario de entidades en Grail mediante DQL se requiere el permiso IAM explícito `storage:entities:read`.',
      ],
      comparison: {
        headers: ['Capa Smartscape', 'Entidad Grail Representativa', 'Atributo de Relación Topológica'],
        rows: [
          ['Capa 5: Application', 'dt.entity.application', 'calls[dt.entity.service]'],
          ['Capa 4: Service', 'dt.entity.service', 'runs[dt.entity.service_instance]'],
          ['Capa 3: Process Group', 'dt.entity.process_group', 'runs_on[dt.entity.host]'],
          ['Capa 2: Host', 'dt.entity.host', 'contained_in[dt.entity.data_center]'],
          ['Capa 1: Data Center', 'dt.entity.data_center', 'Ubicación física o cloud region'],
        ],
      },
    }),
    section('other', 2, {
      id: 'deep-log-investigation',
      title: '6. Investigar logs sin perder el contexto',
      lead: 'Filtra pronto, estructura después y conserva la evidencia.',
      paragraphs: [
        'Empieza con timeframe, fuente, host, service, severity o patrón relevante. Después inspecciona campos presentes y tipos. Si el contenido es texto o JSON, usa DQL y DPL para extraer `trace_id`, IP, código de error, endpoint o usuario. Comprueba los registros no coincidentes antes de concluir que la regla o parser funciona.',
        'Relaciona logs con entidad, trace y Problem cuando exista contexto. Una búsqueda textual puede encontrar el término, pero un filtro por campo es más preciso y suele ser más eficiente. Guarda query, muestra, timezone y criterio de inclusión para que otra persona pueda reproducir la investigación.',
      ],
      bullets: [
        'Acota timeframe y población.',
        'Filtra por fields cuando existan.',
        'Parsea solo lo que necesitas.',
        'Comprueba tipos y nulls.',
        'Relaciona con entidad o trace.',
      ],
    }),
    section('other', 5, {
      id: 'deep-entities-query',
      title: '7. Entidades y consulta con DQL (storage:entities:read)',
      lead: 'El mismo nombre visible puede ocultar niveles de entidad diferentes.',
      paragraphs: [
        'Host, Process Group, Process Group Instance, Service, Application, Container y Pod responden preguntas distintas. Host sirve para infraestructura; Process Group agrupa procesos que comparten identidad lógica; Process Group Instance representa una ejecución concreta; Service representa una unidad de servicio observable; Frontend/Application representa la experiencia de usuario. Elegir la entidad incorrecta produce un filtro demasiado amplio o una acción que no afecta al componente deseado.',
        'DQL permite consultar entidades mediante `fetch dt.entity.<tipo>` y unirlas a métricas y logs mediante lookups. Sin el permiso IAM `storage:entities:read`, las consultas a tablas de entidades serán rechazadas con un error de autorización 403.',
      ],
      code: 'fetch dt.entity.service\n| fields id, entity.name, runs[dt.entity.service_instance]\n| limit 20',
      codeNote: 'Consulta de servicios en Grail extrayendo los identificadores de las instancias que los ejecutan.',
    }),
    section('other', 7, {
      id: 'deep-hub-extensions',
      title: '8. Hub, apps y Extensions 2.0',
      lead: 'Las apps presentan capacidades; las extensiones conectan y producen observabilidad.',
      paragraphs: [
        'Dynatrace Hub centraliza aplicaciones, extensiones e integraciones. La ficha técnica incluye permisos, intents, contenidos y requisitos. Extensions 2.0 permite llevar métricas de tecnologías al modelo de la plataforma y conectarlas con analytics y monitoring. El lifecycle incluye instalar, configurar, actualizar, revisar release notes, comprobar permisos y validar datos producidos.',
        'No respondas “instala desde Hub” si el escenario también requiere ActiveGate, credenciales, un endpoint, un grupo de usuarios o una capability DPS. El nombre de la app no dice qué records crea, dónde se almacenan ni qué puede consultar cada usuario. Usa la ficha técnica y la documentación de la extensión como fuentes distintas de la vista de catálogo.',
      ],
      bullets: [
        'Catalog: descubrir.',
        'Install: hacer disponible.',
        'Configure: conectar origen y permisos.',
        'Run/use: ejecutar con permisos de aplicación.',
        'Observe: validar records, entities y métricas.',
      ],
    }),
    section('other', 9, {
      id: 'deep-cross-app-troubleshooting',
      title: '9. Drilldowns y diagnóstico transversal',
      lead: 'La investigación madura cambia de aplicación sin perder la entidad ni la evidencia.',
      paragraphs: [
        'Desde Smartscape o una tabla de resultados puedes abrir una entidad en otra aplicación, llevar una query a Notebook, navegar desde un Problem a la root cause, abrir logs desde un Pod o iniciar Investigations con el contexto seleccionado. El drilldown es útil porque mantiene una hipótesis y reduce trabajo manual; no es una invitación a abrir pestañas al azar.',
        'Cuando una transición pierde contexto, registra entity ID, timeframe, segment, query y filtro. Si la aplicación destino muestra algo diferente, compara permisos, variante, record type y timezone. El patrón transversal del path es siempre el mismo: identificar, acotar, relacionar, validar y actuar.',
      ],
      bullets: [
        'Preserva entity ID y timeframe.',
        'Verifica que el destino acepta el record type.',
        'Comprueba permisos de la aplicación y datos.',
        'Documenta la evidencia antes de cambiar de contexto.',
      ],
    }),
  ],
}

export const deepStudyContent: Record<string, StudyChapter> = Object.fromEntries(
  Object.entries(studyContent).map(([moduleId, chapter]) => {
    const attachedSections = chapter.sections.map((currentSection, index) => ({
      ...currentSection,
      sourceRefs: currentSection.sourceRefs?.length ? currentSection.sourceRefs : pickSources(moduleId, index),
    }))
    const additions = deepSections[moduleId] ?? []
    return [moduleId, {
      ...chapter,
      introduction: `${chapter.introduction} Esta versión ampliada añade una lectura de dominio, fuentes por bloque y matices de versión, permisos, límites y troubleshooting para estudiar el apartado sin depender de saltar constantemente fuera de la aplicación.`,
      sections: [...attachedSections, ...additions],
      masteryChecklist: [...chapter.masteryChecklist, 'Puedo localizar la fuente oficial de cada bloque y explicar su condición de aplicabilidad.', 'Puedo resolver un escenario y justificar por qué los distractores no encajan.'],
    }]
  }),
)
