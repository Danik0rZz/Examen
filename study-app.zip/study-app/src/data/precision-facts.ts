export type FactSource = {
  title: string
  url: string
}

export type PrecisionFact = {
  topic: string
  fact: string
  examNote: string
  source: FactSource
}

export type PrecisionFactSheet = {
  title: string
  intro: string
  rows: PrecisionFact[]
}

const source = (title: string, url: string): FactSource => ({ title, url })
const fact = (topic: string, value: string, examNote: string, sourceRef: FactSource): PrecisionFact => ({ topic, fact: value, examNote, source: sourceRef })

const learningPlan = source('Associate Certification Learning Plan', 'https://university.dynatrace.com/learn/public/learning_plan/view/47/dynatrace-associate-certification-learning-plan')
const studyPath = source('Associate Certification Learning Path 2025', 'https://community.dynatrace.com/pssft35649/attachments/pssft35649/GetStarted/1351/1/Associate_Certification_Learning_Path_2025.pdf')
const whatIs = source('What is Dynatrace', 'https://docs.dynatrace.com/docs/discover-dynatrace/what-is-dynatrace')
const davisIntelligence = source('Davis AI engine', 'https://docs.dynatrace.com/docs/dynatrace-intelligence')
const grail = source('Grail overview', 'https://docs.dynatrace.com/docs/platform/grail')
const grailData = source('How to organize your data in Grail', 'https://docs.dynatrace.com/docs/platform/grail/organize-data')
const sharing = source('Share documents', 'https://docs.dynatrace.com/docs/discover-dynatrace/get-started/dynatrace-ui/share')
const notebooks = source('Notebooks', 'https://docs.dynatrace.com/docs/analyze-explore-automate/dashboards-and-notebooks/notebooks')
const dashboards = source('Dashboards', 'https://docs.dynatrace.com/docs/analyze-explore-automate/dashboards-and-notebooks/dashboards-new')
const businessConcepts = source('Basic concepts of Business Observability', 'https://docs.dynatrace.com/docs/observe/business-observability/bo-basic-concepts')
const businessEnrichment = source('Business event enrichment', 'https://docs.dynatrace.com/docs/observe/business-observability/bo-events-enrichment')
const rumModel = source('RUM data model', 'https://docs.dynatrace.com/docs/observe/digital-experience/new-rum-experience/concepts/data-model')
const rumSessions = source('User sessions in web frontends', 'https://docs.dynatrace.com/docs/observe/digital-experience/rum/web-frontends/concepts/user-sessions-web')
const synthetic = source('Synthetic Monitoring', 'https://docs.dynatrace.com/docs/observe/digital-experience/synthetic')
const retention = source('Data retention periods', 'https://docs.dynatrace.com/docs/manage/data-privacy-and-security/data-privacy/data-retention-periods')
const metricFaq = source('FAQ for Metrics', 'https://docs.dynatrace.com/docs/analyze-explore-automate/metrics/faq')
const keyRequests = source('Monitor key requests', 'https://docs.dynatrace.com/docs/observe/application-observability/services-classic/monitor-key-requests')
const dql = source('Dynatrace Query Language', 'https://docs.dynatrace.com/docs/platform/grail/dynatrace-query-language')
const dqlGuide = source('Use DQL queries', 'https://docs.dynatrace.com/docs/platform/grail/dynatrace-query-language/dql-guide')
const dqlCommands = source('DQL commands', 'https://docs.dynatrace.com/docs/platform/grail/dynatrace-query-language/commands')
const dqlMetrics = source('DQL metric commands', 'https://docs.dynatrace.com/docs/platform/grail/dynatrace-query-language/commands/metric-commands')
const dqlTypes = source('DQL data types', 'https://docs.dynatrace.com/docs/platform/grail/dynatrace-query-language/data-types')
const dqlBest = source('DQL best practices', 'https://docs.dynatrace.com/docs/platform/grail/dynatrace-query-language/dql-best-practices')
const appSecurity = source('Application Security', 'https://docs.dynatrace.com/docs/secure/application-security')
const rva = source('Runtime Vulnerability Analytics', 'https://docs.dynatrace.com/docs/secure/application-security/vulnerability-analytics')
const vulnerabilityEvaluation = source('Vulnerability evaluation', 'https://docs.dynatrace.com/docs/secure/application-security/vulnerability-analytics/vulnerability-evaluation')
const vulnerabilityPrioritization = source('Prioritize vulnerabilities', 'https://docs.dynatrace.com/docs/secure/vulnerabilities/prioritize')
const workflows = source('Workflows', 'https://docs.dynatrace.com/docs/analyze-explore-automate/workflows')
const workflowTriggers = source('Workflow triggers', 'https://docs.dynatrace.com/docs/analyze-explore-automate/workflows/build/trigger')
const workflowEvents = source('Event triggers for workflows', 'https://docs.dynatrace.com/docs/analyze-explore-automate/workflows/build/trigger/event-trigger')
const workflowSecurity = source('Manage workflow permissions', 'https://docs.dynatrace.com/docs/analyze-explore-automate/workflows/security')
const workflowRunning = source('Monitor workflow executions', 'https://docs.dynatrace.com/docs/analyze-explore-automate/workflows/running')
const simpleWorkflow = source('Create a simple workflow', 'https://docs.dynatrace.com/docs/analyze-explore-automate/workflows/build/simple-workflow')
const ingest = source('Ingest data into Dynatrace', 'https://docs.dynatrace.com/docs/ingest-from')
const logIngestion = source('Log ingestion', 'https://docs.dynatrace.com/docs/analyze-explore-automate/logs/lma-log-ingestion')
const logRetention = source('Configure log storage and retention', 'https://docs.dynatrace.com/docs/analyze-explore-automate/logs/lma-bucket-assignment')
const openPipeline = source('OpenPipeline', 'https://docs.dynatrace.com/docs/platform/openpipeline')
const otel = source('OpenTelemetry troubleshooting', 'https://docs.dynatrace.com/docs/ingest-from/opentelemetry/troubleshooting')
const smartscape = source('Smartscape topology', 'https://docs.dynatrace.com/docs/shortlink/smartscape')
const logAnalytics = source('Log Analytics', 'https://docs.dynatrace.com/docs/analyze-explore-automate/logs')
const hub = source('Dynatrace Hub', 'https://www.dynatrace.com/hub/')
const entityQuery = source('Query monitored entities in Grail', 'https://docs.dynatrace.com/docs/platform/grail/querying-monitored-entities')
const proctoru = source('ProctorU Equipment Requirements', 'https://support.proctoru.com/hc/en-us/articles/24692181239309-Equipment-Requirements')
const proctoruFaq = source('ProctorU Exam Day FAQs', 'https://support.proctoru.com/hc/en-us/articles/24721945091725-Frequently-Asked-Questions-About-Exam-Day')
const k8sMonitoring = source('Kubernetes monitoring', 'https://docs.dynatrace.com/docs/observe/infrastructure-observability/container-platform-monitoring/kubernetes-monitoring')
const activeGateDocs = source('ActiveGate architecture', 'https://docs.dynatrace.com/docs/platform/activegate')

const oneAgentCapabilities = source('OneAgent monitoring capabilities', 'https://docs.dynatrace.com/docs/platform/oneagent/supported-monitoring-types')
const oneAgentWorks = source('How OneAgent works', 'https://docs.dynatrace.com/docs/platform/oneagent/how-one-agent-works')
const oneAgentModes = source('OneAgent monitoring modes', 'https://docs.dynatrace.com/docs/platform/oneagent/monitoring-modes/monitoring-modes')
const oneAgentEnable = source('Enable OneAgent monitoring modes', 'https://docs.dynatrace.com/docs/platform/oneagent/monitoring-modes/enable-monitoring-modes')
const oneAgentMatrix = source('OneAgent support matrix', 'https://docs.dynatrace.com/docs/ingest-from/technology-support/oneagent-platform-and-capability-support-matrix')
const infrastructure = source('Infrastructure Observability', 'https://docs.dynatrace.com/docs/shortlink/infra-mon')

export const precisionFacts: Record<string, PrecisionFactSheet> = {
  welcome: {
    title: 'Hechos de precisión: Fundamentos y Arquitectura Dynatrace 101',
    intro: 'Estas son las relaciones arquitectónicas y conceptuales esenciales que sustentan el examen Associate. No memorices definiciones aisladas: comprende cómo se conectan las entidades y el valor diagnóstico de cada capa.',
    rows: [
      fact('MELT Stack Unificado', 'Grail unifica métricas, eventos, logs y trazas (MELT) en un data lakehouse columnar sin indexación previa ni esquemas rígidos.', 'Grail elimina silos de almacenamiento; no es una aplicación visual ni un dialecto DQL.', grail),
      fact('Davis AI Causal vs ML', 'Davis AI opera sobre el grafo topológico Smartscape mediante análisis causal determinista y baselines automáticos, no con aprendizaje probabilístico tipo caja negra.', 'Davis identifica causa raíz mediante dependencias topológicas reales, evitando falsas correlaciones estadísticas.', davisIntelligence),
      fact('Smartscape 5 Layers', 'La topología Smartscape modela 5 capas: Data Center, Host, Process Group, Service y Application, conectadas mediante relaciones verticales y horizontales.', 'Comprender qué entidad pertenece a qué capa es crítico para navegar el grafo de problemas en el examen.', smartscape),
      fact('DPS Licensing Model', 'Dynatrace Platform Subscription (DPS) es un modelo de consumo unificado basado en valor donde las capacidades se tarifican por uso real sin silos de licencias perpetuas.', 'DPS permite activar y desactivar capacidades sin renegociar contratos de licencias individuales.', whatIs),
      fact('Grail Schema-on-Read', 'Grail almacena datos estructurados y no estructurados tal como llegan; la estructura y tipos se procesan en el momento de consulta con DQL.', 'Schema-on-read agiliza la ingestión y evita cuellos de botella de indexación en almacenamiento masivo.', grailData),
      fact('Contexto Operativo', 'La telemetría adquiere valor diagnóstico únicamente cuando se relaciona con una entidad monitoreada, una ventana temporal y un impacto en el usuario.', 'Una métrica de saturación de CPU aislada no demuestra la causa raíz de una degradación de servicio.', whatIs),
      fact('Davis event vs Problem', 'Un Davis event es una anomalía individual; un Problem es un incidente correlacionado que agrupa múltiples eventos en una línea de tiempo causal.', 'No confundas la anomalía puntual de una entidad con el Problem que agrupa todo el blast radius.', whatIs),
      fact('Dynatrace Launcher', 'El Launcher de la plataforma es la interfaz unificada para acceder a apps nativas, apps instaladas desde Hub y flujos de trabajo.', 'La interfaz Latest organiza todas las herramientas como aplicaciones modulares sobre Grail.', whatIs),
    ],
  },
  instructions: {
    title: 'Hechos de precisión sobre preparación, requisitos y examen',
    intro: 'Requisitos técnicos indispensables, políticas de proctoring y estrategias analíticas para abordar preguntas de certificación sin caer en trampas de lectura.',
    rows: [
      fact('Outbound Networking 443', 'Toda comunicación entre OneAgent, ActiveGate y el cluster Dynatrace SaaS se realiza exclusivamente mediante tráfico saliente (outbound-only) por el puerto HTTPS 443.', 'No se requieren puertos de entrada (inbound) en los cortafuegos locales para la monitorización estándar.', oneAgentWorks),
      fact('Proxy y PAC Support', 'OneAgent y ActiveGate soportan proxies corporativos HTTP/HTTPS y archivos Proxy Auto-Configuration (PAC) para enrutar telemetría externa.', 'Si un firewall bloquea acceso directo a internet, ActiveGate o un proxy corporativo es el canal de salida.', activeGateDocs),
      fact('Arquitectura Web Multicapa', 'El examen asume dominio de arquitecturas multicapa: balanceador de carga, frontend web, backend de microservicios y bases de datos relacionales/NoSQL.', 'Localizar el cuello de botella requiere relacionar llamadas HTTP de servicios con queries de base de datos.', learningPlan),
      fact('Contenedores y Kubernetes', 'Debes comprender la jerarquía Kubernetes: Cluster → Node → Namespace → Deployment → Pod → Container, y cómo se mapean a entidades Dynatrace.', 'Un Pod de Kubernetes se representa como un Process Group Instance (PGI) ejecutándose en un Host/Node.', k8sMonitoring),
      fact('Entorno ProctorU Guardian', 'El examen supervisado requiere el navegador seguro Guardian Browser, webcam, micrófono, identificación oficial con foto y habitación privada sin pantallas adicionales.', 'Incumplir los requisitos de equipo o software de proctoring invalida la convocatoria de certificación.', proctoru),
      fact('Estrategia Open-Book y Filtros', 'Durante el examen, la búsqueda en la documentación oficial debe ser quirurgica: busca por término exacto (`app-engine:*`, nombres de tablas) y verifica la versión Latest.', 'Revisa siempre el banner de versión en Docs; las rutas o permisos Classic son distractores frecuentes.', learningPlan),
      fact('Lectura Adversarial de Enunciados', 'Examina los términos absolutistas: "only", "always", "first step", "best practice", "write permission" y la variante de plataforma solicitada.', 'Una opción técnicamente cierta en general es incorrecta si no responde a la restricción exacta de la pregunta.', studyPath),
      fact('Simulaciones y Transferencia Práctica', 'Associate no evalúa memorización estéril sino capacidad de interpretar pantallas, tablas DQL, logs y árboles causales de problemas reales.', 'Ante dos respuestas posibles, prioriza siempre el siguiente paso que reduce mayor incertidumbre técnica.', studyPath),
    ],
  },
  platform: {
    title: 'Hechos de precisión de la plataforma',
    intro: 'La plataforma se examina a través de sus contratos: qué guarda cada capa, quién puede acceder, qué aplicación lo representa y qué significa que un recurso esté descubierto pero no configurado.',
    rows: [
      fact('Grail data model', 'Grail organiza datos en buckets, tables y views; las tablas agrupan por tipo de registro y los buckets controlan almacenamiento lógico.', 'Consultar una tabla no implica que todos los buckets o registros sean visibles para tu usuario.', grailData),
      fact('Buckets', 'Un bucket es una unidad lógica asociada a un record type, como logs, events, bizevents, spans o metrics.', 'El bucket influye en retención, acceso, partición y coste; no es un dashboard.', grailData),
      fact('Views', 'Una view ofrece una perspectiva virtual definida sobre datos existentes.', 'Una view no duplica necesariamente los registros ni cambia la ingestión.', grailData),
      fact('Hub', 'Dynatrace Hub es un catálogo para descubrir apps, extensiones e integraciones.', 'Descubrir una tarjeta no significa que esté instalada, configurada o produciendo datos.', hub),
      fact('Hub IAM Permissions', 'Instalar y eliminar aplicaciones de Dynatrace Hub requiere permisos específicos: `app-engine:apps:install` para instalar y `app-engine:apps:delete` para desinstalar.', 'Poder visualizar una app en el Hub no otorga permiso para instalarla en el entorno.', hub),
      fact('Hub Tabs Structure', 'La ficha de un ítem en Hub contiene las pestañas `Overview` (descripción), `Contents` (artefactos incluidos como dashboards y workflows) y `Technical information` (permisos y configuración).', 'Los artefactos que acompañan a una extensión se consultan en la pestaña `Contents`.', hub),
      fact('Problem Records en Grail', 'Los registros de Problems en Grail almacenan los eventos agrupados en el campo de tipo array `dt.davis.event_ids` y sus campos personalizados solo admiten valores string.', 'Los campos custom de un Problem no admiten arrays ni objetos complejos; se restringen a strings.', whatIs),
      fact('Tablas de Sistema en Grail', 'La tabla del sistema `dt.system.buckets` permite consultar la lista de todos los buckets configurados, su record type y sus políticas de retención activas.', 'Consultar `dt.system.buckets` requiere permisos de administración de almacenamiento.', grailData),
      fact('Documentos', 'Dashboards, notebooks y launchpads tienen owner y permisos de view/edit.', 'Poder ver un documento no concede permiso para editarlo, compartirlo o cambiar su owner.', sharing),
      fact('Document Sharing Controls', 'Al compartir un documento, el propietario puede marcar `Allow editors to share` y configurar visibilidad con `Visible to anyone in your environment`.', 'Compartir con el entorno no lo hace público en internet; solo es visible para usuarios autenticados del tenant.', sharing),
      fact('IAM', 'Permisos de lectura, escritura, ejecución, administración y acceso a datos son capacidades distintas.', 'Un resultado vacío puede ser scope, management zone o permiso, no ausencia de datos.', sharing),
      fact('Platform search', 'La búsqueda ayuda a localizar capacidades, entidades y recursos sin depender de una ruta visual fija.', 'La navegación correcta conserva timeframe, filtros, entity ID y fuente.', whatIs),
      fact('Latest y Classic', 'La interfaz y algunos objetos tienen experiencias Latest y Classic con modelos y rutas diferentes.', 'No mezcles sintaxis, permisos o nombres de app sin etiquetar la variante.', learningPlan),
    ],
  },
  observability: {
    title: 'Hechos críticos de OneAgent e Infrastructure Observability',
    intro: 'Este bloque es deliberadamente memorizable: contiene las distinciones de capacidades, modos, comunicación e inyección que suelen esconderse detrás de preguntas aparentemente sencillas.',
    rows: [
      fact('Capacidades', 'OneAgent puede cubrir RUM web/mobile, server-side services, host/process/network, cloud/VM, Docker containers, logs y root-cause analysis, según soporte.', 'La palabra “puede” está condicionada por tecnología, versión, plataforma, modo y configuración.', oneAgentCapabilities),
      fact('Arquitectura', 'OneAgent usa procesos especializados para métricas del sistema, instrumentación de procesos, logs y comunicación con Dynatrace.', 'Instalar el agente no prueba que cada proceso tenga deep monitoring.', oneAgentWorks),
      fact('Comunicación', 'OneAgent inicia comunicación outbound-only hacia el Cluster o a través de ActiveGate usando HTTP/S; WebSocket se reserva para Live Debugger.', 'No confundas el canal de comunicación con code-module injection.', oneAgentWorks),
      fact('Full-Stack', 'Ofrece la mayor profundidad: host/process details, runtime metrics, tracing/profiling y process injection según soporte.', 'Es el modo a evaluar para aplicaciones críticas de negocio cuando se necesita profundidad.', oneAgentModes),
      fact('Infrastructure', 'Proporciona infraestructura, logs, AIOps y backing services; process injection está habilitado por defecto para runtime metrics, salvo condiciones de despliegue.', 'Reduce profundidad de aplicación frente a Full-Stack; no equivale a “sin procesos”.', oneAgentModes),
      fact('Discovery', 'Es un modo ligero de basic monitoring para descubrir hosts/procesos; code-module injection está desactivado por defecto y está ligado a Foundation & Discovery en DPS.', 'No ofrece tracing/profiling completo por defecto y no debe venderse como Full-Stack barato.', oneAgentModes),
      fact('Activación', 'Durante la instalación se puede usar “--set-monitoring-mode=infra-only” o “--set-monitoring-mode=discovery”; desde la UI también se cambia el modo.', 'Después de cambiar auto-injection, los procesos monitorizados deben reiniciarse.', oneAgentEnable),
      fact('Inyección', 'El módulo inyectado se enlaza dinámicamente al proceso y no se retira solo por detener OneAgent; normalmente requiere reiniciar el proceso.', '“OneAgent stopped” y “módulo retirado” son estados diferentes.', oneAgentModes),
      fact('Auto-injection', 'Se puede desactivar globalmente o por reglas de process group con “--set-auto-injection-enabled=false” o la configuración equivalente.', 'Desactivar auto-injection también impide capacidades que dependen del code module, como AppSec o Live Debugger.', oneAgentEnable),
      fact('OneAgent CLI (oneagentctl)', 'La utilidad `oneagentctl` permite consultar el estado del agente, cambiar parámetros de red y reconfigurar modos desde la línea de comandos local.', 'Requiere privilegios de administrador local en el host para ejecutar modificaciones.', oneAgentWorks),
      fact('ActiveGate Kubernetes 1.327+', 'Para aprovechar la visibilidad mejorada de objetos de Kubernetes (Enhanced Object Visibility), el ActiveGate debe estar en versión 1.327 o superior.', 'ActiveGates antiguos no podrán recopilar los metadatos extendidos de objetos de Kubernetes.', k8sMonitoring),
      fact('ActiveGate', 'Puede actuar como gateway y soportar monitorización remota; no es un sustituto universal de OneAgent.', 'Para VMware, cloud o sistemas remotos revisa red, grupo, credenciales, versión y permisos.', infrastructure),
      fact('Entidades', 'Host aloja procesos; process group agrupa procesos; process group instance representa una ejecución; service representa una función observable.', 'El nivel de entidad determina el drill-down correcto.', oneAgentWorks),
      fact('Soporte', 'La support matrix es el contrato para plataforma, sistema operativo, tecnología, versión y capability status.', 'Nunca generalices una capacidad observada en Linux/Java a cualquier tecnología.', oneAgentMatrix),
      fact('AppSec en Discovery', 'En Discovery, Application Security requiere habilitar code-module injection y reiniciar el proceso; la profundidad contextual puede ser limitada.', 'Que el modo permita una capability no significa que venga activa ni con la misma precisión.', appSecurity),
      fact('Diagnóstico', 'Para datos ausentes separa servicio, conexión, versión, token, modo, compatibilidad, proceso, permisos, timeframe y entidad.', 'El orden de comprobación es parte de la respuesta técnica.', oneAgentEnable),
    ],
  },
  notebooks: {
    title: 'Hechos de precisión sobre Notebooks y Dashboards',
    intro: 'La diferencia no es “uno sirve para consultar y otro para graficar”. Ambos pueden consultar y visualizar; lo que cambia es la intención, la narrativa, la persistencia y la audiencia.',
    rows: [
      fact('Notebooks', 'Son documentos de análisis que combinan consultas, visualizaciones, Markdown, resultados y narrativa.', 'Elige Notebook cuando necesites explorar, explicar y conservar el razonamiento.', notebooks),
      fact('Dashboards', 'Están orientados a seguimiento continuo y comunicación de indicadores para una audiencia operativa o ejecutiva.', 'Elige Dashboard cuando la pregunta sea “qué vigilo de forma recurrente”.', dashboards),
      fact('Tile Types en Dashboards', 'Los Dashboards soportan tiles de DQL query, tiles de Markdown con texto/anotaciones y componentes de visualización estructurada.', 'Las anotaciones y notas explicativas se incorporan mediante tiles Markdown dedicados.', dashboards),
      fact('Variables y Parámetros ($var)', 'Tanto Notebooks como Dashboards admiten variables reactivas referenciadas como `$variable` en queries DQL para parametrizar vistas.', 'Al cambiar el selector de variable, todas las queries asociadas se reejecutan automáticamente.', notebooks),
      fact('Estructura JSON de Documentos', 'Los Dashboards y Notebooks se representan internamente como documentos JSON estructurados gestionados vía Document API.', 'Permite versionar y desplegar cuadros de mando mediante pipelines de GitOps y automatización.', dashboards),
      fact('Drilldowns y Enlaces de Contexto', 'Los tiles de Dashboard admiten acciones de drilldown que transmiten timeframe, entity ID y variables hacia Notebooks u otras vistas.', 'Un drilldown bien diseñado preserva el contexto analítico del usuario sin reiniciar la búsqueda.', dashboards),
      fact('Secciones', 'Una sección de Notebook puede usar DQL, visualizaciones, Markdown y otras capacidades de análisis.', 'Una visualización bonita no corrige un dataset, unidad, timeframe o filtro incorrectos.', notebooks),
      fact('Persistencia', 'Algunos resultados o visualizaciones pueden depender de volver a ejecutar la consulta; distingue datos persistidos de datos vivos.', 'En una revisión, pregunta si el resultado representa ahora o el momento de ejecución.', notebooks),
      fact('Permisos', 'Notebooks requieren permisos de app, funciones y documentos; crear/actualizar/borrar son permisos distintos.', 'Leer un Notebook no implica poder modificarlo ni compartirlo.', notebooks),
      fact('Sharing', 'El owner puede compartir con Can view o Can edit y puede permitir que editors compartan.', 'El enlace no convierte el documento en público fuera del entorno.', sharing),
      fact('Calidad de gráfico', 'Toda gráfica debe declarar periodo, unidad, agregación, dimensión y tratamiento de null.', 'Un gráfico sin esos metadatos puede inducir a conclusiones falsas.', notebooks),
      fact('Narrativa', 'La conclusión debe apuntar a la consulta, el filtro y el contexto que la sostienen.', 'Separar evidencia de interpretación es una señal de madurez en escenarios.', notebooks),
    ],
  },
  'business-dem': {
    title: 'Hechos de precisión de Business Analytics y DEM',
    intro: 'Aquí se decide si sabes separar experiencia real, pruebas controladas y hechos de negocio. Aprende el flujo y las condiciones, no solo el nombre de cada app.',
    rows: [
      fact('Business event', 'Es una acción o ocurrencia convertida en business-grade data, como una compra, login o pago.', 'Un user event de RUM no se vuelve Business Event solo por llamarlo “de negocio”.', businessConcepts),
      fact('Tablas DEM en Grail: user.events vs user.sessions', 'En Grail, `user.events` contiene los eventos atómicos individuales de RUM mientras que `user.sessions` almacena las sesiones agregadas completas.', 'Consultar duraciones y recuentos de visita requiere consultar `user.sessions`; acciones puntuales van a `user.events`.', rumModel),
      fact('Synthetic Scripting: api.fail()', 'En pasos JavaScript de Synthetic clickpaths, el método `api.fail("mensaje")` fuerza el fallo inmediato del monitor con una causa documentada.', 'Permite validar aserciones funcionales complejas que van más allá de códigos HTTP 200.', synthetic),
      fact('Dataflow', 'El flujo de Business Observability es capture → process → analyze; la visualización y reporting consumen el resultado.', 'Capture no significa que el dato ya esté limpio, enriquecido o retenido como necesitas.', businessConcepts),
      fact('Fuentes', 'Business events pueden llegar desde OneAgent, RUM JavaScript API y fuentes externas.', 'El origen condiciona los campos automáticos y el método de troubleshooting.', businessConcepts),
      fact('Metadata', '“event.provider” y “event.type” son campos obligatorios del modelo de business events; “event.category” es opcional.', 'Confundir event.type con una dimensión visual o con user action cambia la respuesta.', businessConcepts),
      fact('Enrichment', 'RUM business events pueden enriquecerse con geolocalización, dispositivo, navegador y aplicación.', 'El enrichment añade contexto, pero no autoriza a capturar PII sin gobierno.', businessEnrichment),
      fact('RUM', 'RUM observa usuarios reales, user events, sessions, frontend performance y errores.', 'RUM responde “qué experimentan usuarios reales”, no “qué pasaría en una prueba controlada”.', rumModel),
      fact('Session lifecycle', 'En web RUM, una session termina tras 30 minutos de inactividad, al cerrar el navegador, al llegar a 6 horas o con “dtrum.endSession()”.', 'Una session no es ilimitada ni equivale siempre a una visita de negocio.', rumSessions),
      fact('Synthetic', 'Synthetic ejecuta HTTP, browser o NAM monitors desde localizaciones públicas o privadas para comprobar disponibilidad y rendimiento.', 'Synthetic es una observación controlada y programada; no representa a todos los usuarios reales.', synthetic),
      fact('Business-grade', 'Business-grade data busca ser precisa y no depender de muestreo para baselines, tendencias y anomalías de negocio.', 'La precisión de negocio no elimina la necesidad de validar volumen, duplicados y cardinalidad.', businessConcepts),
      fact('Journey', 'Un journey ordena acciones y eventos del usuario para analizar un recorrido, abandono, conversión o fricción.', 'Un journey necesita identificadores y contexto consistentes; no se deduce de una sola métrica técnica.', rumModel),
    ],
  },
  'data-analysis': {
    title: 'Hechos de precisión: retención, métricas y análisis',
    intro: 'Este cuadro contiene cifras y condiciones que conviene saber de memoria. Son valores de referencia de Latest Dynatrace consultados en la documentación oficial; revisa la fecha y no mezcles automáticamente Classic con Grail.',
    rows: [
      fact('Metrics powered by Grail', 'Retención incluida general: 15 meses con granularidad de 1 minuto por defecto; puede ampliarse hasta 10 años.', 'Si la pregunta dice Grail metrics, la respuesta esperada no es la retención de Metrics Classic.', metricFaq),
      fact('storage:bucket-definitions:write', 'Crear nuevos buckets o modificar las políticas de retención en Grail requiere el permiso IAM explícito `storage:bucket-definitions:write`.', 'Tener acceso de lectura o escritura a los datos de un bucket no permite alterar su retención.', grailData),
      fact('Retención de Buckets del Sistema', 'El bucket `default_logs` tiene 35 días por defecto; `security.events` y los eventos de Davis tienen retenciones preconfiguradas extendidas (1 año o más).', 'Los buckets de sistema no permiten reducir su retención por debajo de los mínimos operativos de la plataforma.', retention),
      fact('timeseries default:0', 'En DQL, la cláusula `default:0` dentro del comando `timeseries` sustituye los intervalos temporales vacíos (null) por el valor numérico 0.', 'Evita discontinuidades y saltos artificiales en gráficos de líneas cuando no hay muestras en ciertos minutos.', dqlMetrics),
      fact('Metrics Classic', 'Retención general indicada para Metrics Classic: 5 años; Grail metrics usa un almacenamiento separado.', 'Classic metrics y Grail metrics no comparten automáticamente su histórico.', retention),
      fact('Distributed traces en Grail', 'Retención configurable de 10 días a 10 años; el bucket “default_spans” aparece con 10 días.', 'No confundas el mínimo incluido de tracing con la retención ampliada de DPS.', retention),
      fact('Logs en Grail', 'El bucket “default_logs” tiene 35 días; los buckets de logs se pueden configurar según el rango permitido por la capacidad, hasta 10 años.', 'El valor por defecto y el valor configurado son preguntas diferentes.', logRetention),
      fact('RUM y Synthetic', 'User events, user sessions, user replays y Synthetic aparecen con 35 días como retención general por defecto.', 'No extrapoles esta cifra a todas las métricas derivadas ni a datos Classic específicos.', retention),
      fact('Davis', 'Davis problems and events tienen 14 meses de retención general.', 'Un Problem no comparte automáticamente la retención de un log, trace o metric.', retention),
      fact('Application Security', 'Security data powered by Grail se conserva entre 1 y 3 años según fuente; la tabla general indica 3 años para Dynatrace-generated y 1 año para third-party.', 'Antes de responder, identifica si la pregunta habla de Grail security o Security Classic.', retention),
      fact('OneAgent diagnostics', 'Support archives y analysis results de OneAgent tienen 30 días de retención general.', 'No es la retención de toda la telemetría del host.', retention),
      fact('Key requests Classic', 'Detailed code-level data: 10 días; aggregated code-level data: 35 días; long-term metric history: 5 años.', 'La palabra “detailed”, “aggregated” o “long-term” cambia la respuesta.', keyRequests),
      fact('Buckets custom', 'Los buckets custom permiten diseñar retención y acceso por tipo de dato; acortar retención puede eliminar datos que ya superan el nuevo periodo.', 'La retención es una política de storage, no un filtro visual del dashboard.', grailData),
      fact('Granularidad', 'La retención y la granularidad no son lo mismo: se puede conservar un periodo largo con datos agregados o consultar detalle solo mientras exista.', 'Lee la unidad temporal antes de comparar dos historiales.', metricFaq),
    ],
  },
  dql: {
    title: 'Hechos de precisión de DQL',
    intro: 'DQL se domina entendiendo el flujo de records y fields, los comandos que cambian la forma del resultado y las condiciones de tipo, timeframe, permisos y volumen.',
    rows: [
      fact('Pipeline', 'Los comandos se encadenan con “|”; cada comando recibe el resultado anterior y devuelve una tabla o colección de records.', 'El orden afecta al resultado y al rendimiento.', dqlGuide),
      fact('Filtros Temporales Explícitos', 'En DQL se define el rango temporal con `from:now()-2h`, `from:now()-7d` o `to:now()`; anula el selector global de la interfaz.', 'Fijar el timeframe dentro de la query garantiza reproducibilidad en ejecuciones programadas y workflows.', dqlGuide),
      fact('Campos Canónicos de Kubernetes', 'En logs de contenedores, los atributos semánticos oficiales son `k8s.container.name`, `k8s.pod.name` y `k8s.namespace.name`.', 'No utilices nombres propietarios inventados para filtrar contenedores en DQL.', dqlCommands),
      fact('Funciones sobre Arrays en DQL', 'DQL proporciona funciones como `arraySize()`, `arrayContains()` y el operador `expand` para aplanar arrays en múltiples filas.', 'El operador `expand` es imprescindible cuando una entidad contiene una lista de subelementos que deseas filtrar.', dqlTypes),
      fact('fetch', 'Define la fuente inicial, por ejemplo “fetch logs” o “fetch bizevents”; si no se especifica timeframe, se usa el de la UI.', 'Un timeframe de la UI puede ser la causa oculta de un resultado vacío.', dqlGuide),
      fact('filter', '“filter” conserva records que cumplen una condición; reducir pronto el volumen suele mejorar consulta y claridad.', 'Filtrar una dimensión después de agregarla no es equivalente a filtrar el dato bruto.', dqlCommands),
      fact('fields', '“fields” conserva los campos seleccionados; “fieldsAdd”, “fieldsKeep”, “fieldsRemove” y “fieldsRename” cambian el esquema de salida.', 'No confundas ocultar un campo con eliminarlo del almacenamiento.', dqlCommands),
      fact('summarize', 'Agrupa records por “by:{...}” y aplica aggregations como “count()”, “avg()” o “countDistinct()”.', 'El resultado ya no tiene una fila por evento original.', dqlGuide),
      fact('timeseries', 'Combina carga, filtrado y agregación de métricas y produce series homogéneas con timeframe e interval.', 'Para una serie temporal de métricas, “timeseries” es distinto de “summarize” sobre records.', dqlMetrics),
      fact('metrics command', '“metrics” es exploratorio, limitado a los últimos 10 días y a 100.000 metric series por query; no está pensado para charting o cálculos.', 'Si necesitas charting o cálculo de una serie, estudia “timeseries”.', dqlMetrics),
      fact('Tipos', 'DQL es strongly typed: string, long, double, boolean, timestamp, duration, array y record aceptan operaciones distintas.', 'Si el tipo no encaja, inspecciona y convierte explícitamente; no compares todo como texto.', dqlTypes),
      fact('parse y DPL', '“parse” interpreta un campo con un patrón DPL; JSON/KVP pueden producir un “record” estructurado.', 'DQL consulta; DPL describe el patrón de parsing.', dqlTypes),
      fact('data', '“data” genera records de ejemplo durante la ejecución y sirve para probar o documentar una consulta pequeña.', 'No equivale a ingestar esos datos en Grail.', dqlCommands),
      fact('Permisos', 'Para “timeseries” y “metrics” se necesitan permisos de lectura de metrics y buckets adecuados.', 'Una query válida puede fallar o devolver menos datos por autorización.', dqlMetrics),
      fact('Buenas prácticas', 'Filtra por campos directamente, limita el timeframe, considera “scanLimitGBytes” y evita transformaciones innecesarias antes de reducir datos.', 'La consulta correcta también debe ser operable en volumen.', dqlBest),
    ],
  },
  security: {
    title: 'Hechos de precisión de Application Security',
    intro: 'Application Security exige distinguir el componente vulnerable, la evidencia de uso, la exposición y la acción de remediación. No respondas solo con la severidad nominal.',
    rows: [
      fact('RVA', 'Runtime Vulnerability Analytics detecta y evalúa vulnerabilidades open-source, third-party y code-level en runtime.', 'El alcance real depende de capabilities activadas, tecnología, versión, modo y licencia.', rva),
      fact('Third-party vs Code-level', 'Third-party detecta librerías vulnerables cargadas en memoria; Code-level analiza rutas de ejecución con inputs no saneados en código propio.', 'No confunda una vulnerabilidad de dependencia externa (CVE) con una debilidad de código propia (CWE).', rva),
      fact('Factores del Davis Security Score (DSS)', 'DSS pondera la puntuación base CVSS con 3 factores del entorno: exposición pública a internet, activos de datos alcanzables y existencia de exploit público.', 'Un CVSS 9.8 puede tener un DSS moderado si el proceso está aislado sin exposición externa ni exploits conocidos.', vulnerabilityPrioritization),
      fact('Tabla dt.security.vulnerabilities', 'En Grail, la tabla `dt.security.vulnerabilities` permite consultar mediante DQL el inventario en tiempo real de todas las vulnerabilidades detectadas.', 'Permite correlacionar vulnerabilidades de seguridad con Process Groups y Services afectados.', rva),
      fact('Reglas de Silenciado (Mute Rules)', 'Las reglas de silenciado permiten descartar alertas sobre vulnerabilidades evaluadas como falso positivo o riesgo aceptado temporalmente.', 'Silenciar una vulnerabilidad en la UI no elimina el código vulnerable ni altera su presencia en Grail.', vulnerabilityEvaluation),
      fact('Third-party', 'OneAgent reporta librerías cuando un proceso las está cargando; se emite el hallazgo cuando el componente está en uso.', 'Un paquete presente en un artefacto pero no cargado puede no generar el mismo resultado.', vulnerabilityEvaluation),
      fact('Code-level', 'Analiza cómo el input fluye por la aplicación y si existen caminos de código inseguros explotables.', 'No es lo mismo que listar CVEs de una librería de terceros.', rva),
      fact('Risk context', 'La evaluación puede considerar public internet exposure, reachable data assets, vulnerable functions y topología.', 'CVSS o severidad no cuentan toda la historia del riesgo contextual.', vulnerabilityPrioritization),
      fact('Auto-resolution', 'Una vulnerabilidad puede resolverse automáticamente cuando desaparece la causa raíz, por ejemplo si se elimina una librería vulnerable o se detiene el proceso.', 'Resolver en la UI no equivale a corregir el software.', vulnerabilityEvaluation),
      fact('Monitoring modes', 'Full-Stack ofrece la mayor profundidad; Infrastructure y Discovery tienen cobertura limitada para algunas detecciones; RAP aparece cubierta en los tres modos según la tabla de soporte.', 'AppSec en Discovery requiere code-module injection y puede tener menos contexto ambiental.', appSecurity),
      fact('Process restart', 'Cambiar controles de detección o inyección puede requerir reiniciar el proceso para que la instrumentación aplicada cambie.', 'Un cambio guardado sin reinicio no demuestra que la cobertura ya se modificó.', appSecurity),
      fact('Davis Security Score', 'El riesgo usa contexto y AI para priorizar vulnerabilidades relevantes del entorno, no solo impacto teórico.', 'DSS ayuda a priorizar; no es una garantía de explotación ni una prueba de remediación.', vulnerabilityPrioritization),
      fact('Classic vs Latest', 'Las apps Classic de Third-Party Vulnerabilities y Code-Level Vulnerabilities pueden estar deprecadas frente a la experiencia unificada Latest.', 'Lee el banner de variante y no memorices rutas antiguas como si fueran universales.', appSecurity),
      fact('Permiso API', 'La API de vulnerabilities usa “securityProblems.read” para lectura en el ejemplo de Environment API.', 'El permiso de API no equivale automáticamente al permiso de editar o remediar desde la UI.', vulnerabilityEvaluation),
    ],
  },
  automation: {
    title: 'Hechos de precisión de Workflows y AutomationEngine',
    intro: 'Los escenarios de automation suelen probar cuándo se ejecuta el flujo, quién lo ejecuta, qué permisos hereda y qué límite impide usarlo como una canalización masiva.',
    rows: [
      fact('iam:service-users:use', 'Para desacoplar un workflow de cuentas personales y ejecutarlo de forma desatendida se requiere el permiso `iam:service-users:use` para vincular un Service User.', 'Evita que la automatización falle si el empleado que creó el workflow abandona la organización.', workflowSecurity),
      fact('automation:workflows:write', 'Crear, actualizar o eliminar la definición de un flujo de trabajo requiere el permiso IAM `automation:workflows:write`.', 'Tener permiso para ejecutar manualmente un workflow no autoriza a modificar sus tareas o triggers.', workflowSecurity),
      fact('Filtros de Event Trigger', 'La expresión compilada de filtrado DQL en un Event Trigger no puede superar los 1.000 caracteres de longitud.', 'Diseña filtros concisos sobre campos clave en vez de queries extensas multilínea.', workflowEvents),
      fact('Acciones JS vs DQL en Workflows', 'Las tareas JavaScript permiten ejecutar lógica algorítmica compleja y consumir APIs REST externas; las tareas DQL consultan directamente Grail.', 'JavaScript no sustituye a DQL para recuperar millones de registros de telemetría.', workflows),
      fact('Trigger categories', 'Las categorías principales son On demand, Event y Schedule; una API puede disparar un workflow live independientemente del tipo de trigger.', 'Los triggers automáticos solo aplican a live workflows; el draft puede ejecutarse manualmente.', workflowTriggers),
      fact('Problem trigger', 'Reacciona al Problem como situación agrupada cuando abre, cambia o resuelve.', 'No es igual que reaccionar a cada Davis event individual.', workflowEvents),
      fact('Davis event trigger', 'Reacciona a alertas individuales cuando Dynatrace Intelligence detecta anomalías.', 'Si necesitas el conjunto agrupado, estudia Problem trigger.', workflowEvents),
      fact('Event trigger', 'Puede reaccionar a events, bizevents, security.events o dt.system.events mediante filtro DQL según el tipo.', 'El actor necesita permisos de lectura del event type correspondiente.', workflowEvents),
      fact('Límites de trigger', 'Los event triggers tienen límite de 1.000 ejecuciones por hora y expresión compilada de filtro de 1.000 caracteres.', 'Usa Query past events y reduce volumen antes de desplegar.', workflowEvents),
      fact('Actor', 'Cada ejecución de task ocurre en el contexto de un user actor; por defecto puede ser el creador o último editor, salvo configuración de service user.', 'AutomationEngine no puede superar los permisos reales del usuario actor.', workflowSecurity),
      fact('Consentimiento', 'La primera ejecución puede requerir autorizar los permisos que AutomationEngine ejercerá con ese actor.', 'Un 403 suele apuntar a permisos del usuario, authorization settings o tarea.', workflowSecurity),
      fact('Simple workflow', 'Está limitado a un trigger y una task; no consume workflow hours directamente, aunque las acciones pueden consumir otras capacidades.', 'Añadir complejidad cambia el tipo o funcionalidad y no se debe tratar como workflow estándar.', simpleWorkflow),
      fact('Action result', 'Los resultados de action execution no pueden superar 6 MB menos el tamaño de logs de la ejecución.', 'AutomationEngine es un orquestador, no un data pipeline para mover grandes volúmenes.', workflowRunning),
      fact('Workflow result', 'Un workflow result inválido o mayor de 10 MB hace fallar la ejecución; los simple workflows no tienen workflow result.', 'Valida JSON y tamaño antes de devolver resultados.', workflowRunning),
      fact('Workflows vs ingestion', 'La documentación indica que Workflows no está pensado para ingestión o exportación masiva; usa OpenPipeline o soluciones específicas.', 'Este distractor aparece como “automatizar todo con un workflow”.', workflows),
      fact('Service user', 'Para usos colaborativos o productivos se recomienda actor service user con mínimo privilegio.', 'Usar una identidad personal hace frágil la continuidad cuando cambia el usuario.', workflowSecurity),
    ],
  },
  ingestion: {
    title: 'Hechos de precisión sobre ingestión y gobierno del dato',
    intro: 'La ingestión se evalúa como una cadena completa, no como una llamada HTTP aislada. Debes saber qué mecanismo corresponde a cada origen y qué ocurre después de aceptar el payload.',
    rows: [
      fact('OpenPipeline Processing Stages', 'OpenPipeline estructura el procesamiento en tres etapas principales: Ingest, Process y Route hacia los buckets de destino.', 'Permite aplicar reglas de masking y descartes tempranos antes de comprometer almacenamiento.', openPipeline),
      fact('Atributos dt.openpipeline.source.*', 'Durante el tránsito por OpenPipeline se inyectan metadatos como `dt.openpipeline.source.type` y `dt.openpipeline.stage` para auditoría y enrutamiento.', 'Estos atributos del sistema permiten crear reglas condicionales según el origen de la telemetría.', openPipeline),
      fact('Log Ingest API Contratos', 'El endpoint de Log Ingest API soporta hasta 1.000 registros por payload HTTP POST, recomendando compresión gzip y autenticación con Bearer token.', 'Enviar payloads sin estructurar o que superen los límites genera códigos de error HTTP 413 o 429.', logIngestion),
      fact('Syslog Receiver en ActiveGate', 'ActiveGate puede configurarse como receptor de syslog de red en el puerto UDP/TCP 514 para reenviar logs hacia Grail de forma centralizada.', 'Dispositivos de red e hipervisores que no admiten agentes se integran habitualmente vía syslog.', activeGateDocs),
      fact('Data path', 'El camino es origen → transporte → autenticación → ingestión → OpenPipeline → persistencia → permisos → consulta.', 'HTTP 200 o una respuesta de aceptación no prueba que el dato sea visible en la query.', ingest),
      fact('OneAgent', 'Es el canal recomendado cuando el dato nace en hosts y procesos soportados y quieres contexto automático de entidad.', 'No siempre es posible en serverless, SaaS gestionado o sistemas remotos.', ingest),
      fact('ActiveGate', 'Puede proporcionar gateway, conectividad remota, endpoints de API y módulos OTLP según configuración.', 'No es lo mismo un Environment ActiveGate que un OneAgent instalado en el origen.', ingest),
      fact('OpenTelemetry', 'Permite instrumentación y exportación vendor-neutral de logs, metrics y traces mediante SDKs, collectors y endpoints compatibles.', 'Comprueba propagación, endpoint, protocolo, TLS, resource attributes y visualización final.', otel),
      fact('Log ingestion', 'Los logs ingeridos pasan por procesamiento y almacenamiento en Grail/OpenPipeline; se pueden filtrar, enriquecer, transformar y enrutar.', 'El parser no crea una fuente; solo estructura lo que ya llegó.', logIngestion),
      fact('Timestamp de logs', 'La ingestión de logs tiene ventanas de timestamp y reglas de rechazo; un registro demasiado antiguo o futuro puede descartarse o ajustarse según el endpoint.', 'Ante datos ausentes revisa el timestamp original, no solo la hora de la query.', logIngestion),
      fact('OpenPipeline', 'Matcher, orden, transformación, masking, drop y destino determinan lo que finalmente se almacena y consulta.', 'Una regla correcta en el scope equivocado produce el mismo síntoma que una regla incorrecta.', openPipeline),
      fact('Retention', 'El bucket determina retención y acceso; “default_logs” está indicado con 35 días y los buckets custom pueden cubrir necesidades mayores.', 'Retención no es lo mismo que timeframe seleccionado.', logRetention),
      fact('Metrics ingestion', 'Una métrica necesita key, valor, timestamp, unidad y dimensiones con cardinalidad controlada.', 'Más dimensiones no siempre aportan más precisión; pueden multiplicar series y coste.', ingest),
      fact('Traces', 'Sampling, propagación de trace context y límites de retención afectan a la capacidad de unir spans con logs y metrics.', 'No asumas trazas completas si el sistema usa sampling o no propaga contexto.', otel),
      fact('VMware/cloud', 'Las integraciones remotas suelen necesitar ActiveGate, credenciales, permisos, región o endpoint y feature set.', 'Un dashboard vacío puede ser conectividad o contrato de la integración, no DQL.', ingest),
    ],
  },
  other: {
    title: 'Hechos de precisión de Smartscape, logs, entidades y Hub',
    intro: 'Este módulo reúne los objetos que se usan como pegamento durante un troubleshooting. Su importancia está en que una pregunta puede cambiar la respuesta solo por cambiar el nivel de entidad o la fase del análisis.',
    rows: [
      fact('Consultas de Entidades en Grail', 'En Latest Dynatrace, las entidades se consultan con `fetch dt.entity.host`, `fetch dt.entity.service` o `fetch dt.entity.process_group`.', 'Sustituye a la API clásica de Entity V2 para investigaciones correlacionadas en Notebooks con DQL.', entityQuery),
      fact('Campos de Relación Topológica', 'Las relaciones entre entidades se modelan en atributos array como `runs[dt.entity.service_instance]` y `is_instance_of`.', 'Permiten navegar desde un Host hacia los Process Groups y Servicios que hospeda en una única query DQL.', smartscape),
      fact('Permiso storage:entities:read', 'Consultar el catálogo y topología de entidades monitorizadas en Grail requiere el permiso IAM `storage:entities:read`.', 'Sin este permiso, las consultas `fetch dt.entity.*` devuelven un error de autorización 403.', entityQuery),
      fact('Smartscape 5-Layer Hierarchy', 'La jerarquía estricta de Smartscape fluye verticalmente: Data Center → Host → Process Group → Service → Application.', 'Las dependencias horizontales se producen entre Servicios (llamadas de servicio) o entre Hosts en red.', smartscape),
      fact('Smartscape', 'Muestra nodos y edges de la topología construida a partir de datos observados.', 'Una relación depende de lifetime, timeframe, soporte, fuente y permisos.', smartscape),
      fact('Entity model', 'Host es infraestructura; process group agrupa procesos; process group instance es una ejecución; service es una función observable.', 'El mismo síntoma puede requerir navegar por niveles distintos.', entityQuery),
      fact('Log Analytics', 'Permite explorar logs sin exigir un esquema fijo de antemano y analizarlos con DQL y schema-on-read.', 'Que no haya esquema previo no elimina la necesidad de tipos y parsing.', logAnalytics),
      fact('Parsing', '“parse” y patrones DPL extraen campos desde contenido; JSON/KVP puede producir records estructurados.', 'Parser y DQL cumplen funciones diferentes: uno extrae, el otro consulta y procesa.', dqlTypes),
      fact('Buckets', 'Las tablas consultan por record type y los buckets separan almacenamiento, retención, acceso y coste.', 'Leer “logs” no implica consultar solo un bucket.', grailData),
      fact('Hub', 'El catálogo descubre apps, extensiones, integraciones y templates, pero cada elemento conserva requisitos de versión y configuración.', 'Hub no es una garantía de que el componente esté instalado.', hub),
      fact('Lookup', 'Un lookup añade campos relacionando claves; claves no únicas pueden multiplicar registros y distorsionar agregaciones.', 'Valida cardinalidad y tipo antes de enriquecer en producción.', dqlCommands),
      fact('Investigación reproducible', 'Conserva timeframe, filtro, query, muestra y conclusión para que otra persona repita el análisis.', 'Un screenshot sin consulta ni contexto es una evidencia débil.', logAnalytics),
      fact('Logs y contexto', 'Un log aislado gana valor cuando contiene timestamp, servicio, entidad, trace ID, severidad y campos estructurados.', 'Volumen de logs no equivale a observabilidad útil.', logAnalytics),
      fact('Entity query', 'Las entidades se pueden consultar en Grail y relacionar con datos observables mediante campos y vistas soportadas.', 'No inventes un entity ID ni asumas que todas las entidades tienen los mismos campos.', entityQuery),
    ],
  },
}
