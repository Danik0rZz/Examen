import { modules } from './modules'
import type { Module, Question, QuestionBucket } from './types'
import { buildQuestion } from './bank-core'
import { bankWelcome } from './bank-welcome'
import { bankInstructions } from './bank-instructions'
import { bankA } from './bank-a'
import { bankExtra } from './bank-extra'
import { bankB } from './bank-b'
import { bankC } from './bank-c'
import { bankD } from './bank-d'
import { bankE } from './bank-e'
import { bankExpansion } from './bank-expansion'
import { finalPlatform } from './bank-final-platform'
import { finalObservability } from './bank-final-observability'
import { finalNotebooks } from './bank-final-notebooks'
import { finalBusiness } from './bank-final-business'
import { finalData } from './bank-final-data'
import { finalDql } from './bank-final-dql'
import { finalSecurity } from './bank-final-security'
import { finalAutomation } from './bank-final-automation'
import { finalIngestion } from './bank-final-ingestion'
import { finalOther } from './bank-final-other'

export const finalQuestions = [
  ...finalPlatform, ...finalObservability, ...finalNotebooks, ...finalBusiness,
  ...finalData, ...finalDql, ...finalSecurity, ...finalAutomation,
  ...finalIngestion, ...finalOther,
]

export const allQuestions: Question[] = [
  ...bankWelcome,
  ...bankInstructions,
  ...bankA,
  ...bankExtra,
  ...bankB,
  ...bankC,
  ...bankD,
  ...bankE,
  ...finalQuestions,
  ...bankExpansion,
].map(buildQuestion)

export const questionsById: Record<string, Question> = Object.fromEntries(allQuestions.map((question) => [question.id, question]))
export const questionsByModule: Record<string, Question[]> = Object.fromEntries(
  modules.map((module) => [module.id, allQuestions.filter((question) => question.moduleId === module.id)]),
)
export const modulesWithQuestions: Module[] = modules.map((module) => ({
  id: module.id,
  order: module.order,
  title: module.title,
  eyebrow: module.eyebrow,
  summary: module.summary,
  objectives: module.objectives,
  keyTerms: module.keyTerms,
  sources: module.sources,
  focus: module.focus,
  questionIds: questionsByModule[module.id].map((question) => question.id),
}))
export const questionCounts = Object.fromEntries(modules.map((module) => [
  module.id,
  Object.fromEntries((['knowledge', 'precision', 'scenario', 'troubleshooting', 'practical'] as QuestionBucket[])
    .map((bucket) => [bucket, questionsByModule[module.id].filter((question) => question.bucket === bucket).length])),
])) as Record<string, Record<QuestionBucket, number>>
