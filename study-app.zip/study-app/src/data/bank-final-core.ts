import type { Draft, SourceKey } from './bank-core'
import type { QuestionBucket } from './types'

export const finalQuestion = (prefix: string, n: number, source: SourceKey,
  objective: string, bucket: QuestionBucket, prompt: string,
  choices: [string, string, string, string], correct: number | number[],
  explanation: string): Draft => ({
  id: `${prefix}-${String(n).padStart(3, '0')}`,
  source, objective, bucket,
  difficulty: bucket === 'knowledge' ? 'intermediate' : 'advanced',
  prompt, choices, correct: Array.isArray(correct) ? correct : [correct], explanation,
})
