import type { Draft } from './bank-core'

export const bankExtra: Draft[] = [
  {
    id: 'A-061', source: 'retention', objective: 'grail-retention', bucket: 'scenario', difficulty: 'advanced',
    prompt: 'Un equipo consulta logs de auditoría a 90 días, pero los registros se ingirieron en default_logs. El selector del Notebook permite 90 días y la consulta no devuelve los registros antiguos. ¿Cuál es la explicación más probable?',
    choices: [
      'El timeframe no amplía la retención; default_logs conserva los registros según la política del bucket.',
      'El Notebook conserva los registros durante 90 días, pero requiere ejecutar la sección Query antes que Explore.',
      'La tabla logs sólo admite consultas de 35 días aunque un bucket personalizado retenga más.',
      'La tabla logs exige un filtro de bucket explícito para cualquier consulta superior a 35 días.',
    ], correct: [0],
    explanation: 'La retención depende del bucket en que se almacenaron los logs. Un selector temporal puede solicitar datos fuera de la retención, pero no recuperarlos.',
  },
  {
    id: 'A-062', source: 'retention', objective: 'grail-table-bucket', bucket: 'scenario', difficulty: 'intermediate',
    prompt: 'Los logs de dos equipos están en default_logs y en un bucket personalizado. Un analista ejecuta fetch logs con permiso sobre ambos. ¿Qué debe esperar?',
    choices: [
      'Registros de ambos buckets, porque logs es la tabla lógica del tipo de registro.',
      'Sólo registros de default_logs, porque fetch logs no atraviesa buckets personalizados.',
      'Sólo registros del bucket personalizado, porque éste tiene prioridad sobre el predeterminado.',
      'Dos tablas de salida, una por bucket, aunque la consulta no especifique separación.',
    ], correct: [0],
    explanation: 'La tabla agrupa registros del mismo tipo en los buckets accesibles; un bucket concreto puede seleccionarse para acotar la lectura.',
  },
  {
    id: 'A-063', source: 'retention', objective: 'grail-custom-bucket', bucket: 'troubleshooting', difficulty: 'advanced',
    prompt: 'Se acorta la retención de un bucket personalizado de logs. Un informe histórico deja de mostrar parte de los registros. ¿Qué efecto documentado explica el cambio?',
    choices: [
      'Los datos más antiguos que el nuevo período pueden eliminarse al actualizar la retención.',
      'La reducción sólo cambia el selector por defecto del informe; los datos siguen íntegros.',
      'Grail mueve automáticamente esos registros a default_logs para conservarlos.',
      'El cambio sólo afecta a nuevos registros; los ya almacenados conservan siempre el período anterior.',
    ], correct: [0],
    explanation: 'Reducir la retención puede eliminar datos que exceden el nuevo período. Antes de cambiarla hay que evaluar la necesidad histórica y el alcance del bucket.',
  },
  {
    id: 'A-064', source: 'retention', objective: 'grail-view', bucket: 'precision', difficulty: 'intermediate',
    prompt: 'Una vista de Grail filtra registros de la tabla logs. ¿Qué afirmación describe correctamente su relación con el almacenamiento?',
    choices: [
      'La vista es una tabla virtual definida por una consulta; los registros siguen sujetos a sus buckets.',
      'La vista copia físicamente los logs y aplica una retención independiente de todos los buckets.',
      'La vista materializa una copia filtrada al crearla, pero conserva la política de retención original.',
      'La vista concede automáticamente permisos de lectura sobre los buckets de origen.',
    ], correct: [0],
    explanation: 'Las vistas proporcionan una perspectiva filtrada o transformada de tablas existentes; el almacenamiento y la autorización permanecen ligados a los datos subyacentes.',
  },
  {
    id: 'A-065', source: 'retention', objective: 'grail-partition', bucket: 'scenario', difficulty: 'advanced',
    prompt: 'Dos equipos deben consultar logs con retenciones y permisos distintos. ¿Qué decisión de diseño resuelve ambos requisitos en Grail?',
    choices: [
      'Separar los flujos en buckets personalizados apropiados y asignar permisos sobre cada bucket y la tabla logs.',
      'Guardar ambos flujos en default_logs y diferenciar sólo los timeframes de los dashboards.',
      'Crear una vista para cada equipo sin revisar permisos ni retención de los buckets.',
      'Conceder storage:logs:read a ambos equipos y mantener un único bucket con una sola retención.',
    ], correct: [0],
    explanation: 'Los buckets permiten particionar por retención y acceso. Leer logs también requiere el permiso de tabla correspondiente.',
  },
  {
    id: 'A-066', source: 'retention', objective: 'grail-defaults', bucket: 'knowledge', difficulty: 'intermediate',
    prompt: 'No se configuró asignación de bucket en el pipeline de logs. ¿Cuál es el destino esperado de los registros y qué dato controla su retención?',
    choices: [
      'default_logs; la política de retención de ese bucket.',
      'La tabla logs como almacenamiento físico; la retención de la sección Query.',
      'Una cola interna de OpenPipeline hasta que se asigne un bucket desde el primer Dashboard.',
      'El último bucket personalizado creado; su nombre determina automáticamente la retención.',
    ], correct: [0],
    explanation: 'Sin asignación explícita, los logs van al bucket predeterminado de su tipo. La retención corresponde al bucket, no al documento que los consulta.',
  },
]
