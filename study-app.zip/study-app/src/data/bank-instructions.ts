import type { Draft } from './bank-core'
import { finalQuestion } from './bank-final-core'

const q = (n: number, source: 'instructionsnetworking' | 'instructionsproctoru' | 'instructionsstrategy' | 'instructionsk8s',
  objective: string, bucket: 'knowledge' | 'precision' | 'scenario' | 'troubleshooting' | 'practical',
  prompt: string, choices: [string, string, string, string], correct: number | number[], explanation: string): Draft =>
  finalQuestion('I', n, source, objective, bucket, prompt, choices, correct, explanation)

export const bankInstructions: Draft[] = [
  // 1-10: Redes, Conectividad Outbound y Proxies
  q(1, 'instructionsnetworking', 'outbound-port', 'knowledge',
    '¿Cuál es el único sentido y puerto de tráfico de red requerido para que OneAgent comunique telemetría hacia Dynatrace SaaS o un ActiveGate?',
    [
      'Tráfico entrante (inbound) en los puertos UDP 8020 y 9999.',
      'Tráfico exclusivamente saliente (outbound-only) por el puerto estándar HTTPS 443.',
      'Tráfico bidireccional no seguro en el puerto HTTP 80.',
      'Conexión directa mediante túneles SSH en el puerto 22.',
    ], 1,
    'Toda la comunicación de OneAgent y ActiveGate hacia el clúster es saliente (outbound-only) mediante TLS por el puerto estándar HTTPS 443.'),

  q(2, 'instructionsnetworking', 'firewall-rules', 'precision',
    'Un administrador de seguridad exige abrir puertos de entrada en el cortafuegos perimetral para permitir que el clúster SaaS de Dynatrace interrogue a los servidores locales. ¿Cómo debe responderse a este requerimiento?',
    [
      'Aceptar y abrir todos los puertos TCP por encima del 1024 hacia la IP pública de los servidores.',
      'Explicar que Dynatrace nunca realiza conexiones entrantes (inbound); OneAgent y ActiveGate siempre inician la conexión de forma saliente hacia Dynatrace.',
      'Configurar una red privada virtual (VPN) permanente gestionada por el proveedor de hardware.',
      'Instalar un servidor FTP en cada máquina para transferir métricas.',
    ], 1,
    'Dynatrace SaaS nunca inicia conexiones entrantes hacia la infraestructura del cliente; OneAgent inicia toda comunicación de manera saliente hacia el endpoint de ingestión.'),

  q(3, 'instructionsnetworking', 'proxy-support', 'knowledge',
    'Si los servidores monitorizados residen en una red aislada sin acceso directo a internet, ¿qué mecanismo soporta OneAgent para enrutar su tráfico?',
    [
      'Soporta proxies HTTP/HTTPS estándar, autenticación básica/NTLM y archivos de configuración automática de proxy (PAC).',
      'Exige conectar cables de módem telefónico a cada placa base.',
      'Obliga a trasladar físicamente los servidores a un centro de datos público.',
      'No es posible monitorizar servidores que no tengan una dirección IP pública directa en internet.',
    ], 0,
    'OneAgent y ActiveGate soportan proxies corporativos HTTP/HTTPS y archivos PAC (Proxy Auto-Configuration), además de poder enrutar mediante ActiveGates intermedios.'),

  q(4, 'instructionsnetworking', 'pac-files', 'precision',
    '¿Qué función cumple un archivo PAC (Proxy Auto-Configuration) en la configuración de red de OneAgent?',
    [
      'Contiene una función JavaScript que determina automáticamente qué servidor proxy debe utilizar el agente en función de la URL de destino solicitada.',
      'Es un archivo que contiene las claves privadas de cifrado de todos los empleados.',
      'Es un instalador de drivers de tarjeta gráfica para servidores Linux.',
      'Es un archivo que apaga el cortafuegos durante los fines de semana.',
    ], 0,
    'Un archivo PAC define reglas dinámicas en JavaScript para enrutar el tráfico del agente hacia el proxy adecuado según el dominio o la dirección IP de destino.'),

  q(5, 'instructionsnetworking', 'dns-resolution', 'troubleshooting',
    'Tras instalar OneAgent en un servidor Linux, el comando `oneagentctl --status` muestra que el agente no puede comunicarse con el clúster. La prueba de ping al gateway falla por nombre pero funciona por IP. ¿Cuál es la causa raíz más probable?',
    [
      'Fallo en la resolución DNS local del servidor que impide resolver el nombre de dominio cualificado (FQDN) del endpoint de Dynatrace.',
      'El servidor tiene demasiados núcleos de procesador para ejecutar OneAgent.',
      'OneAgent requiere que el sistema operativo esté configurado en idioma alemán.',
      'El disco duro del servidor está funcionando demasiado rápido.',
    ], 0,
    'La resolución DNS es un prerrequisito indispensable: OneAgent necesita resolver el FQDN del clúster SaaS o del ActiveGate para establecer la sesión HTTPS.'),

  q(6, 'instructionsnetworking', 'tls-termination', 'precision',
    'Si una organización implementa inspección profunda de paquetes TLS (SSL Decryption) en su proxy corporativo mediante un certificado de CA intermedio propio, ¿qué debe configurarse en OneAgent?',
    [
      'Desactivar por completo el cifrado en los servidores de producción.',
      'Añadir el certificado raíz de la CA corporativa al almacén de certificados de confianza de OneAgent para evitar fallos de verificación TLS.',
      'Desinstalar el sistema operativo y cambiar a una versión antigua.',
      'Configurar contraseñas en blanco para todos los usuarios del sistema.',
    ], 1,
    'Si un proxy intermedio intercepta y regenera los certificados TLS con una CA interna, se debe agregar el certificado de dicha CA en la configuración de certificados de confianza de OneAgent.'),

  q(7, 'instructionsk8s', 'hierarchy', 'knowledge',
    '¿Cuál es la jerarquía estándar de objetos en un clúster de Kubernetes que un candidato de Associate debe dominar?',
    [
      'Cluster → Node → Namespace → Deployment/Workload → Pod → Container.',
      'Datacenter → Switch → Router → Cable → Ordenador.',
      'Tenant → Dashboard → Tile → Metric → Log.',
      'CPU → Memoria → Disco → Placa → Teclado.',
    ], 0,
    'El candidato debe comprender la jerarquía nativa de Kubernetes: Cluster aloja Nodes físicos/virtuales, que contienen Namespaces con Workloads/Deployments, los cuales gestionan Pods con Containers.'),

  q(8, 'instructionsk8s', 'pod-mapping', 'precision',
    'En el modelo topológico de Dynatrace, ¿cómo se mapea conceptualmente un Pod de Kubernetes instrumentado por OneAgent?',
    [
      'Como un Data Center físico independiente en Smartscape.',
      'Como una Process Group Instance (PGI) que se ejecuta dentro del Host correspondiente al Node de Kubernetes.',
      'Como una política de retención de 10 años en Grail.',
      'Como un usuario humano con permisos de administrador en la consola.',
    ], 1,
    'Un Pod de Kubernetes aloja uno o más contenedores en ejecución; Dynatrace lo modela como una Process Group Instance (PGI) ejecutándose sobre la entidad Host que representa al Node.'),

  q(9, 'instructionsk8s', 'operator-role', 'knowledge',
    '¿Cuál es la función del Dynatrace Operator en un entorno de Kubernetes?',
    [
      'Automatizar el despliegue, ciclo de vida, actualización y configuración de OneAgent y ActiveGate en los nodos del clúster de forma nativa.',
      'Reescribir el código fuente de los microservicios en lenguaje Rust.',
      'Cobrar comisiones bancarias por cada contenedor desplegado en el clúster.',
      'Apagar los pods que consuman más de un 10% de CPU.',
    ], 0,
    'Dynatrace Operator es el operador nativo de Kubernetes que gestiona de manera declarativa los Custom Resources (CRD) para desplegar OneAgent, ActiveGate y recopilar métricas del clúster.'),

  q(10, 'instructionsnetworking', 'web-app-tiers', 'knowledge',
    'En una arquitectura web clásica multicapa, ¿cuál es el orden habitual de dependencias entre componentes?',
    [
      'Base de datos → Servidor Web → Balanceador de carga → Cliente.',
      'Cliente Web / Navegador → Balanceador de Carga (Load Balancer) → Frontend Web → Servicios de Aplicación Backend → Base de Datos / Almacenamiento.',
      'Microservicio Backend → Cable de red → Teclado → Monitor.',
      'Memoria RAM → Procesador → Tarjeta de Sonido → Disco Duro.',
    ], 1,
    'El flujo de arquitectura web estándar transcurre desde el cliente hacia el balanceador, frontend, capa de servicios backend y persistencia en base de datos.'),

  // 11-20: Reglas de Proctoring y Entorno de Examen
  q(11, 'instructionsproctoru', 'guardian-browser', 'knowledge',
    '¿Qué software de navegación seguro es obligatorio para realizar el examen de certificación supervisado por ProctorU?',
    [
      'Google Chrome con extensiones de bloqueo de publicidad activadas.',
      'Guardian Browser de ProctorU, que verifica el entorno y bloquea software no autorizado.',
      'Internet Explorer 6 en modo de compatibilidad.',
      'Cualquier navegador web sin importar su configuración ni extensiones.',
    ], 1,
    'ProctorU exige utilizar su propio navegador seguro, Guardian Browser, diseñado para supervisar la sesión y bloquear procesos en segundo plano no permitidos.'),

  q(12, 'instructionsproctoru', 'room-requirements', 'precision',
    'Durante el proceso de verificación previa al examen, ¿qué requisito del entorno físico es estrictamente evaluado por el supervisor (proctor)?',
    [
      'La estancia debe estar completamente a oscuras con las persianas bajadas.',
      'El candidato debe estar solo en una habitación privada, bien iluminada, con el escritorio completamente despejado de libros, papeles y dispositivos no autorizados, realizando un escaneo de 360 grados con la cámara web.',
      'Debe haber al menos tres compañeros de trabajo presentes en la sala para ayudar en caso de duda.',
      'Se debe colocar música de fondo a volumen alto para comprobar el micrófono.',
    ], 1,
    'Las normas de proctoring exigen aislamiento total en una habitación privada, mesa limpia y escaneo de 360 grados del espacio con la webcam antes de iniciar el examen.'),

  q(13, 'instructionsproctoru', 'dual-monitors', 'precision',
    '¿Está permitido el uso de monitores secundarios (pantallas dobles) durante el examen supervisado de certificación?',
    [
      'Sí, se permite conectar hasta 4 monitores adicionales siempre que sean de la misma marca.',
      'No, está terminantemente prohibido; cualquier monitor adicional debe estar completamente desconectado de la corriente eléctrica y del ordenador.',
      'Solo se permite si el segundo monitor muestra un canal de televisión de noticias.',
      'Solo se permite en ordenadores portátiles de la marca Apple.',
    ], 1,
    'Está terminantemente prohibido utilizar más de una pantalla activa durante el examen de certificación; los monitores secundarios deben desconectarse físicamente.'),

  q(14, 'instructionsproctoru', 'headphones-policy', 'knowledge',
    '¿Cuál es la política oficial respecto al uso de auriculares (headphones o earbuds) durante el examen supervisado?',
    [
      'Es obligatorio utilizar auriculares de diadema de gran tamaño.',
      'No están permitidos los auriculares de ningún tipo; el audio debe ser emitido y capturado por los altavoces y micrófono integrados o externos del equipo.',
      'Se permiten auriculares inalámbricos pero no auriculares con cable.',
      'Se permite el uso de auriculares solo durante los primeros 10 minutos.',
    ], 1,
    'Por motivos de seguridad y para evitar transmisiones encubiertas, los supervisores de ProctorU prohíben el uso de auriculares durante el examen.'),

  q(15, 'instructionsproctoru', 'identification', 'knowledge',
    '¿Qué tipo de identificación es válida y obligatoria presentar ante la cámara antes de comenzar el examen?',
    [
      'Una tarjeta de socio de un videoclub o supermercado.',
      'Un documento de identidad oficial emitido por el gobierno con fotografía reconocible y vigente (DNI, pasaporte o carnet de conducir oficial).',
      'Una tarjeta de visita profesional escrita a mano.',
      'Una fotografía de la infancia guardada en el teléfono móvil.',
    ], 1,
    'Se requiere una identificación legal válida emitida por el gobierno con fotografía clara y nombre completo coincidente con la inscripción en Dynatrace University.'),

  q(16, 'instructionsproctoru', 'virtual-machines', 'precision',
    '¿Se permite realizar el examen desde dentro de una máquina virtual (ej. VMware, VirtualBox o Parallels)?',
    [
      'Sí, de hecho es el entorno recomendado por el fabricante.',
      'No, el software de proctoring detecta y bloquea hipervisores y máquinas virtuales; el examen debe rendirse directamente sobre el sistema operativo anfitrión físico.',
      'Solo si la máquina virtual tiene asignados más de 32 GB de memoria RAM.',
      'Solo si la máquina virtual ejecuta el sistema operativo MS-DOS.',
    ], 1,
    'Guardian Browser bloquea la ejecución dentro de máquinas virtuales para prevenir trampas y manipulación de procesos; debe ejecutarse en el hardware físico nativo.'),

  q(17, 'instructionsstrategy', 'exam-duration', 'knowledge',
    '¿Cuál es la duración estándar publicada para el examen oficial Dynatrace Associate y cuántas preguntas contiene habitualmente?',
    [
      '30 minutos para responder 15 preguntas.',
      'Aproximadamente 105 minutos para abordar unas 60 a 70 preguntas escritas y de escenario.',
      '8 horas ininterrumpidas para resolver 500 preguntas teóricas.',
      'No hay límite de tiempo; el examen permanece abierto durante un mes.',
    ], 1,
    'El examen estándar Associate consta habitualmente de entre 60 y 70 preguntas para resolver en una ventana de aproximadamente 105 minutos (más tiempo de verificación previo).'),

  q(18, 'instructionsstrategy', 'passing-score', 'knowledge',
    '¿Cuál es el porcentaje aproximado de respuestas correctas requerido para superar el examen Dynatrace Associate?',
    [
      'Aproximadamente el 50% de las preguntas.',
      'Generalmente alrededor del 70% o superior, según la especificación vigente de Dynatrace University.',
      'Se exige el 100% perfecto sin admitir ningún fallo.',
      'Basta con acertar la primera pregunta del examen.',
    ], 1,
    'La puntuación de corte publicada por Dynatrace suele situarse en el entorno del 70% o superior; siempre debe reconfirmarse en el Learning Plan antes de la cita.'),

  q(19, 'instructionsproctoru', 'room-interruption', 'troubleshooting',
    'Si durante el examen una persona externa entra accidentalmente en la habitación donde el candidato realiza la prueba, ¿cuál es la consecuencia reglamentaria?',
    [
      'El supervisor puede advertir al candidato, solicitar un nuevo escaneo de la sala o suspender e invalidar inmediatamente el examen por vulneración de la seguridad.',
      'El candidato recibe automáticamente 10 puntos de bonificación en su puntuación final.',
      'El examen se pausa durante tres días laborales completos.',
      'No ocurre nada porque las terceras personas tienen permiso de estancia.',
    ], 0,
    'La presencia de terceras personas en la sala es una falta grave en exámenes supervisados que puede acarrear la anulación inmediata de la convocatoria sin reembolso.'),

  q(20, 'instructionsstrategy', 'time-management', 'scenario',
    'Un candidato se encuentra bloqueado en una pregunta compleja que no comprende tras 3 minutos de lectura. ¿Cuál es la mejor táctica de gestión del tiempo?',
    [
      'Quedarse en esa misma pregunta durante 45 minutos hasta que se le ocurra una idea.',
      'Marcar la pregunta con la opción de revisión (Flag for review), seleccionar una respuesta tentativa provisional y continuar avanzando para no comprometer el tiempo de las preguntas restantes.',
      'Cerrar el navegador web y abandonar el examen definitivamente.',
      'Elegir siempre la opción A sin leer las alternativas.',
    ], 1,
    'La gestión del tiempo es crítica: si una pregunta se atasca, márcala con la bandera de revisión, pon tu mejor estimación provisional y sigue adelante para no dejar preguntas fáciles sin responder al final.'),

  // 21-35: Tácticas de Búsqueda en Documentación Oficial y Versionado
  q(21, 'instructionsstrategy', 'open-book-rules', 'knowledge',
    'En los exámenes oficiales de Dynatrace que permiten acceso a la documentación oficial abierta, ¿qué recurso está explícitamente autorizado para consultar?',
    [
      'Foros públicos no oficiales de internet, chats de mensajería instantánea y redes sociales.',
      'El portal oficial de documentación técnica de Dynatrace (docs.dynatrace.com) en una pestaña controlada.',
      'Motores de búsqueda de inteligencia artificial generativa externos no autorizados.',
      'Llamadas telefónicas a compañeros de departamento.',
    ], 1,
    'En las convocatorias con política open-book, el acceso permitido se limita estrictamente a la documentación oficial de Dynatrace (docs.dynatrace.com).'),

  q(22, 'instructionsstrategy', 'version-banner', 'precision',
    'Al consultar un artículo en docs.dynatrace.com durante el estudio o examen, ¿por qué es fundamental revisar el banner de versión situado en la parte superior de la página?',
    [
      'Para comprobar la cotización de las acciones de Dynatrace en la bolsa de Nueva York.',
      'Para verificar si el artículo describe el comportamiento de Latest Dynatrace (Grail y AppEngine) o si corresponde a la experiencia Classic, cuyas rutas y modelos difieren.',
      'Para saber el santoral del día en que se redactó el artículo.',
      'Para comprobar si el autor del artículo tiene cuenta de LinkedIn.',
    ], 1,
    'Revisar la etiqueta de versión (Latest vs Classic) evita caer en preguntas trampa donde se pregunta por el modelo de Latest Dynatrace pero se responde con una ruta o límite de Classic.'),

  q(23, 'instructionsstrategy', 'search-terms-precision', 'scenario',
    'Una pregunta del examen pide identificar el permiso IAM necesario para instalar aplicaciones desde Dynatrace Hub. ¿Cuál es la consulta de búsqueda más eficaz en docs.dynatrace.com?',
    [
      'Escribir "cómo poner cosas nuevas en la pantalla de mi ordenador".',
      'Buscar el término exacto "app-engine:apps:install" o "Hub permissions IAM".',
      'Buscar la palabra "Dynatrace" y leer todos los resultados desde el primero.',
      'Escribir una carta de reclamación al departamento de soporte.',
    ], 1,
    'Las búsquedas quirúrgicas ahorran tiempo: utilizar términos técnicos específicos en inglés (`app-engine:apps:install`, `storage:bucket-definitions:write`) localiza la tabla de permisos en segundos.'),

  q(24, 'instructionsstrategy', 'feature-status', 'precision',
    'En la documentación técnica oficial de Dynatrace, ¿qué implica que una capacidad esté etiquetada como "Preview" o "Early Access"?',
    [
      'Que la funcionalidad está disponible de forma completa y predeterminada en el 100% de los clientes desde hace 10 años.',
      'Que la capacidad está en fase de prueba y puede requerir activación explícita por soporte, tener limitaciones documentadas y no ser el comportamiento estándar general evaluado.',
      'Que la funcionalidad es obligatoria por ley en todos los países de la Unión Europea.',
      'Que la capacidad solo funciona durante las noches de luna llena.',
    ], 1,
    'Las capacidades en Preview o Early Access tienen restricciones operativas y no representan el comportamiento estable de General Availability (GA) a menos que el escenario lo especifique explícitamente.'),

  q(25, 'instructionsstrategy', 'classic-routes-trap', 'scenario',
    'Un distractor en una pregunta de examen describe una ruta como "Settings > Server-side service monitoring > Custom service detection". ¿A qué experiencia pertenece esta ruta?',
    [
      'A la experiencia Classic de Dynatrace, que no debe confundirse con la navegación moderna de Latest Dynatrace basada en aplicaciones y Launcher.',
      'A la consola de administración de un router doméstico WiFi.',
      'A la configuración de hardware de la BIOS de la placa base.',
      'A un comando de consola de Linux de los años 80.',
    ], 0,
    'Las rutas jerárquicas clásicas de "Settings > ..." son típicas de Classic; en Latest Dynatrace la configuración se gestiona dentro de cada aplicación modular o mediante Settings API / Workflows.'),

  q(26, 'instructionsnetworking', 'activegate-traffic-reduction', 'knowledge',
    '¿Cómo ayuda el despliegue de un ActiveGate a optimizar el tráfico de red en un centro de datos con 500 servidores monitorizados?',
    [
      'Obliga a los servidores a apagar sus tarjetas de red por las noches.',
      'Concentra las conexiones salientes de los 500 OneAgents locales en un único canal seguro hacia Dynatrace SaaS, reduciendo el consumo de ancho de banda y conexiones firewall.',
      'Convierte los datos en ondas de radio de onda corta para no usar cables de red.',
      'Borra el 90% de los logs para que no salgan del centro de datos.',
    ], 1,
    'Un Environment ActiveGate actúa como concentrador y enrutador: consolida las conexiones de cientos de OneAgents internos hacia una única salida externa por el puerto 443.'),

  q(27, 'instructionsk8s', 'container-injection', 'precision',
    '¿Cómo instrumenta OneAgent los contenedores de aplicaciones que se ejecutan dentro de Pods en Kubernetes?',
    [
      'Requiere que el programador edite el Dockerfile y copie los binarios de OneAgent manualmente dentro de la imagen base de la aplicación.',
      'Inyecta dinámicamente las librerías de instrumentación en el contenedor en el momento en que se inicia el Pod, aprovechando volúmenes compartidos y webhooks de mutación.',
      'OneAgent no es capaz de monitorizar contenedores en Kubernetes.',
      'Instala un sistema operativo completo dentro de cada contenedor de la aplicación.',
    ], 1,
    'A través de init containers o webhooks de mutación del Dynatrace Operator, OneAgent monta sus librerías dinámicamente en el pod sin necesidad de modificar las imágenes de contenedor en los Dockerfiles.'),

  q(28, 'instructionsproctoru', 'clean-desk', 'precision',
    '¿Cuál de los siguientes objetos está explícitamente prohibido en el escritorio durante el examen supervisado?',
    [
      'El ratón del ordenador.',
      'Teléfonos móviles, tabletas, relojes inteligentes (smartwatches), notas adhesivas, bolígrafos y hojas de papel en blanco (salvo autorización explícita de pizarra virtual).',
      'El teclado conectado al ordenador.',
      'La cámara web requerida por el supervisor.',
    ], 1,
    'Dispositivos electrónicos auxiliares, teléfonos, smartwatches y cualquier material impreso o notas manuscritas están estrictamente vetados del espacio de trabajo.'),

  q(29, 'instructionsstrategy', 'adversarial-reading-absolutes', 'precision',
    'Al leer una opción de examen que contiene términos absolutistas como "siempre", "nunca", "en todos los casos sin excepción" o "únicamente", ¿cuál suele ser el juicio analítico correcto?',
    [
      'Elegirla inmediatamente porque la seguridad absoluta es siempre la respuesta correcta en ingeniería.',
      'Desconfiar y evaluarla con extremo rigor crítico, ya que las afirmaciones absolutas en arquitectura suelen ser falsas al existir excepciones documentadas, requisitos previos o modos alternativos.',
      'Ignorarla porque las preguntas de examen nunca tienen palabras en negrita.',
      'Traducir la opción al idioma francés antes de contestar.',
    ], 1,
    'En exámenes de certificación, las afirmaciones categóricas absolutas ("always", "never", "only") suelen ser distractores incorrectos que ignoran condiciones de soporte o configuraciones avanzadas.'),

  q(30, 'instructionsstrategy', 'best-next-step', 'scenario',
    'Una pregunta de examen describe un problema de conectividad y formula: "¿Cuál es el PRIMER paso que debe realizar el ingeniero?". Dos opciones son técnicamente válidas a largo plazo. ¿Cómo se decide la correcta?',
    [
      'Elegir la opción que describe la solución más costosa financieramente.',
      'Elegir la acción de diagnóstico inmediata que reduce mayor incertidumbre antes de aplicar cambios destructivos o de configuración (ej. verificar conectividad antes de reinstalar).',
      'Lanzar una moneda al aire para elegir al azar.',
      'Elegir la opción con el texto más corto.',
    ], 1,
    'Las preguntas de "primer paso" (first step) evalúan la metódica diagnóstica: se debe verificar la evidencia preliminar (logs de conexión, estado del servicio) antes de emprender acciones correctivas mayores.'),

  // 31-45: Kubernetes, Microservicios y Prácticas de Diagnóstico
  q(31, 'instructionsk8s', 'namespace-isolation', 'knowledge',
    'En Kubernetes, ¿para qué se utiliza un Namespace y cómo influye en la observabilidad de Dynatrace?',
    [
      'Para dividir físicamente el procesador del servidor en dos mitades.',
      'Para aislar lógicamente recursos, microservicios y equipos dentro del mismo clúster; Dynatrace permite filtrar métricas, logs y trazas segmentando por `k8s.namespace.name`.',
      'Para cambiar la hora oficial de los servidores de producción.',
      'Para evitar que los desarrolladores utilicen bases de datos SQL.',
    ], 1,
    'Los Namespaces agrupan lógicamente cargas de trabajo; en Dynatrace constituyen una dimensión analítica fundamental para filtrar telemetría y delimitar Management Zones.'),

  q(32, 'instructionsnetworking', 'http-status-codes', 'knowledge',
    'En una investigación de rendimiento web, ¿qué indica un código de estado HTTP de la serie 5xx frente a un código 4xx?',
    [
      '5xx indica que la página se cargó correctamente y 4xx que el servidor está apagado.',
      '5xx representa un error en el servidor o servicio backend (Server Error); 4xx indica un error en la petición del cliente (ej. 404 Not Found o 403 Forbidden).',
      '5xx significa que la conexión es segura por fibra óptica y 4xx que es por satélite.',
      'No hay diferencia: todos los números superiores a 100 indican éxito de la petición.',
    ], 1,
    'Conocimiento base de redes: los errores 4xx representan fallos en el origen de la petición del cliente, mientras que los 5xx reflejan averías o excepciones no controladas en el servidor.'),

  q(33, 'instructionsk8s', 'cgroups-resources', 'precision',
    '¿Qué tecnología del núcleo de Linux utilizan los contenedores de Kubernetes para limitar el consumo de CPU y memoria de un pod?',
    [
      'Linux Control Groups (cgroups).',
      'La tarjeta gráfica del ordenador cliente.',
      'El sistema de sonido de alta fidelidad del servidor.',
      'El protocolo de correo electrónico SMTP.',
    ], 0,
    'Los contenedores Linux se apoyan en namespaces del kernel para el aislamiento y en cgroups (control groups) para monitorizar y restringir el uso de CPU y memoria.'),

  q(34, 'instructionsnetworking', 'load-balancer-headers', 'knowledge',
    'Cuando una petición atraviesa un balanceador de carga o proxy inverso hacia un servidor backend, ¿qué cabecera HTTP estándar permite conocer la dirección IP original del cliente?',
    [
      'X-Forwarded-For.',
      'Content-Length.',
      'Set-Cookie.',
      'Accept-Language.',
    ], 0,
    'La cabecera `X-Forwarded-For` transporta la dirección IP de origen real del cliente cuando la petición es reenviada a través de proxies intermedios o balanceadores de carga.'),

  q(35, 'instructionsproctoru', 'technical-issues', 'troubleshooting',
    'Si durante la realización del examen supervisado la conexión a internet se interrumpe durante 30 segundos, ¿cuál es el procedimiento habitual?',
    [
      'El candidato es expulsado permanentemente de Dynatrace University de por vida.',
      'Guardian Browser intenta restablecer la conexión; una vez recuperada, el supervisor retoma la sesión, puede requerir una breve verificación de seguridad y el examen continúa.',
      'El ordenador se apaga automáticamente y se borra el disco duro.',
      'Se envía una multa económica a la dirección postal del candidato.',
    ], 1,
    'ProctorU gestiona desconexiones breves reconectando con el supervisor en cuanto vuelve la señal de red para reanudar el examen tras una rápida comprobación.'),

  q(36, 'instructionsstrategy', 'multi-select-strategy', 'precision',
    'En preguntas de opción múltiple con varias respuestas correctas ("Select the TWO best answers"), ¿cuál es la técnica de resolución más rigurosa?',
    [
      'Seleccionar todas las opciones disponibles sin leerlas para asegurar el acierto.',
      'Evaluar cada una de las cuatro alternativas como una proposición de verdadero/falso independiente, verificando que las dos elegidas cumplan todas las restricciones técnicas de la pregunta.',
      'Marcar solo una opción porque las preguntas múltiples son opcionales.',
      'Elegir las opciones que tengan nombres más largos en caracteres.',
    ], 1,
    'En preguntas de selección múltiple, evalúa cada alternativa de forma aislada contrastándola con la documentación; nunca marques más ni menos de las opciones explícitamente solicitadas.'),

  q(37, 'instructionsnetworking', 'tls-handshake-failure', 'troubleshooting',
    'En los logs de OneAgent aparece el mensaje recurrente `TLS handshake failed: certificate expired`. ¿Qué significa este error de infraestructura?',
    [
      'Que el servidor físico se ha quedado sin espacio en disco.',
      'Que el certificado digital SSL/TLS del endpoint de destino ha superado su fecha de caducidad y el agente rechaza la conexión por seguridad.',
      'Que el cable de red está desconectado físicamente del enchufe.',
      'Que la memoria RAM del ordenador es de baja velocidad.',
    ], 1,
    'Un error de handshake TLS por certificado expirado revela un problema de infraestructura PKI: el certificado SSL del clúster o proxy ha caducado y debe ser renovado.'),

  q(38, 'instructionsk8s', 'daemonset-concept', 'knowledge',
    '¿Qué tipo de recurso de Kubernetes utiliza habitualmente Dynatrace Operator para asegurar que OneAgent se ejecute en todos los nodos de un clúster?',
    [
      'Un StatefulSet con réplica única.',
      'Un DaemonSet, que garantiza que una copia del pod de OneAgent se ejecute automáticamente en cada nodo elegible del clúster.',
      'Un CronJob que se ejecuta únicamente los domingos por la tarde.',
      'Un servicio de tipo ClusterIP sin selectores.',
    ], 1,
    'En Kubernetes, un DaemonSet es el controlador estándar para agentes y monitorización: asegura que cada nodo del clúster ejecute una instancia de OneAgent.'),

  q(39, 'instructionsstrategy', 'hands-on-importance', 'knowledge',
    '¿Por qué se recomienda encarecidamente utilizar un entorno de prácticas (Playground o tenant de prueba) antes de presentarse al examen oficial?',
    [
      'Porque Dynatrace exige presentar un diploma impreso de asistencia a clases presenciales.',
      'Porque muchas preguntas sitúan al candidato en escenarios operativos reales (investigar problemas en Smartscape, escribir consultas DQL o configurar dashboards) difíciles de dominar solo con teoría abstracta.',
      'Porque los tenants de prueba son necesarios para instalar videojuegos.',
      'Porque solo los usuarios con tenant pueden registrarse en el portal de exámenes.',
    ], 1,
    'La certificación Associate evalúa transferencia operativa real: navegar por la consola, filtrar en Smartscape y escribir consultas DQL en vivo consolida un criterio que la mera memorización no aporta.'),

  q(40, 'instructionsproctoru', 'proctor-chat', 'knowledge',
    'Durante el examen supervisado, ¿cómo se comunica el candidato con el supervisor de ProctorU en caso de requerir asistencia técnica?',
    [
      'Gritando por la ventana de la habitación.',
      'A través del chat de texto o canal de audio bidireccional integrado en la aplicación de supervisión de Guardian Browser.',
      'Enviando un mensaje privado por redes sociales.',
      'Llamando por teléfono móvil al supervisor.',
    ], 1,
    'La aplicación de proctoring dispone de un panel de soporte interactivo con chat de texto y audio directo con el supervisor para atender cualquier incidencia técnica.'),

  // 41-55: Escenarios de Decisión y Análisis Crítico
  q(41, 'instructionsnetworking', 'proxy-authentication', 'precision',
    'Si el proxy de salida corporativo exige autenticación para permitir tráfico hacia internet, ¿qué métodos soporta OneAgent?',
    [
      'Únicamente reconocimiento facial del administrador del sistema.',
      'Autenticación básica (Basic Auth), NTLM y paso de credenciales configuradas en los archivos de instalación o mediante `oneagentctl`.',
      'No soporta autenticación en proxies bajo ninguna circunstancia.',
      'Exige que el proxy no tenga contraseña.',
    ], 1,
    'OneAgent admite proxies autenticados corporativos con esquemas de autenticación estándar como Basic o NTLM, configurando usuario y contraseña cifrados.'),

  q(42, 'instructionsstrategy', 'distractor-analysis', 'scenario',
    'En una pregunta sobre cómo visualizar errores de un servicio en DQL, un distractor propone: `fetch errors | filter service == "MyService"`. ¿Por qué esta opción es técnicamente incorrecta?',
    [
      'Porque en Grail no existe la tabla raíz llamada `errors`; los errores se investigan consultando `fetch logs`, `fetch events` o mediante la métrica de tasa de fallos en `timeseries`.',
      'Porque DQL no permite utilizar filtros con nombres de servicios entre comillas.',
      'Porque la palabra `fetch` solo puede usarse una vez por trimestre.',
      'Porque los errores están prohibidos en las consultas de Grail.',
    ], 0,
    'Un error clásico en distractores es inventar tablas inexistentes: `errors` no es una fuente de Grail; los errores de servicio se consultan en `logs`, `events` o con métricas como `dt.service.failure_rate`.'),

  q(43, 'instructionsk8s', 'node-resource-exhaustion', 'scenario',
    'En un clúster de Kubernetes, un Node se queda sin memoria RAM libre y el kernel activa el Out-Of-Memory Killer (OOM Killer). ¿Cómo detecta e informa Dynatrace este evento?',
    [
      'Dynatrace se apaga y borra todas las métricas del clúster.',
      'OneAgent detecta la terminación abrupta del proceso por OOM en el nodo, registra el evento de infraestructura y Davis puede correlacionarlo en un Problem de indisponibilidad.',
      'Dynatrace compra automáticamente más memoria RAM en una tienda online.',
      'El evento se ignora porque los OOM son normales en Kubernetes.',
    ], 1,
    'OneAgent captura los eventos de OOM Killer a nivel de kernel y los asocia al contenedor y pod afectado, permitiendo que Davis correlacione la caída en el árbol del Problem.'),

  q(44, 'instructionsnetworking', 'dns-ttl-impact', 'precision',
    '¿Qué impacto tiene un valor de Time-To-Live (TTL) de DNS extremadamente alto en el endpoint de un ActiveGate cuando este cambia de dirección IP?',
    [
      'Hace que el ordenador funcione al doble de velocidad.',
      'Puede provocar que los OneAgents sigan intentando conectar a la dirección IP antigua hasta que expire el TTL de la caché DNS local, causando interrupciones temporales de telemetría.',
      'No tiene ningún impacto porque las direcciones IP nunca caducan.',
      'Borra automáticamente los datos de los discos duros.',
    ], 1,
    'Un TTL de DNS excesivamente prolongado retiene IPs obsoletas en la caché local tras una migración de red, impidiendo que los agentes alcancen la nueva IP del ActiveGate.'),

  q(45, 'instructionsproctoru', 'permitted-breaks', 'knowledge',
    '¿Cuál es la norma general respecto a levantarse del asiento o abandonar el encuadre de la cámara durante el examen oficial supervisado?',
    [
      'El candidato puede salir de la sala cuantas veces desee sin avisar.',
      'Abandonar la vista de la cámara sin autorización previa del supervisor suspende el examen y puede causar la invalidación inmediata de la prueba por sospecha de fraude.',
      'Es obligatorio salir a pasear durante 15 minutos cada media hora.',
      'Se permite ausentarse siempre que se deje un cartel explicativo.',
    ], 1,
    'El candidato debe permanecer enfocado por la cámara web durante toda la duración de la prueba; ausentarse sin permiso del proctor conlleva la anulación del examen.'),

  q(46, 'instructionsstrategy', 'elimination-tactic', 'scenario',
    'Ante una pregunta compleja con cuatro opciones de respuesta, el candidato identifica que dos opciones contradicen frontalmente principios básicos de la documentación oficial. ¿Qué táctica debe aplicar?',
    [
      'Elegir una de las dos opciones descartadas por si la documentación estaba equivocada.',
      'Descartar con seguridad las dos opciones erróneas y concentrar el análisis comparativo exclusivamente entre las dos alternativas restantes para identificar la condición omitida.',
      'Cerrar el navegador de inmediato.',
      'Preguntar en voz alta a la habitación.',
    ], 1,
    'El método de descarte sistemático es la técnica más eficaz en certificaciones: eliminar distractores inviables reduce la incertidumbre al 50% entre las dos opciones técnicamente sólidas.'),

  q(47, 'instructionsk8s', 'enhanced-visibility', 'knowledge',
    '¿Qué beneficio aporta la funcionalidad Enhanced Object Visibility en la monitorización de Kubernetes con Dynatrace?',
    [
      'Permite capturar metadatos detallados y el estado operativo de objetos avanzados de Kubernetes (Events, Ingresses, Persistent Volume Claims) directamente desde la API del clúster.',
      'Cambia el color de la consola web a verde fluorescente.',
      'Duplica el número de réplicas de los pods sin avisar a los desarrolladores.',
      'Elimina la necesidad de utilizar contraseñas en el clúster.',
    ], 0,
    'Enhanced Object Visibility enriquece la observabilidad del clúster recopilando objetos de API (PVCs, eventos de Kubernetes, ingress controllers) para un diagnóstico integral de infraestructura.'),

  q(48, 'instructionsnetworking', 'firewall-inspection-proxy', 'scenario',
    'Un cortafuegos corporativo bloquea el tráfico de OneAgent porque no reconoce el protocolo binario empaquetado sobre HTTPS. ¿Cómo se soluciona este bloqueo respetando las políticas de seguridad?',
    [
      'Desactivando el cortafuegos perimetral de toda la compañía.',
      'Desplegando un Environment ActiveGate en la DMZ o segmento permitido para que concentre la telemetría y actúe como punto de salida formal autorizado por la política de seguridad.',
      'Obligando a los empleados a trabajar desde sus domicilios particulares.',
      'Desinstalando Dynatrace de todos los servidores.',
    ], 1,
    'La solución arquitectónica corporativa estándar ante firewalls restrictivos es desplegar un ActiveGate intermedio en una zona autorizada (DMZ) para centralizar la salida segura.'),

  q(49, 'instructionsstrategy', 'keyword-flags', 'precision',
    'En un enunciado de examen, ¿qué diferencia de criterio existe entre la frase "What is the RECOMMENDED practice?" y "What is a POSSIBLE workaround?"?',
    [
      'No hay diferencia: ambas piden exactamente la misma respuesta.',
      '"Recommended practice" pide la solución arquitectónica estándar y oficial respaldada por Dynatrace; "Possible workaround" busca un parche temporal funcional aunque no sea la arquitectura ideal.',
      '"Recommended practice" solo aplica a ordenadores portátiles.',
      '"Workaround" significa que el software no funciona.',
    ], 1,
    'Presta atención a la intención del enunciado: las preguntas de "best practice" penalizan parches no soportados y premian soluciones canónicas alineadas con la arquitectura oficial.'),

  q(50, 'instructionsproctoru', 'camera-positioning', 'knowledge',
    '¿Cómo debe colocarse la cámara web durante la realización del examen supervisado?',
    [
      'Apuntando hacia el techo o hacia el suelo para que no se vea al candidato.',
      'Enfocando frontalmente al candidato de modo que su rostro, manos y el espacio inmediato del teclado sean claramente visibles para el supervisor en todo momento.',
      'Tapada con una pegatina negra por motivos de privacidad.',
      'Colocada en otra habitación diferente de donde se realiza el examen.',
    ], 1,
    'La cámara web debe ofrecer un encuadre claro y continuo del rostro y las manos del aspirante frente al ordenador durante todo el tiempo de examen.'),

  // 51-68: Consolidación y Verificación de Criterio de Examen
  q(51, 'instructionsstrategy', 'retake-policies', 'knowledge',
    '¿Cuál es la política general de reintento de examen (retake policy) publicada por Dynatrace University en caso de no superar la prueba en el primer intento?',
    [
      'El candidato debe esperar un periodo mínimo obligatorio de enfriamiento (generalmente 24 a 48 horas tras el primer intento, y periodos mayores tras intentos sucesivos) antes de poder volver a presentarse.',
      'El candidato nunca más podrá volver a presentarse a ningún examen de Dynatrace.',
      'Se puede repetir el examen inmediatamente en el mismo minuto sin coste.',
      'Es obligatorio cambiar de nombre y apellidos para solicitar un segundo examen.',
    ], 0,
    'Dynatrace University establece periodos de espera (cooling-off periods) entre intentos para asegurar que el candidato dedique tiempo al estudio de los dominios débiles identificados en el informe.'),

  q(52, 'instructionsnetworking', 'hybrid-connectivity', 'scenario',
    'Una empresa cuenta con servidores en un centro de datos on-premises y workloads en Amazon AWS. ¿Qué arquitectura de conectividad es la más recomendada para unificar su observabilidad?',
    [
      'Desplegar dos tenants de Dynatrace totalmente independientes y no compartir nunca los datos entre ellos.',
      'Conectar ambos entornos a un único tenant de Dynatrace SaaS, utilizando ActiveGates locales en el centro de datos y en AWS según sea necesario para optimizar el tráfico de red.',
      'Instalar OneAgent únicamente en los ordenadores de la oficina central.',
      'Utilizar memorias USB para copiar los datos de un servidor a otro semanalmente.',
    ], 1,
    'Dynatrace SaaS unifica entornos híbridos y multicloud en un único panel de control mediante el despliegue de ActiveGates estratégicos en cada centro de datos y proveedor cloud.'),

  q(53, 'instructionsk8s', 'resource-quotas', 'knowledge',
    'Si un contenedor en Kubernetes supera su límite de memoria (Memory Limit) configurado en el Pod spec, ¿qué acción toma el sistema operativo?',
    [
      'El contenedor continúa ejecutándose sin ninguna consecuencia.',
      'El kernel finaliza el contenedor mediante OOMKilled y Kubernetes lo reinicia según la política de RestartPolicy definida.',
      'Kubernetes desinstala automáticamente OneAgent.',
      'Se apagan todos los nodos del clúster a la vez.',
    ], 1,
    'Superar el límite estricto de memoria provoca la terminación inmediata del contenedor por OOMKilled; este evento es registrado por OneAgent y visible en la Kubernetes App de Dynatrace.'),

  q(54, 'instructionsstrategy', 'exam-score-report', 'knowledge',
    'Al finalizar el examen oficial supervisado, ¿qué información proporciona el informe de resultados al candidato?',
    [
      'Únicamente una carta de agradecimiento sin ninguna nota ni indicación de aprobado o suspenso.',
      'El resultado global (Aprobado / Suspenso) y el desglose porcentual de rendimiento obtenido en cada uno de los dominios de conocimiento evaluados.',
      'La lista exacta de preguntas con las respuestas correctas para compartirlas en foros.',
      'El código de barras de la tarjeta de crédito del supervisor.',
    ], 1,
    'El score report desglosa el porcentaje de aciertos por módulo temático, permitiendo al candidato saber con precisión qué áreas domina y en cuáles necesita reforzar su formación.'),

  q(55, 'instructionsnetworking', 'sni-support', 'precision',
    '¿Qué estándar de extensión TLS es imprescindible que soporte el proxy corporativo para permitir el enrutamiento adecuado hacia tenants multi-tenant de Dynatrace SaaS?',
    [
      'Server Name Indication (SNI).',
      'El protocolo POP3 de correo electrónico.',
      'El sistema de archivos FAT32.',
      'El estándar de vídeo VGA.',
    ], 0,
    'SNI (Server Name Indication) permite al cliente indicar el nombre del host al que intenta conectarse en el inicio del handshake TLS, fundamental para el enrutamiento en infraestructuras SaaS multitenant.'),

  q(56, 'instructionsk8s', 'kubelet-readiness', 'knowledge',
    '¿Qué diferencia fundamental existe entre un Liveness Probe y un Readiness Probe en Kubernetes y cómo influye en el tráfico observable?',
    [
      'Liveness determina si el pod debe reiniciarse por bloqueo; Readiness determina si el pod está preparado para recibir tráfico del Service de red.',
      'Liveness es para servidores Windows y Readiness para Linux.',
      'Liveness solo comprueba el espacio en disco y Readiness la velocidad del ventilador.',
      'No hay diferencia: son sinónimos absolutos en la documentación de Kubernetes.',
    ], 0,
    'Liveness reinicia el contenedor si está congelado; Readiness retira el contenedor de los balanceadores de carga del Service si aún no ha terminado de inicializarse, evitando errores 503 a los usuarios.'),

  q(57, 'instructionsproctoru', 'desk-mirror', 'knowledge',
    '¿Por qué algunos supervisores de proctoring solicitan al candidato mostrar la pantalla del ordenador utilizando un espejo de mano o la cámara del teléfono móvil durante el check-in?',
    [
      'Para comprobar que el candidato va bien peinado para la fotografía de la credencial.',
      'Para verificar que no hay notas adhesivas, chuletas ni dispositivos electrónicos ocultos pegados en el marco de la pantalla del monitor o teclado.',
      'Para comprobar la marca y modelo del monitor LCD.',
      'Es un procedimiento opcional que solo se realiza en días festivos.',
    ], 1,
    'El supervisor debe cerciorarse de que no existen notas pegadas en los bordes de la pantalla ni cámaras secundarias instaladas en el marco del monitor.'),

  q(58, 'instructionsstrategy', 'mock-exam-role', 'scenario',
    'Un estudiante obtiene un 95% en un simulacro de examen tras haber memorizado de memoria las respuestas de los tests de práctica. ¿Por qué esto representa un riesgo grave de cara al examen oficial?',
    [
      'Porque en el examen oficial las preguntas formulan escenarios diferentes y barajan opciones, evaluando comprensión conceptual y razonamiento diagnóstico en lugar de memoria posicional.',
      'Porque Dynatrace cancela los exámenes de los estudiantes con notas superiores al 90%.',
      'Porque los simulacros están prohibidos por el contrato de licencia de software.',
      'Porque la memoria humana es perjudicial para la informática.',
    ], 0,
    'Memorizar preguntas de memoria crea una falsa sensación de dominio: el examen real utiliza variantes, modifica condiciones operativas y exige saber justificar por qué los distractores son incorrectos.'),

  q(59, 'instructionsnetworking', 'activegate-clustering', 'knowledge',
    '¿Cómo se garantiza la alta disponibilidad y tolerancia a fallos en el enrutamiento de telemetría de OneAgents mediante ActiveGates?',
    [
      'Configurando múltiples ActiveGates asignados al mismo ActiveGate Group, permitiendo balanceo de carga automático y conmutación por error (failover).',
      'Conectando todos los ActiveGates al mismo cable de red eléctrico.',
      'Instalando ActiveGate en una memoria USB compartida.',
      'Reiniciando el ActiveGate cada 5 minutos mediante una tarea programada.',
    ], 0,
    'Agrupar varios ActiveGates en un ActiveGate Group común asegura que si uno se cae por mantenimiento, los OneAgents redirigen su tráfico de forma transparente a los gateways supervivientes.'),

  q(60, 'instructionsk8s', 'configmap-secret', 'knowledge',
    'En una arquitectura de contenedores, ¿cuál es la buena práctica para inyectar tokens de conexión de Dynatrace hacia el operador de Kubernetes?',
    [
      'Escribirlos en texto plano dentro del código fuente de la aplicación en GitHub.',
      'Almacenarlos de forma segura en un Kubernetes Secret y referenciarlos en el Custom Resource del Dynatrace Operator.',
      'Imprimirlos en papel y dejarlos encima del teclado del servidor.',
      'Publicarlos en un blog público de internet para que los servidores los descarguen.',
    ], 1,
    'Las credenciales sensibles y API tokens deben custodiarse siempre en objetos Kubernetes Secrets cifrados en etcd y nunca en ConfigMaps ni texto claro en código fuente.'),

  q(61, 'instructionsstrategy', 'flagging-review-routine', 'scenario',
    'Al finalizar la revisión de todas las preguntas de un bloque, quedan 15 minutos en el temporizador del examen y 5 preguntas marcadas con bandera (flagged). ¿Cuál es la conducta recomendada?',
    [
      'Pulsar el botón de entrega definitiva del examen inmediatamente para terminar antes.',
      'Revisar con calma únicamente las 5 preguntas marcadas, releyendo con atención el enunciado para verificar la restricción técnica omitida antes de confirmar la entrega final.',
      'Cambiar al azar todas las respuestas de las preguntas que no tenían bandera.',
      'Cerrar la tapa del ordenador portátil para desconectarse.',
    ], 1,
    'Aprovecha el tiempo restante para auditar las preguntas dudosas marcadas con bandera; relee el enunciado en busca de matices (Latest vs Classic, write vs read) sin cambiar respuestas por puro nerviosismo.'),

  q(62, 'instructionsproctoru', 'ambient-noise', 'troubleshooting',
    'Si durante el examen se escucha ruido constante de conversaciones humanas o ladridos de perros en la habitación, ¿qué acción tomará el supervisor?',
    [
      'El supervisor solicitará por chat o audio que el candidato detenga el ruido y confirme que está solo; si las conversaciones persisten, la sesión puede ser cancelada.',
      'El supervisor subirá el volumen de su propio micrófono para cantar una canción.',
      'El sistema sumará automáticamente 5 minutos extra al examen.',
      'No se realiza ninguna acción porque el audio no es supervisado.',
    ], 0,
    'El supervisor monitoriza el audio en directo: ruidos sospechosos de voces humanas pueden ser interpretados como comunicación fraudulenta y provocar la interrupción del examen.'),

  q(63, 'instructionsnetworking', 'cloud-endpoints-latency', 'scenario',
    'Una compañía multinacional tiene oficinas en Europa, Asia y América. ¿Por qué es una mala práctica forzar que todos los OneAgents del mundo enruten su tráfico hacia un único ActiveGate situado en Madrid?',
    [
      'Porque la legislación prohíbe el tráfico de red internacional.',
      'Porque añade una latencia de red innecesaria en el tránsito transcontinental de la telemetría y crea un único punto de fallo (SPOF) global para toda la compañía.',
      'Porque los ActiveGates solo entienden el huso horario de España.',
      'Porque los servidores de Asia no pueden comunicarse con servidores europeos.',
    ], 1,
    'Diseño de arquitectura de red: la telemetría debe procesarse con baja latencia; desplegar ActiveGates locales por región geográfica o conectar directamente a los endpoints SaaS regionales optimiza el rendimiento.'),

  q(64, 'instructionsk8s', 'pod-restart-loop', 'troubleshooting',
    'En un clúster Kubernetes, un pod entra en estado `CrashLoopBackOff`. ¿Qué significa este estado y dónde debe comenzar el diagnóstico en Dynatrace?',
    [
      'Que el pod se está ejecutando perfectamente y no requiere ninguna revisión.',
      'Que el contenedor principal falla reiteradamente tras iniciarse y Kubernetes lo reinicia en bucle; se deben consultar los logs del contenedor y los eventos del pod en la Kubernetes App.',
      'Que el servidor físico ha sido robado del centro de datos.',
      'Que OneAgent ha decidido suspender la monitorización de ese pod por falta de memoria.',
    ], 1,
    '`CrashLoopBackOff` indica que el proceso dentro del contenedor se detiene con error tras arrancar; inspeccionar los logs del pod y los eventos de terminación en Dynatrace revela la excepción causante.'),

  q(65, 'instructionsstrategy', 'prerequisite-confidence', 'knowledge',
    '¿Cuál es la función del checklist de prerrequisitos técnicos incluido al inicio de cada guía de preparación de Dynatrace?',
    [
      'Servir de adorno tipográfico sin ninguna utilidad real.',
      'Permitir al candidato realizar una autoevaluación honesta de sus competencias previas (redes, arquitectura web, sistemas operativos) antes de abordar conceptos avanzados de la plataforma.',
      'Exigir la firma de un notario público antes de comenzar la lectura.',
      'Obligar al estudiante a comprar manuales de hardware adicionales.',
    ], 1,
    'El checklist de prerrequisitos establece la línea base de conocimientos necesarios; identificar lagunas en conceptos de redes o contenedores antes de estudiar permite subsanarlas a tiempo.'),

  q(66, 'instructionsnetworking', 'tcp-handshake-basics', 'knowledge',
    '¿Cuáles son los tres pasos que componen el saludo inicial (three-way handshake) de una conexión de red TCP estándar antes de negociar TLS?',
    [
      'SYN → SYN-ACK → ACK.',
      'HELLO → OK → BYE.',
      'PING → PONG → DISCONNECT.',
      'START → RUN → STOP.',
    ], 0,
    'Fundamento de redes IP: el saludo de tres vías TCP se compone de la secuencia SYN, SYN-ACK y ACK para establecer la conexión fiable a nivel de transporte.'),

  q(67, 'instructionsproctoru', 'closing-preparation', 'knowledge',
    'Antes de iniciar la sesión de examen con ProctorU, ¿qué acción técnica previa debe realizar el candidato en su equipo?',
    [
      'Cerrar todas las aplicaciones abiertas (Outlook, Slack, Teams, navegadores web auxiliares, software de mensajería o herramientas de desarrollo) y reiniciar el ordenador.',
      'Abrir todas las pestañas de YouTube posibles para calentar la tarjeta de red.',
      'Desconectar el ratón y escribir solo con la tecla de espacio.',
      'Cambiar la resolución de pantalla al mínimo posible.',
    ], 0,
    'Reiniciar el equipo y cerrar todas las aplicaciones no esenciales garantiza que no queden procesos residuales ni herramientas de mensajería que Guardian Browser pueda marcar como software prohibido.'),

  q(68, 'instructionsstrategy', 'summary-instructions-mastery', 'knowledge',
    'En resumen, ¿cuál es la fórmula de preparación que garantiza el mayor porcentaje de éxito en la certificación Dynatrace Associate?',
    [
      'Memorizar deprisa un banco de preguntas la noche anterior sin leer documentación oficial.',
      'Combinar el estudio profundo de la documentación técnica oficial (docs.dynatrace.com), la práctica activa en un entorno real de la plataforma y el análisis riguroso de escenarios y distractores.',
      'Intentar aprobar el examen confiando exclusivamente en la intuición personal.',
      'Comprar exámenes filtrados no verificados en foros clandestinos de internet.',
    ], 1,
    'El éxito en Associate se sustenta en tres pilares: dominio de la documentación oficial, práctica en tenant real para consolidar soltura operativa y entrenamiento analítico de razonamiento técnico.'),
]
