import type { ModuleRevision } from './types'
import { welcomeRevision } from './welcome'
import { instructionsRevision } from './instructions'
import { platformRevision } from './platform'
import { observabilityRevision } from './observability'
import { notebooksRevision } from './notebooks'
import { businessRevision } from './business'
import { dataRevision } from './data'
import { dqlRevision } from './dql'
import { securityRevision } from './security'
import { automationRevision } from './automation'
import { ingestionRevision } from './ingestion'
import { otherRevision } from './other'

export const moduleRevisions: ModuleRevision[] = [
  welcomeRevision, instructionsRevision, platformRevision, observabilityRevision, notebooksRevision, businessRevision, dataRevision, dqlRevision, securityRevision, automationRevision, ingestionRevision, otherRevision,
]
