import type { SourceRef } from '../types'
import type { ModuleRevision, NewQuestion } from './types'

const D = 'https://docs.dynatrace.com/docs/analyze-explore-automate/workflows'
const src = (title: string, url: string): SourceRef => ({ title, url, kind: 'official-docs' })

const AE = src('AutomationEngine', 'https://docs.dynatrace.com/docs/platform/automationengine')
const CONCEPTS = src('Workflows concepts', `${D}/concepts`)
const TRIG = src('Workflow triggers', `${D}/build/trigger`)
const SCHED = src('Workflow schedules', `${D}/build/trigger/schedules`)
const EVT = src('Event triggers for workflows', `${D}/build/trigger/event-trigger`)
const BUILD = src('Build workflows', `${D}/build`)
const SEC = src('Manage workflow permissions', `${D}/security`)
const RUN = src('Monitor workflow executions', `${D}/running`)
const DQLA = src('Execute DQL Query workflow action', `${D}/default-workflow-actions/dql-query-workflow-action`)
const JSA = src('Run JavaScript workflow action', `${D}/default-workflow-actions/run-javascript-workflow-action`)
const RWF = src('Run workflow action', `${D}/default-workflow-actions/run-workflow-action`)
const HTTP = src('HTTP Request workflow action', `${D}/default-workflow-actions/http-request-workflow-action`)
const SIMPLE = src('Create a simple workflow', `${D}/build/simple-workflow`)
const JINJA = src('Expression reference (Jinja)', `${D}/reference`)
const QUICK = src('Get started with Workflows', `${D}/quickstart`)

const LATEST = 'Dynatrace SaaS (Latest) · Workflows/AutomationEngine · verificado en docs.dynatrace.com (octubre 2026).'

const keyAt = (to: 'A' | 'B' | 'C' | 'D', o: { id: string; text: string }[]) => {
  const t = o.map((x) => ({ ...x }))
  const i = 'ABCD'.indexOf(to)
  const first = t[0].text
  t[0].text = t[i].text
  t[i].text = first
  return { options: t, correctOptionIds: [to] }
}

const opts = (a: string, b: string, c: string, d: string) => [
  { id: 'A', text: a }, { id: 'B', text: b }, { id: 'C', text: c }, { id: 'D', text: d },
]

const added: NewQuestion[] = [
  {
    id: 'R-AUT-01', moduleId: 'automation', chapterId: 'triggers', objectiveId: 'automation:schedule-active-hours',
    bucket: 'scenario', difficulty: 'intermediate', cognitiveLevel: 'apply',
    promptEs: 'Un health check debe ejecutarse cada 30 minutos, pero solo entre las 08:00 y las 18:00. ¿Qué configuración del trigger encaja mejor?',
    options: opts(
      'Un Event trigger filtrado por las horas de oficina en el DQL.',
      'Un Time interval trigger de 30 minutos con Active hours 08:00–18:00.',
      'Un Fixed time trigger a las 08:00 con un loop que espere 30 minutos.',
      'Un cron de seis campos estilo Quartz con el rango de horas incluido.',
    ),
    correctOptionIds: ['B'],
    explanationEs: 'El Time interval trigger repite la ejecución cada N minutos y admite Active hours para limitarla a una franja diaria. Un Event trigger no arranca por tiempo; un Fixed time trigger con espera dentro del workflow alarga la ejecución y no repite; el cron de seis campos (Quartz) no está soportado: solo se admite el formato estándar de cinco campos.',
    sourceRefs: [SCHED], classicOrLatest: 'latest', versionNote: LATEST,
  },
  {
    id: 'R-AUT-02', moduleId: 'automation', chapterId: 'triggers', objectiveId: 'automation:schedule-interval-range',
    bucket: 'troubleshooting', difficulty: 'intermediate', cognitiveLevel: 'analyze',
    promptEs: 'Un compañero intenta guardar este Schedule trigger y el editor no acepta el valor del intervalo. ¿Cuál es el mejor siguiente paso?',
    stimulus: {
      kind: 'table', title: 'Configuración del Schedule trigger',
      columns: ['Campo', 'Valor'],
      rows: [['Type', 'Time interval'], ['Interval', '1440 minutes'], ['Timezone', 'Europe/Madrid'], ['Active hours', '—']],
    },
    options: opts(
      'Cambiar Timezone a UTC, porque los intervalos largos solo se aceptan en UTC.',
      'Dividir el intervalo en dos Schedule triggers de 720 minutos en el mismo workflow.',
      'Usar un Fixed time trigger diario: Time interval admite como máximo 720 minutos.',
      'Configurar Active hours, que es obligatorio con intervalos superiores a 12 horas.',
    ),
    correctOptionIds: ['C'],
    explanationEs: 'Time interval admite intervalos de 1 a 720 minutos (12 horas). Para una ejecución diaria corresponde Fixed time (o cron). La zona horaria no cambia el rango permitido, Active hours es opcional y un workflow tiene exactamente un trigger, así que no puede llevar dos Schedule triggers.',
    sourceRefs: [SCHED, CONCEPTS], classicOrLatest: 'latest', versionNote: LATEST,
  },
  {
    id: 'R-AUT-03', moduleId: 'automation', chapterId: 'triggers', objectiveId: 'automation:schedule-business-calendar',
    bucket: 'scenario', difficulty: 'intermediate', cognitiveLevel: 'apply',
    promptEs: 'Un informe con Fixed time trigger se ejecuta de lunes a viernes, pero no debe ejecutarse en los festivos nacionales. ¿Qué usas?',
    options: opts(
      'Una custom condition en la primera task que compare la fecha con un JSON fijo.',
      'Un Event trigger que escuche un evento de festivo publicado cada mañana.',
      'Desactivar el trigger manualmente la víspera de cada festivo del año.',
      'Una scheduling rule basada en un business calendar que excluya los festivos.',
    ),
    correctOptionIds: ['D'],
    explanationEs: 'Las scheduling rules y los business calendars controlan en qué días se ejecuta un Schedule trigger y permiten saltar festivos. La condición con un JSON fijo exige mantenimiento manual y la ejecución arranca igualmente; el Event trigger y la desactivación manual no son mecanismos de calendario.',
    sourceRefs: [SCHED], classicOrLatest: 'latest', versionNote: LATEST,
  },
  {
    id: 'R-AUT-04', moduleId: 'automation', chapterId: 'deep-jinja-dql', objectiveId: 'automation:dql-event-data-json',
    bucket: 'practical', difficulty: 'advanced', cognitiveLevel: 'analyze',
    promptEs: 'Un workflow con Event trigger usa esta consulta en su primera task Execute DQL Query en lugar de `fetch events`. ¿Qué problema evita?',
    stimulus: {
      kind: 'code', title: 'Execute DQL Query · input',
      content: `data json:"""{{ event()|to_json }}"""
| fields timestamp, event.name, event.id`,
    },
    options: opts(
      'Que la task falle por no tener el actor permiso storage:events:read.',
      'Depender de que el evento que lo activó ya esté persistido en Grail.',
      'Que la consulta use UTC en vez de la zona horaria del navegador.',
      'Que el timeframe por defecto de dos horas deje fuera el evento.',
    ),
    correctOptionIds: ['B'],
    explanationEs: 'Cuando un workflow arranca por un Event trigger, el evento puede no estar aún persistido en Grail. La documentación propone esperar 30–45 segundos o pasar el evento directamente con `data` y `{{ event()|to_json }}`. No cambia la zona horaria (la action sigue en UTC por defecto), no sustituye los permisos del actor y el problema no es el timeframe sino la persistencia.',
    sourceRefs: [DQLA], classicOrLatest: 'latest', versionNote: LATEST,
  },
  {
    id: 'R-AUT-05', moduleId: 'automation', chapterId: 'deep-execution-states', objectiveId: 'automation:workflow-state-unhandled-error',
    bucket: 'troubleshooting', difficulty: 'intermediate', cognitiveLevel: 'analyze',
    promptEs: 'La vista de una ejecución muestra estas tasks, todas ya terminadas. ¿Qué estado tendrá la workflow execution?',
    stimulus: {
      kind: 'table', title: 'Executions · tasks',
      columns: ['Task', 'Estado', 'Sucesores'],
      rows: [['query_problems', 'Success', 'create_ticket, notify_slack'], ['create_ticket', 'Error', '—'], ['notify_slack', 'Success', '—']],
    },
    options: opts(
      'Success, porque dos de las tres tasks terminaron correctamente.',
      'Running, hasta que alguien reintente manualmente create_ticket.',
      'Canceled, porque la rama de create_ticket se detuvo antes de acabar.',
      'Error, porque hay una task fallida que ningún sucesor gestiona.',
    ),
    correctOptionIds: ['D'],
    explanationEs: 'Una workflow execution termina en Error cuando tiene al menos una task fallida no gestionada; Success exige que no quede ningún fallo sin gestionar. Running implica tasks en Idle o Running, y Canceled corresponde a una cancelación del usuario.',
    sourceRefs: [RUN], classicOrLatest: 'latest', versionNote: LATEST,
  },
  {
    id: 'R-AUT-06', moduleId: 'automation', chapterId: 'deep-workflow-anatomy', objectiveId: 'automation:js-return-vs-throw',
    bucket: 'practical', difficulty: 'intermediate', cognitiveLevel: 'analyze',
    promptEs: 'La task `get_orders` devuelve `records` vacío. ¿Qué estado tendrá la task Run JavaScript que ejecuta este script?',
    stimulus: {
      kind: 'code', title: 'Run JavaScript · check_orders',
      content: `import { result } from '@dynatrace-sdk/automation-utils';

export default async function () {
  const r = await result('get_orders');
  if (r.records.length === 0) {
    return { ok: false };
  }
  return { ok: true, count: r.records.length };
}`,
    },
    options: opts(
      'Error, porque el resultado contiene ok: false.',
      'Skipped, porque no hay registros que procesar.',
      'Success; para que falle, el script debe lanzar una excepción.',
      'Error, porque result() no está disponible en el runtime JavaScript.',
    ),
    correctOptionIds: ['C'],
    explanationEs: 'Devolver un objeto, aunque contenga ok: false, es un resultado normal: la task termina en Success. Para marcarla como fallida hay que lanzar una excepción (throw new Error()). Skipped depende de las condiciones de la task, no del contenido del script, y `result()` de @dynatrace-sdk/automation-utils es la forma documentada de leer resultados de tasks previas.',
    sourceRefs: [JSA], classicOrLatest: 'latest', versionNote: LATEST,
  },
  {
    id: 'R-AUT-07', moduleId: 'automation', chapterId: 'safe-automation', objectiveId: 'automation:http-credentials',
    bucket: 'scenario', difficulty: 'intermediate', cognitiveLevel: 'apply',
    promptEs: 'Revisas un workflow antes de pasarlo a producción. ¿Qué cambio recomienda la documentación?',
    stimulus: {
      kind: 'case', title: 'Task HTTP Request · create_incident',
      content: 'Method: POST · URL: https://itsm.example.com/api/incidents · Headers: Authorization = "Bearer eyJhbGciOi…" (token pegado en el editor) · Payload: {{ event()|to_json }}',
    },
    options: opts(
      'Mover el token a una custom condition para que no aparezca en el payload.',
      'Mantener el header y restringir la visibilidad del workflow a private.',
      'Codificar el token en base64 con un filtro Jinja antes de enviarlo.',
      'Quitar el header estático y usar credenciales del credential vault.',
    ),
    correctOptionIds: ['D'],
    explanationEs: 'La documentación de HTTP Request desaconseja expresamente un header Authorization estático porque filtra el secreto; las credenciales deben guardarse en el credential vault (Authentication Basic o Token) o gestionarse desde Run JavaScript. Hacerlo private no protege el secreto de quien tenga acceso, base64 no es cifrado y una condición no es lugar para credenciales.',
    sourceRefs: [HTTP], classicOrLatest: 'latest', versionNote: LATEST,
  },
  {
    id: 'R-AUT-08', moduleId: 'automation', chapterId: 'deep-workflow-anatomy', objectiveId: 'automation:http-response-shape',
    bucket: 'precision', difficulty: 'intermediate', cognitiveLevel: 'remember',
    promptEs: 'Una task HTTP Request recibe una respuesta con payload JSON. ¿Qué dos propiedades de su resultado puede leer una task posterior? (Selecciona 2)',
    options: opts('status_code', 'records', 'json', 'statusText'),
    correctOptionIds: ['A', 'C'],
    explanationEs: 'El resultado de HTTP Request incluye status_code, body, headers y, para payloads JSON, json con la respuesta ya parseada. records pertenece a Execute DQL Query y statusText no forma parte del resultado documentado.',
    sourceRefs: [HTTP], classicOrLatest: 'latest', versionNote: LATEST,
  },
  {
    id: 'R-AUT-09', moduleId: 'automation', chapterId: 'simple-workflow', objectiveId: 'automation:simple-workflow-actions',
    bucket: 'precision', difficulty: 'intermediate', cognitiveLevel: 'remember',
    promptEs: 'Diseñas un simple workflow para no consumir workflow hours. ¿Qué dos actions no podrás usar en su task? (Selecciona 2)',
    options: opts('Execute DQL Query', 'Run JavaScript', 'HTTP Request', 'Run workflow'),
    correctOptionIds: ['B', 'D'],
    explanationEs: 'Un simple workflow tiene un trigger y una task, y puede usar las actions disponibles salvo Run JavaScript y Run workflow (tampoco la action de aprobación manual). Execute DQL Query y HTTP Request sí están permitidas.',
    sourceRefs: [SIMPLE], classicOrLatest: 'latest', versionNote: LATEST,
  },
  {
    id: 'R-AUT-10', moduleId: 'automation', chapterId: 'event-trigger-precision', objectiveId: 'automation:event-trigger-data-types',
    bucket: 'precision', difficulty: 'intermediate', cognitiveLevel: 'remember',
    promptEs: 'Configuras un Event trigger genérico con un filtro DQL. ¿Qué dos tipos de datos puedes escuchar con él? (Selecciona 2)',
    options: opts('bizevents', 'logs', 'spans', 'security.events'),
    correctOptionIds: ['A', 'D'],
    explanationEs: 'El Event trigger genérico admite events, bizevents, security.events y dt.system.events, cada uno con su permiso de lectura (storage:events:read, storage:bizevents:read, storage:security.events:read o storage:system:read). Logs y spans no pueden activar un Event trigger.',
    sourceRefs: [EVT], classicOrLatest: 'latest', versionNote: LATEST,
  },
  {
    id: 'R-AUT-11', moduleId: 'automation', chapterId: 'deep-actor-permissions', objectiveId: 'automation:least-privilege-run',
    bucket: 'scenario', difficulty: 'intermediate', cognitiveLevel: 'apply',
    promptEs: 'Un operador de guardia debe ver los workflows y lanzarlos con Run o por API, pero no modificarlos. ¿Qué dos permisos le asignas con mínimo privilegio? (Selecciona 2)',
    options: opts('automation:workflows:write', 'automation:workflows:read', 'automation:workflows:run', 'automation:workflows:admin'),
    correctOptionIds: ['B', 'C'],
    explanationEs: 'automation:workflows:read permite ver workflows y automation:workflows:run ejecutarlos manualmente desde la UI o por API. write permite crear, actualizar y borrar (incluidos triggers), y admin administra workflows saltándose propiedad y visibilidad: ambos exceden lo pedido.',
    sourceRefs: [SEC], classicOrLatest: 'latest', versionNote: LATEST,
  },
  {
    id: 'R-AUT-12', moduleId: 'automation', chapterId: 'deep-jinja-dql', objectiveId: 'automation:dql-action-inputs',
    bucket: 'precision', difficulty: 'intermediate', cognitiveLevel: 'remember',
    promptEs: 'Además de la propia consulta, ¿qué dos campos puedes configurar en la action Execute DQL Query? (Selecciona 2)',
    options: opts('Timezone', 'Bucket de destino del resultado', 'Retention del resultado', 'Fail on empty result'),
    correctOptionIds: ['A', 'D'],
    explanationEs: 'La action admite DQL query, Filter segment, Timezone (UTC si no se indica) y Fail on empty result. No escribe en un bucket ni define retención: el resultado queda en la ejecución del workflow, que se conserva 30 días.',
    sourceRefs: [DQLA, RUN], classicOrLatest: 'latest', versionNote: LATEST,
  },
  {
    id: 'R-AUT-13', moduleId: 'automation', chapterId: 'execution-limits', objectiveId: 'automation:js-runtime-limits',
    bucket: 'precision', difficulty: 'advanced', cognitiveLevel: 'remember',
    promptEs: 'Un script de Run JavaScript procesa un JSON grande y a veces se corta. ¿Qué dos límites del runtime debes tener en cuenta? (Selecciona 2)',
    options: opts('Timeout de 120 segundos del runtime.', '1 GB de memoria por invocación.', '256 MB de RAM.', 'Timeout de 15 minutos por invocación.'),
    correctOptionIds: ['A', 'C'],
    explanationEs: 'El Dynatrace JavaScript runtime tiene un timeout de 120 segundos, que no se ajusta con el timeout de la task, y dispone de 256 MB de RAM; además, el resultado de la task no puede superar 6 MB. 1 GB y 15 minutos no corresponden al runtime.',
    sourceRefs: [JSA, BUILD], classicOrLatest: 'latest', versionNote: LATEST,
  },
  {
    id: 'R-AUT-14', moduleId: 'automation', chapterId: 'debug-workflow', objectiveId: 'automation:cancel-task-loop',
    bucket: 'scenario', difficulty: 'advanced', cognitiveLevel: 'understand',
    promptEs: 'Una task con loop va por la iteración 4 de 20 y la cancelas (cancel task, no la ejecución completa). ¿Qué ocurre?',
    options: opts(
      'La iteración en curso termina y la task acaba en Canceled.',
      'Se interrumpe al instante y la task queda en Error.',
      'Se cancelan todas las tasks del workflow, incluidas las de otras ramas.',
      'Las iteraciones restantes continúan y la task acaba en Discarded.',
    ),
    correctOptionIds: ['A'],
    explanationEs: 'Cancelar una task deja terminar la iteración actual y después la task finaliza en Canceled. Detener todas las tasks en curso e impedir que empiecen otras es el efecto de cancelar la ejecución completa; Discarded corresponde a una task detenida por condiciones no cumplidas.',
    sourceRefs: [RUN], classicOrLatest: 'latest', versionNote: LATEST,
  },
  {
    id: 'R-AUT-15', moduleId: 'automation', chapterId: 'debug-workflow', objectiveId: 'automation:rerun-input',
    bucket: 'troubleshooting', difficulty: 'intermediate', cognitiveLevel: 'understand',
    promptEs: 'Una ejecución falló por una caída del sistema destino. Ya restablecido, usas Rerun sobre esa ejecución. ¿Con qué datos se repite?',
    options: opts(
      'Con el input por defecto actual del workflow, sin el evento original.',
      'Con el input y los parámetros originales de esa ejecución.',
      'Con un evento nuevo que el trigger busca de nuevo en Grail.',
      'Con el input de la última ejecución correcta del workflow.',
    ),
    correctOptionIds: ['B'],
    explanationEs: 'Rerun repite la ejecución usando el input y los parámetros originales, lo que permite reproducir el caso que falló. No reconsulta Grail ni toma el input de otra ejecución.',
    sourceRefs: [RUN], classicOrLatest: 'latest', versionNote: LATEST,
  },
  {
    id: 'R-AUT-16', moduleId: 'automation', chapterId: 'event-trigger-precision', objectiveId: 'automation:problem-minimum-duration',
    bucket: 'scenario', difficulty: 'intermediate', cognitiveLevel: 'apply',
    promptEs: 'El equipo recibe avisos de Problems que se cierran solos en pocos minutos. Solo quiere notificar los que sigan abiertos 15 minutos. ¿Qué ajuste del Problem trigger usa?',
    options: opts(
      'Wait for root cause analysis activado.',
      'Problem state: active or closed.',
      'Minimum duration de 15 minutos en el Problem trigger.',
      'Wait before de 900 segundos en la task de notificación.',
    ),
    correctOptionIds: ['C'],
    explanationEs: 'Minimum duration pospone el trigger hasta que el Problem lleva abierto al menos el tiempo configurado (de 5 minutos a una semana). Wait before solo retrasa la task: el workflow ya ha arrancado y notificaría igualmente. Wait for root cause analysis espera al análisis causal, no a una duración, y active or closed añade la notificación de cierre.',
    sourceRefs: [EVT, BUILD], classicOrLatest: 'latest', versionNote: LATEST,
  },
  {
    id: 'R-AUT-17', moduleId: 'automation', chapterId: 'event-trigger-precision', objectiveId: 'automation:problem-updates',
    bucket: 'scenario', difficulty: 'advanced', cognitiveLevel: 'apply',
    promptEs: 'Un workflow notifica la apertura de cada Problem. Ahora también debe avisar cuando cambie la severity del Problem abierto. ¿Qué haces?',
    options: opts(
      'Activar Updates en el Problem trigger y seleccionar el campo severity.',
      'Cambiar a Davis event trigger, que se dispara con cada cambio del Problem.',
      'Añadir un Schedule trigger cada 5 minutos que compare la severity.',
      'Cambiar Problem state a active or closed para recibir los cambios.',
    ),
    correctOptionIds: ['A'],
    explanationEs: 'La opción Updates del Problem trigger vuelve a disparar el workflow cuando cambia un campo seleccionado (por ejemplo severity o affected entities); cada combinación distinta de valores dispara como mucho una vez. Davis event trigger actúa sobre alertas individuales, un workflow tiene un único trigger y active or closed solo cubre apertura y cierre.',
    sourceRefs: [EVT, CONCEPTS], classicOrLatest: 'latest', versionNote: LATEST,
  },
  {
    id: 'R-AUT-18', moduleId: 'automation', chapterId: 'execution-limits', objectiveId: 'automation:task-default-timeout',
    bucket: 'troubleshooting', difficulty: 'advanced', cognitiveLevel: 'analyze',
    promptEs: 'Una loop task que procesa cientos de elementos falla por timeout a los 60 minutos, aunque nadie configuró ningún timeout. ¿Qué lo explica y cómo lo resuelves?',
    options: opts(
      'Es el timeout de 120 s del Dynatrace runtime; hay que reducir cada iteración.',
      'La ejecución completa caduca a los 60 minutos; hay que dividir el workflow.',
      'Es el timeframe de 2 horas de DQL; hay que ampliar el timeframe de la consulta.',
      'Es el timeout por defecto de la task; puede ampliarse hasta siete días.',
    ),
    correctOptionIds: ['D'],
    explanationEs: 'El timeout por defecto de una task es de 60 minutos y se puede configurar hasta siete días; en una loop task cuenta el tiempo total de todas las iteraciones. Los 120 s del Dynatrace runtime limitan cada action individual (cada iteración), no la task completa; la ejecución completa admite hasta 30 días y las 2 horas son el timeframe por defecto de una consulta DQL, no un timeout.',
    sourceRefs: [BUILD, RUN], classicOrLatest: 'latest', versionNote: LATEST,
  },
  {
    id: 'R-AUT-19', moduleId: 'automation', chapterId: 'deep-jinja-dql', objectiveId: 'automation:loop-item-variable',
    bucket: 'practical', difficulty: 'intermediate', cognitiveLevel: 'apply',
    promptEs: 'Una task con loop itera sobre la lista de hosts con esta configuración. ¿Qué expresión devuelve el elemento actual dentro de su input?',
    stimulus: {
      kind: 'code', title: 'Task options · Loop task',
      content: `Item variable name: host
List: {{ result("get_hosts")["records"] }}
Concurrency: 1`,
    },
    options: opts(
      '{{ loop.host }}',
      '{{ input()["host"] }}',
      '{{ _.host }}',
      '{{ result("get_hosts")["host"] }}',
    ),
    correctOptionIds: ['C'],
    explanationEs: 'El elemento actual de un loop se referencia con `{{ _.<item variable name> }}`; con el nombre host, `{{ _.host }}`. input() devuelve el input del workflow, result() el resultado completo de otra task y loop.* son variables del bucle `{% for %}` de Jinja, no de la task loop.',
    sourceRefs: [BUILD, JINJA], classicOrLatest: 'latest', versionNote: LATEST,
  },
  {
    id: 'R-AUT-20', moduleId: 'automation', chapterId: 'deep-jinja-dql', objectiveId: 'automation:problem-link',
    bucket: 'practical', difficulty: 'advanced', cognitiveLevel: 'apply',
    promptEs: 'Un workflow con Problem trigger envía un mensaje que debe incluir el enlace al Problem en la app Problems. ¿Qué expresión usas?',
    options: opts(
      '{{ environment().url }}',
      '{{ problem_link() }}',
      '{{ execution()["problem_url"] }}',
      '{{ result("trigger")["problem.url"] }}',
    ),
    correctOptionIds: ['B'],
    explanationEs: 'problem_link() devuelve la URL del Problem en la app Problems y solo funciona con triggers de Davis problem. environment().url devuelve la URL del entorno, no la del Problem; execution() y result() no exponen ese campo.',
    sourceRefs: [JINJA], classicOrLatest: 'latest', versionNote: LATEST,
  },
  {
    id: 'R-AUT-21', moduleId: 'automation', chapterId: 'safe-automation', objectiveId: 'automation:schedule-stagger',
    bucket: 'troubleshooting', difficulty: 'intermediate', cognitiveLevel: 'analyze',
    promptEs: 'Diez workflows con Fixed time a las 00:00 llaman a la misma API de ITSM y varios reciben HTTP 429 cada noche. ¿Cuál es el mejor siguiente paso?',
    options: opts(
      'Escalonar unos minutos la hora de inicio de cada workflow.',
      'Cambiar Timezone de todos los triggers a UTC para alinearlos.',
      'Convertirlos en simple workflows para no consumir workflow hours.',
      'Subir el timeout de cada task a siete días para que esperen.',
    ),
    correctOptionIds: ['A'],
    explanationEs: 'La documentación de schedules recomienda escalonar unos minutos los inicios cuando varios workflows apuntan al mismo sistema, para evitar ráfagas de peticiones. Cambiar la zona horaria no separa las ejecuciones, el tipo de workflow no afecta a la carga y un timeout mayor no evita los 429.',
    sourceRefs: [SCHED], classicOrLatest: 'latest', versionNote: LATEST,
  },
  {
    id: 'R-AUT-22', moduleId: 'automation', chapterId: 'safe-automation', objectiveId: 'automation:secrets-in-results',
    bucket: 'scenario', difficulty: 'advanced', cognitiveLevel: 'analyze',
    promptEs: 'Un script de Run JavaScript lee un token del credential vault y lo incluye en su `return` para que lo use la task siguiente. ¿Qué riesgo señala la documentación?',
    options: opts(
      'El resultado supera los 6 MB y la task falla al serializar el token.',
      'El token caduca porque el resultado se conserva 30 días en Grail.',
      'El resultado es visible para cualquiera con acceso de lectura a la ejecución.',
      'El token se reenvía al trigger y se escribe en el bucket de eventos.',
    ),
    correctOptionIds: ['C'],
    explanationEs: 'Los resultados de ejecución son visibles para quien tenga acceso de lectura, por lo que nunca deben contener secretos; cada task que lo necesite debe leerlo del credential vault. Un token no se acerca a 6 MB y el resultado no se reenvía al trigger.',
    sourceRefs: [JSA], classicOrLatest: 'latest', versionNote: LATEST,
  },
]

const baseReplace: ModuleRevision['replace'] = {
    'A-057': {
      difficulty: 'intermediate',
      ...keyAt('D', opts(
        'Puede seguir iniciándose por API aunque el trigger esté desactivado.',
        'La invocación por API queda bloqueada hasta que se reactive el trigger.',
        'Se permite Run desde la UI, pero la API devuelve un error de estado.',
        'Hay que hacer undeploy del workflow para poder iniciarlo por API.',
      )),
      explanationEs: 'Un trigger desactivado no arranca ejecuciones automáticas, pero el workflow live puede seguir ejecutándose por API: una llamada API puede disparar un workflow live sea cual sea su trigger. Undeploy lo dejaría solo como draft.',
      reason: 'Quitar absolutos de distractores y precisar la explicación con la doc.',
    },
    'A-058': {
      promptEs: 'Un usuario puede editar un workflow, pero una task devuelve 403 al leer eventos. ¿Qué dos comprobaciones son pertinentes? (Selecciona 2)',
      explanationEs: 'Cada task se ejecuta con los permisos del actor y, además, AutomationEngine debe tener concedido ese permiso en Settings > Authorization settings (Primary/Secondary permissions). Poder editar el workflow o los permisos del creador no cuentan si el actor es otro.',
      reason: 'Formato de respuesta múltiple y explicación verificada.',
    },
    'A-060': {
      ...keyAt('D', opts(
        'Usar otro mecanismo: AutomationEngine no está pensado para exportación masiva.',
        'Aumentar la concurrencia del loop hasta que la exportación masiva sea estable.',
        'Cambiar el trigger a Schedule, pensado para procesar grandes volúmenes cada hora.',
        'Dividir la exportación en un workflow por bucket y mantener el mismo mecanismo.',
      )),
      explanationEs: 'La documentación indica que AutomationEngine no está pensado para ingestión ni exportación masiva de datos; Workflows sirve para actuar sobre datos de monitorización (reaccionar, programar informes, orquestar procesos). Ni la concurrencia, ni el tipo de trigger, ni repartir por bucket cambian ese propósito.',
      reason: 'Explicación sin afirmaciones no documentadas (OpenPipeline como sustituto) y distractores más plausibles.',
    },
    'B-057': {
      promptEs: 'Se guarda un workflow con Schedule trigger, pero solo existe como draft (no se ha hecho deploy). ¿Qué falta para que el trigger lo ejecute?',
      ...keyAt('D', opts(
        'Hacer deploy del workflow para que exista una versión live.',
        'Ejecutarlo una vez con Run para que la programación quede activada.',
        'Nada: el draft ya está programado y arrancará en la siguiente franja.',
        'Añadir un Event trigger al draft para habilitar el Schedule.',
      )),
      explanationEs: 'Los triggers solo arrancan workflows live; el draft es una copia de trabajo que se prueba manualmente. Ejecutar el draft con Run no lo despliega y un workflow tiene exactamente un trigger, así que no se añade otro.',
      reason: 'Terminología en inglés (trigger, draft, deploy) y distractores precisos.',
    },
    'B-058': {
      promptEs: 'Un equipo copia en un Schedule trigger la expresión `0 0 6 ? * MON-FRI` de su antiguo planificador Quartz y no la puede guardar. ¿Qué debe hacer?',
      options: opts(
        'Mantenerla: el Schedule trigger acepta Quartz siempre que Timezone sea UTC.',
        'Añadir un séptimo campo con el año, que el cron de Workflows exige.',
        'Reescribirla en cron estándar de cinco campos, sin el comodín ?.',
        'Sustituir solo ? por *, porque el resto de la expresión ya es válida.',
      ),
      correctOptionIds: ['C'],
      explanationEs: 'El cron schedule de Workflows admite la sintaxis estándar de cinco campos; las expresiones Quartz de seis campos y el comodín ? no están soportados (aquí: `0 6 * * 1-5`). La zona horaria no cambia la sintaxis y cambiar solo ? deja seis campos.',
      sourceRefs: [SCHED],
      bucket: 'troubleshooting', difficulty: 'intermediate', cognitiveLevel: 'apply',
      reason: 'Duplicaba A-056; reorientada a la sintaxis cron verificada.',
    },
    'B-059': {
      difficulty: 'intermediate',
      promptEs: 'Un sistema externo decide cuándo iniciar un workflow y necesita pasarle datos. ¿Qué mecanismo encaja?',
      options: opts(
        'Un Schedule trigger cada minuto que consulte la decisión externa.',
        'Un Event trigger, aunque el sistema externo no emita eventos.',
        'Invocarlo por API (On demand) y pasar el input en la llamada.',
        'Una ejecución con Run desde la UI por cada solicitud externa.',
      ),
      explanationEs: 'On demand arranca solo cuando se invoca explícitamente, por ejemplo vía API; el input enviado en la llamada se fusiona con el input por defecto y se lee con input(). Sondear con Schedule o depender de eventos inexistentes no refleja la decisión externa, y Run manual no es automatizable.',
      reason: 'Terminología en inglés y clave menos larga que los distractores.',
    },
    'B-061': {
      difficulty: 'intermediate',
      promptEs: 'Ana creó un workflow y configuró un service user como actor. ¿Con los permisos de qué identidad se ejecutan sus tasks?',
      options: opts(
        'De Ana, porque es la owner del workflow.',
        'Del último usuario que abrió el editor del workflow.',
        'Del actor configurado, en este caso el service user.',
        'Del owner del bucket donde se guardan los resultados.',
      ),
      explanationEs: 'El actor es la identidad en cuyo contexto se ejecuta el workflow: cada task usa los permisos del actor. Ser owner o haber abierto el editor no cambia la identidad de ejecución.',
      reason: 'Terminología (service user, owner) y quitar absoluto de distractor.',
    },
    'B-063': {
      difficulty: 'intermediate',
      promptEs: 'Una persona quiere seleccionar un service user como actor de un workflow. ¿Qué permiso necesita sobre ese service user?',
      ...keyAt('C', opts('iam:service-users:use', 'automation:workflows:admin', 'automation:workflows:run', 'app-engine:functions:run')),
      explanationEs: 'iam:service-users:use permite asignar service users como actor; solo se pueden asignar los que se te han concedido. Los permisos automation:* gobiernan ver, editar, ejecutar o administrar workflows, y app-engine:functions:run el uso del function executor.',
      reason: 'Distractores con nombres de permiso reales (absorbe G-141).',
    },
    'C-029': {
      promptEs: 'Luis edita un workflow cuyo actor era Ana. No tiene admin mode activado y el actor no es un service user. ¿Qué cambio debe prever?',
      ...keyAt('D', opts(
        'Luis pasa a ser el actor del workflow al guardar su cambio.',
        'Ana permanece como actor porque es la owner del workflow.',
        'El workflow queda sin actor hasta que alguien lo asigne.',
        'Se asigna como actor un service user del entorno por defecto.',
      )),
      explanationEs: 'Al actualizar un workflow, quien lo edita pasa a ser el actor automáticamente, salvo que tenga admin mode activado o el actor sea un service user. Así nadie ejecuta sus cambios con la identidad de otro usuario.',
      reason: 'Terminología en inglés y quitar absolutos de distractores.',
    },
    'C-031': {
      ...keyAt('D', opts(
        'Puede: la API inicia cualquier workflow live, sea cual sea su trigger.',
        'La API inicia workflows On demand; los Schedule esperan su horario.',
        'Debe deshabilitarse el Schedule trigger antes de iniciarlo por API.',
        'La API encola la petición hasta el siguiente horario programado.',
      )),
      explanationEs: 'Una llamada API puede disparar siempre un workflow live, con independencia de que su trigger sea Schedule, Event u On demand. No hay que deshabilitar el trigger ni esperar al horario.',
      reason: 'Equilibrar absolutos y longitudes.',
    },
    'C-032': {
      difficulty: 'intermediate',
      options: opts(
        'Un único trigger y una única task.',
        'Una task, pero tantos triggers como se necesiten.',
        'Un trigger, pero una cadena ilimitada de tasks.',
        'Varias tasks si todas comparten el mismo actor.',
      ),
      explanationEs: 'SIMPLE identifica workflows con un trigger y una task, que no consumen workflow hours; por eso se puede conceder automation:workflows:write con esa condición a más usuarios sin consumir workflow hours (aunque sus acciones pueden consumir otras capacidades facturables, como AppEngine o consultas DQL). Los distractores fallan porque todo workflow tiene exactamente un trigger y porque añadir una segunda task, con cualquier actor, lo convierte en workflow estándar.',
      reason: 'Terminología (task) y quitar absoluto de distractor. Auditoría: precisar el coste (sin workflow hours, no sin coste).',
    },
    'D-029': {
      promptEs: 'Una task con Retry on error falla dos veces antes de terminar bien. ¿Cómo se reflejan esos intentos en el modelo de ejecución?',
      explanationEs: 'Con Retry on error se mantiene una task execution y cada intento crea su propia action execution; la task termina en Success con el primer intento correcto.',
      reason: 'Terminología en inglés (task).',
    },
    'D-030': {
      promptEs: 'Una task con reintentos alcanza su timeout mientras sigue ejecutándose una action. ¿Qué determina el estado final de la task?',
      options: opts(
        'Se ignora el timeout hasta agotar los reintentos configurados.',
        'La task falla al vencer el timeout, aunque la action termine después.',
        'El temporizador se reinicia al comenzar cada nuevo intento de retry.',
        'La task pasa a Success si alguno de los intentos iniciados acaba bien.',
      ),
      explanationEs: 'La task falla en cuanto vence su timeout; una action en curso puede terminar, pero su resultado ya no cambia el estado. El timeout de la task cubre todos los intentos de retry.',
      reason: 'Terminología, quitar absolutos de distractores (absorbe E-047).',
    },
    'D-031': {
      difficulty: 'intermediate',
      promptEs: 'Necesitas revisar una ejecución de un workflow iniciada hace 45 días. ¿Qué límite de retención afecta a su información de workflow, task y action?',
      options: opts(
        '10 días desde que terminó la última action.',
        '30 días desde el inicio de la ejecución.',
        '45 días desde el deploy del workflow.',
        'La retención del bucket default_logs donde se registran las ejecuciones.',
      ),
      explanationEs: 'La información de ejecución de workflow, tasks y actions se conserva 30 días desde la fecha de inicio de la ejecución; a los 45 días ya no está disponible.',
      reason: 'Terminología y quitar absoluto de distractor.',
    },
    'D-032': {
      promptEs: 'Una task B depende de A y se dejó la condición de estado por defecto. ¿Cuándo se ejecuta B?',
      options: opts(
        'Cuando A empieza, aunque todavía no haya terminado.',
        'Cuando A termina con estado success o skipped.',
        'Cuando A termina, sea cual sea su estado (opción any).',
        'Cuando A termina en error o cancelled.',
      ),
      explanationEs: 'La condición de estado por defecto es "success or skipped": la predecesora debe terminar bien u omitirse. Las demás opciones existen pero hay que elegirlas: success, error or cancelled, error y any.',
      sourceRefs: [BUILD],
      reason: 'La clave anterior omitía skipped: el valor por defecto documentado es "success or skipped".',
    },
    'E-046': {
      promptEs: 'Una task con loop procesa cinco elementos y uno falla sin recuperarse. ¿Qué estado final tiene la task?',
      options: opts(
        'Success, porque la mayoría de iteraciones terminó bien.',
        'Error, porque una iteración falló.',
        'Success, porque cuenta el resultado de la última iteración.',
        'Running hasta que se reintenten las iteraciones fallidas.',
      ),
      explanationEs: 'En un loop cada iteración genera una action execution y la task falla si falla cualquier iteración. Con Retry on error solo se reintentan las iteraciones fallidas.',
      reason: 'Terminología y quitar absoluto de distractor.',
    },
    'E-048': {
      promptEs: 'Una task debe usar event.type del evento que activó el workflow. ¿Qué expresión lee ese valor?',
      options: opts(
        '{{ event()["event.type"] }}',
        '{{ input()["event.type"] }}',
        '{{ result("trigger")["event.type"] }}',
        '{{ execution()["event.type"] }}',
      ),
      explanationEs: 'event() da acceso al evento pasado en los parámetros de la ejecución; los atributos con puntos se leen con corchetes. input() es el input del workflow, result() lee resultados de tasks y execution() el contexto de la ejecución.',
      sourceRefs: [JINJA, EVT],
      reason: 'Distractores Jinja plausibles en lugar de funciones inexistentes.',
    },
    'FA-002': {
      promptEs: 'La primera task necesita la root cause ya calculada. ¿Qué opción del Problem trigger evita arrancar con datos incompletos?',
      explanationEs: 'Con Wait for root cause analysis el trigger arranca solo cuando Dynatrace Intelligence ha completado el root cause analysis del Problem. Minimum duration espera tiempo, no el análisis.',
      reason: 'Terminología en inglés (task, root cause).',
    },
    'FA-003': {
      ...keyAt('D', opts(
        'Cada evento se evalúa por separado; no hay agregaciones multievento.',
        'El matcher agrupa eventos por entidad, pero no por ventana de tiempo.',
        'El matcher admite count() en ventanas de hasta un minuto de duración.',
        'La agregación se permite si todos los eventos comparten event.type.',
      )),
      explanationEs: 'Cada evento se evalúa individualmente al entrar en OpenPipeline; las funciones de agregación y las consultas multievento no están soportadas en el filtro del trigger.',
      reason: 'Quitar absolutos de distractores y pista de longitud.',
    },
    'FA-004': {
      promptEs: 'Un Event trigger escucha Business Events en un bucket acotado. ¿Qué dos permisos de lectura necesita su actor? (Selecciona 2)',
      reason: 'Formato de respuesta múltiple.',
    },
    'FA-005': {
      promptEs: 'Un Event trigger demasiado amplio genera 1.200 ejecuciones en una hora. ¿Qué límite aplica y qué ocurre con el exceso?',
      options: opts(
        '1.000 ejecuciones por hora para todos los workflows del entorno; el resto se descarta.',
        '1.000 ejecuciones event-triggered por hora y workflow; el exceso se limita (HTTP 429).',
        '1.000 ejecuciones simultáneas por workflow, sin límite horario; el exceso se encola.',
        '1.000 ejecuciones por día y Event trigger; el exceso desactiva el trigger al instante.',
      ),
      explanationEs: 'Cada workflow está limitado a 1.000 ejecuciones event-triggered por hora; al superarlo, las ejecuciones se limitan (HTTP 429) hasta una hora. Si se supera tres veces en siete días, el trigger se desactiva.',
      reason: 'Enunciado y clave confusos ("por evento"); ámbito verificado: por workflow y por hora (absorbe G-144).',
    },
    'FA-007': {
      ...keyAt('D', opts(
        '1.000 caracteres para la expresión completa compilada de todos los campos.',
        '1.000 caracteres por cada condición, sin límite conjunto.',
        '1.000 caracteres para el Additional custom filter query, aparte de los filtros.',
        '1.000 caracteres por evento evaluado; las expresiones largas se fragmentan.',
      )),
      explanationEs: 'La expresión de coincidencia completa, compilada a partir de todos los campos del trigger (filtros de entidad, nombre del evento y Additional custom filter query), está limitada a 1.000 caracteres.',
      reason: 'Quitar absolutos de distractores (absorbe G-143).',
    },
    'FA-008': {
      explanationEs: 'Success indica que la consulta se ejecutó sin error; con Fail on empty result desactivado la task puede terminar bien con records=[]. Antes de leer campos conviene comprobar `{{ result("dql_task")["records"] | length > 0 }}`.',
      reason: 'Terminología (task) y explicación más precisa.',
    },
    'FA-009': {
      difficulty: 'intermediate',
      options: opts(
        'Fail on empty result en la task de DQL.',
        'Cambiar la condición de éxito de la task sin tocar la consulta.',
        'Añadir limit 0 al final de la consulta para forzar el estado Error.',
        'Usar Continue on error para convertir records=[] en fallo.',
      ),
      explanationEs: 'Fail on empty result hace fallar la task cuando la consulta no devuelve registros, de modo que una rama con condición de error puede reaccionar. Sin esa opción, records=[] termina en Success.',
      reason: 'Terminología en inglés (task).',
    },
    'FA-010': {
      ...keyAt('C', opts(
        'La zona horaria: la acción usa UTC si no se configura Timezone.',
        'El timeframe por defecto de la acción, que desplaza el mes natural.',
        'La zona horaria del owner del workflow, que la acción hereda.',
        'La zona horaria de la región donde se aloja el bucket consultado.',
      )),
      explanationEs: 'Execute DQL Query usa UTC si no se configura Timezone (en el campo o en la consulta), mientras que Notebooks y Dashboards aplican automáticamente la zona del navegador o la de user settings, a la que la action no tiene acceso; las anclas de calendario como -1M@M se evalúan en esa zona. La action no hereda la zona del owner, la región del bucket no interviene y el timeframe por defecto (2 horas) no desplaza un ancla de mes explícita.',
      reason: 'Quitar absolutos de distractores. Auditoría: Notebooks/Dashboards usan navegador o user settings, según dql-query-workflow-action.',
    },
    'FA-012': {
      promptEs: 'El workflow se dispara por un evento y su primera task con fetch events no lo encuentra aún. ¿Qué causa probable documenta Dynatrace?',
      ...keyAt('C', opts(
        'El workflow puede procesarse antes de que el evento que lo activó se haya persistido en Grail.',
        'El Event trigger usa una tabla distinta de la que expone fetch events.',
        'La task DQL se ejecuta en un bucket de staging aislado que aún no ha sincronizado con Grail.',
        'La task DQL excluye por defecto los eventos que activaron el workflow.',
      )),
      explanationEs: 'El evento puede no estar persistido aún en Grail cuando arranca el workflow. Se recomienda esperar 30–45 segundos o pasar el evento con `data json:"""{{ event()|to_json }}"""`.',
      reason: 'Terminología y explicación con la solución documentada.',
    },
    'FA-013': {
      difficulty: 'intermediate',
      promptEs: 'Una task posterior debe leer filas y metadatos de la consulta. ¿Qué propiedades ofrece la respuesta de Execute DQL Query?',
      reason: 'Terminología (task) (absorbe G-147).',
    },
    'FA-016': {
      difficulty: 'intermediate',
      promptEs: 'Una validación de negocio en Run JavaScript debe hacer fallar la task y activar su rama de error. ¿Qué hace el script?',
      explanationEs: 'Para señalar el fallo, el script lanza una excepción (throw new Error()); la task termina en Error. Devolver false, un objeto o escribir en console.log son resultados normales y la task acaba en Success.',
      reason: 'Terminología (task).',
    },
    'FA-017': {
      promptEs: 'Una task Run JavaScript devuelve un objeto JSON de 8 MB. ¿Qué límite es relevante?',
      ...keyAt('C', opts(
        '6 MB para el resultado de una task Run JavaScript.',
        '10 MB para el resultado de cualquier función JavaScript.',
        '100 MB si el workflow se lanzó por API.',
        'No aplica límite si el script termina antes de 120 segundos.',
      )),
      explanationEs: 'El resultado de una task Run JavaScript no puede superar 6 MB; en general, el resultado de una action execution no puede superar 6 MB menos el tamaño de sus logs. 10 MB es el límite del workflow result, no de una task.',
      reason: 'Quitar absoluto de distractor y ampliar explicación (absorbe G-148).',
    },
    'FA-018': {
      options: opts(
        'Se guarda como texto plano sin afectar al estado.',
        'La ejecución del workflow falla al evaluar el resultado.',
        'Falla la última task, pero la ejecución acaba en Success.',
        'El resultado se reemplaza por records=[].',
      ),
      explanationEs: 'El workflow result debe evaluarse a un objeto JSON válido y no superar 10 MB; si no, la ejecución falla.',
      reason: 'Quitar absoluto y referencia irrelevante a Code tile.',
    },
    'FA-019': {
      promptEs: 'Una task no cumple su condición y en su configuración se eligió Skip para ese caso. ¿Qué estado muestra el monitor?',
      options: opts('Skipped.', 'Discarded.', 'Canceled.', 'Idle.'),
      explanationEs: 'Si las condiciones no se cumplen, Skip omite la task (estado Skipped) y continúa con las siguientes; Stop detiene la rama (estado Discarded). Canceled indica una cancelación del usuario e Idle una task aún no disparada.',
      sourceRefs: [RUN, BUILD],
      reason: 'Distractores con estados reales y sin absolutos.',
    },
    'FA-020': {
      ...keyAt('D', opts(
        'automation:workflows:run y acceso al workflow seleccionado.',
        'automation:workflows:read sobre el padre y app-engine:functions:run.',
        'storage:events:read, aunque el workflow hijo no consulte eventos.',
        'iam:service-users:use sobre el actor del workflow hijo.',
      )),
      explanationEs: 'El actor del workflow padre necesita permiso para ejecutar workflows y acceso al workflow seleccionado en la action. El permiso IAM es automation:workflows:run (la página de Run workflow lo escribe en singular, pero el nombre en IAM es plural). Run workflow ejecuta la versión live del hijo.',
      sourceRefs: [RWF, SEC],
      reason: 'Nombre de permiso corregido (automation:workflows:run) y distractores plausibles.',
    },
    'FA-021': {
      options: opts(
        'Run workflow ejecuta el draft si el hijo tiene trigger On demand.',
        'La lista de candidatos excluye workflows que solo existen como draft.',
        'El hijo debe ser un simple workflow para aparecer en la lista.',
        'Run workflow no admite encadenar workflows que residen en el mismo entorno.',
      ),
      explanationEs: 'La lista de Run workflow excluye simple workflows y workflows que solo existen como draft; la action ejecuta la versión live del hijo. Tampoco se permiten recursiones directas ni indirectas.',
      reason: 'Quitar absolutos de distractores; dato de simple workflows corregido.',
    },
    'B-064': {
      options: opts(
        'Según la propiedad y visibilidad existentes cuando comenzó la ejecución.',
        'Según la visibilidad pública actual del workflow, también para ejecuciones pasadas.',
        'Según la visibilidad que tenga el workflow cuando finalice la ejecución.',
        'Según los permisos del actor de la task, aunque el lector no tenga acceso al workflow.',
      ),
      reason: 'Terminología (task).',
    },
    'C-030': {
      difficulty: 'intermediate',
      promptEs: 'Un workflow con Event trigger debe reaccionar a un evento nuevo. ¿Qué condición activa el trigger?',
      reason: 'Terminología (trigger).',
    },
    'E-043': {
      difficulty: 'intermediate',
      reason: 'Dificultad ajustada: concepto central del temario.',
    },
    'FA-001': {
      difficulty: 'intermediate',
      reason: 'Dificultad ajustada.',
    },
    'FA-011': {
      difficulty: 'intermediate',
      reason: 'Dificultad ajustada: dato de referencia.',
    },
    'FA-015': {
      difficulty: 'intermediate',
      reason: 'Dificultad ajustada: dato de referencia.',
    },
    'G-142': {
      difficulty: 'intermediate',
      promptEs: '¿Qué permiso IAM se requiere para crear un workflow, modificar sus tasks o actualizarlo?',
      ...keyAt('C', opts('automation:workflows:write', 'automation:workflows:run', 'automation:workflows:read', 'storage:bucket-definitions:write')),
      explanationEs: 'automation:workflows:write permite crear, actualizar y borrar workflows y configurar triggers y schedules. run sirve para ejecutarlos manualmente o por API y read para verlos.',
      reason: 'Distractores con permisos reales y terminología en inglés.',
    },
    'G-145': {
      promptEs: 'Un equipo usa simple workflows que envían mensajes de Slack al abrirse un Problem. ¿Qué afirmación sobre su coste es correcta?',
      options: opts(
        'Consumen la mitad de workflow hours que un workflow estándar.',
        'No consumen workflow hours, pero pueden generar consumo de otras capacidades.',
        'No generan consumo facturable mientras tengan un único trigger.',
        'Consumen workflow hours cuando se ejecutan por API en vez de por trigger.',
      ),
      correctOptionIds: ['B'],
      explanationEs: 'Los simple workflows no consumen workflow hours directamente, pero su ejecución puede activar capacidades facturables (por ejemplo, el mensaje de Slack implica invocaciones de AppEngine). Los workflows estándar sí consumen workflow hours.',
      reason: 'Distractores absurdos; reorientada al coste (el límite 1 trigger/1 task ya lo cubre C-032).',
    },
    'G-146': {
      promptEs: 'Un script de Run JavaScript necesita el resultado de la task previa `fetch_data`. ¿Cómo debe leerlo?',
      options: opts(
        'Con `{{ result("fetch_data") }}` incrustado directamente en el código del script.',
        'Con `await result("fetch_data")` importado de @dynatrace-sdk/automation-utils.',
        'Con `input()["fetch_data"]`, porque el input recibe los resultados previos.',
        'Con `event()["fetch_data"]`, que expone las salidas de tasks anteriores.',
      ),
      correctOptionIds: ['B'],
      explanationEs: 'Run JavaScript no admite expresiones en su input para evitar code injection; los resultados previos se leen con el SDK (`result()` de @dynatrace-sdk/automation-utils o el executionsClient). input() y event() no contienen resultados de tasks.',
      reason: 'Reformulada sobre el dato verificado; distractores plausibles.',
    },
    'G-149': {
      promptEs: '¿Cuál es el tamaño máximo del resultado consolidado de un workflow (workflow result)?',
      options: opts('6 MB.', '10 MB.', '1 MB.', '16 MB.'),
      explanationEs: 'El workflow result debe ser JSON válido y no superar 10 MB; el input por defecto del workflow tiene el mismo límite. 6 MB es el límite del resultado de una action execution.',
      sourceRefs: [RUN, BUILD],
      reason: 'Dato verificado; distractores cercanos.',
    },
    'G-151': {
      promptEs: 'Un workflow live funciona, pero quieres detener sus arranques automáticos mientras preparas cambios, sin perder el trabajo. ¿Qué opción lo consigue?',
      ...keyAt('D', opts(
        'Hacer undeploy: el workflow vuelve a quedar solo como draft.',
        'Borrar la versión live; el draft se conserva y sigue activo.',
        'Editar el draft: mientras exista un draft, el trigger no arranca.',
        'Restaurar en version history la versión marcada como Current.',
      )),
      explanationEs: 'Undeploy detiene el arranque automático y deja el workflow solo como draft, sin perder el trabajo (desactivar el trigger también evitaría las ejecuciones automáticas). Un draft convive con la versión live sin afectarla y la versión Current no se puede restaurar.',
      sourceRefs: [CONCEPTS, TRIG],
      reason: 'Distractores absurdos y solape con B-057; reorientada a undeploy.',
    },
    'G-152': {
      promptEs: 'Un workflow padre usa Run workflow y pasa `{"ticket": "INC-42"}` como input. ¿Cómo lo lee el sub-workflow?',
      options: opts(
        'Con `{{ input()["ticket"] }}` en el sub-workflow.',
        'Con `{{ event()["ticket"] }}`, porque el padre lo envía como evento.',
        'Con `{{ result("parent")["ticket"] }}`, leyendo la task del padre.',
        'Con `{{ execution()["ticket"] }}`, que contiene los parámetros del padre.',
      ),
      correctOptionIds: ['A'],
      explanationEs: 'El input de la action se fusiona con el input por defecto del sub-workflow y se lee con input(). event() solo contiene el evento que activó el workflow, result() lee tasks de la misma ejecución y execution() devuelve el contexto de la ejecución.',
      bucket: 'practical', difficulty: 'advanced', cognitiveLevel: 'apply',
      reason: 'Pregunta trivial con distractores absurdos; reorientada a input().',
    },
    'G-153': {
      promptEs: 'Una task usa la action Request approval y nadie ha respondido todavía. ¿En qué estado aparece la task?',
      options: opts(
        'Idle, porque aún no se ha disparado.',
        'Canceled, hasta que alguien la apruebe.',
        'Waiting for approval, en pausa hasta que alguien responda.',
        'Skipped hasta que se apruebe.',
      ),
      correctOptionIds: ['C'],
      explanationEs: 'Waiting for approval indica que la task está en pausa esperando que un usuario la apruebe o rechace. Idle es una task aún no disparada, Canceled una cancelación y Skipped una task omitida por condiciones.',
      bucket: 'precision', difficulty: 'intermediate', cognitiveLevel: 'understand',
      reason: 'Distractores absurdos; estado verificado.',
    },
    'G-154': {
      promptEs: 'Un usuario ejecuta con Run un workflow nuevo por primera vez y aparece un diálogo que pide autorización. ¿Por qué?',
      options: opts(
        'Porque falta que un admin asigne un service user como actor.',
        'Porque hay que autorizar a AutomationEngine a ejecutar el workflow como tu usuario.',
        'Porque el draft debe aprobarse con Request approval antes de su primera ejecución.',
        'Porque el usuario carece de automation:workflows:write sobre el workflow.',
      ),
      explanationEs: 'La primera vez que ejecutas un workflow se te pide autorizar al servicio de automatización para ejecutarlo como tu usuario ("Allow and run"); los permisos concretos se gestionan en Settings > Authorization settings.',
      sourceRefs: [QUICK, SEC],
      reason: 'Distractores absurdos sustituidos por causas plausibles.',
    },
    'G-155': {
      promptEs: 'Un equipo en Tokio (UTC+9) crea un Fixed time trigger a las 08:00 sin tocar Timezone. El informe llega a las 17:00 hora local. ¿Qué lo explica?',
      ...keyAt('D', opts(
        'Timezone es UTC por defecto; hay que fijar Asia/Tokyo (formato IANA).',
        'El trigger usa la zona del navegador del creador; hay que cambiar su perfil.',
        'El trigger usa la zona de la región SaaS del entorno; hay que abrir un ticket.',
        'Fixed time no admite zonas horarias; hay que pasar a cron con un offset +9.',
      )),
      explanationEs: 'La zona horaria del Schedule trigger se indica en formato IANA y es UTC por defecto: 08:00 UTC son las 17:00 en Tokio. Todos los tipos de schedule admiten zona horaria y gestionan el cambio de horario automáticamente.',
      sourceRefs: [SCHED],
      bucket: 'troubleshooting', cognitiveLevel: 'analyze',
      reason: 'Valor por defecto verificado (UTC), distractores plausibles y fuente corregida.',
    },
    'G-156': {
      promptEs: 'Un usuario añade una segunda task a un simple workflow (pasa a estándar) y después la borra. ¿Qué ocurre?',
      options: opts(
        'Vuelve a ser simple workflow al quedar con una única task.',
        'Sigue siendo estándar; para volver, crea otro o restaura una versión.',
        'Vuelve a simple tras el siguiente deploy si el actor es un service user.',
        'Queda bloqueado hasta que un admin lo reclasifique como SIMPLE.',
      ),
      explanationEs: 'Al usar funciones de workflow estándar no hay opción para volver atrás, aunque se eliminen las tasks o actions añadidas: hay que crear un workflow nuevo o restaurar una versión anterior desde version history.',
      reason: 'Dato verificado (no hay vuelta atrás automática) y distractores plausibles.',
    },
    'G-157': {
      promptEs: 'En la custom condition de una task posterior a una consulta DQL, ¿qué expresión Jinja comprueba que la consulta devolvió al menos un registro?',
      ...keyAt('D', opts(
        '{{ result("query_task")["records"] | length > 0 }}',
        '{{ result("query_task").records > 0 }}',
        '{{ event()["records"] | length > 0 }}',
        '{{ result("query_task")["metadata"] | length > 0 }}',
      )),
      explanationEs: 'result("query_task")["records"] es la lista de registros y el filtro length cuenta sus elementos. Comparar la lista directamente con un número no es válido, event() contiene el evento que activó el workflow y metadata describe la ejecución de la consulta, no las filas.',
      reason: 'Distractores Jinja plausibles.',
    },
    'G-158': {
      promptEs: 'Una task HTTP Request falla a veces por errores de red transitorios. ¿Qué opción de la task lo mitiga y con qué valores por defecto?',
      options: opts(
        'Retry on error, que por defecto hace 2 reintentos separados 30 s.',
        'Retry on error: 3 reintentos con backoff exponencial desde 10 s.',
        'Wait before: 60 s de espera antes de repetir la task fallida.',
        'Timeout: al vencer los 60 minutos, la task se repite una vez.',
      ),
      correctOptionIds: ['A'],
      explanationEs: 'Retry on error configura Number of retries (2 por defecto) y Delay between retries (30 s por defecto); no se documenta backoff exponencial. Wait before retrasa el inicio de la task y el timeout la hace fallar, no la repite.',
      sourceRefs: [BUILD],
      bucket: 'precision',
      reason: 'Se eliminó el backoff exponencial no documentado; valores por defecto verificados.',
    },
    'G-159': {
      promptEs: 'Un workflow se dispara con bizevents de tipo order.created y su task genera otro bizevent order.created. ¿Qué protección aplica la plataforma si entra en bucle?',
      options: opts(
        'Throttling a 1.000 ejecuciones/hora por workflow; 3 excesos en 7 días desactivan el trigger.',
        'Detecta la recursión y descarta el evento generado por el propio workflow antes de ingerirlo.',
        'Rechaza el deploy porque el trigger y la task usan el mismo tipo de evento de negocio.',
        'Limita a 100 ejecuciones simultáneas y descarta el resto sin desactivar el trigger.',
      ),
      correctOptionIds: ['A'],
      explanationEs: 'Cada workflow admite 1.000 ejecuciones event-triggered por hora (exceso con HTTP 429) y el trigger se desactiva si se supera tres veces en siete días. Evitar el bucle es responsabilidad del diseño: el filtro debe excluir los eventos que genera el propio workflow.',
      sourceRefs: [EVT],
      reason: 'Clave sin datos inventados ("auditoría de eventos"), fuente corregida.',
    },
}

const baseRemove: ModuleRevision['remove'] = {
    'B-060': 'Duplicado de A-057 (API tras desactivar el trigger).',
    'E-044': 'Duplicado de A-057 con distractor absurdo.',
    'B-062': 'Duplicado de A-058 (403: permisos del actor + autorización).',
    'E-045': 'Duplicado de D-029 (retry y action executions).',
    'E-047': 'Duplicado de D-030 (task timeout).',
    'G-141': 'Duplicado de B-063 (iam:service-users:use).',
    'G-143': 'Duplicado de FA-007 (1.000 caracteres).',
    'G-144': 'Duplicado de FA-005 (1.000 ejecuciones por hora).',
    'G-147': 'Duplicado de FA-013 (records, types, metadata) con distractores absurdos.',
    'G-148': 'Duplicado de FA-017 (6 MB); el dato general se incorpora a su explicación.',
    'G-150': 'Duplicado de E-043 (Problem trigger vs Davis event trigger).',
    'G-160': 'Duplicado de A-060 con metacomentario y distractores absurdos.',
}

// V3_MARKER
/* ---------------------------------------------------------------------------
 * Revisión v3 (octubre 2026): calidad, duplicados y cobertura del módulo.
 * ------------------------------------------------------------------------- */

const VERSIONS = src('Manage workflow versions', `${D}/manage-workflows/workflows-versioning`)

const v3Replace: ModuleRevision['replace'] = {
  'A-058': {
    options: opts(
      'Permisos de lectura de eventos del actor del workflow.',
      'Autorización concedida a AutomationEngine para ejercer esos permisos.',
      'El permiso de edición del workflow por parte del usuario interactivo.',
      'El permiso de lectura de eventos del owner del workflow.',
    ),
    correctOptionIds: ['A', 'B'],
    explanationEs: 'Cada task se ejecuta con los permisos del actor y, además, AutomationEngine debe estar autorizado a usarlos (Settings > Authorization settings de Workflows, listas Primary y Secondary permissions); si falta cualquiera de los dos, la task recibe 403. Poder editar el workflow no da permisos de datos a sus tasks, y los permisos del owner no cuentan: cuenta el actor.',
    sourceRefs: [SEC],
    reason: 'v3: distractor D sin coletilla ("aunque…") y explicación que desmonta cada opción.',
  },
  'A-059': {
    options: opts(
      'Un service user con los permisos mínimos necesarios.',
      'El creador, haciendo los cambios en admin mode para conservarlo.',
      'Una cuenta personal compartida por el equipo de operaciones.',
      'El usuario que pulse Run en cada ejecución manual.',
    ),
    correctOptionIds: ['A'],
    explanationEs: 'Dynatrace recomienda service users para workflows colaborativos de producción: no dependen del estado de la cuenta de una persona y se les conceden permisos mínimos. Admin mode evita que el editor pase a ser actor, pero el actor seguiría siendo el creador; una cuenta personal compartida tiene la misma fragilidad; y el actor no es quien pulsa Run, sino la identidad configurada.',
    sourceRefs: [SEC],
    reason: 'v3: distractores inverosímiles sustituidos por alternativas plausibles.',
  },
  'A-060': {
    promptEs: 'Un equipo propone varios usos de Workflows. ¿Cuál no corresponde al propósito de AutomationEngine según la documentación?',
    options: opts(
      'Exportar cada hora el volumen completo de logs a un data lake.',
      'Crear un ticket de ITSM cuando se abre un Problem.',
      'Enviar un informe semanal de SLO a un canal de Slack.',
      'Lanzar una remediación closed-loop cuando se abre un Problem.',
    ),
    correctOptionIds: ['A'],
    explanationEs: 'La documentación indica que AutomationEngine no está pensado para ingestión ni exportación masiva de datos (para grandes volúmenes plantea OpenPipeline o extensiones). Notificar y colaborar (tickets, mensajes de Slack) y la remediación closed-loop de Problems son casos de uso documentados de Workflows.',
    sourceRefs: [AE],
    bucket: 'scenario', difficulty: 'intermediate', cognitiveLevel: 'analyze',
    reason: 'v3: la clave destacaba frente a ajustes técnicos; reformulada como elección entre casos de uso reales.',
  },
  'B-059': {
    options: opts(
      'Un Schedule trigger cada minuto que consulte la decisión externa.',
      'Un Event trigger con un filtro sobre el nombre del sistema externo.',
      'Invocarlo por API (On demand) y pasar el input en la llamada.',
      'Una ejecución con Run desde la UI por cada solicitud externa.',
    ),
    correctOptionIds: ['C'],
    explanationEs: 'On demand arranca solo cuando se invoca explícitamente, por ejemplo vía API; el input enviado en la llamada se fusiona con el input por defecto y se lee con input(). Sondear con Schedule añade retraso y ejecuciones vacías, un Event trigger necesita que el sistema emita eventos que se ingieran en OpenPipeline y Run manual no es automatizable.',
    reason: 'v3: distractor B sin coletilla.',
  },
  'B-061': {
    options: opts(
      'De Ana, porque es la owner del workflow.',
      'Del usuario que pulse Run en cada ejecución manual.',
      'Del actor configurado, en este caso el service user.',
      'De AutomationEngine, como identidad de sistema con permisos propios.',
    ),
    correctOptionIds: ['C'],
    explanationEs: 'El actor es la identidad en cuyo contexto se ejecutan las tasks y determina qué permisos pueden usar: aquí, el service user. Ser owner no cambia el actor, quien pulsa Run no lo sustituye y AutomationEngine no tiene permisos propios: ejerce, con autorización, los del actor.',
    reason: 'v3: distractores plausibles.',
  },
  'B-064': {
    options: opts(
      'Según la propiedad y visibilidad existentes cuando comenzó la ejecución.',
      'Según la visibilidad pública actual del workflow, también para ejecuciones pasadas.',
      'Según la visibilidad que tenga el workflow cuando finalice la ejecución.',
      'Según los permisos del actor configurado en el workflow.',
    ),
    correctOptionIds: ['A'],
    explanationEs: 'El acceso a una ejecución depende de la propiedad y la visibilidad (private/public) que tenía el workflow cuando comenzó la ejecución; cambiarlas solo afecta a ejecuciones futuras. No cuenta el estado actual ni el final, y el actor determina los permisos de las tasks, no quién puede consultar la ejecución.',
    reason: 'v3: distractor D sin coletilla; explicación completa.',
  },
  'C-030': {
    options: opts(
      'La ingesta en OpenPipeline de un evento que coincide con el filtro.',
      'La persistencia del evento en Grail, que el trigger consulta cada minuto.',
      'La creación de un Davis problem a partir de ese evento.',
      'Una consulta DQL periódica que encuentra el evento ya almacenado.',
    ),
    correctOptionIds: ['A'],
    explanationEs: 'Un Event trigger se activa cuando se ingiere en OpenPipeline un evento que coincide con su condición: cada evento se evalúa al entrar, incluso antes de persistirse en Grail. No consulta Grail periódicamente ni necesita que se cree un Problem.',
    reason: 'v3: distractores que se descartaban sin conocer el producto.',
  },
  'C-031': {
    explanationEs: 'Una llamada API puede iniciar siempre un workflow live, con independencia de que su trigger sea Schedule, Event u On demand, e incluso con el trigger desactivado. No hay que deshabilitar el trigger ni esperar al horario, y la API no encola la petición.',
    reason: 'v3: absorbe A-057 (trigger desactivado) en la explicación.',
  },
  'E-043': {
    options: opts('Problem trigger.', 'Davis event trigger.', 'Schedule trigger cada minuto.', 'Event trigger genérico sobre la tabla events.'),
    correctOptionIds: ['A'],
    explanationEs: 'Problem trigger actúa sobre el Problem, que puede agrupar varios Davis events; Davis event trigger se activa con cada alerta individual. Un Schedule trigger no reacciona a la apertura y un Event trigger genérico evalúa cada evento por separado.',
    reason: 'v3: distractor D plausible y explicación completa.',
  },
  'E-046': {
    options: opts(
      'Success, porque la mayoría de iteraciones terminó bien.',
      'Error, porque una iteración falló.',
      'Success con aviso, porque el loop continúa tras un error.',
      'Canceled, porque el loop se interrumpe en la iteración fallida.',
    ),
    correctOptionIds: ['B'],
    explanationEs: 'En una loop task cada iteración crea una action execution; la task termina en Success si todas las iteraciones terminan bien y en Error si falla al menos una. Con Retry on error se reintentan únicamente las iteraciones fallidas. Canceled corresponde a una cancelación del usuario.',
    sourceRefs: [RUN, BUILD],
    reason: 'v3: distractores plausibles; dato de reintento de iteraciones verificado en Monitor workflow executions.',
  },
  'FA-002': {
    options: opts(
      'Minimum duration de 5 minutos.',
      'Wait for root cause analysis.',
      'Wait before de 60 segundos en la primera task.',
      'Cambiar a Davis event trigger del evento inicial.',
    ),
    correctOptionIds: ['B'],
    explanationEs: 'Con Wait for root cause analysis el trigger arranca solo cuando Dynatrace Intelligence ha completado el root cause analysis del Problem. Minimum duration y Wait before esperan un tiempo fijo, no el análisis, y un Davis event trigger reacciona a alertas individuales, no al Problem analizado.',
    sourceRefs: [EVT, BUILD],
    reason: 'v3: distractor C que no era una opción real; distractores con opciones existentes.',
  },
  'FA-005': {
    promptEs: 'Un Event trigger demasiado amplio genera 1.200 ejecuciones en una hora, y la situación se repite varios días. ¿Qué dos afirmaciones describen el comportamiento documentado? (Selecciona 2)',
    options: opts(
      '1.000 ejecuciones event-triggered por hora y workflow; el exceso se limita con HTTP 429.',
      '1.000 ejecuciones por hora para el conjunto de workflows del entorno; el exceso se descarta.',
      'Si el límite se supera tres veces en siete días, el trigger se desactiva.',
      'El trigger se desactiva en cuanto se supera el límite horario por primera vez.',
    ),
    correctOptionIds: ['A', 'C'],
    explanationEs: 'Cada workflow admite 1.000 ejecuciones event-triggered por hora; al superarlo se aplica throttling (HTTP 429) durante hasta una hora. Si ocurre tres veces en siete días, el trigger se desactiva. El límite es por workflow, no por entorno, y un único exceso no desactiva el trigger.',
    bucket: 'precision', difficulty: 'advanced', cognitiveLevel: 'understand',
    reason: 'v3: fusiona FA-006 y G-159 (mismo límite) en una respuesta múltiple.',
  },
  'FA-009': {
    promptEs: 'Una rama de error debe ejecutarse cuando la consulta DQL de una task no devuelve resultados. ¿Qué opción usas?',
    options: opts(
      'Fail on empty result en la task de DQL.',
      'Una custom condition en la propia task DQL que exija records.',
      'Retry on error con 0 reintentos para marcar el vacío como fallo.',
      'La condición de estado error en la task sucesora, sin más cambios.',
    ),
    correctOptionIds: ['A'],
    explanationEs: 'Fail on empty result hace fallar la task cuando la consulta no devuelve records, y entonces una rama con condición de estado error puede reaccionar. Sin esa opción, records=[] termina en Success, así que la condición error del sucesor no se cumple; Retry on error solo actúa sobre una task que ya ha fallado, y la custom condition de una task decide si esa task se ejecuta, no evalúa su propio resultado.',
    sourceRefs: [DQLA, BUILD],
    reason: 'v3: distractores absurdos ("limit 0") sustituidos por opciones reales.',
  },
  'FA-011': {
    promptEs: 'Una consulta de una task Execute DQL Query no fija timeframe. ¿Qué intervalo usa por defecto la action?',
    options: opts('Últimas dos horas.', 'Últimas veinticuatro horas.', 'El último mes natural.', 'El timeframe del Schedule trigger que inició el workflow.'),
    correctOptionIds: ['A'],
    explanationEs: 'Si la consulta no fija su propio timeframe, Execute DQL Query usa las últimas 2 horas. No hereda ningún periodo del trigger; conviene fijar el timeframe en la consulta cuando la decisión dependa del periodo.',
    reason: 'v3: distractor D plausible y explicación completa.',
  },
  'FA-014': {
    promptEs: 'Un script de Run JavaScript importa un paquete SDK que necesita contexto de navegador y falla al ejecutarse. ¿Qué explica el fallo?',
    options: opts(
      'Corre en el Dynatrace JavaScript runtime, sin contexto de app ni navegador.',
      'Corre en el navegador del autor, que bloquea la carga de esos paquetes SDK.',
      'Corre en el contexto de la app Workflows, que no expone ese SDK.',
      'Corre en un ActiveGate del entorno, sin acceso a paquetes externos.',
    ),
    correctOptionIds: ['A'],
    explanationEs: 'Run JavaScript se ejecuta en el Dynatrace JavaScript runtime, sin contexto de app ni de navegador, por lo que los paquetes SDK que lo necesitan no funcionan. No corre en el navegador del autor, ni dentro de la app Workflows, ni en un ActiveGate.',
    reason: 'v3: enunciado confuso ("contrato de ejecución") y distractor irrelevante (Code tile).',
  },
  'FA-015': {
    options: opts(
      'Una función async exportada por defecto.',
      'Código top-level sin función, que se ejecuta al cargarse.',
      'Una función exportada con el nombre main.',
      'Una clase exportada por defecto con un método run().',
    ),
    correctOptionIds: ['A'],
    explanationEs: 'El script debe exportar por defecto una función async (export default async function), que el runtime invoca al ejecutar la task; lo que devuelve es el resultado de la task. El runtime no busca código top-level, una función llamada main ni una clase con run().',
    reason: 'v3: distractores que se descartaban solos.',
  },
  'G-142': {
    promptEs: 'Una desarrolladora ve y ejecuta workflows, pero no puede guardar un cambio en el Schedule trigger de un workflow del que es owner. Con mínimo privilegio, ¿qué permiso le falta?',
    options: opts('automation:workflows:admin', 'iam:service-users:use', 'automation:workflows:write', 'app-engine:functions:run'),
    correctOptionIds: ['C'],
    explanationEs: 'automation:workflows:write permite crear, actualizar y borrar workflows, incluida la configuración de schedules y Event triggers. admin también lo permitiría, pero da acceso a todos los workflows y ejecuciones del entorno y excede el mínimo privilegio; iam:service-users:use sirve para asignar service users como actor y app-engine:functions:run para el function executor.',
    bucket: 'scenario', difficulty: 'intermediate', cognitiveLevel: 'apply',
    reason: 'v3: pregunta deducible del nombre; convertida en escenario de mínimo privilegio.',
  },
  'G-153': {
    promptEs: 'Una task pausa la ejecución hasta que un responsable decida manualmente si el workflow continúa. Mientras nadie decide, ¿qué estado muestra esa task?',
    options: opts(
      'Idle, porque sus predecesoras todavía no han terminado.',
      'Running, porque su action execution sigue en curso.',
      'Waiting for approval, en pausa hasta que alguien decida.',
      'Discarded, porque se detiene la rama hasta la respuesta.',
    ),
    correctOptionIds: ['C'],
    explanationEs: 'Waiting for approval indica que la task está en pausa esperando que un usuario la apruebe o la rechace manualmente. Idle es una task que aún no se ha disparado porque sus predecesoras no han terminado, Running implica una action execution en curso o pendiente y Discarded es una task detenida por condiciones no cumplidas.',
    sourceRefs: [RUN],
    reason: 'v3: el enunciado repetía "approval" y delataba la clave.',
  },
}

v3Replace['G-151'] = {
  sourceRefs: [CONCEPTS, TRIG, VERSIONS],
  reason: 'v3: fuente de version history (la versión Current no se puede restaurar).',
}

v3Replace['FA-012'] = {
  explanationEs: 'Cuando el workflow arranca, el evento que lo activó puede no estar persistido aún en Grail. La documentación recomienda esperar 30–45 segundos o pasar el evento a la consulta con `data json:"""{{ event()|to_json }}"""`. El trigger no usa un bucket de staging ni otra tabla, y fetch events no excluye esos eventos: simplemente aún no están almacenados.',
  reason: 'v3: explicación que desmonta los distractores.',
}
v3Replace['FA-013'] = {
  explanationEs: 'Execute DQL Query devuelve las tres propiedades de la respuesta de la Grail Query API: records (filas), types (esquema) y metadata (detalles de ejecución, como timeframe o bytes escaneados). Los demás nombres (schema, stats, results, rows…) no forman parte del resultado.',
  reason: 'v3: explicación completa y terminología (action).',
}
v3Replace['FA-018'] = {
  explanationEs: 'El workflow result se compila con expresiones a partir de resultados de tasks y debe evaluarse a JSON válido y no superar 10 MB; si no, la ejecución del workflow falla. No se guarda como texto plano, no es un fallo de la última task con ejecución en Success y no se sustituye por records=[].',
  reason: 'v3: explicación que desmonta los distractores.',
}
v3Replace['FA-020'] = {
  options: opts(
    'iam:service-users:use sobre el actor del workflow hijo.',
    'automation:workflows:read sobre el padre y app-engine:functions:run.',
    'storage:events:read y automation:workflows:read sobre el hijo.',
    'automation:workflows:run y acceso al workflow seleccionado.',
  ),
  correctOptionIds: ['D'],
  explanationEs: 'El actor del workflow padre necesita automation:workflows:run y acceso al workflow seleccionado en la action; Run workflow ejecuta la versión live del hijo. iam:service-users:use sirve para asignar service users como actor, app-engine:functions:run para el function executor, y leer un workflow o eventos no permite ejecutarlo.',
  reason: 'v3: distractor sin coletilla y explicación sin notas internas.',
}
v3Replace['FA-021'] = {
  promptEs: 'Run workflow no encuentra un sub-workflow que solo existe como draft. ¿Qué restricción explica el resultado?',
  reason: 'v3: ortografía (solo) y término sub-workflow.',
}

const v3Remove: ModuleRevision['remove'] = {
  'A-056': 'v3: trivial (Schedule para un informe semanal); los tipos de schedule se evalúan en R-AUT-01/02/03, B-058 y G-155.',
  'A-057': 'v3: duplicado de C-031 (la API inicia cualquier workflow live); el caso del trigger desactivado pasa a su explicación.',
  'FA-006': 'v3: duplicado de FA-005, que pasa a respuesta múltiple con la desactivación tras tres excesos en siete días.',
  'G-159': 'v3: duplicado de FA-005 (throttling y desactivación).',
  'FA-016': 'v3: duplicado de R-AUT-06 (throw para hacer fallar Run JavaScript).',
  'G-149': 'v3: duplicado de FA-017/FA-018 (6 MB por action, 10 MB por workflow result).',
}

const addedV3: NewQuestion[] = [
  {
    id: 'R-AUT-23', moduleId: 'automation', chapterId: 'event-trigger-precision', objectiveId: 'automation:event-trigger-query-past-events',
    bucket: 'scenario', difficulty: 'intermediate', cognitiveLevel: 'apply',
    promptEs: 'Antes de guardar un Event trigger nuevo sobre bizevents quieres estimar cuántos eventos de tu entorno coinciden con el filtro. ¿Qué haces?',
    options: opts(
      'Usar Query past events en la configuración del trigger.',
      'Hacer deploy y revisar las ejecuciones de la primera hora.',
      'Ejecutar el workflow con Run para que evalúe eventos pasados.',
      'Activar Fail on empty result en la primera task del workflow.',
    ),
    correctOptionIds: ['A'],
    explanationEs: 'Query past events estima cuántos eventos coinciden con el filtro antes de guardar el trigger, lo que ayuda a no superar el límite de 1.000 ejecuciones por hora. Desplegar para medir arriesga ese límite, Run no evalúa el filtro sobre eventos pasados y Fail on empty result es una opción de Execute DQL Query.',
    sourceRefs: [EVT], classicOrLatest: 'latest', versionNote: LATEST,
  },
  {
    id: 'R-AUT-24', moduleId: 'automation', chapterId: 'deep-execution-states', objectiveId: 'automation:task-wait-before',
    bucket: 'practical', difficulty: 'intermediate', cognitiveLevel: 'apply',
    promptEs: 'La primera task de un workflow con Event trigger debe esperar 45 segundos antes de empezar, para dar tiempo a que el evento se persista. ¿Qué opción de la task usas?',
    options: opts(
      'Wait before con 45 segundos.',
      'Retry on error con 45 segundos entre reintentos.',
      'Un timeout de task de 45 segundos.',
      'Minimum duration de 45 segundos en el trigger.',
    ),
    correctOptionIds: ['A'],
    explanationEs: 'Wait before retrasa el inicio de la task (0 segundos por defecto, hasta 86.400). Retry on error solo actúa después de un fallo, el timeout hace fallar la task al vencer y Minimum duration es una opción del Problem trigger que se mide en minutos.',
    sourceRefs: [BUILD, DQLA, EVT], classicOrLatest: 'latest', versionNote: LATEST,
  },
  {
    id: 'R-AUT-25', moduleId: 'automation', chapterId: 'simple-workflow', objectiveId: 'automation:simple-to-standard',
    bucket: 'precision', difficulty: 'intermediate', cognitiveLevel: 'understand',
    promptEs: 'Un simple workflow debe seguir siéndolo para no consumir workflow hours. ¿Qué dos cambios lo convertirían en un workflow estándar? (Selecciona 2)',
    options: opts(
      'Añadir una custom condition a su task.',
      'Cambiar su trigger de On demand a Schedule.',
      'Activar Retry on error en su task.',
      'Cambiar la action de la task por HTTP Request.',
    ),
    correctOptionIds: ['A', 'C'],
    explanationEs: 'Usar task conditions (como una custom condition) o task options (como Retry on error) convierte el workflow en estándar, igual que añadir una segunda task, acceder al workflow result o activar logs completos. Un simple workflow admite cualquier trigger, y HTTP Request es una action permitida.',
    sourceRefs: [SIMPLE], classicOrLatest: 'latest', versionNote: LATEST,
  },
  {
    id: 'R-AUT-26', moduleId: 'automation', chapterId: 'deep-workflow-anatomy', objectiveId: 'automation:run-workflow-recursion',
    bucket: 'scenario', difficulty: 'advanced', cognitiveLevel: 'analyze',
    promptEs: 'El workflow A usa Run workflow para invocar a B, y B usa Run workflow para invocar a A con otros datos. ¿Qué indica la documentación?',
    options: opts(
      'No está permitido: se prohíben las recursiones directas e indirectas.',
      'Se permite si los dos workflows tienen trigger On demand.',
      'Se permite hasta diez niveles de anidamiento antes de fallar.',
      'Se permite si B se ejecuta como draft en lugar de live.',
    ),
    correctOptionIds: ['A'],
    explanationEs: 'Run workflow no admite recursiones directas ni indirectas de ejecuciones. El tipo de trigger no cambia la regla, la documentación no define niveles de anidamiento permitidos para la recursión y la action ejecuta la versión live del sub-workflow: los workflows que solo existen como draft no aparecen en la lista.',
    sourceRefs: [RWF], classicOrLatest: 'latest', versionNote: LATEST,
  },
  {
    id: 'R-AUT-27', moduleId: 'automation', chapterId: 'deep-jinja-dql', objectiveId: 'automation:dql-action-record-limit',
    bucket: 'troubleshooting', difficulty: 'intermediate', cognitiveLevel: 'analyze',
    promptEs: 'Esta consulta, en una task Execute DQL Query, devuelve exactamente 1.000 records, aunque sabes que hubo más errores en el periodo. ¿Qué explica el corte?',
    stimulus: { kind: 'code', title: 'Execute DQL Query · get_errors', content: 'fetch logs, from: now() - 2h\n| filter loglevel == "ERROR"\n| fields timestamp, dt.entity.host, content' },
    options: opts(
      'El límite por defecto de la action es 1.000 records; añade limit con un valor mayor.',
      'El resultado de la action se trunca al llegar a 6 MB; reduce los campos devueltos.',
      'Fail on empty result recorta el resultado a 1.000 records; desactiva esa opción.',
      'El timeframe por defecto se aplica sobre from:; elimínalo de la consulta.',
    ),
    correctOptionIds: ['A'],
    explanationEs: 'Execute DQL Query devuelve por defecto como máximo 1.000 records; para obtener más se usa el comando limit con un valor mayor. El límite de 6 MB no produce un corte exacto en 1.000 filas, Fail on empty result solo hace fallar la task si no hay records y el timeframe por defecto (2 horas) solo se aplica cuando la consulta no fija el suyo.',
    sourceRefs: [DQLA], classicOrLatest: 'latest', versionNote: LATEST,
  },
  {
    id: 'R-AUT-28', moduleId: 'automation', chapterId: 'deep-workflow-anatomy', objectiveId: 'automation:http-failure-codes',
    bucket: 'troubleshooting', difficulty: 'intermediate', cognitiveLevel: 'apply',
    promptEs: 'Una task HTTP Request hace un DELETE de limpieza y el endpoint responde 404 cuando el recurso ya no existe. La task falla y corta la rama, pero para este caso 404 es aceptable. ¿Qué ajustas?',
    options: opts(
      'La opción de fallar según códigos de respuesta HTTP, para excluir el 404.',
      'Retry on error con más reintentos hasta recibir un código 200.',
      'Fail on empty result, para no tratar como error una respuesta sin body.',
      'El timeout de la task, para esperar una respuesta distinta de 404.',
    ),
    correctOptionIds: ['A'],
    explanationEs: 'HTTP Request permite desactivar la opción de fallar según códigos de respuesta o definir qué códigos hacen fallar la task. Reintentar no cambia la respuesta de un recurso inexistente, Fail on empty result pertenece a Execute DQL Query y el timeout no influye en el código devuelto.',
    sourceRefs: [HTTP], classicOrLatest: 'latest', versionNote: LATEST,
  },
  {
    id: 'R-AUT-29', moduleId: 'automation', chapterId: 'deep-actor-permissions', objectiveId: 'automation:workflow-visibility',
    bucket: 'troubleshooting', difficulty: 'intermediate', cognitiveLevel: 'analyze',
    promptEs: 'Creas un workflow y un compañero con automation:workflows:read no lo ve en la lista de Workflows. ¿Qué explica la situación y qué haces?',
    options: opts(
      'Es private por defecto: hazlo public o transfiere su propiedad a un grupo.',
      'Le falta automation:workflows:write, necesario para listar workflows.',
      'Aparece cuando hay versión live: haz deploy del draft para que lo vea.',
      'Debe ser el actor del workflow: asígnaselo en la configuración.',
    ),
    correctOptionIds: ['A'],
    explanationEs: 'Por defecto un workflow es private: solo el owner puede verlo, gestionarlo y ejecutarlo. Para compartirlo se hace public o se transfiere la propiedad a otro usuario o a un grupo. read basta para ver workflows accesibles, el deploy no cambia la visibilidad y el actor define el contexto de ejecución, no quién ve el workflow.',
    sourceRefs: [SEC], classicOrLatest: 'latest', versionNote: LATEST,
  },
  {
    id: 'R-AUT-30', moduleId: 'automation', chapterId: 'deep-actor-permissions', objectiveId: 'automation:workflows-admin',
    bucket: 'scenario', difficulty: 'intermediate', cognitiveLevel: 'apply',
    promptEs: 'La persona que creó varios workflows privados ha dejado la empresa y hay que modificarlos. ¿Qué permiso permite a un administrador gestionarlos?',
    options: opts(
      'automation:workflows:admin, con acceso a todos los workflows y ejecuciones.',
      'automation:workflows:write, que permite editar los workflows del entorno.',
      'iam:service-users:use, que permite actuar en nombre del owner.',
      'automation:workflows:run, que permite abrir y relanzar sus ejecuciones.',
    ),
    correctOptionIds: ['A'],
    explanationEs: 'automation:workflows:admin da acceso a todos los workflows y ejecuciones del entorno y permite gestionar aquellos cuyo owner ya no está disponible (en Workflow admin mode). write no salta la propiedad ni la visibilidad de un workflow private, iam:service-users:use sirve para asignar service users como actor y run para ejecutar.',
    sourceRefs: [SEC], classicOrLatest: 'latest', versionNote: LATEST,
  },
  {
    id: 'R-AUT-31', moduleId: 'automation', chapterId: 'deep-jinja-dql', objectiveId: 'automation:jinja-md-table',
    bucket: 'practical', difficulty: 'intermediate', cognitiveLevel: 'apply',
    promptEs: 'Un mensaje de Slack debe mostrar como tabla el resultado de la task DQL `top_errors`. ¿Qué expresión usas?',
    options: opts(
      '{{ result("top_errors") | md_table }}',
      '{{ result("top_errors") | to_table }}',
      '{{ result("top_errors")["types"] | md_table }}',
      '{{ event()["top_errors"] | md_table }}',
    ),
    correctOptionIds: ['A'],
    explanationEs: 'El filtro md_table convierte el resultado de una consulta DQL (o una lista de objetos) en una tabla markdown. to_table no es un filtro documentado, types contiene el esquema y no las filas, y event() devuelve el evento que activó el workflow, no resultados de tasks.',
    sourceRefs: [JINJA], classicOrLatest: 'latest', versionNote: LATEST,
  },
]

const mergeReplace = (...maps: ModuleRevision['replace'][]): ModuleRevision['replace'] => {
  const out: ModuleRevision['replace'] = {}
  for (const map of maps) for (const [id, patch] of Object.entries(map)) out[id] = out[id] ? { ...out[id], ...patch } : patch
  return out
}

export const automationRevision: ModuleRevision = {
  moduleId: 'automation',
  replace: mergeReplace(baseReplace, v3Replace),
  remove: { ...baseRemove, ...v3Remove },
  add: [...added, ...addedV3],
}
