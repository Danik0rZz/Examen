import type { Question } from '../types'
import type { ModuleRevision } from './types'

export const REVISION_DATE = '2026-10-01'

/** Aplica las revisiones por módulo al banco original y devuelve el banco vigente. */
export function applyRevisions(base: Question[], revisions: ModuleRevision[]): Question[] {
  const replace = new Map<string, ModuleRevision['replace'][string]>()
  const remove = new Set<string>()
  for (const revision of revisions) {
    for (const [id, patch] of Object.entries(revision.replace)) replace.set(id, patch)
    for (const id of Object.keys(revision.remove)) remove.add(id)
  }
  const revised = base
    .filter((question) => !remove.has(question.id))
    .map((question) => {
      const patch = replace.get(question.id)
      if (!patch) return question
      const { reason: _reason, ...fields } = patch
      const merged: Question = { ...question, ...fields, lastVerified: REVISION_DATE }
      merged.type = merged.correctOptionIds.length > 1 ? 'multiple' : 'single'
      return merged
    })
  const added: Question[] = revisions.flatMap((revision) => revision.add.map((question) => ({
    ...question,
    form: 'R' as const,
    type: question.correctOptionIds.length > 1 ? 'multiple' as const : 'single' as const,
    lastVerified: REVISION_DATE,
  })))
  return [...revised, ...added]
}
