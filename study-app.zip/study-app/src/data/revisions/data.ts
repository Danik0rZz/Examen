import type { SourceRef } from '../types'
import type { ModuleRevision, NewQuestion } from './types'

const doc = (title: string, url: string): SourceRef => ({ title, url, kind: 'official-docs' })
const ORG = doc('Organize data in Grail', 'https://docs.dynatrace.com/docs/platform/grail/organize-data')
const MET = doc('DQL metric commands', 'https://docs.dynatrace.com/docs/platform/grail/dynatrace-query-language/commands/metric-commands')
const LIM = doc('Metrics limits', 'https://docs.dynatrace.com/docs/analyze-explore-automate/metrics/limits')
const FAQ = doc('FAQ for Metrics', 'https://docs.dynatrace.com/docs/analyze-explore-automate/metrics/faq')
const BPM = doc('Optimize metrics cost', 'https://docs.dynatrace.com/docs/analyze-explore-automate/metrics/best-practices-metrics')
const RET = doc('Data retention periods', 'https://docs.dynatrace.com/docs/manage/data-privacy-and-security/data-privacy/data-retention-periods')
const KR = doc('Monitor key requests', 'https://docs.dynatrace.com/docs/observe/application-observability/services-classic/monitor-key-requests')
const SES = doc('RUM user sessions', 'https://docs.dynatrace.com/docs/observe/digital-experience/rum/web-frontends/concepts/user-sessions-web')
const REP = doc('Dashboard reports', 'https://docs.dynatrace.com/docs/shortlink/dashboard-reports')
const API = doc('Metrics API - GET metric data points', 'https://docs.dynatrace.com/docs/dynatrace-api/environment-api/metric-v2/get-data-points')
const PERM = doc('Permissions in Grail', 'https://docs.dynatrace.com/docs/platform/grail/organize-data/assign-permissions-in-grail')
const SRC = doc('DQL data source commands', 'https://docs.dynatrace.com/docs/platform/grail/dynatrace-query-language/commands/data-source-commands')
const AGG = doc('DQL aggregation commands', 'https://docs.dynatrace.com/docs/platform/grail/dynatrace-query-language/commands/aggregation-commands')
const RCA = doc('Root cause analysis', 'https://docs.dynatrace.com/docs/dynatrace-intelligence/root-cause-analysis')
const TRC = doc('Distributed traces', 'https://docs.dynatrace.com/docs/observe/application-observability/distributed-traces')
const UBA = doc('User behavior analysis in RUM Classic', 'https://docs.dynatrace.com/docs/observe/digital-experience/rum-classic/web-applications/analyze-and-use/user-behavior-analysis')
const PERF = doc('Performance analysis in RUM Classic', 'https://docs.dynatrace.com/docs/observe/digital-experience/rum-classic/web-applications/analyze-and-use/performance-analysis')
const USQL = doc('Custom queries, segmentation, and aggregation of session data', 'https://docs.dynatrace.com/docs/observe/digital-experience/session-segmentation/custom-queries-segmentation-and-aggregation-of-session-data')
const DIFF = doc('Differences between Dashboards and Notebooks', 'https://docs.dynatrace.com/docs/analyze-explore-automate/dashboards-and-notebooks/differences-dashboards-notebooks')

const o = (a: string, b: string, c: string, d: string) => [
  { id: 'A', text: a }, { id: 'B', text: b }, { id: 'C', text: c }, { id: 'D', text: d },
]

const LATEST = 'Latest Dynatrace (SaaS, Grail). Verificado en docs.dynatrace.com en octubre de 2026.'
const CLASSIC = 'Funcionalidad Classic. Verificado en docs.dynatrace.com en octubre de 2026.'

const add: NewQuestion[] = [
  {
    id: 'R-DAT-01', moduleId: 'data-analysis', chapterId: 'sessions-problems', objectiveId: 'data-analysis:session-end-conditions',
    bucket: 'knowledge', difficulty: 'intermediate', cognitiveLevel: 'remember',
    promptEs: 'En RUM (Latest Dynatrace) para web frontends, ¿qué dos condiciones cierran una user session? (Selecciona 2)',
    options: o(
      '30 minutos de inactividad del navegador.',
      'Alcanzar 200 user actions dentro de la misma sesión.',
      'Una llamada a dtrum.endSession() desde la RUM JavaScript API.',
      'Alcanzar 2 horas de duración total de la sesión.',
    ),
    correctOptionIds: ['A', 'C'],
    explanationEs: 'La sesión termina tras 30 minutos de inactividad, al cerrar el navegador, al llegar a 6 horas de duración o al llamar a dtrum.endSession(). El límite de 200 acciones era propio de RUM Classic (RUM no impone límite de eventos) y la duración máxima es de 6 horas, no de 2.',
    sourceRefs: [SES], classicOrLatest: 'latest', versionNote: 'RUM (Latest). En RUM Classic existía además un límite de 200 user actions por sesión.',
  },
  {
    id: 'R-DAT-02', moduleId: 'data-analysis', chapterId: 'sessions-problems', objectiveId: 'data-analysis:session-registration',
    bucket: 'troubleshooting', difficulty: 'advanced', cognitiveLevel: 'analyze',
    promptEs: 'Una SPA genera muchas peticiones XHR en segundo plano, pero algunas visitas que solo producen esas peticiones no aparecen como user sessions. ¿Qué lo explica?',
    options: o(
      'Las request events abren sesión cuando superan el umbral de Apdex configurado en la aplicación.',
      'Hace falta al menos un evento de actividad del usuario, como una navigation o una user action.',
      'Las request events requieren que el código llame a dtrum.endSession() para registrar la sesión.',
      'Las request events se guardan en user.sessions, pero no en user.events, hasta el cierre.',
    ),
    correctOptionIds: ['B'],
    explanationEs: 'Para registrar una sesión debe capturarse al menos un evento que indique actividad del usuario (user action o navigation); las request events por sí solas no la registran. Apdex no decide el registro, dtrum.endSession() cierra sesiones (no las crea) y las request events son eventos, no sesiones agregadas.',
    sourceRefs: [SES], classicOrLatest: 'latest', versionNote: LATEST,
  },
  {
    id: 'R-DAT-03', moduleId: 'data-analysis', chapterId: 'sessions-problems', objectiveId: 'data-analysis:bounce-definition',
    bucket: 'precision', difficulty: 'basic', cognitiveLevel: 'understand',
    promptEs: 'Un informe de marketing usa la tasa de bounce de RUM. ¿Qué sesiones se etiquetan como bounced?',
    options: o(
      'Las que duran menos de 10 segundos, con independencia del número de acciones.',
      'Las que terminan con un error de JavaScript en la primera página visitada.',
      'Las que no alcanzan ningún conversion goal definido para la aplicación.',
      'Las que contienen una única user action o navigation.',
    ),
    correctOptionIds: ['D'],
    explanationEs: 'RUM marca como bounced una sesión con una sola user action o navigation. La duración, los errores de JavaScript o las conversiones se analizan junto al bounce, pero no lo definen.',
    sourceRefs: [SES], classicOrLatest: 'latest', versionNote: LATEST,
  },
  {
    id: 'R-DAT-04', moduleId: 'data-analysis', chapterId: 'reporting', objectiveId: 'data-analysis:dashboard-report-access',
    bucket: 'troubleshooting', difficulty: 'intermediate', cognitiveLevel: 'apply',
    promptEs: 'Un directivo sin cuenta de Dynatrace recibe por email el report semanal de un classic dashboard, pero el enlace le pide credenciales. ¿Qué ajuste revisas primero?',
    options: o(
      'Que esté activado "Allow anonymous access" en Settings > Dashboards > General settings.',
      'Que el directivo tenga una cuenta con permiso de lectura sobre el dashboard compartido.',
      'Que el report se haya configurado como monthly, la única frecuencia con enlace público.',
      'Que el dashboard se haya migrado a Dashboards (Latest) antes de activar los reports.',
    ),
    correctOptionIds: ['A'],
    explanationEs: 'Cada email de dashboard report incluye un enlace público al report; para verlo sin credenciales debe estar activado "Allow anonymous access" en la configuración general de Dashboards. Las personas sin acceso a Dynatrace pueden suscribirse mediante la Reports API, el enlace no depende de la frecuencia y la función pertenece a Dashboards Classic.',
    sourceRefs: [REP], classicOrLatest: 'classic', versionNote: CLASSIC,
  },
  {
    id: 'R-DAT-05', moduleId: 'data-analysis', chapterId: 'reporting', objectiveId: 'data-analysis:dashboard-report-content',
    bucket: 'knowledge', difficulty: 'intermediate', cognitiveLevel: 'remember',
    promptEs: '¿Qué dos afirmaciones sobre los dashboard reports de Dashboards Classic son correctas? (Selecciona 2)',
    options: o(
      'Pueden recibirse con frecuencia weekly, monthly o ambas.',
      'El email adjunta un PDF con los tiles del dashboard.',
      'Se envían a diario con el timeframe de las últimas 24 horas.',
      'El enlace incluye un timeframe acorde a la frecuencia elegida.',
    ),
    correctOptionIds: ['A', 'D'],
    explanationEs: 'Los reports pueden ser weekly (cada lunes por la mañana), monthly (primer lunes del mes) o ambos, y el enlace del email abre el report con el timeframe de esa frecuencia. El email contiene un enlace, no un PDF adjunto, y no existe frecuencia diaria.',
    sourceRefs: [REP], classicOrLatest: 'classic', versionNote: CLASSIC,
  },
  {
    id: 'R-DAT-06', moduleId: 'data-analysis', chapterId: 'deep-reporting-analysis', objectiveId: 'data-analysis:metrics-api-v2-scope',
    bucket: 'practical', difficulty: 'intermediate', cognitiveLevel: 'apply',
    promptEs: 'Una herramienta externa de reporting debe leer por REST los data points de métricas Classic. ¿Qué endpoint y token scope corresponden?',
    options: o(
      'POST /api/v2/metrics/ingest con un token con scope metrics.read.',
      'GET /api/v2/metrics/query con un token con scope metrics.ingest.',
      'GET /api/v2/metrics/query con un token con scope metrics.read.',
      'GET /api/v2/metrics/query con el permiso storage:metrics:read.',
    ),
    correctOptionIds: ['C'],
    explanationEs: 'Metrics API v2 expone los data points en GET /api/v2/metrics/query y requiere un token con scope metrics.read. metrics.ingest es para enviar métricas, /ingest no consulta datos y storage:metrics:read es un permiso IAM de Grail para leer la tabla metrics con DQL, no un token scope de esta API Classic.',
    sourceRefs: [API, PERM], classicOrLatest: 'classic', versionNote: 'Metrics API v2 consulta métricas Classic. Verificado en octubre de 2026.',
  },
  {
    id: 'R-DAT-07', moduleId: 'data-analysis', chapterId: 'timeframes', objectiveId: 'data-analysis:metrics-api-resolution',
    bucket: 'troubleshooting', difficulty: 'advanced', cognitiveLevel: 'analyze',
    promptEs: 'Un script pide a /api/v2/metrics/query 30 días de una métrica (from y to explícitos) sin el parámetro resolution, y recibe unos 120 puntos por serie en lugar de datos a 1 minuto. ¿Cuál es la causa más probable?',
    options: o(
      'Sin resolution, la API devuelve por defecto unos 120 data points por serie.',
      'La API aplica el límite de 10.080 data points por tupla y recorta el resto.',
      'Metrics Classic conserva 1 minuto durante los últimos 2 días del timeframe.',
      'Sin resolution, la API ignora from y devuelve el timeframe por defecto now-2h.',
    ),
    correctOptionIds: ['A'],
    explanationEs: 'El parámetro resolution tiene por defecto 120 data points, por lo que la API reparte el timeframe en unos 120 intervalos. El límite de 10.080 puntos por tupla daría muchos más puntos, Classic mantiene 1 minuto durante los primeros 14 días (no 2) y now-2h es el valor por defecto de from solo cuando no se indica.',
    sourceRefs: [API, RET], classicOrLatest: 'classic', versionNote: 'Metrics API v2 (métricas Classic). Verificado en octubre de 2026.',
  },
  {
    id: 'R-DAT-08', moduleId: 'data-analysis', chapterId: 'key-requests', objectiveId: 'data-analysis:key-request-tiles',
    bucket: 'scenario', difficulty: 'intermediate', cognitiveLevel: 'apply',
    promptEs: 'Lee el caso. ¿Qué explica lo que ve el equipo?',
    stimulus: {
      kind: 'case', title: 'Key request recién marcada',
      content: 'Lunes 10:00: el equipo marca POST /checkout como key request en Services Classic.\nLunes 11:00: añade un tile de la key request a un classic dashboard con timeframe "Last 7 days".\nEl tile solo muestra datos desde el lunes a las 10:00, aunque el servicio lleva meses recibiendo checkouts.',
    },
    options: o(
      'La key request tarda 7 días en recalcular su baseline antes de mostrar historial.',
      'Los tiles de key requests incluyen datos recogidos a partir del marcado.',
      'El tile usa el bucket default_spans, que tiene una retención de 10 días.',
      'El dashboard limita los tiles de key requests al timeframe de las últimas 24 horas.',
    ),
    correctOptionIds: ['B'],
    explanationEs: 'La documentación indica que los dashboard tiles de una key request solo incluyen datos recogidos a partir del momento en que se marcó. No se trata de una baseline, de la retención de spans de Grail ni de un límite de timeframe del tile.',
    sourceRefs: [KR], classicOrLatest: 'classic', versionNote: CLASSIC,
  },
  {
    id: 'R-DAT-09', moduleId: 'data-analysis', chapterId: 'key-requests', objectiveId: 'data-analysis:key-request-benefits',
    bucket: 'precision', difficulty: 'intermediate', cognitiveLevel: 'understand',
    promptEs: '¿Qué dos ventajas documentadas aporta marcar una request como key request en Services Classic? (Selecciona 2)',
    options: o(
      'El alerting está siempre activo aunque aporte menos del 1 % del throughput.',
      'Su code-level detail se conserva 5 años en lugar de 10 días.',
      'Dispone de métricas dedicadas y tiles propios en los dashboards.',
      'Cada servicio admite un número ilimitado de key requests.',
    ),
    correctOptionIds: ['A', 'C'],
    explanationEs: 'Las key requests tienen métricas dedicadas, tiles para dashboards, thresholds propios y alerting siempre activo aunque aporten menos del 1 % del throughput. El code-level detail sigue en 10 días (35 días agregado); lo que alcanza 5 años es el historial de métricas. El máximo es de 100 key requests por servicio y 500 por entorno.',
    sourceRefs: [KR], classicOrLatest: 'classic', versionNote: CLASSIC,
  },
  {
    id: 'R-DAT-10', moduleId: 'data-analysis', chapterId: 'sampling-completeness', objectiveId: 'data-analysis:sampling-ratio',
    bucket: 'scenario', difficulty: 'advanced', cognitiveLevel: 'analyze',
    promptEs: 'Un analista copia en un report el resultado de esta consulta como "total de errores de la semana". ¿Qué debes advertirle?',
    stimulus: {
      kind: 'code', title: 'Notebook · DQL',
      content: 'fetch logs, from:-7d, samplingRatio:100\n| filter loglevel == "ERROR"\n| summarize errors = count()\n\n// errors: 1 234',
    },
    options: o(
      'Es el total exacto; samplingRatio reduce el tiempo de ejecución, no los registros.',
      'Es el recuento del 1 % del timeframe más reciente, no de los siete días completos.',
      'Es el recuento de los 100 primeros registros de error por host en cada día.',
      'Cuenta aproximadamente 1/100 de los registros de log, así que no es el total real.',
    ),
    correctOptionIds: ['D'],
    explanationEs: 'samplingRatio aplica muestreo vertical sobre los registros de log: con 100 se devuelve aproximadamente 1/100 de los registros disponibles en todo el timeframe. El valor 1 (por defecto) no muestrea. El ratio usado queda en el campo oculto dt.system.sampling_ratio, que hay que documentar si se extrapola.',
    sourceRefs: [SRC], classicOrLatest: 'latest', versionNote: LATEST,
  },
  {
    id: 'R-DAT-11', moduleId: 'data-analysis', chapterId: 'sampling-completeness', objectiveId: 'data-analysis:scan-limit',
    bucket: 'troubleshooting', difficulty: 'advanced', cognitiveLevel: 'analyze',
    promptEs: 'Un fetch logs sobre 90 días de un bucket personalizado muy voluminoso devuelve resultados con un aviso de que se alcanzó el límite de escaneo. ¿Qué parámetro controla ese comportamiento?',
    options: o(
      'scanLimitGBytes, cuyo valor por defecto es 500 GB de datos sin comprimir.',
      'samplingRatio, cuyo valor por defecto limita el escaneo al 10 % de los logs.',
      'bucket, que por defecto restringe el escaneo a default_logs durante 35 días.',
      'timeframe, que por defecto corta el escaneo a los 30 días más recientes.',
    ),
    correctOptionIds: ['A'],
    explanationEs: 'scanLimitGBytes regula el volumen de datos sin comprimir analizado; por defecto es 500 GB y -1 analiza todos los datos del timeframe (con más coste). samplingRatio vale 1 por defecto (sin muestreo), bucket no restringe por defecto y timeframe no tiene ese corte.',
    sourceRefs: [SRC], classicOrLatest: 'latest', versionNote: LATEST,
  },
  {
    id: 'R-DAT-12', moduleId: 'data-analysis', chapterId: 'deep-metric-design', objectiveId: 'data-analysis:maketimeseries-logs',
    bucket: 'practical', difficulty: 'intermediate', cognitiveLevel: 'apply',
    promptEs: 'Quieres graficar la evolución de los logs de error de un host. Un compañero propone la consulta A y otro la B. ¿Cuál es la valoración correcta?',
    stimulus: {
      kind: 'code', title: 'Propuestas',
      content: '// A\ntimeseries count(logs), filter:{loglevel == "ERROR"}\n\n// B\nfetch logs\n| filter dt.entity.host == "HOST-15FE58391F97B7AA" and loglevel == "ERROR"\n| makeTimeseries count()',
    },
    options: o(
      'A es correcta: timeseries lee la tabla logs y es más eficiente que makeTimeseries.',
      'B es correcta: makeTimeseries crea series a partir de registros como logs o events.',
      'Son equivalentes; la consulta B añade el filtro de host que le falta a la consulta A.',
      'No sirven: los logs deben convertirse antes en métrica con OpenPipeline.',
    ),
    correctOptionIds: ['B'],
    explanationEs: 'timeseries consulta métricas; para graficar en el tiempo datos de registros (logs, events) se usa makeTimeseries, que genera series homogéneas a partir del stream. Convertir logs en métricas con OpenPipeline es una opción para paneles de larga duración, pero no es requisito para esta consulta.',
    sourceRefs: [AGG, MET], classicOrLatest: 'latest', versionNote: LATEST,
  },
  {
    id: 'R-DAT-13', moduleId: 'data-analysis', chapterId: 'retention-model', objectiveId: 'data-analysis:log-query-permissions',
    bucket: 'precision', difficulty: 'intermediate', cognitiveLevel: 'remember',
    promptEs: 'Un usuario nuevo debe poder ejecutar fetch logs sobre default_logs. ¿Qué dos permisos IAM necesita como mínimo? (Selecciona 2)',
    options: o(
      'storage:buckets:read',
      'storage:bucket-definitions:read',
      'storage:logs:read',
      'storage:metrics:read',
    ),
    correctOptionIds: ['A', 'C'],
    explanationEs: 'Consultar logs requiere acceso al bucket (storage:buckets:read) y a la tabla (storage:logs:read). storage:bucket-definitions:read permite ver la configuración de buckets, no leer registros, y storage:metrics:read corresponde a la tabla metrics.',
    sourceRefs: [PERM], classicOrLatest: 'latest', versionNote: LATEST,
  },
  {
    id: 'R-DAT-14', moduleId: 'data-analysis', chapterId: 'retention-model', objectiveId: 'data-analysis:record-level-permissions',
    bucket: 'troubleshooting', difficulty: 'advanced', cognitiveLevel: 'analyze',
    promptEs: 'Un analista con esta policy ejecuta fetch logs. Hay logs en default_logs y en el bucket personalizado team_b_logs. ¿Qué registros obtiene?',
    stimulus: {
      kind: 'code', title: 'IAM policy',
      content: 'ALLOW storage:buckets:read WHERE storage:bucket-name="default_logs";\nALLOW storage:logs:read WHERE storage:dt.security_context="TeamA";',
    },
    options: o(
      'Los logs de default_logs; la condición de security context afecta a team_b_logs.',
      'Los logs de ambos buckets con dt.security_context="TeamA", porque logs es una tabla lógica.',
      'Los logs de default_logs cuyo dt.security_context sea "TeamA".',
      'Ningún registro, porque falta storage:bucket-definitions:read sobre default_logs.',
    ),
    correctOptionIds: ['C'],
    explanationEs: 'La condición storage:bucket-name limita el acceso al bucket default_logs y storage:dt.security_context limita los registros de la tabla logs a TeamA; ambas se combinan. bucket-definitions:read no es necesario para leer registros.',
    sourceRefs: [PERM], classicOrLatest: 'latest', versionNote: LATEST,
  },
  {
    id: 'R-DAT-15', moduleId: 'data-analysis', chapterId: 'metric-retention', objectiveId: 'data-analysis:classic-granularity-tiers',
    bucket: 'precision', difficulty: 'advanced', cognitiveLevel: 'apply',
    promptEs: 'En Data Explorer Classic analizas una métrica Classic de hace 60 días. ¿Cuál es la granularidad más fina disponible para ese periodo?',
    options: o('1 minuto.', '5 minutos.', '1 hora.', '1 día.'),
    correctOptionIds: ['C'],
    explanationEs: 'Metrics Classic guarda 1 minuto durante 0–14 días, 5 minutos durante 14–28 días, 1 hora durante 28–400 días y 1 día de 400 días a 5 años. Metrics powered by Grail, en cambio, mantiene 1 minuto durante todo el historial.',
    sourceRefs: [RET, LIM], classicOrLatest: 'classic', versionNote: CLASSIC,
  },
  {
    id: 'R-DAT-16', moduleId: 'data-analysis', chapterId: 'metric-retention', objectiveId: 'data-analysis:classic-grail-separate-storage',
    bucket: 'scenario', difficulty: 'advanced', cognitiveLevel: 'analyze',
    promptEs: 'Un entorno empezó a guardar métricas en Grail hace dos semanas y lleva años con métricas Classic. Un Dashboard (Latest) con DQL no muestra la CPU de hace seis meses. ¿Cuál es el mejor siguiente paso?',
    options: o(
      'Ampliar el timeframe del Dashboard: DQL lee el historial Classic de forma transparente.',
      'Consultar ese periodo en Data Explorer Classic o Dashboards Classic; son almacenes separados.',
      'Cambiar el metric key a builtin:host.cpu.usage dentro de la consulta timeseries.',
      'Aumentar la retención de default_metrics para recuperar los datos anteriores.',
    ),
    correctOptionIds: ['B'],
    explanationEs: 'Las métricas Classic y Grail son bases de datos separadas y el historial Classic no se transfiere a Grail; sigue disponible en Data Explorer Classic y Dashboards Classic. DQL no admite metric selectors Classic y los buckets default_ no se modifican.',
    sourceRefs: [FAQ, ORG], classicOrLatest: 'mixed', versionNote: 'Compara Metrics Classic y Metrics powered by Grail. Verificado en octubre de 2026.',
  },
  {
    id: 'R-DAT-17', moduleId: 'data-analysis', chapterId: 'deep-metric-design', objectiveId: 'data-analysis:cardinality-remediation',
    bucket: 'scenario', difficulty: 'advanced', cognitiveLevel: 'analyze',
    promptEs: 'El consumo de una métrica OpenTelemetry se ha disparado. La tabla muestra los valores distintos de cada dimensión en 24 h. ¿Cuál es el mejor siguiente paso sin perder el análisis por servicio y ruta?',
    stimulus: {
      kind: 'table', title: 'http.server.duration · cardinalidad por dimensión (24 h)',
      columns: ['Dimensión', 'Valores distintos'],
      rows: [['service.name', '40'], ['http.route', '120'], ['request.id', '2 300 000'], ['cloud.region', '4']],
    },
    options: o(
      'Quitar request.id en el OTel Collector o con un processor de OpenPipeline.',
      'Mover la métrica a un bucket personalizado con una retención más corta.',
      'Usar interval:1h en los Dashboards para consultar menos data points.',
      'Quitar cloud.region, la única dimensión que no aporta valor de negocio al análisis.',
    ),
    correctOptionIds: ['A'],
    explanationEs: 'Se factura por data points ingeridos y la cardinalidad (combinaciones únicas) los multiplica; request.id es un identificador único que debe eliminarse en origen (filter/transform del OTel Collector) o en OpenPipeline (Remove fields). Las métricas no admiten buckets personalizados, la consulta no cambia lo ingerido y cloud.region apenas añade series.',
    sourceRefs: [BPM, ORG], classicOrLatest: 'latest', versionNote: LATEST,
  },
  {
    id: 'R-DAT-18', moduleId: 'data-analysis', chapterId: 'timeframes', objectiveId: 'data-analysis:timeseries-shift',
    bucket: 'practical', difficulty: 'intermediate', cognitiveLevel: 'apply',
    promptEs: 'Quieres superponer en un mismo gráfico la disponibilidad de disco de las últimas 24 horas y la del mismo periodo de la semana anterior. ¿Qué parámetro de timeseries usas en la segunda serie?',
    options: o('rate:7d', 'shift:-7d', 'interval:7d', 'from:-7d'),
    correctOptionIds: ['B'],
    explanationEs: 'shift desplaza el timeframe de una serie para compararla con otro periodo, por ejemplo con append y una segunda timeseries con shift:-7d. rate normaliza valores, interval fija el ancho de cada slot y from:-7d consultaría los últimos siete días completos, no el mismo día de la semana anterior.',
    sourceRefs: [MET], classicOrLatest: 'latest', versionNote: LATEST,
  },
  {
    id: 'R-DAT-19', moduleId: 'data-analysis', chapterId: 'correlation', objectiveId: 'data-analysis:correlation-vs-causation',
    bucket: 'scenario', difficulty: 'intermediate', cognitiveLevel: 'analyze',
    promptEs: 'La CPU de un host y la latencia del servicio que corre en él suben a la vez. Antes de afirmar que la CPU es la root cause, ¿qué dos comprobaciones aportan más evidencia? (Selecciona 2)',
    options: o(
      'Revisar los spans de las requests lentas para ver dónde se consume el tiempo.',
      'Calcular la correlación entre ambas series y concluir si supera 0,9.',
      'Ampliar el timeframe a 15 meses para confirmar que la relación se repite.',
      'Comprobar en Smartscape la dependencia y qué señal empezó primero.',
    ),
    correctOptionIds: ['A', 'D'],
    explanationEs: 'Una segunda señal independiente (spans) y la relación topológica y temporal entre entidades permiten pasar de correlación a una hipótesis causal; Davis usa ese enfoque basado en topología y dependencias. Un coeficiente alto o una relación repetida en el tiempo siguen siendo correlación.',
    sourceRefs: [RCA, TRC], classicOrLatest: 'latest', versionNote: LATEST,
  },
  {
    id: 'R-DAT-20', moduleId: 'data-analysis', chapterId: 'data-types', objectiveId: 'data-analysis:signal-for-latency-breakdown',
    bucket: 'knowledge', difficulty: 'basic', cognitiveLevel: 'understand',
    promptEs: 'Una request distribuida tarda 4 s y necesitas saber en qué servicio y operación se consume el tiempo. ¿Qué tipo de dato responde mejor a esa pregunta?',
    options: o(
      'Logs del servicio de entrada, filtrados por el identificador de la petición.',
      'La métrica de response time del servicio de entrada, agrupada por endpoint.',
      'Los Davis events del servicio de entrada durante el periodo de la request.',
      'Traces y spans, que muestran el recorrido de la request entre servicios.',
    ),
    correctOptionIds: ['D'],
    explanationEs: 'Los distributed traces muestran cómo viaja una request entre servicios y dónde están los cuellos de botella. Las métricas indican cuánto tarda en conjunto, los logs aportan contexto puntual y los Davis events señalan anomalías o cambios, no el recorrido de una request.',
    sourceRefs: [TRC], classicOrLatest: 'latest', versionNote: LATEST,
  },
  {
    id: 'R-DAT-21', moduleId: 'data-analysis', chapterId: 'sampling-completeness', objectiveId: 'data-analysis:fetch-bucket-sampling',
    bucket: 'precision', difficulty: 'advanced', cognitiveLevel: 'understand',
    promptEs: '¿Qué dos afirmaciones sobre los parámetros de fetch son correctas? (Selecciona 2)',
    options: o(
      'bucket acepta un nombre, una lista o un patrón con comodín *.',
      'samplingRatio también se aplica a la tabla metrics.',
      'El ratio aplicado se ve en el campo oculto dt.system.sampling_ratio.',
      'bucket amplía la retención de los datos que se consultan.',
    ),
    correctOptionIds: ['A', 'C'],
    explanationEs: 'bucket selecciona los buckets de origen (nombre, lista o comodín) y el ratio de muestreo queda en el campo oculto dt.system.sampling_ratio, visible con fields. samplingRatio está pensado para registros de log y las métricas se consultan con timeseries; seleccionar un bucket no cambia su retención.',
    sourceRefs: [SRC], classicOrLatest: 'latest', versionNote: LATEST,
  },
  {
    id: 'R-DAT-22', moduleId: 'data-analysis', chapterId: 'metric-retention', objectiveId: 'data-analysis:classic-vs-grail-querying',
    bucket: 'precision', difficulty: 'intermediate', cognitiveLevel: 'understand',
    promptEs: 'Un equipo migra consultas de métricas de Classic a Grail. ¿Qué dos afirmaciones son correctas? (Selecciona 2)',
    options: o(
      'DQL se usa en apps de Dynatrace; los metric selectors, en herramientas Classic.',
      'Los metric keys son idénticos en Classic y en Grail.',
      'Ingerir en ambos sistemas duplica el consumo de licencia de esas métricas.',
      'En Grail cambian los metric keys, a menudo con correspondencia uno a uno.',
    ),
    correctOptionIds: ['A', 'D'],
    explanationEs: 'DQL solo puede usarse en apps de Dynatrace y los metric selectors Classic solo en herramientas Classic; los metric keys siguen otra convención en Grail, con correspondencia uno a uno en muchos casos. Solo cuenta el consumo de la licencia activa, sin doble cargo.',
    sourceRefs: [FAQ], classicOrLatest: 'mixed', versionNote: 'Compara Metrics Classic y Metrics powered by Grail. Verificado en octubre de 2026.',
  },
  {
    id: 'R-DAT-23', moduleId: 'data-analysis', chapterId: 'sup-user-behavior', objectiveId: 'data-analysis:usql-closed-sessions',
    bucket: 'troubleshooting', difficulty: 'intermediate', cognitiveLevel: 'analyze',
    stimulus: {
      kind: 'code', title: 'Query User Sessions · USQL',
      content: 'SELECT COUNT(*) FROM usersession\n\n// Timeframe: última hora\n// Resultado: 1 842\n// En ese momento hay sesiones de usuarios todavía navegando por la aplicación',
    },
    promptEs: 'Un analista ejecuta esta consulta en RUM Classic para contar las sesiones de la última hora. Las sesiones que siguen en curso no aparecen en el recuento. ¿Qué lo explica?',
    options: o(
      'USQL consulta sesiones cerradas; las live sessions aún no están incluidas.',
      'USQL devuelve por defecto 50 filas, así que el recuento queda recortado.',
      'Las sesiones en curso se guardan en la tabla useraction hasta que se cierran.',
      'USQL extrapola los timeframes de una hora a partir de una muestra de sesiones.',
    ),
    correctOptionIds: ['A'],
    explanationEs: 'USQL solo consulta user sessions cerradas; las live sessions no se incluyen hasta que terminan. El límite de 50 filas afecta al número de filas devueltas, no a un COUNT(*) que devuelve una sola fila; useraction guarda acciones, no sesiones en curso; y la extrapolación desde una muestra se menciona para timeframes grandes, no para una hora.',
    sourceRefs: [USQL], classicOrLatest: 'classic', versionNote: CLASSIC,
  },
  {
    id: 'R-DAT-24', moduleId: 'data-analysis', chapterId: 'sup-user-behavior', objectiveId: 'data-analysis:usql-basics',
    bucket: 'precision', difficulty: 'intermediate', cognitiveLevel: 'remember',
    promptEs: '¿Qué dos afirmaciones sobre User Sessions Query Language (USQL) son correctas? (Selecciona 2)',
    options: o(
      'Consulta tablas como usersession y useraction.',
      'Es SQL estándar sobre una base de datos relacional de sesiones.',
      'Con LIMIT puede devolver hasta 5.000 resultados.',
      'Sin LIMIT devuelve todas las filas que cumplen la condición.',
    ),
    correctOptionIds: ['A', 'C'],
    explanationEs: 'USQL trabaja sobre tablas como usersession y useraction (además de userevent y usererror) y, con LIMIT, devuelve hasta 5.000 resultados. No es SQL y Dynatrace no guarda las sesiones en una base relacional; sin LIMIT el resultado por defecto es de 50 filas.',
    sourceRefs: [USQL], classicOrLatest: 'classic', versionNote: CLASSIC,
  },
  {
    id: 'R-DAT-25', moduleId: 'data-analysis', chapterId: 'sup-user-behavior', objectiveId: 'data-analysis:returning-users',
    bucket: 'knowledge', difficulty: 'intermediate', cognitiveLevel: 'remember',
    promptEs: 'En el análisis de comportamiento de RUM Classic, un usuario que vuelve a la aplicación tres meses después figura como returning. ¿En qué se basa Dynatrace?',
    options: o(
      'En una cookie persistente del navegador, válida durante 2 años.',
      'En el user tag asignado con la RUM JavaScript API durante el login.',
      'En la dirección IP y la geolocalización registradas en la primera visita.',
      'En una cookie de sesión que caduca tras 30 minutos de inactividad.',
    ),
    correctOptionIds: ['A'],
    explanationEs: 'Un returning visitor se determina mediante una cookie persistente en el navegador, válida durante 2 años. El user tag identifica a un usuario con nombre, pero no es lo que define returning; la IP y la geolocalización no identifican al visitante, y 30 minutos de inactividad cierran una sesión, no la identidad del usuario.',
    sourceRefs: [UBA], classicOrLatest: 'classic', versionNote: CLASSIC,
  },
  {
    id: 'R-DAT-26', moduleId: 'data-analysis', chapterId: 'sup-user-behavior', objectiveId: 'data-analysis:exit-actions',
    bucket: 'scenario', difficulty: 'intermediate', cognitiveLevel: 'apply',
    promptEs: 'Un equipo sospecha que una página lenta hace que los usuarios abandonen la aplicación. En el análisis de comportamiento de RUM Classic, ¿qué acciones conviene revisar primero?',
    options: o(
      'Las exit actions: la última page load o XHR action de cada sesión.',
      'Las entry actions: la primera page load o XHR action de cada sesión.',
      'Las other actions: las que no son ni la primera ni la última de la sesión.',
      'Las acciones con peor Apdex de la primera página que visita cada usuario.',
    ),
    correctOptionIds: ['A'],
    explanationEs: 'La exit action es la última page load o XHR action de una sesión; revisarlas ayuda a identificar si problemas de rendimiento hacen que los usuarios se vayan. Las entry actions son las páginas de llegada, las other actions son las intermedias y la primera página no dice dónde abandonan.',
    sourceRefs: [UBA], classicOrLatest: 'classic', versionNote: CLASSIC,
  },
  {
    id: 'R-DAT-27', moduleId: 'data-analysis', chapterId: 'sup-user-behavior', objectiveId: 'data-analysis:conversion-goals',
    bucket: 'precision', difficulty: 'basic', cognitiveLevel: 'understand',
    promptEs: '¿Cuándo cuenta RUM Classic una sesión como convertida para calcular la conversion rate?',
    options: o(
      'Cuando la sesión cumple al menos uno de los conversion goals definidos.',
      'Cuando la sesión incluye más de una user action y no se marca como bounced.',
      'Cuando la sesión termina en la exit action configurada como objetivo.',
      'Cuando la sesión cumple todos los conversion goals de la aplicación.',
    ),
    correctOptionIds: ['A'],
    explanationEs: 'Cada sesión convertida ha cumplido al menos uno de los conversion goals definidos para la aplicación. No bounced no equivale a convertida, el objetivo no se define por la exit action y no hace falta cumplir todos los goals.',
    sourceRefs: [UBA], classicOrLatest: 'classic', versionNote: CLASSIC,
  },
  {
    id: 'R-DAT-28', moduleId: 'data-analysis', chapterId: 'sup-user-behavior', objectiveId: 'data-analysis:slowest-actions-ranking',
    bucket: 'scenario', difficulty: 'advanced', cognitiveLevel: 'analyze',
    promptEs: 'En la performance analysis de RUM Classic, una user action poco frecuente que tarda 9 s no aparece en el top 3 de acciones más lentas, y sí otra de 2 s muy frecuente. ¿Por qué?',
    options: o(
      'El ranking usa total time consumed: duración multiplicada por frecuencia.',
      'El ranking usa la mediana de duración y descarta los valores extremos.',
      'El ranking excluye las acciones con Apdex frustrated para no sesgar la media.',
      'El ranking considera las XHR actions, medidas con la métrica Response end.',
    ),
    correctOptionIds: ['A'],
    explanationEs: 'Las acciones del top 3 se ordenan por prioridad (las de prioridad alta primero) y por total time consumed (duración × número de acciones): una acción algo lenta pero muy frecuente consume más tiempo total que una muy lenta y rara. No se usa la mediana, no se excluyen acciones por Apdex y el ranking no se limita a XHR actions.',
    sourceRefs: [PERF], classicOrLatest: 'classic', versionNote: CLASSIC,
  },
  {
    id: 'R-DAT-29', moduleId: 'data-analysis', chapterId: 'sup-user-behavior', objectiveId: 'data-analysis:action-metrics',
    bucket: 'precision', difficulty: 'intermediate', cognitiveLevel: 'remember',
    promptEs: 'En la performance analysis de RUM Classic, ¿qué métrica de duración se muestra para cada tipo de user action?',
    options: o(
      'Visually complete para load actions y Response end para XHR actions.',
      'Response end para load actions y Visually complete para XHR actions.',
      'Speed index para ambos tipos, porque es la métrica compuesta de carga.',
      'Time to first byte para load actions y Visually complete para XHR actions.',
    ),
    correctOptionIds: ['A'],
    explanationEs: 'La performance analysis usa Visually complete para las load actions y Response end para las XHR actions. Speed index y time to first byte forman parte de las métricas compuestas de respuesta, pero no son la métrica principal de cada tipo.',
    sourceRefs: [PERF], classicOrLatest: 'classic', versionNote: CLASSIC,
  },
  {
    id: 'R-DAT-30', moduleId: 'data-analysis', chapterId: 'deep-reporting-analysis', objectiveId: 'data-analysis:metrics-api-v2-params',
    bucket: 'practical', difficulty: 'intermediate', cognitiveLevel: 'apply',
    promptEs: 'Un script exporta datos con GET /api/v2/metrics/query para una hoja de cálculo. ¿Qué dos afirmaciones son correctas? (Selecciona 2)',
    options: o(
      'metricSelector admite hasta 10 métricas separadas por comas.',
      'Sin from, la consulta abarca por defecto los últimos 30 días.',
      'La respuesta puede pedirse en CSV mediante la cabecera Accept.',
      'La respuesta es CSV por defecto y JSON con un parámetro format.',
    ),
    correctOptionIds: ['A', 'C'],
    explanationEs: 'metricSelector selecciona hasta 10 métricas por sus keys, separadas por comas, y la respuesta es JSON por defecto o CSV (con o sin cabecera) según la cabecera Accept. Sin from, el valor por defecto es now-2h.',
    sourceRefs: [API], classicOrLatest: 'classic', versionNote: CLASSIC,
  },
  {
    id: 'R-DAT-31', moduleId: 'data-analysis', chapterId: 'sup-metric-limits', objectiveId: 'data-analysis:sub-minute-billing',
    bucket: 'precision', difficulty: 'advanced', cognitiveLevel: 'understand',
    promptEs: 'Un exporter envía una métrica personalizada cada 10 segundos a Metrics powered by Grail. ¿Cómo influye esa frecuencia en los data points facturados por serie?',
    options: o(
      'Se agregan por minuto: como máximo un data point por minuto y serie.',
      'Se facturan seis data points por minuto, uno por cada envío recibido.',
      'Se factura un data point por hora, porque Grail consolida tras 14 días.',
      'Se factura por serie activa, con independencia de la frecuencia de envío.',
    ),
    correctOptionIds: ['A'],
    explanationEs: 'Las métricas recogidas con más frecuencia que un minuto se agregan en intervalos fijos, de modo que se factura como máximo un data point por minuto y serie. No se cobra cada envío, Grail mantiene 1 minuto en todo el historial (la consolidación es de Classic) y el consumo se basa en data points ingeridos, no en series activas.',
    sourceRefs: [BPM], classicOrLatest: 'latest', versionNote: LATEST,
  },
  {
    id: 'R-DAT-32', moduleId: 'data-analysis', chapterId: 'reporting', objectiveId: 'data-analysis:notebooks-vs-dashboards',
    bucket: 'scenario', difficulty: 'basic', cognitiveLevel: 'apply',
    promptEs: 'Un SRE investiga un incidente complejo combinando métricas, logs y traces, y quiere compartir el razonamiento con su equipo. Otro equipo necesita seguir los SLOs del servicio en tiempo real. ¿Qué reparto encaja con la documentación?',
    options: o(
      'Notebook para la investigación compartida; Dashboard para el seguimiento continuo.',
      'Dashboard para la investigación compartida; Notebook para el seguimiento continuo.',
      'Notebook para ambos casos, porque cada sección se recalcula al abrirlo.',
      'Dashboard para ambos casos, porque los Notebooks no combinan logs y traces.',
    ),
    correctOptionIds: ['A'],
    explanationEs: 'Los Notebooks encajan en el análisis ad hoc, la investigación de incidentes complejos y la colaboración; los Dashboards, en la monitorización continua en tiempo real y el seguimiento de SLOs. Los Notebooks sí consolidan métricas, logs y traces, y sus datos se guardan dentro del notebook.',
    sourceRefs: [DIFF], classicOrLatest: 'latest', versionNote: LATEST,
  },
  {
    id: 'R-DAT-33', moduleId: 'data-analysis', chapterId: 'reporting', objectiveId: 'data-analysis:notebook-dashboard-data',
    bucket: 'precision', difficulty: 'intermediate', cognitiveLevel: 'understand',
    promptEs: 'Un analista guarda un Notebook con el resultado de una consulta y crea un Dashboard con la misma consulta. Días después, ¿qué diferencia de comportamiento documenta Dynatrace?',
    options: o(
      'Los datos del notebook se guardan en él; el dashboard consulta al abrirse.',
      'Ambos guardan una copia de los datos y la refrescan al editar la consulta.',
      'El dashboard guarda los datos en un bucket propio; el notebook consulta al abrirse.',
      'Ambos recalculan la consulta al abrirse, porque no almacenan resultados.',
    ),
    correctOptionIds: ['A'],
    explanationEs: 'Según la comparación oficial, los datos de un notebook se almacenan dentro del notebook, mientras que los de un dashboard se consultan al abrirlo. Por eso el Notebook sirve como registro del análisis y el Dashboard como vista viva.',
    sourceRefs: [DIFF], classicOrLatest: 'latest', versionNote: LATEST,
  },
]

const ABS = 'Equilibrio de absolutos: se quitan "sólo/automáticamente/cualquier" de los distractores para que no delaten la clave.'

/** Ajustes de redacción de distractores en preguntas correctas (sin cambio de clave). */
const wording: ModuleRevision['replace'] = {
  'A-061': {
    options: o(
      'El timeframe no amplía la retención; default_logs conserva los registros según la política del bucket.',
      'fetch logs aplica muestreo por defecto en timeframes largos y omite los registros más antiguos.',
      'La tabla logs admite consultas de 35 días como máximo, aunque un bucket personalizado retenga más.',
      'La tabla logs exige un filtro de bucket explícito en las consultas de más de 35 días.',
    ),
    explanationEs: 'La retención depende del bucket en que se almacenaron los logs: default_logs conserva 35 días, y un selector de 90 días puede pedir datos fuera de la retención, pero no recuperarlos. samplingRatio vale 1 por defecto (sin muestreo); la tabla logs no tiene un límite propio de 35 días (un bucket personalizado puede retener hasta 10 años) y no exige un filtro de bucket.',
    reason: ABS + ' Auditoría final: distractor B sin base (orden de secciones Query/Explore) sustituido por una confusión real con el muestreo de fetch.',
  },
  'A-062': {
    options: o(
      'Registros de ambos buckets, porque logs es la tabla lógica del tipo de registro.',
      'Registros de default_logs, porque fetch logs no atraviesa buckets personalizados.',
      'Registros del bucket personalizado, porque tiene prioridad sobre el predeterminado.',
      'Dos tablas de salida, una por bucket, aunque la consulta no especifique separación.',
    ),
    reason: ABS,
  },
  'A-063': {
    options: o(
      'Los datos más antiguos que el nuevo período se eliminan al actualizar la retención.',
      'La reducción cambia el selector por defecto del informe; los datos siguen íntegros.',
      'Grail mueve esos registros a default_logs para conservarlos.',
      'El cambio afecta a los nuevos registros; los ya almacenados conservan el período anterior.',
    ),
    explanationEs: 'La documentación indica que acortar la retención en una actualización elimina los datos que superan el nuevo período (el borrado se ejecuta de forma asíncrona). Antes de cambiarla hay que evaluar la necesidad histórica y el alcance del bucket.',
    reason: ABS + ' Redacción alineada con la documentación ("will delete the data").',
  },
  'A-064': {
    options: o(
      'La vista es una tabla virtual definida por una consulta; los registros siguen sujetos a sus buckets.',
      'La vista copia físicamente los logs y aplica una retención independiente de sus buckets.',
      'La vista materializa una copia filtrada al crearla, pero conserva la política de retención original.',
      'La vista concede permisos de lectura sobre los buckets de origen a quien la consulta.',
    ),
    reason: ABS,
  },
  'A-065': {
    options: o(
      'Separar los flujos en buckets personalizados y asignar permisos sobre cada bucket y la tabla logs.',
      'Guardar ambos flujos en default_logs y diferenciar los timeframes de los dashboards.',
      'Crear una vista por equipo sobre default_logs, con un filtro por equipo.',
      'Usar dt.security_context en un único bucket para separar los registros de cada equipo.',
    ),
    explanationEs: 'Los buckets personalizados particionan por retención y por acceso, y leer logs requiere además storage:logs:read sobre la tabla. Una vista no copia datos ni cambia su retención; dt.security_context separa el acceso, pero en un único bucket todos los registros comparten retención; y el timeframe de un dashboard no cambia lo almacenado.',
    reason: ABS + ' Distractores C y D autodesmontables sustituidos por alternativas plausibles que resuelven solo uno de los dos requisitos.',
  },
  'B-033': {
    options: o(
      'La tabla metrics consulta menos buckets que logs.',
      'La retención documentada de default_metrics es más larga que la de default_logs.',
      'Los logs pierden permisos de lectura al cumplir un mes.',
      'Los logs pasan a almacenamiento frío, inaccesible para DQL, tras 30 días.',
    ),
    reason: ABS,
  },
  'B-036': {
    options: o(
      'Truncate del bucket, que borra sus registros y conserva el bucket.',
      'Delete del bucket, que conserva la definición pero borra los registros.',
      'Reducir su retención a cero días y volver a ampliarla.',
      'Renombrar el bucket para que los registros anteriores dejen de verse.',
    ),
    reason: ABS,
  },
  'B-038': {
    options: o(
      'Los buckets personalizados se ofrecen para logs, events, bizevents, security events y spans; metrics no figura.',
      'Los buckets personalizados se ofrecen para metrics y spans, pero no para logs.',
      'Se ofrecen para todas las tablas, incluida metrics, con retención de 1 día a 10 años.',
      'Metrics admite bucket personalizado, pero con una retención máxima de 15 meses.',
    ),
    explanationEs: 'Los buckets personalizados se pueden crear para events, security events, bizevents, logs y spans; metrics no figura en la lista, así que default_metrics (15 meses) no admite un bucket propio. El rango de 1 día a 10 años es el de los buckets personalizados de los tipos admitidos, y 15 meses es la retención incluida de default_metrics, no el máximo de un bucket de métricas.',
    reason: ABS + ' Auditoría final: distractores C y D inverosímiles sustituidos por confusiones reales (rango de retención, 15 meses).',
  },
  'C-020': {
    options: o(
      'El borrado es asíncrono y el vaciado puede tardar; hay que seguir su estado en bucket definitions.',
      'El DELETE completó la eliminación y deleting es una etiqueta histórica permanente.',
      'El bucket ya está disponible para nuevas escrituras mientras se eliminan los registros previos.',
      'El estado deleting significa que hubo un conflicto 409 por processors activos.',
    ),
    reason: ABS,
  },
  'D-017': {
    options: o(
      'Crea registros para las dimensiones que no existen en los datos.',
      'Rellena con 0 los huecos temporales que serían null en la serie devuelta.',
      'Convierte a 0 los valores negativos observados.',
      'Sustituye por 0 el último intervalo, todavía incompleto.',
    ),
    explanationEs: 'default sustituye por el valor indicado los intervalos vacíos (null) de una serie existente; no crea series para dimensiones ausentes, no altera valores observados y no trata de forma especial el último intervalo.',
    reason: ABS + ' Distractor D absurdo (recuperar datos fuera de retención) sustituido.',
  },
  'E-025': {
    options: o(
      'union:true, que incluye series presentes en cualquiera de las columnas.',
      'union:false, que incluye las series sin coincidencia.',
      'scalar:true, que fusiona los hosts en una serie.',
      'default:0, que crea las dimensiones ausentes antes del cruce.',
    ),
    reason: ABS,
  },
  'E-028': {
    options: o(
      'El número de series métricas distintas presentes en ese intervalo.',
      'La suma de los valores numéricos de las series en el intervalo.',
      'El número total de muestras que componen cada serie en el intervalo.',
      'El número de combinaciones de dimensiones distintas durante todo el timeframe, sin dividirlo en intervalos.',
    ),
    explanationEs: 'Según la referencia de timeseries, count calcula el número de series distintas de la métrica en cada time slot (cardinalidad); sum agrega los valores y no hay agregación que cuente muestras individuales.',
    reason: 'Verificada la definición de count (cardinalidad por slot); clave correcta. ' + ABS,
  },
  'FD-001': {
    options: o(
      'La hora inicial; cada serie puede tener un intervalo distinto.',
      'Inicio, fin, intervalo y número de posiciones.',
      'El número de muestras observadas, sin posiciones vacías.',
      'El intervalo, aunque cada dimensión determina su propio timeframe.',
    ),
    reason: ABS,
  },
  'FD-002': {
    options: o(
      'Se usa la resolución mínima de un minuto.',
      'Se deriva un intervalo apropiado a partir del timeframe.',
      'Se toma la frecuencia original de la métrica sin alinearla.',
      'Se usa el intervalo de la primera serie encontrada para las demás.',
    ),
    reason: ABS,
  },
  'FD-004': {
    options: o(
      'Como filter global de timeseries para ambas agregaciones.',
      'En la agregación del numerador, dejando la otra sin ese filtro.',
      'Como filter global seguido de union:true en el denominador.',
      'En by:{status_code}, porque agrupar por código ya separa los 5xx.',
    ),
    reason: ABS,
  },
  'FD-010': {
    options: o(
      'La exploración puede escanear como máximo 100.000 series por consulta.',
      'metrics devuelve las primeras 100.000 claves, aunque tengan más series.',
      'metrics agrupa las dimensiones de cardinalidad alta en un valor "other".',
      'El límite se aplica a 100.000 puntos temporales, independientemente de las series.',
    ),
    reason: ABS,
  },
  'FD-012': {
    options: o(
      'Metrics Classic, porque mantiene un minuto durante cinco años.',
      'Metrics powered by Grail, porque no consolida los datos antiguos.',
      'Ambas, porque Classic no consolida datos antiguos.',
      'Metrics Classic, porque Grail consolida a una hora tras 28 días.',
    ),
    explanationEs: 'Metrics powered by Grail mantiene la granularidad de 1 minuto durante todo el historial incluido (15 meses). Metrics Classic conserva 5 años, pero con 1 minuto solo de 0 a 14 días; después pasa a 5 minutos, 1 hora y 1 día, así que no mantiene un minuto ni deja de consolidar. La consolidación a 1 hora tras 28 días es de Classic, no de Grail.',
    reason: ABS + ' Auditoría final: la clave era la única opción sin justificación; añadida para igualar la estructura.',
  },
  'FD-013': {
    options: o(
      'El prefijo dt. está reservado para métricas controladas por Dynatrace.',
      'dt. es obligatorio para todas las métricas personalizadas.',
      'dt. puede usarse si la métrica tiene dimensión host.',
      'dt. identifica una métrica Classic frente a una de Grail.',
    ),
    explanationEs: 'Dynatrace reserva el prefijo dt. para métricas que controla; los datos ingeridos con ese prefijo se descartan.',
    reason: 'Añadido el efecto documentado (drop). ' + ABS,
  },
  'FD-015': {
    options: o(
      'Se genera una serie por cada combinación distinta de valores dimensionales.',
      'Se genera exactamente una serie por dimensión, sin combinar valores.',
      'Las dimensiones afectan a la visualización, no al número de series.',
      'Porque Dynatrace almacena una réplica de la métrica por cada entidad Smartscape asociada.',
    ),
    reason: ABS,
  },
  'FD-020': {
    options: o(
      'Los buckets integrados default_ no se modifican; para otra política se usa uno personalizado.',
      'default_logs admite otra retención mediante PATCH y los personalizados son inmutables.',
      'default_logs hereda la retención global del tenant definida en la licencia DPS.',
      'Se requiere renombrar default_logs antes de cambiar su política.',
    ),
    reason: ABS,
  },
}

export const dataRevision: ModuleRevision = {
  moduleId: 'data-analysis',
  replace: {
    ...wording,
    'A-066': {
      options: o(
        'default_logs; la política de retención de ese bucket.',
        'La tabla logs como almacenamiento físico; el timeframe de la consulta.',
        'El bucket personalizado de logs más reciente; la retención global del tenant.',
        'Un bucket dt_ interno de OpenPipeline; la retención que defina el pipeline.',
      ),
      explanationEs: 'Sin asignación explícita, los logs van al bucket integrado de su tipo (default_logs, 35 días). La retención corresponde al bucket; la tabla logs es lógica, el timeframe no amplía la retención y no se usa el último bucket creado.',
      reason: 'Distractores descartables (cola hasta el primer Dashboard) sustituidos por errores plausibles.',
    },
    'B-034': {
      promptEs: 'En un análisis post-incidente, un equipo encuentra en default_logs los logs de hace tres semanas, pero ninguna trace de esos minutos en default_spans. No hay buckets personalizados. ¿Qué lo explica?',
      options: o(
        'default_spans retiene 10 días, mientras que default_logs conserva 35.',
        'default_spans retiene 7 días y los spans antiguos pasan a default_events.',
        'default_spans retiene 35 días, pero los spans se descartan al cerrarse el Problem.',
        'default_spans retiene 14 días y después conserva solo los spans con error.',
      ),
      correctOptionIds: ['A'],
      explanationEs: 'default_spans retiene 10 días y default_logs 35 días, así que a las tres semanas los logs siguen disponibles y los spans ya han caducado. Los spans no se mueven a default_events, no dependen del cierre de un Problem y default_spans no conserva una parte de los spans (por ejemplo, los de error) tras su retención: con 10 días caducan todos.',
      reason: 'Clave tautológica ("comparar la retención"); reformulada para exigir la cifra de default_spans (absorbe G-086). Auditoría final: coletilla de D que mezclaba Classic sustituida.',
    },
    'B-035': {
      options: o(
        'Un bucket se asocia a un único tipo de registro; hacen falta buckets por tipo.',
        'Pueden mezclarse si ambos flujos pasan por el mismo pipeline de OpenPipeline.',
        'Pueden mezclarse si el bucket se crea con el tipo events, que incluye bizevents.',
        'Pueden mezclarse, pero la retención se aplica por separado a cada tabla.',
      ),
      explanationEs: 'Cada bucket tiene un único table type (logs, events, bizevents, security events o spans). Para una misma retención hacen falta dos buckets, uno de logs y otro de bizevents, con el mismo periodo. events y bizevents son tablas distintas.',
      reason: 'Distractores descartables y explicación confusa; reescritos.',
    },
    'B-037': {
      options: o(
        'El nombre técnico puede editarse con PATCH sin afectar a las consultas.',
        'El nombre queda fijado al crearlo; hay que crear otro bucket y redirigir la ingestión.',
        'Puede renombrarse si antes se vacía el bucket con truncate y se pausa la ingestión.',
        'Basta con cambiar el display name, que actúa como identificador técnico.',
      ),
      explanationEs: 'El nombre del bucket se fija al crearlo y no puede editarse después; solo el display name (descriptivo) es editable. Vaciar el bucket no permite renombrarlo.',
      reason: 'Distractor absurdo (renombrar Dashboard) sustituido; matiz del display name añadido.',
    },
    'B-040': {
      options: o(
        'El bucket es integrado (default_) y por eso no puede eliminarse.',
        'Un processor de OpenPipeline lo referencia; hay que retirar esa referencia antes.',
        'Falta storage:bucket-definitions:delete y la API lo indica con 409 en vez de 403.',
        'El bucket contiene datos; primero hay que ejecutar truncate y luego delete.',
      ),
      explanationEs: 'La API devuelve 409 conflict si el bucket está referenciado activamente por processors de OpenPipeline. El enunciado habla de un bucket personalizado; un permiso ausente no produce 409 y delete elimina el bucket con sus datos sin truncate previo.',
      reason: 'Verificado el 409 en la documentación; distractores mejorados.',
    },
    'C-018': {
      promptEs: '¿Qué dos afirmaciones sobre los buckets personalizados de Grail son correctas? (Selecciona 2)',
      options: o(
        'Su retención puede fijarse entre 1 día y 10 años.',
        'Tienen un display name descriptivo, aparte del nombre del bucket.',
        'Su retención máxima es de 15 meses, como la de default_metrics.',
        'Pueden crearse para la tabla metrics con una retención propia.',
      ),
      correctOptionIds: ['A', 'B'],
      explanationEs: 'En un bucket personalizado la retención va de 1 día a 10 años (más una semana adicional), y el display name describe el bucket aparte de su nombre, que no puede cambiarse. 15 meses es la retención de default_metrics, y los buckets personalizados se ofrecen para events, security events, bizevents, logs y spans, no para metrics.',
      sourceRefs: [ORG],
      reason: 'Opción A vaga y solapada con FD-020/B-037/B-035; reescrita para evaluar el rango de retención y el display name.',
    },
    'B-039': {
      options: o(
        'storage:bucket-definitions:read, para gestionar las definiciones de bucket.',
        'storage:bucket-definitions:write, para crear buckets y cambiar su retención.',
        'storage:bucket-definitions:truncate, para ajustar el periodo de datos del bucket.',
        'settings:objects:write, para modificar la configuración de almacenamiento.',
      ),
      explanationEs: 'Leer datos y administrar buckets son autorizaciones separadas: storage:bucket-definitions:write permite crear buckets y cambiar su retención. bucket-definitions:read solo permite ver las definiciones, bucket-definitions:truncate vacía el bucket sin cambiar su retención y settings:objects:write se refiere a objetos de Settings, no a bucket definitions.',
      sourceRefs: [ORG, PERM],
      reason: 'Distractores autodesmontables ("porque también permite editar", "que implica escritura") y absurdo (Dashboard) sustituidos por permisos reales.',
    },
    'D-019': {
      options: o(
        '300 solicitudes por segundo, porque rate no tiene en cuenta el intervalo.',
        '60 solicitudes por segundo, al dividir por cinco.',
        '1 solicitud por segundo, al distribuir 300 entre 300 segundos.',
        '5 solicitudes por segundo, al multiplicar por el intervalo.',
      ),
      reason: 'Equilibrio de longitudes: la clave era la opción más larga.',
    },
    'D-020': {
      options: o(
        'timeseries p99=percentile(dt.service.request.response_time, 99), by:{dt.entity.service}.',
        'timeseries p99=avg(dt.service.request.response_time), by:{dt.entity.service}.',
        'timeseries p99=max(dt.service.request.response_time), by:{dt.entity.service}.',
        'timeseries p99=percentRank(dt.service.request.response_time, 99), by:{dt.entity.service}.',
      ),
      explanationEs: 'percentile(..., 99) estima el percentil 99; dt.service.request.response_time admite percentile sin rollup. percentRank(..., 99) devuelve la fracción de valores por debajo de 99 (no el percentil), avg da la media que oculta la cola y max solo el peor valor de cada intervalo.',
      sourceRefs: [MET],
      reason: 'Distractor count poco plausible sustituido por percentRank (confusión real con percentile); longitudes equilibradas.',
    },
    'E-029': {
      options: o(
        'metrics se limita a los últimos diez días.',
        'metrics se limita a las últimas dos horas.',
        'metrics no permite filtrar por host.',
        'metrics se limita a los últimos 35 días, como default_logs.',
      ),
      explanationEs: 'El comando metrics es exploratorio y su rango temporal llega como máximo a los últimos 10 días; además escanea hasta 100.000 series por consulta. No se limita a dos horas ni a 35 días (esa es la retención de default_logs, no un límite del comando), y sí admite filtrar por dimensiones como el host.',
      sourceRefs: [MET],
      reason: 'Absolutos ("sólo") en los distractores sustituidos. Auditoría final: D (métricas Synthetic) no respondía a la pregunta; sustituido por un límite vecino.',
    },
    'D-018': {
      options: o(
        'default:0, que crea la serie ausente y rellena sus intervalos.',
        'nonempty:true junto con default:0 en la agregación filtrada.',
        'nonempty:true, que crea la serie y rellena sus intervalos con 0.',
        'union:true en la combinación, que conserva la serie del denominador.',
      ),
      explanationEs: 'nonempty:true devuelve resultado aunque no haya registros y default:0 rellena con 0 los intervalos vacíos, de modo que el cociente da 0 %. default:0 por sí solo no crea series, nonempty:true sin default deja los intervalos en null y union:true conserva la serie del denominador, pero el numerador sigue vacío.',
      reason: 'Tres distractores empezaban por "Sólo", pista de que la clave era la combinación; reescritos sin absolutos.',
    },
    'C-019': {
      options: o(
        '250 buckets personalizados; los integrados no cuentan en ese límite.',
        '250 buckets en total, incluidos los default_ y dt_.',
        '100 buckets personalizados, ampliables por volumen de ingesta.',
        '80 buckets personalizados, sin posibilidad de ampliación.',
      ),
      explanationEs: 'El límite por defecto es de 250 buckets personalizados por entorno; los buckets integrados no forman parte de ese cupo y puede solicitarse un aumento.',
      reason: 'Cifra verificada (250); distractor con absoluto sustituido por un límite vecino.',
    },
    'E-027': {
      options: o(
        'percentile(metric, umbral).',
        'percentRank(metric, umbral).',
        'avg(metric) dividido entre el umbral.',
        'count(metric, filter:{value < umbral}).',
      ),
      explanationEs: 'percentRank devuelve la fracción (0,0–1,0) de valores por debajo del parámetro indicado; percentile hace lo inverso (devuelve el valor de un percentil). Igual que percentile, se aplica a histogram y requiere rollup en gauge o count. Una fracción de 0,9 significa que aproximadamente el 90 % de valores queda por debajo del umbral. Dividir la media entre el umbral da una proporción de la media, no la fracción de observaciones, y count devuelve el número de series distintas (cardinalidad), no una fracción de valores.',
      reason: 'Verificado que percentRank existe en timeseries; explicación ampliada (absorbe FD-006). Auditoría final: distractores C y D con sintaxis absurda sustituidos por alternativas plausibles.',
    },
    'FD-005': {
      explanationEs: 'percentile (y percentRank) se aplican a métricas histogram; para gauge o count la documentación exige el parámetro rollup.',
      reason: 'Verificado en DQL metric commands.',
    },
    'FD-011': {
      options: o(
        'Grail 500 millones; Classic 20 millones.',
        'Grail 20 millones; Classic 500 millones.',
        'Ambos 20 millones de data points.',
        'Grail 500 millones; Classic 100.000.',
      ),
      explanationEs: 'Metrics limits indica 500 millones de data points por consulta en Grail y 20 millones en Classic (también el máximo por request de Metrics API v2). 100.000 es el límite de custom metric keys.',
      reason: 'Cifras verificadas; distractor absoluto sustituido por cifra vecina.',
    },
    'G-082': {
      options: o('10 días.', '35 días.', '15 meses.', '1 año.'),
      explanationEs: 'default_logs retiene 35 días. Los buckets integrados no se modifican: para otra retención (de 1 día a 10 años) se envían los logs a un bucket personalizado.',
      difficulty: 'basic',
      reason: 'La explicación afirmaba que default_logs es configurable; distractor ajustado.',
    },
    'G-085': {
      promptEs: 'Comparas la retención de métricas entre Metrics Classic y Metrics powered by Grail. ¿Qué afirmación es correcta?',
      options: o(
        'Classic: 5 años con granularidad decreciente; Grail: 15 meses incluidos a 1 minuto.',
        'Classic: 15 meses a 1 minuto; Grail: 5 años con granularidad decreciente con la antigüedad.',
        'Classic: 14 días a 1 minuto y nada después; Grail: 35 días a 1 minuto.',
        'Classic y Grail: 15 meses incluidos, ambos con granularidad constante de 1 minuto.',
      ),
      explanationEs: 'Metrics Classic conserva 5 años, con 1 minuto solo los primeros 14 días y menor detalle después. Metrics powered by Grail incluye 15 meses a 1 minuto en todo el historial, ampliables hasta 10 años.',
      sourceRefs: [RET, LIM],
      classicOrLatest: 'mixed',
      reason: 'Distractores absurdos y pista de longitud; opciones paralelas con cifras vecinas.',
    },
    'G-088': {
      promptEs: 'En un análisis de rendimiento con DQL, ¿cuándo encaja timeseries mejor que fetch … | summarize?',
      options: o(
        'Cuando necesitas los valores de una métrica en intervalos regulares para graficarlos.',
        'Cuando necesitas un ranking de servicios por número de logs de error en el periodo.',
        'Cuando quieres convertir logs en series, porque timeseries lee la tabla logs directamente.',
        'Cuando quieres una fila por dimensión con el total del timeframe, sin array temporal.',
      ),
      explanationEs: 'timeseries consulta métricas y devuelve arrays de valores en intervalos homogéneos, ideales para gráficos. Un ranking o un total por dimensión es tarea de summarize, y para convertir logs en series se usa makeTimeseries.',
      difficulty: 'intermediate',
      reason: 'Distractores absurdos y pista de longitud.',
    },
    'G-091': {
      promptEs: 'Una aplicación envía a Grail una métrica personalizada con un timestamp como dimensión y genera millones de combinaciones únicas. ¿Qué consecuencia es la más relevante?',
      options: o(
        'Grail descarta la dimensión volátil y conserva la métrica sin coste adicional.',
        'Crecen las series y el consumo, y Dynatrace puede restringir o rechazar esa configuración.',
        'La métrica pasa a un bucket personalizado con una retención de 35 días.',
        'Se aplica el límite de 1 millón de dimensiones por métrica, como en Metrics Classic.',
      ),
      explanationEs: 'Grail admite dimensiones sin límite fijo salvo las muy volátiles; usar timestamps o IDs únicos como dimensión dispara la cardinalidad y el consumo, y Dynatrace puede restringir o rechazar esas configuraciones. El límite de 1 millón por métrica es de Classic.',
      reason: 'Distractores absurdos y concepto de Classic aplicado a Grail; verificado en Metrics limits.',
    },
    'G-092': {
      options: o(
        'Una única serie con la media de CPU del conjunto de hosts del timeframe.',
        'Una serie (array de valores por intervalo) para cada host presente en los datos.',
        'Una fila por host con un único valor medio, sin array temporal.',
        'Una serie por host, excluyendo los hosts sin datos en algún intervalo.',
      ),
      explanationEs: 'by:{...} divide la agregación en una serie por cada valor de la dimensión. Cada serie conserva el array temporal; los intervalos sin datos aparecen como null (o el valor de default) y no excluyen el host.',
      difficulty: 'intermediate',
      reason: 'Distractores absurdos; dificultad ajustada.',
    },
    'G-097': {
      options: o('10 días.', '35 días.', '14 meses.', '15 meses.'),
      explanationEs: 'default_user_sessions y default_user_events retienen 35 días, igual que los buckets de Synthetic. 14 meses corresponde a Davis problems y events, y 15 meses a métricas.',
      difficulty: 'basic',
      reason: 'Distractores de cifras vecinas del mismo tema.',
    },
    'G-098': {
      promptEs: 'Una métrica de Grail tiene 15 meses de retención a 1 minuto. Un Dashboard la muestra con interval:1h para los últimos 7 días. ¿Qué afirmación es correcta?',
      options: o(
        'Los datos a 1 minuto siguen almacenados; interval:1h cambia la agregación consultada.',
        'Consultar con interval:1h reduce a 7 días la retención almacenada de la métrica.',
        'Grail consolida los datos a 1 hora tras 14 días, por eso el Dashboard usa ese interval.',
        'La resolución de 1 minuto se pierde al guardar el Dashboard con interval:1h.',
      ),
      explanationEs: 'Resolución (anchura de cada punto en la consulta) y retención (cuánto tiempo se guardan los datos) son independientes. Grail mantiene 1 minuto en todo el historial; la consolidación tras 14 días es propia de Metrics Classic.',
      sourceRefs: [MET, LIM],
      bucket: 'scenario',
      reason: 'Pregunta trivial con distractores absurdos convertida en escenario.',
    },
    'G-099': {
      promptEs: '¿Qué retención documenta Dynatrace para Davis problems y Davis events?',
      options: o('35 días.', '14 meses.', '15 meses.', '1 año.'),
      explanationEs: 'Davis problems y events se conservan 14 meses. 15 meses es la retención incluida de métricas en Grail y 1 año la de default_securityevents y dt_system_events.',
      sourceRefs: [RET],
      reason: 'Cifra verificada en Data retention periods; fuente corregida y distractores vecinos.',
    },
  },
  remove: {
    'C-017': 'Memorización muy fina (default_securityevents_builtin frente a default_securityevents) con poco valor para Associate; la tabla de buckets integrados queda en la guía.',
    'FD-007': 'Pregunta resoluble por el estado Preview (metaconocimiento) y de nicho (countDistinct sobre métricas cardinality).',
    'FD-008': 'Enunciado vago sobre start()/end() con distractores poco plausibles; bajo valor de examen.',
    'FD-009': 'La clave repetía el enunciado (scalar no aplica a start/end) y su distractor A era la negación directa.',
    'FD-018': 'Duplicado de G-097 (35 días para los buckets de RUM y Synthetic).',
    'G-086': 'Duplicado de B-034, que ahora evalúa la retención de default_spans en un escenario.',
    'G-089': 'Duplicado de R-DAT-09 (ventajas de key requests, mismo distractor de 5 años de code-level).',
    'G-095': 'Duplicado de R-DAT-17 (quitar dimensiones volátiles; mismos distractores de bucket personalizado e interval).',
    'FD-017': 'Duplicado de C-017 (mismo dato con el orden invertido).',
    'FD-006': 'Duplicado de E-027 (percentRank); la interpretación de 0,9 pasa a la explicación de E-027.',
    'G-081': 'Duplicado de B-039 (storage:bucket-definitions:write).',
    'G-083': 'Duplicado de G-085 y B-033 (15 meses de métricas en Grail).',
    'G-084': 'Duplicado de D-017 (default:0).',
    'G-087': 'Premisa falsa: los buckets integrados no se modifican; no existe un mínimo justificado por baselines de Davis.',
    'G-090': 'Duplicado de A-063 y exagera el efecto ("purga inmediata"); el borrado es asíncrono.',
    'G-093': 'Support archives de OneAgent: dato ajeno al módulo y sin valor de examen para análisis de datos.',
    'G-094': 'Duplicado de C-017 (retención de security events).',
    'G-096': 'Duplicado de E-029 y FD-010 (límites del comando metrics).',
    'G-100': 'Metacomentario de resumen ("En conclusión") sin escenario evaluable; cubierto por A-065 y B-035.',
  },
  add,
}
