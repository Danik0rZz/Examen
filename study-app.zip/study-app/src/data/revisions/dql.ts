import type { ModuleRevision, NewQuestion } from './types'

const base = 'https://docs.dynatrace.com/docs/platform/grail/dynatrace-query-language'
const ref = (title: string, path: string) => ({ title, url: `${base}${path}`, kind: 'official-docs' as const })

const CMDS = ref('DQL commands', '/commands')
const DATASRC = ref('DQL data source commands', '/commands/data-source-commands')
const FILTER = ref('DQL filter and search commands', '/commands/filtering-commands')
const SELECT = ref('DQL selection and modification commands', '/commands/selection-and-modification-commands')
const EXTRACT = ref('DQL extraction and parsing commands', '/commands/extraction-and-parsing-commands')
const ORDER = ref('DQL ordering commands', '/commands/ordering-commands')
const STRUCT = ref('DQL structuring commands', '/commands/structuring-commands')
const AGG = ref('DQL aggregation commands', '/commands/aggregation-commands')
const JOIN = ref('DQL correlation and join commands', '/commands/correlation-and-join-commands')
const SMART = ref('DQL Smartscape commands', '/commands/smartscape-commands')
const METRIC = ref('DQL metric commands', '/commands/metric-commands')
const BEST = ref('DQL best practices', '/dql-best-practices')
const TYPES = ref('DQL data types', '/data-types')
const OPS = ref('DQL operators', '/operators')
const REF = ref('DQL language reference', '/dql-reference')
const F_ARRAY = ref('DQL array functions', '/functions/array-functions')
const F_AGG = ref('DQL aggregation functions', '/functions/aggregation-functions')
const F_CONV = ref('DQL conversion and casting functions', '/functions/conversion-and-casting-functions')
const F_COND = ref('DQL conditional functions', '/functions/conditional-functions')
const F_TIME = ref('DQL time functions', '/functions/time-functions')
const F_GEN = ref('DQL general functions', '/functions/general-functions')
const DPL = { title: 'Dynatrace Pattern Language', url: 'https://docs.dynatrace.com/docs/platform/grail/dynatrace-pattern-language', kind: 'official-docs' as const }
const F_BOOL = ref('DQL boolean functions', '/functions/boolean-functions')
const F_STRING = ref('DQL string functions', '/functions/string-functions')
const GRAIL_PERMS = { title: 'Permissions in Grail', url: 'https://docs.dynatrace.com/docs/platform/grail/organize-data/assign-permissions-in-grail', kind: 'official-docs' as const }
const SEMDICT = { title: 'Semantic Dictionary fields', url: 'https://docs.dynatrace.com/docs/semantic-dictionary/fields', kind: 'official-docs' as const }

const opts = (a: string, b: string, c: string, d: string) => [
  { id: 'A', text: a }, { id: 'B', text: b }, { id: 'C', text: c }, { id: 'D', text: d },
]

const NOTE = 'Dynatrace SaaS (Grail, DQL). Sintaxis verificada en docs.dynatrace.com en octubre de 2026.'

const q = (x: Omit<NewQuestion, 'moduleId' | 'classicOrLatest' | 'versionNote'>): NewQuestion => ({
  moduleId: 'dql', classicOrLatest: 'latest', versionNote: NOTE, ...x,
})

export const dqlRevision: ModuleRevision = {
  moduleId: 'dql',
  replace: {
    'A-019': {
      reason: 'Añadido el matiz del grupo null de summarize (auditoría: pregunta trivial).',
      difficulty: 'intermediate',
      bucket: 'precision',
      promptEs: 'Cuatro logs ERROR llegan a summarize errors = count(), by:{service.name}. Uno de ellos no tiene el campo service.name. ¿Qué devuelve summarize?',
      stimulus: { kind: 'table', title: 'Logs filtrados', columns: ['loglevel', 'service.name'], rows: [['ERROR', 'api'], ['ERROR', 'api'], ['ERROR', 'web'], ['ERROR', '(campo ausente)']] },
      options: opts(
        'Tres filas: api=2, web=1 y un grupo service.name=null con 1.',
        'Dos filas: api=2 y web=1; el registro sin campo se descarta.',
        'Dos filas: api=3 y web=1; el registro sin campo se suma al primer grupo.',
        'Una fila con errors=4, porque falta el campo en un registro.',
      ),
      correctOptionIds: ['A'],
      explanationEs: 'summarize crea un grupo por valor de service.name y, según la referencia, si el campo de agrupación no existe en todos los registros añade un grupo null. No descarta el registro ni lo reparte en otro grupo, y la ausencia del campo no anula la agrupación.',
      sourceRefs: [AGG],
    },
    'A-021': {
      reason: 'Distractores con absolutos y poco plausibles; se añaden comandos reales con propósito distinto.',
      options: opts(
        'parse sobre content con un patrón DPL que extraiga el código.',
        'fieldsAdd code = content, que copia el texto sin extraer el valor.',
        'fieldsFlatten sobre content, que convierte el texto en campos.',
        'search sobre content, que añade un campo con el término encontrado.',
      ),
      explanationEs: 'parse aplica un patrón DPL a un campo de texto y crea campos estructurados que luego se pueden agrupar. fieldsAdd solo copiaría el string completo, fieldsFlatten trabaja sobre records (no sobre texto) y search filtra registros sin crear campos.',
      sourceRefs: [EXTRACT],
    },
    'A-023': {
      reason: 'Formato de respuesta múltiple y distractor sin absolutos.',
      promptEs: 'Selecciona los dos comandos que pueden iniciar una consulta para los objetivos descritos. (Selecciona 2)',
      options: opts(
        'fetch logs para leer registros de log almacenados en Grail.',
        'timeseries para obtener valores de métricas por intervalos.',
        'filter loglevel == "ERROR" como primer comando de la consulta.',
        'summarize count() como origen que carga la tabla de logs.',
      ),
      explanationEs: 'fetch (data source command) carga registros de un data object y timeseries (metric command) combina carga, filtrado y agregación de métricas. filter y summarize procesan los registros que reciben por el pipe; no cargan datos.',
      sourceRefs: [CMDS],
    },
    'A-025': {
      reason: 'Se quitan absolutos de los distractores; la opción de grupos finales duplicaba la de la tabla de salida y se sustituye por la confusión con el muestreo (auditoría final).',
      options: opts(
        'La agregación cuenta solo los cien registros que deja pasar limit.',
        'limit restringe la tabla de salida una vez calculada la agregación.',
        'summarize extrapola el total a partir de la muestra de cien registros.',
        'summarize recupera los registros descartados por limit para el conteo.',
      ),
      explanationEs: 'Cada comando procesa la salida del anterior: un limit previo a summarize recorta la entrada de la agregación y falsea los totales. limit solo actúa sobre la tabla de salida cuando va después de summarize (y de sort); summarize no extrapola nada a partir de los registros recibidos ni recupera los que limit descartó: simplemente cuenta los cien que le llegan.',
      sourceRefs: [ORDER, BEST],
    },
    'A-026': {
      reason: 'Sintaxis canónica by:{…} con llaves, coherente con el resto del banco.',
      options: opts(
        'by:{dt.entity.host} dentro de timeseries.',
        'limit 2 después de la agregación.',
        'fieldsRemove dt.entity.host antes de visualizar.',
        'sort dt.entity.host asc tras timeseries.',
      ),
      explanationEs: 'El parámetro by: de timeseries (por ejemplo by:{dt.entity.host}) devuelve una serie por valor de la dimensión. limit y sort no crean series y quitar dt.entity.host elimina la dimensión que distingue los hosts.',
    },
    'B-045': {
      reason: 'Distractores débiles o con absolutos; se usan comandos reales de estructura.',
      options: opts(
        'fieldsFlatten, que saca los elementos del array a filas.',
        'expand, que genera un registro por cada elemento del array.',
        'jsonExtract, que convierte cada elemento en un registro.',
        'dedup, que separa el array en valores únicos por fila.',
      ),
      explanationEs: 'expand crea un registro por elemento del array (sin alias, el campo expandido sustituye al array). fieldsFlatten aplana records anidados en columnas, jsonExtract extrae claves de un string JSON y dedup elimina registros duplicados.',
      sourceRefs: [STRUCT],
    },
    'B-046': {
      reason: 'Distractores sin relación con correlación; se sustituyen por append, join y joinNested.',
      options: opts(
        'lookup, que añade campos de la coincidencia en la subconsulta.',
        'append, que añade los campos de la subconsulta a cada fila.',
        'join con kind:inner, que conserva las filas de origen sin coincidencia.',
        'joinNested, que añade el campo como columna plana.',
      ),
      explanationEs: 'lookup añade a cada registro de origen los campos del registro coincidente de la subconsulta (prefijo lookup. por defecto). append concatena registros, join inner descarta las filas sin coincidencia y joinNested añade las coincidencias como array de records.',
      sourceRefs: [JOIN],
    },
    'C-024': {
      reason: 'Distractores con absolutos; se usan alternativas reales.',
      options: opts(
        'joinNested, que añade las coincidencias como array de records.',
        'lookup, que añade cada coincidencia con el prefijo lookup.',
        'join con kind:leftOuter, que anida las coincidencias en un array.',
        'append, que anida los registros de la subconsulta en el original.',
      ),
      explanationEs: 'joinNested añade los resultados coincidentes de la subconsulta como array de records anidados. lookup toma solo la primera coincidencia, join produce una fila por coincidencia (no anida) y append concatena registros.',
      sourceRefs: [JOIN],
    },
    'D-021': {
      reason: 'Fusionada con G-115: se pregunta la sintaxis exacta de fieldsRename (nombre nuevo primero).',
      bucket: 'precision',
      difficulty: 'intermediate',
      promptEs: 'El resultado tiene host.name y el sistema destino espera hostname, sin que quede el campo original. ¿Qué línea es correcta?',
      options: opts(
        '| fieldsAdd hostname = host.name',
        '| fieldsRename hostname = host.name',
        '| fieldsRename host.name = hostname',
        '| fieldsRename host.name as hostname',
      ),
      correctOptionIds: ['B'],
      explanationEs: 'La sintaxis es fieldsRename fieldName = originalName: el nombre nuevo va primero (ej. | fieldsRename severity = loglevel). Invertir el orden busca un campo hostname inexistente, "as" no es sintaxis DQL y fieldsAdd crea una copia pero conserva host.name.',
      sourceRefs: [SELECT],
    },
    'D-022': {
      reason: 'Verificado: jsonExtract existe. Distractores más plausibles y explicación con conflicts.',
      options: opts(
        'jsonExtract sobre el campo que contiene el JSON.',
        'fieldsFlatten sobre el string JSON, con depth: 1.',
        'expand sobre el string JSON, que crea un registro por clave.',
        'fieldsMove con include:{"*"} sobre el string JSON.',
      ),
      explanationEs: 'jsonExtract analiza un string JSON y extrae sus claves de nivel raíz como campos; no sobrescribe campos existentes (las colisiones van al campo indicado en conflicts:). fieldsFlatten necesita un record, expand un array y fieldsMove mueve campos raíz a un record.',
      sourceRefs: [EXTRACT],
    },
    'D-024': {
      reason: 'Verificado: fieldsMove existe. Se quitan absolutos y se añade la sintaxis.',
      options: opts(
        'fieldsRemove, que crea el objeto con los campos eliminados.',
        'fieldsRename, que convierte un campo plano en anidado.',
        'fieldsMove, que mueve campos raíz a un campo de tipo record.',
        'fieldsFlatten, que agrupa en un record los campos que conserva.',
      ),
      explanationEs: 'fieldsMove mueve campos de nivel raíz a un record anidado y requiere include: o exclude:, p. ej. | fieldsMove k8s, include: {"k8s.*"}. fieldsFlatten hace lo contrario (saca campos de un record) y fieldsRemove/fieldsRename no crean records.',
      sourceRefs: [SELECT],
    },
    'E-033': {
      reason: 'Distractores poco plausibles; se usan parámetros reales de traverse.',
      options: opts(
        'fieldsKeep: name en traverse y leer dt.traverse.history del resultado.',
        'direction: backward en traverse y leer el campo name del nodo HOST.',
        'nodeId: name en traverse y leer dt.traverse.history del resultado.',
        'fieldsKeep name después de traverse, sobre los nodos HOST resultantes.',
      ),
      explanationEs: 'traverse admite fieldsKeep: para conservar campos del nodo de origen en dt.traverse.history (p. ej. smartscapeNodes PROCESS | traverse runs_on, HOST, fieldsKeep: name). direction cambia el sentido, nodeId indica el campo identificador (id por defecto) y un fieldsKeep posterior solo ve los campos del HOST.',
    },
    'E-034': {
      reason: 'Se quitan absolutos de distractores.',
      options: opts(
        'Ambos eliminan el registro.',
        'filterOut x conserva el registro; filter not x lo elimina.',
        'filterOut x elimina el registro; filter not x lo conserva.',
        'Ambos conservan el registro.',
      ),
      explanationEs: 'filterOut elimina solo los registros cuya condición es true; si es null, el registro se conserva. filter not x evalúa not null = null y filter descarta todo lo que no sea true.',
    },
    'FQ-015': {
      reason: 'Verificado en DQL data types y time functions: tf[start]/tf[end] y getStart/getEnd. Convertida a respuesta múltiple.',
      promptEs: 'Un campo tf es de tipo timeframe. ¿Qué dos expresiones devuelven su timestamp de inicio? (Selecciona 2)',
      stimulus: { kind: 'code', title: 'Datos de prueba', content: 'data record(tf = timeframe(from:now()-2h, to:now()))\n| fields tf, inicio = ___' },
      options: opts(
        'tf[start]',
        'tf.start',
        'getStart(tf)',
        'tf[0]',
      ),
      correctOptionIds: ['A', 'C'],
      explanationEs: 'La referencia de tipos muestra tf[start] y tf[end], y las time functions incluyen getStart(timeframe) y getEnd(timeframe). tf.start sería un identificador de campo con punto, no un acceso, y [0] es acceso por índice de array.',
      sourceRefs: [TYPES, F_TIME],
    },
    'A-020': {
      reason: 'Se quita un absoluto de distractor.',
      options: opts(
        'k8s.container.name == "coredns"',
        'k8s.container.name ~ "coredns"',
        'search "coredns"',
        'contains(content, "coredns")',
      ),
      explanationEs: 'La guía recomienda == o != para valores conocidos y ~ para valores parciales o desconocidos. search "coredns" busca el término en todos los campos y contains sobre content busca en el texto del log, no en el campo del contenedor.',
      sourceRefs: [BEST],
    },
    'A-022': {
      reason: 'Distractores obvios sustituidos por errores plausibles de orden y selección de campos (revisión v3).',
      options: opts(
        'Añadir fieldsAdd para cada campo necesario antes del primer filter.',
        'Seleccionar pronto los campos con fields, fieldsKeep o fieldsRemove.',
        'Ordenar con sort justo tras fetch para que Grail descarte columnas.',
        'Aplicar fieldsRemove al final, después de summarize y sort.',
      ),
      correctOptionIds: ['B'],
      explanationEs: 'La guía de buenas prácticas propone filtrar primero y después seleccionar pronto los campos con fields, fieldsKeep o fieldsRemove, para que los comandos siguientes procesen menos datos. fieldsAdd añade campos (no reduce el trabajo), ordenar justo tras fetch es lo que la guía pide evitar y quitar campos al final no ahorra el procesamiento de los pasos anteriores.',
      sourceRefs: [BEST, SELECT],
    },
    'FQ-001': {
      reason: 'Se quitan absolutos de distractores y se equilibra la longitud.',
      options: opts(
        'Las filas de spans, con campos null cuando no hay coincidencia.',
        'Las filas que cumplen la condición en ambos lados.',
        'Las filas de ambas tablas, emparejadas cuando hay coincidencia.',
        'Una coincidencia como máximo por cada servicio de origen.',
      ),
      explanationEs: 'join usa kind:inner por defecto y devuelve solo los pares que cumplen la condición. Conservar filas de spans sin coincidencia es leftOuter y conservar ambas es outer.',
    },
    'FQ-004': {
      reason: 'Se quita un absoluto de distractor.',
      options: opts(
        'Sí, si ambas claves son null.',
        'No; null no produce coincidencia de claves.',
        'Sí, pero con kind:outer.',
        'Sí, si la subconsulta tiene una única fila.',
      ),
      explanationEs: 'La referencia indica que, cuando las claves de ambos lados son null, los registros no se emparejan, con cualquier kind. Para tratarlos como iguales habría que sustituir antes el null (p. ej. con coalesce).',
    },
    'FQ-005': {
      reason: 'Equilibrio de longitud de opciones.',
      options: opts(
        'Los tres, como tres filas nuevas en el resultado.',
        'El primer registro coincidente de la subconsulta.',
        'Un array con las tres coincidencias anidadas.',
        'Ninguno, porque lookup exige una clave única.',
      ),
      explanationEs: 'Si hay varias coincidencias, lookup recupera solo el primer registro coincidente. Una fila por coincidencia es el comportamiento de join y el array de records anidados es el de joinNested; lookup no exige claves únicas.',
    },
    'FQ-007': {
      reason: 'Se quitan absolutos de distractores.',
      options: opts(
        'OR: basta con que coincida uno de los dos.',
        'AND: deben coincidir ambos criterios.',
        'Se aplica el primer criterio e ignora el resto.',
        'Se usa el segundo cuando el primero es null.',
      ),
      explanationEs: 'Las condiciones múltiples de on:{…} se combinan con AND, p. ej. on:{left[service.id] == right[id], left[cloudType] == right[cloud]}.',
    },
    'G-101': {
      reason: 'Serie G: distractores absurdos sustituidos por errores plausibles de sintaxis temporal.',
      options: opts(
        'fetch logs, from:now()-2h, to:now()',
        'fetch logs, interval:2h',
        'fetch logs, shift:-2h',
        'fetch logs | summarize count() | filter timestamp > now()-2h',
      ),
      explanationEs: 'fetch admite from:, to: y timeframe:. interval: y shift: son parámetros de timeseries/makeTimeseries, no de fetch; y tras summarize ya no existe timestamp para filtrar.',
      sourceRefs: [DATASRC],
    },
    'G-102': {
      reason: 'Serie G: distractores plausibles y fuente del Semantic Dictionary.',
      options: opts(
        'k8s.container.name y k8s.pod.name',
        'kubernetes.container.name y kubernetes.pod.name',
        'k8s.container_name y k8s.pod_name',
        'k8s.containerName y k8s.podName',
      ),
      explanationEs: 'El Semantic Dictionary define k8s.container.name, k8s.pod.name y k8s.namespace.name. Las variantes con prefijo kubernetes, guion bajo o camelCase no son los nombres estándar.',
      sourceRefs: [SEMDICT],
    },
    'G-103': {
      reason: 'Serie G: distractores plausibles.',
      options: opts(
        'count(tags)',
        'arraySize(tags)',
        'stringLength(tags)',
        'arrayLength(tags)',
      ),
      explanationEs: 'arraySize devuelve el tamaño de un array. count() es una agregación que cuenta registros, stringLength mide strings y arrayLength no existe en DQL.',
      sourceRefs: [F_ARRAY],
    },
    'G-104': {
      reason: 'Dato erróneo: arrayContains no existe en DQL. Clave cambiada a in(needle, haystack).',
      options: opts(
        'filter tags == "production"',
        'filter arrayContains(tags, "production")',
        'filter in("production", tags)',
        'filter arrayIndexOf(tags, "production") > 0',
      ),
      correctOptionIds: ['C'],
      explanationEs: 'in(needle, haystack) comprueba si un valor es miembro de un array. arrayContains no figura entre las array functions; == compara el array completo, y arrayIndexOf devuelve la posición (0 para el primer elemento, -1 si no está), así que > 0 pierde el caso de la posición 0.',
      sourceRefs: [F_GEN, F_ARRAY],
    },
    'G-106': {
      reason: 'Serie G: distractores plausibles y explicación corregida (fields no equivale a fieldsKeep).',
      options: opts(
        'fieldsAdd añade o reemplaza campos y conserva el resto; fieldsKeep conserva solo los campos indicados.',
        'fieldsAdd conserva los campos indicados y descarta el resto; fieldsKeep añade campos al final del registro.',
        'fieldsKeep acepta expresiones para crear campos calculados; fieldsAdd cambia el orden de las columnas.',
        'Ambos conservan las columnas existentes; fieldsKeep fija además el orden de las columnas indicadas.',
      ),
      explanationEs: 'fieldsAdd evalúa expresiones y añade o reemplaza campos sin descartar los demás. fieldsKeep conserva los campos o patrones indicados (admite comodines) y no crea campos inexistentes; fields sí puede calcular expresiones y reordena.',
      sourceRefs: [SELECT],
    },
    'G-110': {
      reason: 'Serie G: reformulada como caso práctico de tipado fuerte (to* frente a as*).',
      bucket: 'troubleshooting',
      difficulty: 'advanced',
      cognitiveLevel: 'apply',
      promptEs: 'Tras parse, el campo bytes contiene strings como "1532" y sum(bytes) no devuelve el total esperado. DQL es strongly typed. ¿Qué agregación corrige el cálculo?',
      options: opts(
        'summarize total = sum(asLong(bytes))',
        'summarize total = sum(toString(bytes))',
        'summarize total = sum(toLong(bytes))',
        'summarize total = sum(bytes), by:{toLong(bytes)}',
      ),
      correctOptionIds: ['C'],
      explanationEs: 'DQL es strongly typed: funciones y operadores aceptan solo los tipos declarados. toLong convierte un valor compatible a long; asLong solo garantiza el tipo y devuelve null si el valor no es ya long (aquí es string). toString no sirve para sumar y agrupar por el valor no cambia el tipo de bytes.',
      sourceRefs: [F_CONV, TYPES],
    },
    'G-112': {
      reason: 'Serie G: distractores plausibles.',
      options: opts(
        'filter evalúa condiciones sobre campos; search busca términos sin distinguir mayúsculas.',
        'filter busca texto libre en todos los campos; search exige indicar un campo con el operador ==.',
        'search es sensible a mayúsculas; filter con == ignora mayúsculas al comparar valores de tipo string.',
        'search compara el valor completo del campo; filter con ~ busca subcadenas arbitrarias dentro de content.',
      ),
      explanationEs: 'filter conserva los registros que cumplen una condición sobre campos (loglevel == "ERROR"). search hace coincidencia de strings insensible a mayúsculas y basada en tokens, en todos los campos o en uno concreto con field ~ "term".',
      sourceRefs: [FILTER],
    },
    'G-113': {
      reason: 'Serie G: distractores plausibles con parámetros vecinos (bins, from, shift).',
      options: opts(
        'El número total de intervalos (bins) que tendrá cada serie.',
        'El tamaño de cada time slot: un valor por cada 5 minutos.',
        'La ventana total de la consulta, equivalente a from:-5m.',
        'El desplazamiento de la serie 5 minutos hacia el pasado.',
      ),
      explanationEs: 'interval: fija la duración de cada time slot. bins: indica el número de slots (máximo 1.500), from:/to: la ventana y shift: desplaza el timeframe.',
    },
    'G-114': {
      reason: 'Serie G: distractores plausibles.',
      options: opts(
        'json_data[status]',
        'json_data.status',
        'json_data->status',
        'getField(json_data, "status")',
      ),
      explanationEs: 'Los campos de un record se leen con corchetes: person[name], person[address][pcode]. json_data.status se interpretaría como el nombre de un campo con punto, -> no es operador DQL y getField no existe.',
    },
    'G-116': {
      reason: 'Serie G: distractores plausibles; añadido el valor por defecto verificado.',
      difficulty: 'intermediate',
      options: opts(
        'samplingRatio',
        'scanLimitGBytes',
        'maxScanLimitGBytes',
        'bucketLimit',
      ),
      explanationEs: 'scanLimitGBytes limita los datos escaneados por fetch (500 GB por defecto; -1 lee todo). samplingRatio reduce el volumen leyendo una muestra y da resultados aproximados; maxScanLimitGBytes y bucketLimit no existen.',
      sourceRefs: [DATASRC, BEST],
    },
    'G-118': {
      reason: 'Verificado: countDistinct es alias de countDistinctApprox (aproximado). Pregunta reformulada.',
      bucket: 'precision',
      difficulty: 'advanced',
      promptEs: 'Un informe de auditoría exige el número exacto de direcciones IP distintas que generaron errores. ¿Qué agregación usarías dentro de summarize?',
      options: opts(
        'count(ip)',
        'countDistinct(ip)',
        'countDistinctApprox(ip)',
        'countDistinctExact(ip)',
      ),
      correctOptionIds: ['D'],
      explanationEs: 'countDistinctExact calcula la cardinalidad exacta. countDistinct es alias de countDistinctApprox, que usa estimación estocástica (aproximada), y count() cuenta registros, no valores distintos.',
      sourceRefs: [F_AGG],
    },
    'G-119': {
      reason: 'Serie G: clave acortada y distractores plausibles.',
      options: opts(
        'No; timeseries admite una agregación y hay que unir dos consultas con append.',
        'Sí, declarando varias agregaciones separadas por comas en el mismo timeseries.',
        'Sí, pero cada agregación necesita su propio parámetro interval: distinto.',
        'No; hay que usar fetch metrics y summarize con avg() y max().',
      ),
      explanationEs: 'La sintaxis de timeseries admite varias agregaciones: timeseries cpu_avg = avg(dt.host.cpu.usage), cpu_max = max(dt.host.cpu.usage), interval:1h. Todas comparten timeframe e interval; no se cargan métricas con fetch.',
    },
    'A-017': {
      reason: 'Explicación que desmonta cada distractor (revisión v3).',
      explanationEs: 'Primero se filtran los ERROR, después summarize cuenta todos los grupos, sort los ordena por errores y limit 5 se queda con los cinco mayores. Con limit tras sort timestamp se cuentan solo cinco registros, sin filter se cuentan todos los niveles de log y con limit antes de sort se toman cinco grupos cualesquiera.',
      sourceRefs: [BEST, ORDER],
    },
    'A-018': {
      reason: 'Explicación que desmonta cada distractor (revisión v3).',
      options: opts(
        'timeseries con la agregación y el intervalo adecuados.',
        'fetch de la tabla de métricas seguido de summarize por service.name.',
        'summarize con avg() de los datapoints agrupado por host.',
        'makeTimeseries aplicado después de limitar los registros a una muestra fija.',
      ),
      correctOptionIds: ['A'],
      explanationEs: 'timeseries es el comando de inicio que carga y agrega métricas en series temporales con interval: (un valor por time slot). Las métricas no se cargan con fetch, summarize sin bin temporal devuelve una tabla sin intervalos y makeTimeseries trabaja sobre registros del stream: limitarlos antes falsearía la serie.',
      sourceRefs: [METRIC, AGG],
    },
    'B-041': {
      reason: 'Distractor con valor imposible (samplingRatio:0.1) sustituido y explicación completa (revisión v3).',
      options: opts(
        'Usar samplingRatio:100 y multiplicar el resultado por 100 para obtener el total exacto.',
        'Mantener samplingRatio:1, el valor por defecto de fetch.',
        'Aplicar limit 100 antes de summarize y extrapolar.',
        'Usar samplingRatio:10, que conserva todos los registros de error.',
      ),
      correctOptionIds: ['B'],
      explanationEs: 'samplingRatio:1 es el valor por defecto y no muestrea. Con 10, 100, 1000 o 10000, fetch devuelve 1/samplingRatio de los registros, así que el resultado es aproximado aunque se multiplique, y el muestreo no distingue por nivel de log. limit antes de summarize recorta la entrada de la agregación.',
      sourceRefs: [DATASRC, BEST],
    },
    'E-031': {
      reason: 'Explicación que desmonta cada distractor (revisión v3).',
      explanationEs: 'traverse no inicia consultas: recibe nodos de smartscapeNodes y su sintaxis es traverse edgeType, targetType (primero la arista runs_on y después el tipo de nodo HOST). smartscapeEdges carga aristas, no nodos PROCESS; fetch logs no devuelve nodos Smartscape; y describe muestra esquemas de data objects.',
      sourceRefs: [SMART],
    },
    'E-032': {
      reason: 'Explicación que desmonta cada distractor (revisión v3).',
      explanationEs: 'smartscapeEdges carga aristas (relaciones entre nodos) filtradas por su tipo, como runs_on. smartscapeNodes recibe un tipo de nodo (HOST, PROCESS…), timeseries consulta métricas y dt.entity.runs_on no es un data object.',
      sourceRefs: [SMART],
    },
    'E-035': {
      reason: 'Distractor D se autodesmontaba; enunciado precisa que se quiere el registro completo (revisión v3).',
      promptEs: 'Necesitas conservar un registro completo, con todos sus campos, por cada combinación de service.name y status. ¿Qué comando expresa esa intención?',
      options: opts(
        'dedup service.name, status',
        'summarize count(), by:{service.name, status}',
        'summarize collectDistinct(status), by:{service.name}',
        'dedup status, sort:{service.name asc}',
      ),
      correctOptionIds: ['A'],
      explanationEs: 'dedup elimina duplicados según la combinación de campos y conserva un registro completo por combinación. summarize devuelve solo los campos de agrupación y las agregaciones, collectDistinct agrupa solo por servicio y reúne los estados en un array, y dedup status deja un registro por estado: sort: solo decide qué registro se conserva.',
      sourceRefs: [FILTER, AGG],
    },
    'FQ-003': {
      reason: 'Explicación que desmonta cada distractor (revisión v3). El distractor lookup (otro comando, no un valor de kind) se sustituye por rightOuter, valor plausible pero inexistente (auditoría final).',
      options: opts('inner.', 'leftOuter.', 'outer.', 'rightOuter.'),
      correctOptionIds: ['C'],
      explanationEs: 'El parámetro kind de join solo admite inner (por defecto), leftOuter y outer. outer devuelve los registros coincidentes y los no coincidentes de cualquiera de los dos lados. inner solo devuelve coincidencias, leftOuter conserva únicamente los no emparejados de la izquierda y rightOuter no existe en DQL: para conservar los no emparejados de la subconsulta hay que usar outer.',
      sourceRefs: [JOIN],
    },
    'FQ-006': {
      reason: 'Pregunta trivial reorientada al contraste de prefijos por defecto entre join y lookup (revisión v3).',
      promptEs: 'Enriqueces logs con join y, en otra consulta, con lookup, sin indicar prefix. ¿Con qué prefijos aparecen los campos añadidos desde cada subconsulta?',
      options: opts(
        'right. en join y lookup. en lookup.',
        'lookup. tanto en join como en lookup.',
        'right. tanto en join como en lookup.',
        'join. en join y lookup. en lookup.',
      ),
      correctOptionIds: ['A'],
      explanationEs: 'El prefijo por defecto de join es right. y el de lookup es lookup.; ambos se pueden cambiar con el parámetro prefix. join. no es un prefijo por defecto de DQL.',
      sourceRefs: [JOIN],
    },
    'FQ-009': {
      reason: 'Explicación que desmonta cada distractor (revisión v3).',
      explanationEs: 'search con field ~ "term" limita la búsqueda al campo indicado (search content ~ "error"). search "timeout" busca en todos los campos, loglevel == "timeout" compara otro campo con el valor completo y fields() no es una condición de search.',
      sourceRefs: [FILTER],
    },
    'FQ-011': {
      reason: 'Explicación alineada con la referencia (sin sort: la elección es aleatoria) y que desmonta los distractores (revisión v3).',
      explanationEs: 'Sin el parámetro sort:, el registro que dedup conserva de cada grupo es aleatorio; dedup display_id, sort:{timestamp desc} conserva el más reciente. limit 1 antes de dedup deja un único registro en total, un filterOut posterior no cambia la elección y quitar timestamp elimina el criterio de orden.',
      sourceRefs: [FILTER],
    },
    'FQ-012': {
      reason: 'Explicación que desmonta cada distractor (revisión v3).',
      explanationEs: 'fieldsSummary calcula la cardinalidad de los valores de los campos indicados. fieldsFlatten saca a la raíz los campos de un record, fieldsMove mueve campos raíz a un record y fieldsRename cambia nombres.',
      sourceRefs: [AGG, SELECT],
    },
    'FQ-013': {
      reason: 'Explicación que desmonta cada distractor (revisión v3).',
      explanationEs: 'fieldsFlatten extrae los campos de un record anidado a campos de nivel raíz (depth por defecto 1). fieldsMove hace lo contrario, fieldsRemove elimina campos y fieldsKeep conserva campos sin sacarlos del record.',
      sourceRefs: [STRUCT, SELECT],
    },
    'FQ-014': {
      reason: 'Enunciado aclarado y explicación que desmonta cada distractor (revisión v3).',
      promptEs: 'Antes de leer datos quieres ver qué campos y tipos define el esquema de un data object, sin cargar sus registros. ¿Qué comando usarías?',
      explanationEs: 'describe devuelve la definición de esquema de un data object (campos y tipos) sin cargar sus registros. fetch carga registros, load carga un archivo tabular de lookup y append añade registros de una subconsulta.',
      sourceRefs: [DATASRC],
    },
  },
  remove: {
    'B-048': 'Duplicado de A-022 (selección temprana de campos).',
    'C-022': 'Concepto de dedup cubierto por E-035 y FQ-011, más exigentes.',
    'FQ-008': 'Duplicado de D-023 (append frente a join/lookup).',
    'FQ-016': 'Duplicado de B-044 (posición de sort).',
    'G-105': 'Duplicado de B-045 (expand).',
    'G-107': 'Duplicado de E-036 (filtrar antes de transformaciones costosas).',
    'G-108': 'Afirmaba una ventaja de rendimiento de lookup no documentada; la semántica ya está en FQ-005 y FQ-006.',
    'G-109': 'Duplicado de B-044 (posición de sort).',
    'G-111': 'Duplicado de A-025 (limit antes de summarize) con metacomentario.',
    'G-115': 'Fusionada en D-021 (sintaxis de fieldsRename).',
    'G-120': 'Pregunta de resumen con afirmación inexacta sobre subconsultas (join, lookup y append las usan).',
    'A-027': 'Trivial (el pipe pasa la salida al siguiente comando); el efecto del orden ya se evalúa en A-017 y A-025.',
    'B-042': 'Duplicado de R-DQL-07 (acotar from: en el propio fetch), que evalúa además bucket: en el mismo escenario.',
    'B-043': 'Duplicado de R-DQL-07 (fetch con bucket: para reducir el escaneo).',
    'B-044': 'Duplicado de R-DQL-26 (sort al final de la consulta).',
    'E-036': 'Duplicado de R-DQL-26 (filtrar directamente el campo en lugar de transformarlo).',
    'FQ-010': 'Duplicado de G-112 (search insensible a mayúsculas); el matching por tokens ya se evalúa en R-DQL-04.',
    'B-047': 'Duplicado de R-DQL-02 (makeTimeseries frente a timeseries sobre registros de logs).',
    'C-021': 'Trivial sin el matiz de null; filterOut se evalúa con ese matiz en E-034 y R-DQL-01.',
    'C-023': 'Duplicado de G-106 (fieldsAdd añade una columna y conserva el resto).',
    'FQ-002': 'Duplicado de FQ-001 (leftOuter conserva todas las filas de la izquierda) con distractor que se autodesmonta.',
    'G-117': 'Mismo concepto que G-110 (funciones as* frente a to*).',
  },
  add: [
    q({
      id: 'R-DQL-01', chapterId: 'functions-null', objectiveId: 'dql:null-comparison', bucket: 'troubleshooting', difficulty: 'advanced', cognitiveLevel: 'analyze',
      promptEs: 'La consulta debe contar todos los logs que no vienen de nginx, pero faltan los que no tienen el campo log.source. ¿Qué dos cambios los incluyen? (Selecciona 2)',
      stimulus: { kind: 'code', title: 'Consulta actual', content: 'fetch logs, from:-1h\n| filter log.source != "nginx"\n| summarize n = count()' },
      options: opts(
        '| filter isTrueOrNull(log.source != "nginx")',
        '| filter not (log.source == "nginx")',
        '| filterOut log.source == "nginx"',
        '| filter log.source != "nginx" or log.source == null',
      ),
      correctOptionIds: ['A', 'C'],
      explanationEs: 'Con un operando null, != devuelve null y filter descarta lo que no es true. isTrueOrNull incluye los null, y filterOut solo elimina registros cuya condición es true (conserva los null). not null sigue siendo null, y log.source == null también devuelve null, así que esas variantes siguen descartándolos.',
      sourceRefs: [OPS, FILTER],
    }),
    q({
      id: 'R-DQL-02', chapterId: 'aggregation', objectiveId: 'dql:maketimeseries-vs-bin', bucket: 'practical', difficulty: 'intermediate', cognitiveLevel: 'apply',
      promptEs: 'Necesitas el número de logs ERROR por hora durante las últimas 24 horas. ¿Qué dos consultas son válidas? (Selecciona 2)',
      options: opts(
        'fetch logs, from:-24h | filter loglevel == "ERROR" | summarize errors = count(), interval:1h',
        'fetch logs, from:-24h | filter loglevel == "ERROR" | makeTimeseries errors = count(), interval:1h',
        'timeseries errors = count(logs), filter:{loglevel == "ERROR"}, interval:1h, from:-24h',
        'fetch logs, from:-24h | filter loglevel == "ERROR" | summarize errors = count(), by:{bin(timestamp, 1h)}',
      ),
      correctOptionIds: ['B', 'D'],
      explanationEs: 'makeTimeseries crea series a partir de los registros del stream (admite interval:) y summarize con by:{bin(timestamp, 1h)} agrupa por hora en formato tabla. summarize no tiene parámetro interval: y timeseries trabaja sobre métricas, no sobre la tabla logs.',
      sourceRefs: [AGG],
    }),
    q({
      id: 'R-DQL-03', chapterId: 'parse-fields', objectiveId: 'dql:parse-failure-null', bucket: 'troubleshooting', difficulty: 'intermediate', cognitiveLevel: 'analyze',
      promptEs: 'Tras esta consulta aparece una fila status=null con miles de registros. ¿Cuál es la explicación más probable?',
      stimulus: { kind: 'code', title: 'Consulta', content: 'fetch logs, from:-2h\n| parse content, "LD \'status=\' INT:status"\n| summarize n = count(), by:{status}' },
      options: opts(
        'parse descarta los registros que no coinciden; el null procede de otro campo.',
        'Los logs cuyo content no coincide con el patrón se conservan con status=null.',
        'El patrón INT convierte a null los códigos de estado mayores de 499.',
        'summarize crea un grupo null cuando hay más de 1.000 registros por grupo.',
      ),
      correctOptionIds: ['B'],
      explanationEs: 'Si el patrón no coincide, parse conserva el registro y deja null los campos del patrón (con preserveFieldsOnFailure:true se mantendrían los valores existentes). Por eso conviene filtrar antes los logs relevantes o usar parsingPrerequisite. INT no depende del valor y el grupo null de summarize no depende del volumen.',
      sourceRefs: [EXTRACT, DPL],
    }),
    q({
      id: 'R-DQL-04', chapterId: 'functions-null', objectiveId: 'dql:tilde-token-matching', bucket: 'precision', difficulty: 'advanced', cognitiveLevel: 'analyze',
      promptEs: 'Un log tiene content = "connectionTimeout after 30s". ¿Coincide con | filter content ~ "timeout"?',
      options: opts(
        'Sí, porque ~ busca cualquier subcadena sin distinguir mayúsculas ni minúsculas.',
        'No, porque ~ distingue mayúsculas y el log contiene "Timeout".',
        'No: sin comodines, ~ busca tokens completos; "*timeout*" sí coincidiría.',
        'Sí, pero dentro de search; en filter el operador ~ exige el valor completo.',
      ),
      correctOptionIds: ['C'],
      explanationEs: 'El operador ~ es insensible a mayúsculas y, sin comodines, busca el valor como token dentro del string (la documentación muestra que "helloWorld" ~ "World" es false). Con comodines busca el patrón dentro de los tokens, así que "*timeout*" coincide.',
      sourceRefs: [OPS],
    }),
    q({
      id: 'R-DQL-05', chapterId: 'metric-commands', objectiveId: 'dql:timeseries-shift', bucket: 'practical', difficulty: 'intermediate', cognitiveLevel: 'understand',
      promptEs: 'Quieres comparar el espacio libre en disco de hoy con el del mismo periodo de la semana anterior. ¿Qué hace shift:-7d en la segunda consulta?',
      stimulus: { kind: 'code', title: 'Comparación semanal', content: 'timeseries avail = avg(dt.host.disk.avail), by:{dt.entity.host}, from:-24h\n| append [timeseries avail.7d = avg(dt.host.disk.avail), by:{dt.entity.host}, from:-24h, shift:-7d]' },
      options: opts(
        'Desplaza el timeframe 7 días al pasado: mismo periodo de la semana anterior.',
        'Fija en 7 días el tamaño de cada time slot de la segunda serie de la consulta.',
        'Amplía la segunda consulta para incluir todos los datos de los últimos 7 días.',
        'Retrasa 7 días la ejecución programada de la subconsulta incluida en append.',
      ),
      correctOptionIds: ['A'],
      explanationEs: 'shift: desplaza el timeframe (valores negativos, hacia el pasado), lo que permite superponer la serie de la semana anterior. interval: define el tamaño de los slots, from:/to: la ventana, y shift no programa ejecuciones.',
      sourceRefs: [METRIC],
    }),
    q({
      id: 'R-DQL-06', chapterId: 'metric-commands', objectiveId: 'dql:metrics-command-limits', bucket: 'knowledge', difficulty: 'intermediate', cognitiveLevel: 'remember',
      promptEs: 'Quieres explorar qué series de métricas existen en el entorno antes de escribir un timeseries. ¿Qué comando y limitación documentada corresponden?',
      options: opts(
        'timeseries sin agregación, limitado a 1.500 series por consulta y por host.',
        'fetch metrics, limitado a los buckets de métricas con retención por defecto.',
        'metrics, para exploración: últimos 10 días y hasta 100.000 series.',
        'describe metrics, que lista todas las series y sus valores de 30 días.',
      ),
      correctOptionIds: ['C'],
      explanationEs: 'El comando metrics recupera series de métricas, está pensado para consultas exploratorias y se limita a los últimos 10 días y 100.000 series por consulta. 1.500 es el máximo de time slots de timeseries, metrics no se lee con fetch y describe muestra la definición de esquema de un data object.',
      sourceRefs: [METRIC],
    }),
    q({
      id: 'R-DQL-07', chapterId: 'deep-dql-performance', objectiveId: 'dql:reduce-scan', bucket: 'scenario', difficulty: 'advanced', cognitiveLevel: 'apply',
      promptEs: 'Investigas un incidente de los últimos 30 minutos; los logs de auditoría están en el bucket audit_logs y necesitas conteos exactos. ¿Qué dos cambios reducen los datos leídos sin alterar el resultado? (Selecciona 2)',
      stimulus: { kind: 'code', title: 'Consulta actual', content: 'fetch logs, from:-7d\n| filter dt.system.bucket == "audit_logs"\n| filter timestamp >= now() - 30m\n| summarize n = count(), by:{user.id}' },
      options: opts(
        'Usar fetch logs, bucket:{"audit_logs"} en lugar de leer todos los buckets.',
        'Añadir samplingRatio:100 a fetch para leer menos registros.',
        'Cambiar from:-7d por from:-30m en el propio fetch.',
        'Añadir sort timestamp desc justo después de fetch.',
      ),
      correctOptionIds: ['A', 'C'],
      explanationEs: 'La guía recomienda acotar el timeframe en fetch y limitar el procesamiento a buckets concretos con bucket:. samplingRatio reduce datos pero da resultados aproximados, incompatible con conteos exactos, y ordenar tras fetch empeora el rendimiento.',
      sourceRefs: [BEST, DATASRC],
    }),
    q({
      id: 'R-DQL-08', chapterId: 'functions-null', objectiveId: 'dql:coalesce-default', bucket: 'practical', difficulty: 'intermediate', cognitiveLevel: 'apply',
      promptEs: 'Algunos registros no tienen service.name y quieres que aparezcan agrupados como "unknown" en lugar de null. ¿Qué expresión de agrupación usarías?',
      options: opts(
        'by:{svc = toString(service.name)}',
        'by:{svc = coalesce(service.name, "unknown")}',
        'by:{svc = asString(service.name)}',
        'by:{svc = service.name, default:"unknown"}',
      ),
      correctOptionIds: ['B'],
      explanationEs: 'coalesce devuelve el primer argumento no null, así que sustituye el null por "unknown". toString y asString mantienen el null (asString además devuelve null con tipos incompatibles), y default: no es un parámetro de by: (es un parámetro de agregaciones en timeseries/makeTimeseries).',
      sourceRefs: [F_COND],
    }),
    q({
      id: 'R-DQL-09', chapterId: 'deep-dql-aggregation', objectiveId: 'dql:countif-ratio', bucket: 'practical', difficulty: 'intermediate', cognitiveLevel: 'apply',
      promptEs: 'Quieres total de logs y logs ERROR por servicio en una sola agregación para calcular la tasa. ¿Qué completa el hueco ___?',
      stimulus: { kind: 'code', title: 'Consulta', content: 'fetch logs, from:-2h\n| summarize total = count(), errors = ___, by:{service.name}\n| fieldsAdd error_rate = errors * 100.0 / total' },
      options: opts(
        'count(loglevel == "ERROR")',
        'sum(loglevel == "ERROR")',
        'countIf(loglevel == "ERROR")',
        'countDistinct(loglevel == "ERROR")',
      ),
      correctOptionIds: ['C'],
      explanationEs: 'countIf(condition) cuenta los registros que cumplen la condición dentro de cada grupo, sin filtrar antes (lo que eliminaría el total). count() no recibe condición, sum espera números y countDistinct sobre la condición estima cuántos valores booleanos distintos hay.',
      sourceRefs: [F_AGG, AGG],
    }),
    q({
      id: 'R-DQL-10', chapterId: 'pipeline', objectiveId: 'dql:filter-multiple-values', bucket: 'precision', difficulty: 'basic', cognitiveLevel: 'understand',
      promptEs: 'Quieres conservar los logs con loglevel ERROR o FATAL. ¿Qué dos filtros son equivalentes y correctos? (Selecciona 2)',
      options: opts(
        '| filter loglevel == "ERROR" or loglevel == "FATAL"',
        '| filter loglevel == "ERROR" and loglevel == "FATAL"',
        '| filter loglevel ~ "ERROR,FATAL"',
        '| filter in(loglevel, "ERROR", "FATAL")',
      ),
      correctOptionIds: ['A', 'D'],
      explanationEs: 'or conserva los registros que cumplen cualquiera de las dos igualdades, e in(needle, haystack, …) comprueba la pertenencia a la lista de valores. and nunca puede cumplirse con un único valor y ~ buscaría el token literal indicado.',
      sourceRefs: [F_GEN, OPS],
    }),
    q({
      id: 'R-DQL-11', chapterId: 'types', objectiveId: 'dql:backtick-identifiers', bucket: 'precision', difficulty: 'intermediate', cognitiveLevel: 'remember',
      promptEs: 'Un campo ingerido se llama http status (con espacio). ¿Cómo lo referencias en DQL?',
      options: opts(
        'fields ``http status``',
        'fields "http status"',
        'fields [http status]',
        'fields http_status',
      ),
      correctOptionIds: ['A'],
      explanationEs: 'Los nombres de campo con caracteres fuera de a-zA-Z0-9_. deben ir entre backticks. Entre comillas dobles sería un literal string, los corchetes son acceso a record o array y http_status es otro campo.',
      sourceRefs: [REF],
    }),
    q({
      id: 'R-DQL-12', chapterId: 'types', objectiveId: 'dql:expand-limit-empty', bucket: 'precision', difficulty: 'advanced', cognitiveLevel: 'analyze',
      promptEs: '¿Qué dos afirmaciones describen el resultado de esta consulta? (Selecciona 2)',
      stimulus: { kind: 'code', title: 'Consulta', content: 'data record(id = 1, tags = array("a", "b", "c")),\n     record(id = 2, tags = array())\n| expand tags, limit: 2' },
      options: opts(
        'id=1 produce dos registros, con tags "a" y "b".',
        'id=1 produce tres registros: limit se aplica a todas las filas de salida.',
        'id=2 produce un registro con tags null.',
        'id=2 no produce ningún registro.',
      ),
      correctOptionIds: ['A', 'D'],
      explanationEs: 'expand crea un registro por elemento; limit: restringe los registros generados por array tomando los elementos desde el principio. Un array vacío no produce registros, así que id=2 desaparece del resultado.',
      sourceRefs: [STRUCT],
    }),
    q({
      id: 'R-DQL-13', chapterId: 'commands', objectiveId: 'dql:fieldskeep-wildcard', bucket: 'practical', difficulty: 'basic', cognitiveLevel: 'apply',
      promptEs: 'Quieres conservar timestamp y todos los campos que empiezan por k8s., sin enumerarlos. ¿Qué línea lo hace?',
      options: opts(
        '| fieldsRemove timestamp, "k8s.*"',
        '| fieldsFlatten k8s, depth: 2',
        '| fieldsMove k8s, include: {"k8s.*"}',
        '| fieldsKeep timestamp, "k8s.*"',
      ),
      correctOptionIds: ['D'],
      explanationEs: 'fieldsKeep acepta nombres y patrones con comodín (p. ej. "dt.smartscape.*"). fieldsRemove eliminaría justo esos campos, fieldsFlatten saca campos de un record y fieldsMove los mueve a un record anidado.',
      sourceRefs: [SELECT],
    }),
    q({
      id: 'R-DQL-14', chapterId: 'commands', objectiveId: 'dql:sort-case-sensitive', bucket: 'precision', difficulty: 'advanced', cognitiveLevel: 'analyze',
      promptEs: 'Ejecutas | sort server asc sobre la columna mostrada. ¿En qué orden salen las filas?',
      stimulus: { kind: 'table', title: 'Valores de server', columns: ['server'], rows: [['apache'], ['Nginx'], ['envoy']] },
      options: opts(
        'apache, envoy, Nginx',
        'Nginx, envoy, apache',
        'Nginx, apache, envoy',
        'apache, Nginx, envoy',
      ),
      correctOptionIds: ['C'],
      explanationEs: 'sort es ascendente por defecto y distingue mayúsculas: los valores que empiezan por mayúscula se listan antes que los que empiezan por minúscula. Por eso Nginx va primero y después apache y envoy.',
      sourceRefs: [ORDER],
    }),
    q({
      id: 'R-DQL-15', chapterId: 'metric-commands', objectiveId: 'dql:timeseries-default', bucket: 'troubleshooting', difficulty: 'intermediate', cognitiveLevel: 'apply',
      promptEs: 'El gráfico de peticiones muestra huecos en los intervalos sin datos y quieres que esos slots valgan 0. ¿Qué cambio aplicas?',
      stimulus: { kind: 'code', title: 'Consulta actual', content: 'timeseries reqs = sum(http_requests), interval:5m, from:-6h' },
      options: opts(
        'timeseries reqs = sum(http_requests, default:0), interval:5m, from:-6h',
        'timeseries reqs = sum(http_requests), nonempty:true, interval:5m, from:-6h',
        'timeseries reqs = sum(http_requests), union:true, interval:5m, from:-6h',
        'timeseries reqs = sum(http_requests, rollup:sum), interval:5m, from:-6h',
      ),
      correctOptionIds: ['A'],
      explanationEs: 'Los slots vacíos son null salvo que se indique default: en la agregación. nonempty:true devuelve registros aunque ninguna serie cumpla el filtro, union:true combina varias series como outer join y rollup: cambia la agregación temporal.',
      sourceRefs: [METRIC],
    }),
    q({
      id: 'R-DQL-16', chapterId: 'deep-dql-aggregation', objectiveId: 'dql:entityname', bucket: 'practical', difficulty: 'intermediate', cognitiveLevel: 'apply',
      promptEs: 'Un timeseries agrupado por dt.entity.host muestra IDs como HOST-15FE58391F97B7AA. Quieres ver también el nombre del host en la tabla. ¿Qué añades?',
      options: opts(
        '| fieldsRename host = dt.entity.host',
        '| fieldsAdd host = toString(dt.entity.host)',
        '| fieldsAdd host = entityName(dt.entity.host)',
        '| dedup dt.entity.host',
      ),
      correctOptionIds: ['C'],
      explanationEs: 'entityName(expression) devuelve el nombre de la entidad a partir de su ID (p. ej. timeseries … by:{dt.entity.host} | fieldsAdd entityName(dt.entity.host)). Renombrar o convertir a string conserva el ID y dedup solo elimina duplicados. La documentación sugiere getNodeName como alternativa a entityName.',
      sourceRefs: [F_GEN],
    }),
    q({
      id: 'R-DQL-17', chapterId: 'deep-dql-command-contract', objectiveId: 'dql:join-on-different-names', bucket: 'precision', difficulty: 'advanced', cognitiveLevel: 'apply',
      promptEs: 'En la tabla de origen el host está en dt.entity.host y en la subconsulta en id. ¿Qué condición de join es correcta?',
      stimulus: { kind: 'code', title: 'Consulta', content: 'fetch logs, from:-1h\n| join [fetch dt.entity.host | fields id, entity.name], ___' },
      options: opts(
        'on:{dt.entity.host == id}',
        'on:{right[dt.entity.host] == left[id]}',
        'on:{dt.entity.host, id}',
        'on:{left[dt.entity.host] == right[id]}',
      ),
      correctOptionIds: ['D'],
      explanationEs: 'Con nombres distintos se usa on:{left[campo] == right[campo]}; left es la tabla de origen y right la subconsulta. on:{a, b} indica dos campos con el mismo nombre en ambos lados, y sin left[]/right[] no se distingue el lado. Los campos añadidos llevan por defecto el prefijo right.',
      sourceRefs: [JOIN],
    }),
    q({
      id: 'R-DQL-18', chapterId: 'dql-troubleshooting', objectiveId: 'dql:default-result-limit', bucket: 'troubleshooting', difficulty: 'intermediate', cognitiveLevel: 'analyze',
      promptEs: 'Un compañero ejecuta fetch logs, from:-24h | filter loglevel == "ERROR" sin limit, ve exactamente 1.000 filas y concluye que hubo 1.000 errores. ¿Qué le indicas?',
      options: opts(
        'Que sin limit se muestran 1.000 registros; el total se obtiene con summarize count().',
        'Que Grail retiene un máximo de 1.000 logs ERROR por día en cada bucket de logs.',
        'Que filter devuelve una muestra de 1.000 registros cuando hay más coincidencias.',
        'Que debe añadir samplingRatio:1 a fetch para que la consulta devuelva el resto de registros.',
      ),
      correctOptionIds: ['A'],
      explanationEs: 'Si no se especifica limit, la consulta muestra 1.000 resultados. Contar filas visibles no da el total: hay que agregar con summarize count(). Grail no tiene ese tope de retención, filter no muestrea y samplingRatio:1 ya es el valor por defecto (sin muestreo).',
      sourceRefs: [ORDER],
    }),
    q({
      id: 'R-DQL-19', chapterId: 'deep-dql-aggregation', objectiveId: 'dql:timeseries-peak', bucket: 'practical', difficulty: 'advanced', cognitiveLevel: 'apply',
      promptEs: 'Para una tabla quieres el pico de CPU de cada host en el timeframe, no la serie completa. ¿Qué dos opciones lo consiguen? (Selecciona 2)',
      stimulus: { kind: 'code', title: 'Consulta base', content: 'timeseries cpu = max(dt.host.cpu.usage), by:{dt.entity.host}, interval:5m, from:-24h' },
      options: opts(
        'Añadir | fieldsAdd peak = arraySize(cpu)',
        'Añadir | fieldsAdd peak = arrayMax(cpu)',
        'Cambiar la agregación a max(dt.host.cpu.usage, scalar:true)',
        'Añadir | fieldsAdd peak = cpu[0]',
      ),
      correctOptionIds: ['B', 'C'],
      explanationEs: 'timeseries devuelve un array de valores por time slot. arrayMax obtiene el máximo de ese array y scalar:true calcula un único valor para todo el timeframe. arraySize cuenta los slots y cpu[0] es solo el primer slot.',
      sourceRefs: [METRIC, F_ARRAY],
    }),
    q({
      id: 'R-DQL-20', chapterId: 'aggregation', objectiveId: 'dql:percentile-latency', bucket: 'scenario', difficulty: 'intermediate', cognitiveLevel: 'apply',
      promptEs: 'La media de duration de los spans de un servicio parece normal, pero los usuarios se quejan de peticiones lentas ocasionales. ¿Qué agregación muestra mejor esa cola de latencia?',
      options: opts(
        'summarize p95 = percentile(duration, 95), by:{service.name}',
        'summarize p95 = avg(duration) * 0.95, by:{service.name}',
        'summarize p95 = median(duration), by:{service.name}',
        'summarize p95 = takeLast(duration), by:{service.name}',
      ),
      correctOptionIds: ['A'],
      explanationEs: 'percentile(expression, percentile) devuelve el valor bajo el que queda ese porcentaje de spans, y revela la cola que la media oculta. Multiplicar la media no es un percentil, median es el percentil 50 y takeLast devuelve un único valor.',
      sourceRefs: [F_AGG],
    }),
    q({
      id: 'R-DQL-21', chapterId: 'deep-dql-dpl', objectiveId: 'dql:dql-vs-dpl', bucket: 'knowledge', difficulty: 'basic', cognitiveLevel: 'understand',
      promptEs: 'En la consulta mostrada, ¿qué parte está escrita en Dynatrace Pattern Language (DPL)?',
      stimulus: { kind: 'code', title: 'Consulta', content: 'fetch logs, from:-1h\n| parse content, "IPADDR:ip LD HTTPDATE:time"\n| summarize hits = count(), by:{ip}' },
      options: opts(
        'El comando parse completo, incluido el nombre del campo content.',
        'Solo el string "IPADDR:ip LD HTTPDATE:time" que describe el patrón.',
        'La agregación summarize hits = count(), by:{ip}.',
        'El parámetro from:-1h del comando fetch.',
      ),
      correctOptionIds: ['B'],
      explanationEs: 'DQL orquesta la consulta (fetch, parse, summarize); el patrón que recibe parse es DPL, con matchers como IPADDR, LD o HTTPDATE y los nombres de los campos que se exportan.',
      sourceRefs: [EXTRACT, DPL],
    }),
    q({
      id: 'R-DQL-22', chapterId: 'parse-fields', objectiveId: 'dql:data-command-testing', bucket: 'scenario', difficulty: 'basic', cognitiveLevel: 'apply',
      promptEs: 'Quieres probar un patrón de parse con dos líneas de ejemplo en un Notebook sin leer datos de Grail. ¿Con qué comando empiezas?',
      options: opts(
        'load con las líneas de ejemplo como lookup.',
        'describe logs, que devuelve registros de muestra del esquema.',
        'data record(content = "…"), record(content = "…")',
        'fetch logs | limit 2 con las líneas pegadas en filter.',
      ),
      correctOptionIds: ['C'],
      explanationEs: 'data genera datos de ejemplo en tiempo de consulta (data record(a = "DQL", b = 1), record()). load carga archivos tabulares de lookup, describe muestra la definición de esquema y fetch lee datos reales de Grail.',
      sourceRefs: [DATASRC],
    }),
    q({
      id: 'R-DQL-23', chapterId: 'deep-dql-command-contract', objectiveId: 'dql:traverse-direction', bucket: 'practical', difficulty: 'advanced', cognitiveLevel: 'apply',
      promptEs: 'Las aristas runs_on van de PROCESS a HOST. Partiendo de nodos HOST, quieres obtener los procesos que se ejecutan en ellos. ¿Qué consulta es correcta?',
      options: opts(
        'smartscapeNodes HOST | traverse runs_on, PROCESS, direction: backward',
        'smartscapeNodes HOST | traverse runs_on, PROCESS',
        'smartscapeNodes HOST | traverse PROCESS, runs_on, direction: backward',
        'smartscapeEdges HOST | traverse runs_on, PROCESS, direction: forward',
      ),
      correctOptionIds: ['A'],
      explanationEs: 'traverse recibe primero el tipo de arista y después el tipo de nodo destino; direction es forward por defecto. Para recorrer runs_on en sentido contrario (de HOST a PROCESS) hay que indicar direction: backward, y smartscapeEdges carga aristas, no nodos HOST.',
      sourceRefs: [SMART],
    }),
    q({
      id: 'R-DQL-24', chapterId: 'functions-null', objectiveId: 'dql:time-functions', bucket: 'practical', difficulty: 'intermediate', cognitiveLevel: 'apply',
      promptEs: 'Quieres saber a qué hora del día (0-23) se concentran los errores de los últimos 7 días, sumando todos los días en 24 grupos. ¿Qué agrupación usas?',
      options: opts(
        'by:{bin(timestamp, 1h)}',
        'by:{getDayOfWeek(timestamp)}',
        'by:{getHour(timestamp)}',
        'by:{timeframe(timestamp)}',
      ),
      correctOptionIds: ['C'],
      explanationEs: 'getHour(timestamp) extrae la hora y agrupa todos los días en 24 grupos. bin(timestamp, 1h) crea un grupo por cada hora real (168 en 7 días), getDayOfWeek agrupa por día y timeframe() crea un rango a partir de dos timestamps.',
      sourceRefs: [F_TIME],
    }),
    q({
      id: 'R-DQL-25', chapterId: 'deep-dql-command-contract', objectiveId: 'dql:smartscape-type-quoting', bucket: 'precision', difficulty: 'advanced', cognitiveLevel: 'remember',
      promptEs: '¿Qué dos líneas son inicios válidos de una consulta Smartscape? (Selecciona 2)',
      options: opts(
        'smartscapeNodes HOST',
        'smartscapeNodes *EC2*',
        'traverse runs_on, HOST',
        'smartscapeNodes "*EC2*"',
      ),
      correctOptionIds: ['A', 'D'],
      explanationEs: 'smartscapeNodes recibe un tipo concreto sin comillas (HOST) o un patrón entre comillas dobles ("*EC2*"). Un patrón sin comillas no es válido y traverse necesita nodos de entrada, así que no puede iniciar la consulta.',
      sourceRefs: [SMART],
    }),
    q({
      id: 'R-DQL-26', chapterId: 'deep-dql-performance', objectiveId: 'dql:best-practice-review', bucket: 'scenario', difficulty: 'advanced', cognitiveLevel: 'analyze',
      promptEs: 'Revisas esta consulta lenta. ¿Qué dos cambios recomienda la guía de buenas prácticas? (Selecciona 2)',
      stimulus: { kind: 'code', title: 'Consulta lenta', content: 'fetch logs, from:-24h\n| sort timestamp desc\n| filter matchesValue(lower(k8s.namespace.name), "astro*")\n| summarize n = count(), by:{k8s.pod.name}' },
      options: opts(
        'Añadir limit 100 tras fetch para reducir el volumen.',
        'Filtrar directamente: filter k8s.namespace.name ~ "astro*".',
        'Filtrar con lookup contra la lista de todos los namespaces astro.',
        'Mover sort al final, tras summarize (sort n desc).',
      ),
      correctOptionIds: ['B', 'D'],
      explanationEs: 'La guía pide filtrar directamente sobre el campo (filter k8s.namespace.name ~ "astro*") en lugar de transformarlo, y dejar sort al final: ordenar tras fetch reduce el rendimiento. limit antes de agregar falsea el conteo y se deben evitar joins/lookups innecesarios para filtrar.',
      sourceRefs: [BEST],
    }),
    q({
      id: 'R-DQL-27', chapterId: 'sup-dql-sources', objectiveId: 'dql:data-objects', bucket: 'knowledge', difficulty: 'basic', cognitiveLevel: 'remember',
      promptEs: 'Necesitas analizar en DQL los business events y los spans de trazas distribuidas almacenados en Grail. ¿Qué dos inicios de consulta son válidos? (Selecciona 2)',
      options: opts(
        'fetch bizevents, from:-2h',
        'fetch traces, from:-2h',
        'fetch spans, from:-2h',
        'fetch business.events, from:-2h',
      ),
      correctOptionIds: ['A', 'C'],
      explanationEs: 'bizevents y spans son data objects de Grail que se cargan con fetch (la guía de buenas prácticas usa fetch bizevents, from:-10m y fetch spans, samplingRatio:100). traces y business.events no son data objects: las trazas se consultan a través de sus spans.',
      sourceRefs: [DATASRC, BEST],
    }),
    q({
      id: 'R-DQL-28', chapterId: 'sup-dql-sources', objectiveId: 'dql:grail-permissions', bucket: 'troubleshooting', difficulty: 'intermediate', cognitiveLevel: 'apply',
      promptEs: 'Un usuario no puede consultar logs con fetch logs en un Notebook porque le faltan permisos. Según el modelo de permisos de Grail, ¿qué dos permisos necesita para consultar los logs? (Selecciona 2)',
      options: opts(
        'storage:logs:read',
        'storage:metrics:read',
        'storage:buckets:read',
        'settings:objects:read',
      ),
      correctOptionIds: ['A', 'C'],
      explanationEs: 'Grail exige dos niveles: el permiso de bucket storage:buckets:read y el permiso de tabla del data object, aquí storage:logs:read. storage:metrics:read es el permiso de tabla de las métricas y settings:objects:read da acceso a objetos de configuración de Settings, no a datos de Grail.',
      sourceRefs: [GRAIL_PERMS],
    }),
    q({
      id: 'R-DQL-29', chapterId: 'sup-dql-timeseries', objectiveId: 'dql:timeseries-filter', bucket: 'practical', difficulty: 'intermediate', cognitiveLevel: 'apply',
      promptEs: 'Quieres la serie de peticiones HTTP con código 503, y code es una dimensión de la métrica http_requests. ¿Qué consulta aplica la condición a los datos de origen antes de agregar?',
      options: opts(
        'timeseries http_503 = sum(http_requests), filter:{code == 503}',
        'timeseries http_503 = sum(http_requests), by:{code == 503}',
        'timeseries http_503 = sum(http_requests), nonempty:{code == 503}',
        'timeseries http_503 = sum(http_requests) | filter code == 503',
      ),
      correctOptionIds: ['A'],
      explanationEs: 'El parámetro filter: de timeseries aplica la condición sobre los registros de origen antes de la agregación (la referencia usa timeseries http_503=sum(http_requests), filter:{code==503}). by: indica dimensiones de agrupación, nonempty: es un booleano que devuelve registros aunque no haya datos, y un filter posterior actúa sobre las series ya agregadas, que sin by:{code} no contienen el campo code.',
      sourceRefs: [METRIC],
    }),
    q({
      id: 'R-DQL-30', chapterId: 'sup-dql-join', objectiveId: 'dql:lookup-fields', bucket: 'precision', difficulty: 'advanced', cognitiveLevel: 'apply',
      promptEs: 'Los logs guardan el ID del clúster en dt.entity.kubernetes_cluster y la subconsulta lo tiene en id. ¿Qué completa el hueco?',
      stimulus: { kind: 'code', title: 'Consulta', content: 'fetch logs, from:-1h\n| lookup [fetch dt.entity.kubernetes_cluster], ___,\n    fields:{cluster.name = entity.name}' },
      options: opts(
        'sourceField: id, lookupField: dt.entity.kubernetes_cluster',
        'on:{dt.entity.kubernetes_cluster == id}',
        'sourceField: dt.entity.kubernetes_cluster, lookupField: id',
        'kind:leftOuter, on:{left[dt.entity.kubernetes_cluster] == right[id]}',
      ),
      correctOptionIds: ['C'],
      explanationEs: 'lookup empareja mediante sourceField (campo de la tabla de origen) y lookupField (campo de la subconsulta). Invertirlos busca el ID del clúster en el campo equivocado de cada lado; on: y kind: son parámetros de join, no de lookup.',
      sourceRefs: [JOIN],
    }),
    q({
      id: 'R-DQL-31', chapterId: 'sup-dql-aggregation-functions', objectiveId: 'dql:summarize-empty-input', bucket: 'precision', difficulty: 'advanced', cognitiveLevel: 'analyze',
      promptEs: 'Un filter no deja pasar ningún registro y después se ejecuta | summarize n = count(), total = sum(bytes), sin by:. ¿Qué devuelve summarize?',
      options: opts(
        'Un único registro con n = 0 y total = 0.',
        'Ningún registro, porque no hay entrada que agrupar.',
        'Un único registro con n = null y total = null.',
        'Un único registro con n = 0 y total = null.',
      ),
      correctOptionIds: ['D'],
      explanationEs: 'Sin by:, summarize devuelve un único registro aunque no reciba entrada: count() vale 0 porque cuenta cero registros, y sum() vale null porque no hay valores que sumar. Con by:, en cambio, no habría grupos que devolver.',
      sourceRefs: [AGG],
    }),
    q({
      id: 'R-DQL-32', chapterId: 'sup-dql-filtering', objectiveId: 'dql:if-null', bucket: 'precision', difficulty: 'advanced', cognitiveLevel: 'analyze',
      promptEs: 'Calculas | fieldsAdd tier = if(duration > 1s, "slow", else:"fast"). ¿Qué valor de tier obtiene un registro que no tiene el campo duration?',
      options: opts(
        '"slow", porque el campo ausente no se compara.',
        '"fast", porque la condición evalúa a null.',
        'null, porque la condición evalúa a null.',
        'Ninguno: fieldsAdd elimina el registro.',
      ),
      correctOptionIds: ['B'],
      explanationEs: 'Sin duration, la comparación duration > 1s devuelve null, e if devuelve el valor de else cuando la condición es false o null. if devuelve then solo si la condición es true, no devuelve null cuando hay else y fieldsAdd no elimina registros.',
      sourceRefs: [F_COND, OPS],
    }),
    q({
      id: 'R-DQL-33', chapterId: 'sup-dql-filtering', objectiveId: 'dql:isnull-missing', bucket: 'practical', difficulty: 'intermediate', cognitiveLevel: 'apply',
      promptEs: 'Quieres listar los logs que no tienen el campo service.name para corregir su ingesta. ¿Qué filtro los devuelve?',
      options: opts(
        '| filter service.name == null',
        '| filter isNull(service.name)',
        '| filter not (service.name != null)',
        '| filterOut isNull(service.name)',
      ),
      correctOptionIds: ['B'],
      explanationEs: 'isNull devuelve true para valores null y campos ausentes, así que filter conserva esos registros. Las comparaciones con null (== null, != null) devuelven null y not null sigue siendo null, por lo que filter los descarta; filterOut isNull(…) haría lo contrario y quitaría justo esos registros.',
      sourceRefs: [F_BOOL, OPS],
    }),
    q({
      id: 'R-DQL-34', chapterId: 'sup-dql-timeseries', objectiveId: 'dql:timeseries-output', bucket: 'precision', difficulty: 'intermediate', cognitiveLevel: 'understand',
      promptEs: '¿Qué dos afirmaciones describen la salida de esta consulta? (Selecciona 2)',
      stimulus: { kind: 'code', title: 'Consulta', content: 'timeseries cpu = avg(dt.host.cpu.usage), by:{dt.entity.host}, interval:1h, from:-24h' },
      options: opts(
        'Cada host es un registro y cpu es un array con un valor por time slot.',
        'Cada time slot de cada host es un registro con un valor escalar en cpu.',
        'Todas las series comparten inicio, fin, intervalo y número de elementos.',
        'Cada host recibe un intervalo propio según la densidad de sus datos.',
      ),
      correctOptionIds: ['A', 'C'],
      explanationEs: 'timeseries produce series homogéneas: un registro por serie (aquí, por host) con la agregación como array de un valor por time slot, más los campos timeframe e interval, y todas las series tienen el mismo inicio, fin, intervalo y número de elementos. No genera un registro por slot ni intervalos distintos por serie.',
      sourceRefs: [METRIC],
    }),
    q({
      id: 'R-DQL-35', chapterId: 'sup-dql-filtering', objectiveId: 'dql:contains-case', bucket: 'troubleshooting', difficulty: 'intermediate', cognitiveLevel: 'analyze',
      promptEs: '| filter contains(content, "timeout") no devuelve logs cuyo content incluye "Timeout". ¿Cuál es la causa?',
      options: opts(
        'contains busca tokens completos y "Timeout" forma parte de otra palabra.',
        'contains distingue mayúsculas por defecto; con caseSensitive:false coincidiría.',
        'contains requiere el operador ~ para comparar texto dentro de filter.',
        'contains exige que content sea igual al substring indicado.',
      ),
      correctOptionIds: ['B'],
      explanationEs: 'contains(expression, substring, caseSensitive) busca un substring y su parámetro caseSensitive vale true por defecto, así que "Timeout" no coincide con "timeout". El matching por tokens es propio de ~ y de search, contains se usa directamente como condición de filter y no exige igualdad del valor completo.',
      sourceRefs: [F_STRING],
    }),
  ],
}

// Reparto de la clave: se intercambian opciones para que la correcta no se concentre en A.
const moveKey: [string, string][] = [
  ['A-019', 'C'], ['A-020', 'B'], ['A-021', 'D'], ['A-025', 'D'], ['A-026', 'C'],
  ['C-024', 'C'], ['D-022', 'D'], ['E-033', 'B'], ['G-101', 'C'], ['G-102', 'D'],
]
for (const [id, to] of moveKey) {
  const patch = dqlRevision.replace[id]
  if (!patch.options) continue
  const from = patch.correctOptionIds?.[0] ?? 'A'
  const options = patch.options.map((o) => ({ ...o }))
  const i = options.findIndex((o) => o.id === from)
  const j = options.findIndex((o) => o.id === to)
  const tmp = options[i].text
  options[i].text = options[j].text
  options[j].text = tmp
  patch.options = options
  patch.correctOptionIds = [to]
}

// Dificultad honesta: preguntas de reconocimiento directo de comandos no son 'advanced'.
const difficulty: [string, 'basic' | 'intermediate'][] = [
  ['B-045', 'intermediate'], ['B-046', 'intermediate'],
  ['D-023', 'intermediate'], ['E-032', 'intermediate'], ['FQ-012', 'intermediate'],
  ['FQ-013', 'intermediate'], ['FQ-014', 'intermediate'], ['G-103', 'basic'], ['G-114', 'intermediate'],
]
for (const [id, level] of difficulty) {
  const patch = dqlRevision.replace[id]
  if (patch) patch.difficulty = level
  else dqlRevision.replace[id] = { difficulty: level, reason: 'Dificultad ajustada: reconocimiento directo de un comando.' }
}
