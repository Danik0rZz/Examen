import type { Question } from '../types'

/** Campos de una pregunta que una revisión puede reescribir. */
export type QuestionPatch = Partial<Pick<Question,
  'promptEs' | 'stimulus' | 'options' | 'correctOptionIds' | 'explanationEs' | 'sourceRefs' |
  'bucket' | 'difficulty' | 'cognitiveLevel' | 'classicOrLatest' | 'versionNote'>> & {
  /** Motivo de la revisión (auditoría de octubre de 2026). */
  reason: string
}

/** Pregunta nueva añadida en la revisión. `form`, `type` y `lastVerified` se calculan al aplicar. */
export type NewQuestion = Omit<Question, 'form' | 'type' | 'lastVerified'>

/**
 * Revisión editorial de un módulo, aplicada sobre el banco original.
 * - replace: reescribe campos de preguntas existentes (clave, opciones, explicación…).
 * - remove: retira duplicados o preguntas sin valor, con el motivo.
 * - add: preguntas nuevas (ids `R-<módulo>-NN`).
 */
export type ModuleRevision = {
  moduleId: string
  replace: Record<string, QuestionPatch>
  remove: Record<string, string>
  add: NewQuestion[]
}
