import type { Draft, SourceKey } from './bank-core'
import { finalQuestion } from './bank-final-core'
import type { QuestionBucket } from './types'

const g = (n: number, source: SourceKey, objective: string, bucket: QuestionBucket,
  prompt: string, choices: [string, string, string, string], correct: number | number[], explanation: string): Draft =>
  finalQuestion('G', n, source, objective, bucket, prompt, choices, correct, explanation)

export const bankExpansion: Draft[] = [
  // =========================================================================
  // DOMINIO 1: PLATFORM (G-001 a G-020)
  // =========================================================================
  g(1, 'hub', 'permissions', 'precision',
    '¿Qué permiso IAM específico es obligatorio para que un usuario pueda instalar una nueva aplicación desde Dynatrace Hub en el entorno?',
    [
      'app-engine:apps:run',
      'app-engine:apps:install',
      'storage:bucket-definitions:write',
      'iam:service-users:use',
    ], 1,
    'Para instalar aplicaciones desde Dynatrace Hub se requiere el permiso IAM explícito `app-engine:apps:install`. Para eliminarlas se requiere `app-engine:apps:delete`.'),

  g(2, 'hub', 'permissions-delete', 'precision',
    '¿Qué permiso IAM se requiere para desinstalar o retirar una aplicación previamente desplegada desde Dynatrace Hub?',
    [
      'app-engine:apps:delete',
      'app-engine:apps:write',
      'automation:workflows:delete',
      'settings:objects:delete',
    ], 0,
    'El permiso IAM para retirar o desinstalar aplicaciones desplegadas en el entorno desde Dynatrace Hub es `app-engine:apps:delete`.'),

  g(3, 'hub', 'tabs', 'knowledge',
    'En la ficha de un ítem en Dynatrace Hub, ¿qué pestaña permite consultar los dashboards preconfigurados, notebooks y workflows empaquetados que incluye la solución?',
    [
      'Overview',
      'Contents',
      'Technical information',
      'Release notes',
    ], 1,
    'La pestaña `Contents` muestra los artefactos listos para usar incluidos en la solución (cuadros de mando, cuadernos de investigación y flujos de trabajo).'),

  g(4, 'hub', 'technical-tab', 'knowledge',
    '¿Qué información crítica de administración se encuentra en la pestaña `Technical information` de una aplicación en Dynatrace Hub?',
    [
      'El número de teléfono del equipo de soporte de Dynatrace.',
      'Los permisos IAM requeridos por la app (`app-engine:*`, `storage:*`) y los requisitos de configuración de red y agentes.',
      'La factura mensual desglosada en dólares de la suscripción.',
      'El código fuente completo de la plataforma Dynatrace.',
    ], 1,
    'La pestaña `Technical information` detalla los permisos IAM que la aplicación necesita para operar, así como los requisitos de versión y endpoints.'),

  g(5, 'problems', 'grail-record', 'precision',
    'En los registros de Problems almacenados en Grail, ¿qué campo contiene el array con los identificadores de todos los Davis events correlacionados en el incidente?',
    [
      'event.list',
      'dt.davis.event_ids',
      'problem.events_correlated',
      'davis.anomaly_array',
    ], 1,
    'En Grail, el campo `dt.davis.event_ids` almacena el array de identificadores de los Davis events individuales que componen el Problem.'),

  g(6, 'problems', 'custom-fields', 'precision',
    'Al enriquecer un Problem con campos personalizados (Problem custom fields), ¿qué restricción estricta de tipo de dato aplica la plataforma?',
    [
      'Solo se admiten valores numéricos de tipo float.',
      'Solo se admiten valores de tipo string (cadenas de texto).',
      'Se admiten arrays anidados y objetos JSON binarios.',
      'Solo se admiten valores booleanos (true/false).',
    ], 1,
    'Los campos personalizados de un Problem en Dynatrace solo admiten cadenas de texto (`string values`). No se admiten estructuras anidadas ni objetos complejos.'),

  g(7, 'platform', 'system-buckets', 'precision',
    '¿Qué tabla del sistema en Grail permite consultar el inventario de todos los buckets configurados en el tenant, su record type y sus políticas de retención?',
    [
      'dt.system.buckets',
      'dt.storage.retention',
      'grail.system.tables',
      'settings.storage.buckets',
    ], 0,
    'La tabla de sistema `dt.system.buckets` permite consultar mediante DQL la definición, record type y retención de todos los buckets de almacenamiento.'),

  g(8, 'sharing', 'allow-editors', 'scenario',
    'El propietario de un Dashboard desea que otros miembros del equipo puedan añadir colaboradores al cuadro de mando sin tener que transferirles la propiedad. ¿Qué control debe activar en el menú Share?',
    [
      'Marcar la casilla "Allow editors to share".',
      'Asignar el rol de administrador global de tenant a todos los miembros.',
      'Hacer el dashboard público en internet.',
      'Cambiar el nombre del dashboard para que empiece por `admin_`.',
    ], 0,
    'La casilla `Allow editors to share` autoriza a los usuarios con permisos de edición (`Can edit`) a gestionar la compartición del documento con terceros.'),

  g(9, 'sharing', 'environment-visibility', 'precision',
    '¿Qué garantiza la opción de compartición "Visible to anyone in your environment" en un documento de Dynatrace?',
    [
      'Que el documento es accesible públicamente sin autenticación por cualquier persona en internet.',
      'Que cualquier usuario autenticado con acceso al tenant de Dynatrace puede ver el documento, sin exponerlo al exterior.',
      'Que todos los usuarios del entorno reciben permisos de edición y borrado del documento.',
      'Que el documento se envía por correo electrónico a todos los empleados de la empresa.',
    ], 1,
    '`Visible to anyone in your environment` concede acceso de lectura a todos los usuarios autenticados dentro del mismo tenant corporativo, manteniendo la privacidad externa.'),

  g(10, 'platformsearch', 'navigation', 'knowledge',
    '¿Cuál es la función principal de Platform Search (Ctrl+K / Cmd+K) en la interfaz moderna de Dynatrace?',
    [
      'Buscar virus y malware en los discos duros locales.',
      'Localizar rápidamente aplicaciones, entidades monitorizadas (hosts, servicios), dashboards y documentación sin depender de la ruta del menú.',
      'Ejecutar consultas SQL directas contra bases de datos de clientes.',
      'Comprar licencias de software en tiendas de terceros.',
    ], 1,
    'Platform Search es el buscador global unificado para localizar al instante entidades por nombre/ID, aplicaciones, notebooks y documentación oficial.'),

  g(11, 'platform', 'table-vs-bucket', 'precision',
    'En el modelo de datos de Grail, ¿cuál es la diferencia fundamental entre una Table y un Bucket?',
    [
      'Table es para logs y Bucket es para métricas exclusivamente.',
      'Table es una agrupación lógica por tipo de registro (ej. `logs`, `bizevents`); Bucket es la unidad física de almacenamiento que gestiona retención, particionado y control de acceso.',
      'Bucket es un widget visual en un dashboard y Table es una base de datos relacional MySQL.',
      'No existe diferencia: son sinónimos intercambiables en la documentación.',
    ], 1,
    'Una Table representa el tipo de registro lógico; un Bucket es el contenedor de almacenamiento que rige la retención, permisos de acceso y particionamiento.'),

  g(12, 'platform', 'views-concept', 'knowledge',
    '¿Qué representa una View en el modelo de datos de Grail?',
    [
      'Una perspectiva virtual predefinida basada en una consulta DQL sobre una o más tablas que no duplica el almacenamiento subyacente.',
      'Una captura de pantalla estática guardada en formato JPEG.',
      'Una copia de seguridad física de todos los datos en cinta magnética.',
      'Un permiso especial que solo pueden utilizar los empleados de Dynatrace.',
    ], 0,
    'Una View en Grail proporciona una capa de abstracción virtual sobre tablas existentes sin replicar los datos físicos ni alterar su ingestión.'),

  g(13, 'permissions', 'iam-layers', 'precision',
    'Un usuario puede abrir y visualizar el contenido de un Dashboard, pero las gráficas DQL del interior muestran un error de autorización 403. ¿Por qué ocurre esto?',
    [
      'Porque el navegador web del usuario necesita actualizar su versión.',
      'Porque los permisos del documento (`Can view`) y los permisos de acceso a datos en Grail (`storage:*:read`) son independientes; el usuario tiene permiso para ver el cuadro pero no para consultar la tabla subyacente.',
      'Porque los dashboards solo pueden mostrar datos durante el horario de oficina.',
      'Porque el usuario no ha encendido la cámara web.',
    ], 1,
    'Separación de capas de autorización: tener permiso para ver el documento del Dashboard no exime de necesitar permisos IAM de lectura sobre los datos de Grail consultados por los tiles.'),

  g(14, 'platform', 'data-retention-tenant', 'troubleshooting',
    'Un administrador detecta que los logs de un servicio crítico desaparecen a los 35 días a pesar de que el equipo necesita analizarlos durante 90 días. ¿Qué componente debe ajustarse?',
    [
      'El selector de timeframe en el menú superior del navegador.',
      'La política de retención del bucket de Grail donde se enrutan esos logs (o crear un bucket custom con 90 días de retención).',
      'La resolución de pantalla del monitor del administrador.',
      'El modo de monitorización de OneAgent de Full-Stack a Discovery.',
    ], 1,
    'La retención de datos es una propiedad de storage configurada a nivel de bucket en Grail; para ampliar el historial de 35 a 90 días se debe modificar la retención del bucket.'),

  g(15, 'hub', 'solution-install-flow', 'scenario',
    'Un ingeniero desea monitorizar colas de mensajes de Apache Kafka desplegando la extensión oficial desde Hub. ¿Cuál es el orden metódico de pasos a seguir?',
    [
      'Localizar la extensión en Hub → Verificar requisitos y permisos en Technical info → Instalar extensión (`app-engine:apps:install`) → Configurar ActiveGate/credenciales → Validar ingestión de métricas en Grail.',
      'Abrir un ticket de soporte y esperar 3 meses a que Dynatrace configure el entorno.',
      'Crear un dashboard vacío antes de instalar cualquier agente o extensión.',
      'Desinstalar OneAgent de todos los servidores de la empresa.',
    ], 0,
    'El ciclo metódico oficial exige revisar requisitos técnicos, instalar con los permisos adecuados, configurar credenciales/endpoints y validar que la telemetría llega a Grail.'),

  g(16, 'problems', 'severity-vs-cause', 'precision',
    'En la gestión de incidentes con Dynatrace, ¿por qué es incorrecto asumir que la entidad con mayor severidad es siempre la causa raíz del problema?',
    [
      'Porque Dynatrace asigna severidades al azar mediante un generador aleatorio.',
      'Porque la severidad mide el impacto en el negocio (ej. un frontend caído es crítico), mientras que la causa raíz puede ser un fallo de infraestructura menor en un backend que desencadenó el impacto.',
      'Porque los incidentes nunca tienen causa raíz en entornos cloud.',
      'Porque solo las bases de datos pueden ser la causa raíz de un problema.',
    ], 1,
    'Severidad y causa raíz son dimensiones distintas: una caída de frontend tiene severidad máxima por impacto al usuario, pero la causa raíz puede ser un bloqueo de base de datos o saturación de disco.'),

  g(17, 'sharing', 'transfer-ownership', 'precision',
    '¿Qué sucede de forma inmediata cuando el propietario de un Notebook transfiere la propiedad (ownership) del documento a otro usuario?',
    [
      'Se crea una copia duplicada del notebook para cada empleado de la empresa.',
      'El usuario seleccionado se convierte en el nuevo owner y el propietario original conserva únicamente el nivel de acceso que el nuevo owner le asigne (pudiendo perder acceso si no se le incluye).',
      'El notebook se bloquea permanentemente y no puede volver a editarse.',
      'Se borran todos los datos recopilados en Grail durante la última semana.',
    ], 1,
    'Transferir ownership es una cesión completa de la propiedad; el propietario anterior deja de tener privilegios de gestión sobre el documento salvo que se le mantenga como editor o viewer.'),

  g(18, 'platform', 'appengine-nature', 'knowledge',
    '¿Qué es Dynatrace AppEngine dentro de la arquitectura Latest de la plataforma?',
    [
      'Un servidor de correo electrónico corporativo.',
      'El framework de desarrollo y ejecución de aplicaciones serverless que permite ejecutar apps personalizadas e integraciones nativas sobre Grail con acceso seguro por APIs.',
      'Un videojuego integrado para administradores de sistemas.',
      'Un protocolo de cableado de fibra óptica para centros de datos.',
    ], 1,
    'AppEngine es el runtime de aplicaciones de Dynatrace que aloja tanto las apps oficiales de la plataforma como aplicaciones a medida desarrolladas con el AppEngine SDK.'),

  g(19, 'permissions', 'least-privilege', 'scenario',
    'Se requiere dar acceso a un equipo de desarrollo externo para que investigue problemas de rendimiento de una aplicación sin que puedan alterar la configuración del entorno. ¿Qué política de permisos responde al principio de mínimo privilegio?',
    [
      'Conceder el rol de Administrador global del tenant.',
      'Asignar permisos de visualización (`Can view`) en los dashboards pertinentes y permisos de lectura sobre las tablas de telemetría acotadas a su Management Zone.',
      'Entregar la contraseña del administrador del tenant en una nota manuscrita.',
      'Desactivar todos los cortafuegos del entorno.',
    ], 1,
    'Mínimo privilegio: limitar el acceso a lectura de las tablas estrictamente necesarias y acotar el alcance a su Management Zone mediante políticas de IAM.'),

  g(20, 'platform', 'summary-platform', 'knowledge',
    'En conclusión, ¿por qué la plataforma Dynatrace Latest se describe como una plataforma orientada a datos y aplicaciones?',
    [
      'Porque elimina la necesidad de hardware informático en el mundo.',
      'Porque desacopla el almacenamiento masivo unificado (Grail) de las experiencias de consumo (Apps modulares en Launcher), permitiendo analizar cualquier señal con un modelo de contexto compartido.',
      'Porque solo permite utilizar una pantalla de visualización simultánea.',
      'Porque exige reiniciar los servidores cada 60 minutos.',
    ], 1,
    'Dynatrace Latest unifica toda la telemetría en Grail y proporciona aplicaciones modulares que consultan ese lago común sin silos de datos ni duplicación de esquemas.'),

  // =========================================================================
  // DOMINIO 2: OBSERVABILITY & INFRASTRUCTURE (G-021 a G-040)
  // =========================================================================
  g(21, 'kubernetes', 'activegate-version', 'precision',
    '¿Qué versión mínima de ActiveGate es estrictamente requerida para habilitar la visibilidad avanzada de objetos de Kubernetes (Enhanced Object Visibility)?',
    [
      'ActiveGate 1.200 o superior.',
      'ActiveGate 1.327 o superior.',
      'ActiveGate 2.0 (versión no existente).',
      'No se requiere ActiveGate para Enhanced Object Visibility.',
    ], 1,
    'Para utilizar Enhanced Object Visibility en Kubernetes Platform Monitoring, el ActiveGate debe estar en la versión 1.327 o posterior.'),

  g(22, 'agentcli', 'oneagentctl-utility', 'knowledge',
    '¿Cuál es la utilidad de línea de comandos oficial instalada localmente con OneAgent para gestionar su configuración y estado?',
    [
      'systemctl dynatrace',
      'oneagentctl',
      'dt-agent-cli',
      'agentmgr',
    ], 1,
    '`oneagentctl` es la herramienta de línea de comandos oficial de OneAgent para consultar estado, configurar proxies, cambiar modos y gestionar parámetros locales.'),

  g(23, 'agentcli', 'mode-change-cli', 'precision',
    '¿Qué parámetro del comando `oneagentctl` permite cambiar el modo de monitorización a Discovery directamente desde la consola del host?',
    [
      '--set-monitoring-mode=discovery',
      '--mode=lightweight',
      '--enable-discovery-only',
      '--change-license=foundation',
    ], 0,
    'El comando oficial es `oneagentctl --set-monitoring-mode=discovery` para configurar el agente en modo Discovery.'),

  g(24, 'agent', 'process-restart-injection', 'scenario',
    'Un administrador habilita code-module injection para una aplicación Java crítica que ya estaba ejecutándose en el host. Sin embargo, no aparecen trazas del servicio. ¿Qué paso operativo se ha omitido?',
    [
      'Reinstalar el sistema operativo del servidor.',
      'Reiniciar el proceso de la aplicación Java para que el runtime cargue las librerías dinámicas del code module inyectado.',
      'Apagar el ActiveGate durante 20 minutos.',
      'Cambiar el nombre del archivo JAR de la aplicación.',
    ], 1,
    'La inyección de módulos de código en runtimes (Java, .NET, Node.js) ocurre durante el inicio del proceso; modificar la configuración exige reiniciar el proceso para que cargue el agente en memoria.'),

  g(25, 'modes', 'discovery-license', 'precision',
    '¿A qué paquete de suscripción del modelo DPS está vinculado principalmente el modo OneAgent Discovery?',
    [
      'Foundation & Discovery.',
      'Full Stack Premium Enterprise.',
      'Application Security Dedicated.',
      'ActiveGate Unlimited.',
    ], 0,
    'El modo Discovery está diseñado para la cobertura ligera de inventario y host/process discovery bajo la capability de Foundation & Discovery de DPS.'),

  g(26, 'agentcapabilities', 'discovery-limitations', 'knowledge',
    '¿Cuál de las siguientes capacidades de observabilidad NO está disponible por defecto en el modo OneAgent Discovery?',
    [
      'Detección de procesos y host discovery básico.',
      'Tracing distribuido y profiling profundo de transacciones a nivel de código.',
      'Métricas básicas de utilización de CPU y memoria del host.',
      'Conectividad de red saliente hacia Dynatrace.',
    ], 1,
    'El modo Discovery no realiza tracing distribuido ni profiling de transacciones por defecto; su propósito es el descubrimiento ligero de infraestructura y procesos.'),

  g(27, 'modes', 'infrastructure-mode-injection', 'precision',
    'En el modo Infrastructure Monitoring, ¿cuál es el comportamiento predeterminado respecto a la inyección de procesos?',
    [
      'La inyección está permanentemente bloqueada y es imposible recopilar ninguna métrica de procesos.',
      'La inyección de procesos está habilitada de forma predeterminada para recopilar runtime metrics básicas de servicios (ej. GC de Java, hilos de ejecución), salvo exclusión explícita.',
      'Se realiza tracing de transacciones de extremo a extremo en el 100% de las peticiones web.',
      'Se instalan bases de datos locales dentro de cada contenedor.',
    ], 1,
    'En Infrastructure Monitoring, OneAgent inyecta módulos de proceso para extraer runtime metrics (JVM, Garbage Collection, memory pools) pero sin realizar tracing de peticiones completas.'),

  g(28, 'agent', 'outbound-communication-details', 'precision',
    '¿Qué protocolo de red y cifrado utiliza OneAgent para enviar su telemetría regular hacia el clúster o ActiveGate?',
    [
      'Conexión HTTP sin cifrar en el puerto 8080.',
      'Conexión segura saliente mediante HTTPS con cifrado TLS sobre el puerto estándar 443.',
      'Protocolo Telnet en el puerto 23.',
      'Tráfico SNMP sin autenticación en el puerto 161.',
    ], 1,
    'OneAgent transmite toda la telemetría ordinaria mediante peticiones HTTPS salientes cifradas con TLS por el puerto estándar 443.'),

  g(29, 'agent', 'live-debugger-websocket', 'precision',
    '¿En qué circunstancia específica puede OneAgent establecer una conexión saliente basada en WebSocket además del tráfico HTTP/S ordinario?',
    [
      'Durante la ejecución de sesiones interactivas de Live Debugger / Developer Observability.',
      'Cuando el servidor se queda sin espacio en disco duro.',
      'Cada vez que un usuario abre un Dashboard en el navegador.',
      'Para descargar actualizaciones del sistema operativo.',
    ], 0,
    'Live Debugger puede utilizar conexiones WebSocket para la captura interactiva y bidireccional de datos de depuración en tiempo real.'),

  g(30, 'kubernetes', 'operator-classic-fullstack', 'knowledge',
    'En el despliegue de Dynatrace Operator en Kubernetes, ¿qué modo de monitorización se recomienda para clústeres donde se tiene acceso a nivel de nodo para instrumentación profunda automática?',
    [
      'ClassicFullStack o CloudNativeFullStack.',
      'ApplicationOnly sin operador.',
      'Standalone sin conexión de red.',
      'HardwareMonitoring exclusivo.',
    ], 0,
    'CloudNativeFullStack y ClassicFullStack son los modos estándar del Operator para instrumentar nodos, contenedores y workloads de Kubernetes de forma automatizada.'),

  g(31, 'agentcli', 'get-monitoring-mode', 'knowledge',
    '¿Qué comando de `oneagentctl` permite comprobar el modo de monitorización configurado actualmente en un host local?',
    [
      'oneagentctl --get-monitoring-mode',
      'oneagentctl --show-license',
      'oneagentctl --query-fullstack',
      'oneagentctl --check-mode-status',
    ], 0,
    'El comando `oneagentctl --get-monitoring-mode` devuelve el modo de monitorización activo configurado en la instalación local.'),

  g(32, 'agentcapabilities', 'appsec-in-discovery', 'scenario',
    'Un equipo de seguridad desea utilizar Application Security en hosts configurados en modo Discovery. ¿Qué condición técnica es obligatoria para habilitar la detección de vulnerabilidades?',
    [
      'Desinstalar OneAgent y usar un escáner de puertos externo.',
      'Habilitar explícitamente code-module injection para los procesos correspondientes y reiniciar las aplicaciones afectadas.',
      'Pagar una multa económica en la cuenta bancaria del clúster.',
      'Desactivar el cortafuegos del servidor de producción.',
    ], 1,
    'En modo Discovery, Application Security exige habilitar la inyección de módulos de código y reiniciar los procesos monitorizados para poder inspeccionar librerías en memoria.'),

  g(33, 'agent', 'stopping-vs-injection', 'precision',
    'Si un administrador detiene el servicio del sistema operativo de OneAgent (`systemctl stop oneagent`), ¿qué sucede con los módulos inyectados en los procesos Java que continúan en ejecución?',
    [
      'Los módulos inyectados se desinstalan instantáneamente de la memoria RAM del proceso Java sin reinicio.',
      'Las librerías inyectadas permanecen enlazadas en el espacio de memoria del proceso Java hasta que dicho proceso sea detenido o reiniciado.',
      'El proceso Java se cuelga inmediatamente de forma irreversible.',
      'El servidor físico se apaga de forma automática.',
    ], 1,
    'Detener el servicio del agente de sistema no desvincula las librerías dinámicas ya inyectadas en los procesos en ejecución; retirar la instrumentación exige reiniciar el proceso.'),

  g(34, 'kubernetes', 'enhanced-visibility-prereqs', 'troubleshooting',
    'Un administrador activa Enhanced Object Visibility en Kubernetes pero la UI no muestra los eventos de Kubernetes. El ActiveGate está en versión 1.320. ¿Cuál es el diagnóstico correcto?',
    [
      'El clúster de Kubernetes tiene demasiados pods ejecutándose.',
      'El ActiveGate no cumple con el requisito de versión mínima (1.327+) necesario para soportar Enhanced Object Visibility.',
      'OneAgent no puede monitorizar eventos en contenedores Linux.',
      'Falta instalar Microsoft Office en el ActiveGate.',
    ], 1,
    'Enhanced Object Visibility requiere estrictamente una versión de ActiveGate 1.327 o superior; versiones anteriores no disponen del colector de objetos de API necesario.'),

  g(35, 'agentcapabilities', 'mobile-vs-web-rum', 'knowledge',
    '¿Cómo instrumenta OneAgent las aplicaciones móviles nativas (Android e iOS) frente a las aplicaciones web frontend?',
    [
      'En aplicaciones móviles se compilan bibliotecas SDK (OneAgent SDK for Mobile) dentro de la app; en web se inyecta dinámicamente una etiqueta script con el agente JavaScript.',
      'En aplicaciones móviles se instala un sistema operativo Linux en el teléfono.',
      'No hay diferencia: se inyecta el mismo archivo HTML en ambos casos.',
      'Dynatrace no es compatible con teléfonos inteligentes.',
    ], 0,
    'Web RUM inyecta el agente JavaScript en las páginas servidas; Mobile RUM requiere integrar la librería nativa de OneAgent for Mobile en el código fuente de la app.'),

  g(36, 'modes', 'auto-injection-disabled-impact', 'precision',
    'Si se desactiva globalmente la auto-injection en un entorno, ¿qué capacidad avanzada de diagnóstico deja de funcionar de inmediato?',
    [
      'La lectura del porcentaje de uso de CPU del host en el sistema operativo.',
      'El distributed tracing profundo a nivel de código y la detección de vulnerabilidades en runtime de Application Security.',
      'La resolución de nombres de dominio en el servidor DNS.',
      'La recepción de correos electrónicos en el departamento de TI.',
    ], 1,
    'Desactivar la inyección automática impide enlazar módulos de código en los procesos, deshabilitando el tracing transaccional y la detección de vulnerabilidades en memoria.'),

  g(37, 'agentcli', 'proxy-configuration-cli', 'precision',
    '¿Qué comando de `oneagentctl` se utiliza para configurar un servidor proxy corporativo localmente en el agente?',
    [
      'oneagentctl --set-proxy=https://proxy.corp.com:8080',
      'oneagentctl --enable-gateway-route=8080',
      'oneagentctl --proxy-address-apply',
      'oneagentctl --network-change-proxy',
    ], 0,
    'El comando canónico para configurar la ruta de proxy en OneAgent es `oneagentctl --set-proxy=<url>`.'),

  g(38, 'agent', 'watchdog-process', 'knowledge',
    '¿Cuál es la función del proceso Watchdog de OneAgent en el sistema operativo monitorizado?',
    [
      'Monitorear la salud de los procesos internos de OneAgent y reiniciarlos de forma automática en caso de caída o bloqueo no deseado.',
      'Enviar correos publicitarios a los clientes de la empresa.',
      'Bloquear las descargas de archivos en Google Chrome.',
      'Desconectar la tarjeta de red cuando hay tráfico alto.',
    ], 0,
    'El proceso Watchdog de OneAgent supervisa continuamente los submódulos del agente y garantiza su alta disponibilidad reiniciándolos ante fallos imprevistos.'),

  g(39, 'kubernetes', 'rbac-permissions', 'precision',
    'Para que ActiveGate pueda monitorizar la API de un clúster de Kubernetes, ¿qué recurso de seguridad de Kubernetes debe configurarse?',
    [
      'Un ClusterRole y ClusterRoleBinding con permisos de lectura (`get`, `list`, `watch`) sobre los recursos monitorizados del clúster.',
      'Dar acceso de root directo al hardware del nodo maestro.',
      'Desactivar la autenticación en el API server de Kubernetes.',
      'Cambiar el puerto del API server al puerto 21 de FTP.',
    ], 0,
    'ActiveGate necesita una ServiceAccount asociada a un ClusterRole con permisos RBAC de lectura sobre los endpoints de la API de Kubernetes.'),

  g(40, 'modes', 'summary-modes', 'knowledge',
    '¿Cuál es la recomendación oficial de arquitectura para elegir entre Full-Stack y otros modos de monitorización?',
    [
      'Usar Discovery en todos los servidores sin excepción para ahorrar costes.',
      'Desplegar Full-Stack en las aplicaciones de negocio críticas para trazabilidad de código y resolución automática de problemas, e Infrastructure o Discovery en hosts auxiliares o de inventario.',
      'Usar únicamente Infrastructure en servidores web y Full-Stack en impresoras.',
      'Nunca instalar OneAgent en servidores de producción.',
    ], 1,
    'Estrategia recomendada: Full-Stack en entornos y servicios críticos que requieren análisis causal y trazabilidad profunda; modos ligeros para hosts de soporte o descubrimiento inicial.'),

  // =========================================================================
  // DOMINIO 3: NOTEBOOKS & DASHBOARDS (G-041 a G-060)
  // =========================================================================
  g(41, 'dashboards', 'tile-types', 'knowledge',
    '¿Cuáles son los tres tipos fundamentales de tiles interactivos soportados en los Dashboards de Latest Dynatrace?',
    [
      'Tile de música, Tile de vídeo y Tile de videojuegos.',
      'Query tiles (ejecutan DQL y visualizan datos), Code tiles (ejecutan JavaScript con AppEngine SDK) y Markdown tiles (texto enriquecido y anotaciones).',
      'Tile de BIOS, Tile de disco duro y Tile de ratón.',
      'Solo existe un único tipo de tile que muestra imágenes JPEG.',
    ], 1,
    'Los cuadros de mando en Latest soportan tiles de consulta DQL (Query tiles), tiles de código ejecutable (Code tiles) y componentes de Markdown para anotaciones y narrativa.'),

  g(42, 'notebooks', 'variable-syntax', 'precision',
    'En una consulta DQL dentro de un Notebook o Dashboard, ¿qué sintaxis se utiliza para vincular una variable reactiva definida en el documento?',
    [
      '{{ variable_name }}',
      '$variable_name',
      '%variable_name%',
      '#variable_name#',
    ], 1,
    'En DQL para Dashboards y Notebooks, las variables reactivas se referencian mediante el prefijo de signo de dólar: `$variable_name`.'),

  g(43, 'dashboards', 'variable-prefix-restriction', 'precision',
    'Al crear una variable en un Dashboard, ¿qué restricción oficial de nomenclatura aplica sobre su identificador técnico?',
    [
      'Debe contener al menos 50 caracteres.',
      'No puede comenzar por el prefijo reservado de sistema `dt_`.',
      'Debe escribirse obligatoriamente en números romanos.',
      'No puede contener vocales.',
    ], 1,
    'Los nombres de las variables de Dashboard no pueden comenzar con el prefijo reservado `dt_`, el cual está reservado para variables y metadatos del sistema.'),

  g(44, 'dashboardstructure', 'document-json', 'knowledge',
    '¿En qué formato estructurado se almacena internamente la definición de un Dashboard en Latest Dynatrace y mediante qué API puede administrarse de forma programática?',
    [
      'En un archivo binario `.exe` gestionado por FTP.',
      'Como un documento JSON estructurado administrado mediante la Document API de Dynatrace.',
      'En una tabla de base de datos Microsoft Access.',
      'En un documento de Word protegido con contraseña.',
    ], 1,
    'Los Dashboards se almacenan como documentos JSON declarativos que pueden versionarse, exportarse e implementarse automáticamente mediante la Document API.'),

  g(45, 'drilldowns', 'drilldown-context', 'scenario',
    'Un ingeniero configura una acción de drilldown en un gráfico de Dashboard para que al hacer clic en un servicio se abra un Notebook de investigación. ¿Qué contexto transmite el drilldown automáticamente?',
    [
      'La clave privada de la tarjeta de crédito del usuario.',
      'El timeframe activo en el momento del clic, los identificadores de entidad seleccionados y los valores de las variables asociadas.',
      'El historial de descargas de archivos del navegador web.',
      'Ningún dato: el Notebook siempre se abre en blanco.',
    ], 1,
    'Un drilldown bien diseñado propaga el contexto de la investigación: timeframe temporal, entity ID (ej. `dt.entity.service`) y variables activas hacia la vista de destino.'),

  g(46, 'annotations', 'dashboard-annotations', 'knowledge',
    '¿Para qué se utilizan las anotaciones (Annotations) o componentes Markdown en un Dashboard operativo?',
    [
      'Para modificar la velocidad de los discos duros.',
      'Para incorporar contexto explicativo, instrucciones de escalado, enlaces a runbooks de guardia y notas operativas junto a los gráficos de métricas.',
      'Para enviar mensajes de texto a teléfonos móviles personales.',
      'Para apagar los monitores de los usuarios por la noche.',
    ], 1,
    'Las anotaciones y tiles Markdown proporcionan narrativa y contexto operativo: guían al operador en la interpretación de los KPIs y enlazan con procedimientos de soporte.'),

  g(47, 'notebooks', 'markdown-sections', 'knowledge',
    '¿Qué ventaja ofrece el uso de secciones Markdown en los Notebooks de investigación?',
    [
      'Permite redactar hipótesis, documentar conclusiones reproducibles, añadir enlaces a tickets y formatear código con sintaxis resaltada junto a las consultas.',
      'Permite que el Notebook se imprima en papel continuo.',
      'Convierte el Notebook en una página web abierta al público.',
      'Desactiva los errores en los servidores de bases de datos.',
    ], 0,
    'Markdown en Notebooks aporta el componente de comunicación técnica: documenta el razonamiento, hipótesis y metodología analítica junto a la evidencia en vivo.'),

  g(48, 'dashboards', 'variable-dependency', 'precision',
    'En un Dashboard con múltiples variables, ¿está permitido que una variable A dependa del valor de B y al mismo tiempo B dependa de A?',
    [
      'Sí, es la configuración recomendada para alta disponibilidad.',
      'No, las dependencias circulares entre variables están estrictamente prohibidas y son rechazadas por la validación del documento.',
      'Solo si el dashboard tiene más de 10 tiles.',
      'Solo si ambas variables son de tipo texto libre.',
    ], 1,
    'Las variables admiten dependencias jerárquicas en cascada (ej. País → Ciudad), pero las dependencias circulares (A depende de B y B de A) están prohibidas.'),

  g(49, 'notebooks', 'dql-tile-autocomplete', 'knowledge',
    '¿Qué asistencia proporciona el editor de consultas DQL dentro de los Notebooks de Dynatrace?',
    [
      'Escribe automáticamente los correos electrónicos de disculpa a los clientes.',
      'Proporciona autocompletado contextual de comandos, nombres de tablas, funciones y campos disponibles en el esquema de Grail.',
      'Bloquea cualquier consulta que contenga más de 5 palabras.',
      'Convierte las consultas en archivos de sonido MP3.',
    ], 1,
    'El editor DQL integrado ofrece autocompletado inteligente, validación de sintaxis en tiempo real e inspección de esquemas y tipos de datos de Grail.'),

  g(50, 'dashboards', 'sharing-governance-levels', 'precision',
    '¿Cuál es la diferencia entre conceder acceso `Can view` y `Can edit` en un Dashboard compartido?',
    [
      '`Can view` solo permite encender el monitor y `Can edit` permite apagarlo.',
      '`Can view` permite interactuar con variables y leer los datos; `Can edit` autoriza a modificar la disposición de tiles, editar consultas DQL y alterar la configuración del cuadro.',
      'No existe diferencia: ambos roles tienen acceso de administración total.',
      '`Can edit` permite borrar el tenant de Dynatrace de la empresa.',
    ], 1,
    '`Can view` restringe al usuario a interactuar con el cuadro existente; `Can edit` permite alterar la estructura, cambiar consultas DQL y añadir nuevos componentes.'),

  g(51, 'notebooks', 'run-all-sections', 'knowledge',
    'En un Notebook con 10 bloques de análisis consecutivos, ¿qué acción permite reejecutar todo el flujo analítico completo de forma secuencial?',
    [
      'Reiniciar el ordenador del usuario.',
      'Pulsar el botón "Run all" en la barra de herramientas del Notebook.',
      'Copiar y pegar las consultas en un documento de texto plano.',
      'Cerrar la sesión de Dynatrace y esperar 24 horas.',
    ], 1,
    'El comando "Run all" en Notebooks ejecuta secuencialmente todas las secciones de consulta y código para actualizar todo el análisis forense con telemetría fresca.'),

  g(52, 'dashboards', 'query-performance-impact', 'troubleshooting',
    'Un Dashboard corporativo con 30 tiles tarda más de 20 segundos en cargar cada vez que se abre. ¿Cuál es la causa técnica más probable y la solución adecuada?',
    [
      'El monitor del usuario tiene una tasa de refresco demasiado alta.',
      'Múltiples tiles ejecutan consultas DQL pesadas sin acotar el timeframe o escaneando petabytes de logs sin filtros directos; se deben optimizar las queries y usar variables de timeframe concisas.',
      'Los dashboards no pueden tener más de 3 tiles por ley.',
      'Se debe cambiar el idioma de la plataforma a inglés británico.',
    ], 1,
    'El rendimiento de un Dashboard depende de las queries DQL que contiene: consultas sobre grandes volúmenes de logs sin filtros eficientes ralentizan la carga concurrente de tiles.'),

  g(53, 'notebooks', 'code-tile-javascript', 'knowledge',
    '¿Qué lenguaje de programación y entorno se ejecuta en los Code tiles de los Notebooks?',
    [
      'JavaScript / TypeScript ejecutado en el contexto de Dynatrace AppEngine con acceso a los SDKs de la plataforma.',
      'Código ensamblador para chips ARM.',
      'Scripts de bash para el terminal de MS-DOS.',
      'Lenguaje COBOL para servidores mainframe.',
    ], 0,
    'Los Code tiles permiten programar en TypeScript/JavaScript haciendo uso de los SDKs de Dynatrace AppEngine para computación avanzada y consumo de APIs.'),

  g(54, 'dashboards', 'mobile-responsive', 'knowledge',
    '¿Cómo responde la interfaz de los nuevos Dashboards en Latest Dynatrace ante dispositivos móviles o pantallas estrechas?',
    [
      'Bloquea el acceso y muestra un mensaje de error.',
      'Adapta el layout de forma responsiva apilando los tiles verticalmente para permitir su lectura operativa en pantallas de diferentes tamaños.',
      'Borra los tiles para no saturar la batería del teléfono.',
      'Obliga a conectar un ratón USB al teléfono.',
    ], 1,
    'Los nuevos Dashboards cuentan con diseño responsivo que reordena automáticamente la cuadrícula de componentes para una correcta visualización en dispositivos móviles o tablets.'),

  g(55, 'notebooks', 'export-formats', 'knowledge',
    '¿Qué opciones de exportación y compartición ofrece un Notebook de análisis completado?',
    [
      'Exportar a formato JSON estructurado, generar enlaces de compartición para colaboradores o duplicar el documento como plantilla.',
      'Enviar los datos exclusivamente por fax a una oficina de correos.',
      'Grabar los datos en un disco de vinilo musical.',
      'Los notebooks no pueden exportarse ni compartirse jamás.',
    ], 0,
    'Los Notebooks permiten compartir enlaces interactivos, exportar la definición en formato JSON o reutilizarlos como plantillas de análisis operativo.'),

  g(56, 'dashboards', 'dashboard-reports-classic', 'precision',
    'En la experiencia Classic de Dynatrace existía la función "Dashboard Reports" para enviar PDFs periódicos por correo electrónico. ¿Cómo se aborda esta necesidad en Latest Dynatrace?',
    [
      'Desinstalando la plataforma y volviendo a versiones del año 2010.',
      'Mediante flujos automatizados de Workflows en AutomationEngine que programan la consulta, generan el reporte y lo envían por correo o mensajería de forma nativa.',
      'Obligando a un operador a hacer capturas de pantalla manualmente cada mañana.',
      'Esa necesidad está prohibida en la versión moderna.',
    ], 1,
    'En Latest Dynatrace, la generación y distribución programada de informes se automatiza con Workflows y AutomationEngine mediante acciones de DQL y notificación.'),

  g(57, 'notebooks', 'data-command-testing', 'precision',
    '¿Para qué se utiliza el comando `data` al inicio de una sección de consulta en un Notebook?',
    [
      'Para formatear el disco duro de almacenamiento.',
      'Para generar records sintéticos de prueba en memoria sin necesidad de ingerir datos reales en Grail, permitiendo probar la lógica de transformaciones DQL.',
      'Para cambiar la contraseña de los usuarios administradores.',
      'Para medir la temperatura del procesador.',
    ], 1,
    'El comando `data` crea un dataset simulado en la propia query para probar expresiones, filtros o transformaciones complejas sin depender de datos en Grail.'),

  g(58, 'dashboards', 'single-value-tile', 'knowledge',
    '¿Cuándo es apropiado utilizar una visualización de tipo "Single Value" en un Dashboard?',
    [
      'Cuando se desea mostrar un único indicador o KPI numérico destacado (ej. Total de ventas de hoy, Número de incidentes críticos abiertos o Tiempo de respuesta medio).',
      'Cuando se desea ver la evolución temporal de 50 servidores a la vez.',
      'Cuando se necesita leer un log de 10.000 líneas.',
      'Cuando no se tiene ninguna métrica que mostrar.',
    ], 0,
    'Los componentes Single Value están diseñados para resaltar métricas clave de alto impacto que la audiencia necesita captar de un solo vistazo.'),

  g(59, 'notebooks', 'annotations-timeseries', 'knowledge',
    '¿Cómo se pueden correlacionar eventos de despliegue de software con un gráfico temporal en un Notebook?',
    [
      'Dibujando líneas a mano con un rotulador permanente sobre la pantalla del monitor.',
      'Añadiendo anotaciones de eventos basadas en consultas DQL sobre `fetch events` para superponer líneas verticales en el momento exacto del despliegue sobre la serie temporal.',
      'Apagando los servidores durante el despliegue.',
      'Cambiando el color de fondo del Notebook a color rosa.',
    ], 1,
    'Las anotaciones de eventos en gráficos temporales superponen marcadores en el eje temporal para verificar visualmente si un despliegue coincidió con un aumento de latencia o errores.'),

  g(60, 'dashboards', 'summary-dashboards', 'knowledge',
    '¿Cuál es la regla de oro para el diseño de un Dashboard ejecutivo de éxito?',
    [
      'Saturar la pantalla con 100 gráficos minúsculos sin títulos ni unidades.',
      'Diseñar una vista limpia orientada a responder preguntas de negocio específicas con KPIs claros, unidades definidas, tratamiento de nulos y drilldowns hacia análisis forense.',
      'Utilizar exclusivamente texto en blanco sobre fondo blanco.',
      'Ocultar las fechas para que los datos parezcan siempre nuevos.',
    ], 1,
    'Los mejores Dashboards son concisos, declaran sus unidades, tratan los valores nulos con `default:0`, usan variables reactivas y facilitan el drilldown hacia Notebooks.'),

  // =========================================================================
  // DOMINIO 4: BUSINESS ANALYTICS & DEM (G-061 a G-080)
  // =========================================================================
  g(61, 'rum', 'grail-dem-tables', 'precision',
    'En el modelo de datos de Digital Experience en Grail, ¿cuál es la diferencia entre las tablas `user.events` y `user.sessions`?',
    [
      '`user.events` almacena los eventos atómicos individuales (clics, errores, navegaciones); `user.sessions` almacena los registros consolidados de las sesiones completas de usuario.',
      '`user.events` es para usuarios de pago y `user.sessions` para usuarios gratuitos.',
      '`user.events` solo se conserva durante 5 minutos y `user.sessions` durante 100 años.',
      'No existe la tabla `user.events` en Grail.',
    ], 0,
    'En Grail DEM, `user.events` desglosa cada acción atómica de interacción web/móvil; `user.sessions` contiene la sesión completa agregada con su duración y bounce rate.'),

  g(62, 'synthetic', 'api-fail-method', 'precision',
    'En un paso JavaScript de un browser clickpath en Synthetic Monitoring, ¿qué método de la API se utiliza para forzar intencionadamente el fallo del monitor con un mensaje explicativo?',
    [
      'system.exit(1)',
      'api.fail("mensaje de error")',
      'throw new SyntheticException()',
      'browser.abort()',
    ], 1,
    'El método oficial en la API de scripting sintético de Dynatrace es `api.fail("mensaje descriptivo")`, que aborta la prueba y registra el motivo del fallo funcional.'),

  g(63, 'rumsessions', 'session-inactivity-timeout', 'precision',
    '¿Cuál es el tiempo estándar de inactividad continuada del usuario que provoca el cierre automático de una sesión web en RUM?',
    [
      '5 minutos.',
      '30 minutos.',
      '2 horas.',
      '24 horas.',
    ], 1,
    'Una sesión web de RUM finaliza automáticamente tras 30 minutos sin que se registre ninguna nueva interacción o petición del usuario.'),

  g(64, 'rumsessions', 'session-max-duration', 'precision',
    '¿Cuál es la duración máxima absoluta que puede alcanzar una sesión web en RUM antes de ser cerrada obligatoriamente por la plataforma?',
    [
      '1 hora.',
      '6 horas.',
      '12 horas.',
      'Las sesiones web pueden durar infinitos días sin cerrarse.',
    ], 1,
    'Por diseño de arquitectura, una sesión de usuario en web RUM tiene un límite temporal máximo absoluto de 6 horas de duración continua.'),

  g(65, 'rumsessions', 'end-session-js', 'precision',
    '¿Qué llamada a la API JavaScript de RUM (`dtrum`) permite cerrar programáticamente la sesión actual del usuario (por ejemplo, cuando pulsa "Cerrar sesión" en la web)?',
    [
      'dtrum.endSession()',
      'dtrum.closeUser()',
      'dtrum.stopMonitoring()',
      'dtrum.clearCookies()',
    ], 0,
    'La llamada oficial a la JavaScript API es `dtrum.endSession()`, que fuerza el cierre y envío inmediato de la sesión de usuario activa.'),

  g(66, 'businessbasic', 'mandatory-fields', 'precision',
    'En el modelo estándar de Business Events en Dynatrace, ¿cuáles son los dos campos obligatorios indispensables que debe contener todo evento de negocio?',
    [
      'user.email y user.credit_card',
      'event.provider y event.type',
      'host.ip y process.pid',
      'cost.amount y currency.symbol',
    ], 1,
    'El modelo de Business Events exige obligatoriamente los metadatos `event.provider` (origen del evento) y `event.type` (tipo de hecho de negocio); `event.category` es opcional.'),

  g(67, 'bizevents', 'enrichment-sources', 'knowledge',
    '¿Con qué atributos contextuales puede enriquecer automáticamente Dynatrace un Business Event capturado en el frontend?',
    [
      'Con el historial de compras de la cuenta bancaria del usuario.',
      'Con información geográfica del usuario (país, región, ciudad), datos del dispositivo, tipo de navegador y nombre de la aplicación RUM.',
      'Con las contraseñas de las redes sociales del cliente.',
      'Con el número de teléfono del proveedor de internet.',
    ], 1,
    'Dynatrace enriquece los business events de frontend con datos de geolocalización IP, resolución de pantalla, sistema operativo, navegador y contexto de aplicación.'),

  g(68, 'businesscapture', 'capture-rules-oneagent', 'knowledge',
    '¿Cómo puede OneAgent capturar Business Events desde servicios backend Java o .NET sin necesidad de modificar el código fuente de la aplicación?',
    [
      'Instalando un teclado físico nuevo en el servidor.',
      'Mediante reglas de captura de Business Events configuradas en la plataforma que interceptan argumentos de métodos, cabeceras HTTP o payloads de peticiones en vuelo.',
      'Descompilando y reescribiendo los binarios en el disco duro.',
      'OneAgent solo puede capturar eventos si el programador reescribe la aplicación.',
    ], 1,
    'OneAgent captura eventos en vuelo interceptando parámetros de llamadas de servicio, cabeceras HTTP o cuerpos JSON entrantes según reglas declarativas definidas en la UI o API.'),

  g(69, 'syntheticapp', 'private-synthetic-location', 'scenario',
    'Una entidad bancaria necesita verificar cada 5 minutos la disponibilidad de un portal web interno que solo es accesible desde su red privada local. ¿Cómo se resuelve esta monitorización sintética?',
    [
      'Haciendo el portal accesible a todo el público en internet.',
      'Desplegando una Private Synthetic Location sobre un ActiveGate instalado en la red privada de la entidad.',
      'Pagando a un empleado para que pulse la tecla F5 continuamente las 24 horas del día.',
      'Synthetic no puede monitorizar redes privadas.',
    ], 1,
    'Las Private Synthetic Locations se instalan sobre ActiveGates en centros de datos internos para ejecutar pruebas HTTP y de navegador tras firewalls privados.'),

  g(70, 'rum', 'bounced-session', 'precision',
    'En el análisis de comportamiento de usuario de RUM, ¿cuándo se clasifica una sesión web como "Bounced" (rebote)?',
    [
      'Cuando el usuario introduce una contraseña incorrecta 3 veces.',
      'Cuando la sesión contiene exactamente una única interacción (user action) y el usuario abandona el sitio sin realizar más acciones.',
      'Cuando el ordenador del usuario se apaga por falta de batería.',
      'Cuando la velocidad de descarga supera los 100 MB/s.',
    ], 1,
    'Una sesión se define como bounced (sesión de rebote) cuando el usuario realiza una sola acción de entrada y no continúa navegando por el sitio.'),

  g(71, 'businessflow', 'business-flow-purpose', 'knowledge',
    '¿Cuál es el propósito principal de la aplicación Business Flow en Dynatrace?',
    [
      'Controlar la temperatura de la sala de servidores.',
      'Visualizar la secuencia de pasos de un proceso de negocio de extremo a extremo, analizando tasas de conversión, cuellos de botella y abandonos de clientes.',
      'Calcular el impuesto sobre la renta de la empresa.',
      'Dibujar diagramas artísticos para presentaciones comerciales.',
    ], 1,
    'Business Flow traza el recorrido de un proceso comercial (ej. onboarding o contratación) mediante la secuencia de Business Events para detectar fricción y abandono.'),

  g(72, 'synthetic', 'synthetic-types-comparison', 'knowledge',
    '¿Qué diferencia fundamental existe entre un HTTP Monitor y un Browser Monitor en Synthetic?',
    [
      'HTTP Monitor comprueba llamadas REST y endpoints individuales con bajo consumo de recursos; Browser Monitor lanza un navegador real simulando clics y renderizado de JavaScript.',
      'HTTP Monitor solo funciona en teléfonos móviles y Browser Monitor solo en servidores Linux.',
      'HTTP Monitor es gratuito y Browser Monitor cuesta un millón de dólares por ejecución.',
      'No hay diferencia: ejecutan exactamente el mismo código.',
    ], 0,
    'HTTP Monitors son ligeros y validan APIs o recursos individuales; Browser Monitors usan un navegador Chromium real para simular la experiencia completa con renderizado JS y DOM.'),

  g(73, 'rum', 'apdex-concept', 'knowledge',
    '¿Qué mide el índice Apdex (Application Performance Index) en la experiencia digital de Dynatrace?',
    [
      'El precio de la acción de la empresa en bolsa.',
      'La satisfacción del usuario respecto al tiempo de respuesta según un umbral configurable, clasificando las acciones en Satisfechas, Tolerantes o Frustradas.',
      'La cantidad de gigabytes de memoria RAM libres en el servidor.',
      'El nivel de decibelios del ventilador del procesador.',
    ], 1,
    'Apdex es un estándar de la industria que mide la satisfacción del usuario comparando el tiempo de respuesta con un umbral objetivo (T) para clasificar la experiencia.'),

  g(74, 'businesscapture', 'bizevents-via-api', 'precision',
    'Para ingestar Business Events desde aplicaciones externas o pasarelas de pago que no tienen OneAgent, ¿qué endpoint oficial de API se utiliza?',
    [
      '/api/v2/bizevents/ingest',
      '/api/v1/business/upload',
      '/api/v2/events/post',
      '/api/v1/metrics/ingest',
    ], 0,
    'El endpoint oficial para la ingestión HTTP de Business Events estructurados en JSON o CloudEvents es `/api/v2/bizevents/ingest`.'),

  g(75, 'rumclassic', 'classic-limit-contrast', 'precision',
    '¿Qué límite de RUM Classic respecto al número máximo de acciones por sesión ya NO aplica en la experiencia moderna de RUM on Grail?',
    [
      'El límite histórico de 200 user actions por sesión, que dividía artificialmente las sesiones largas en múltiples partes en RUM Classic.',
      'El límite de 5 letras en el nombre de usuario.',
      'El límite de 1 segundo de navegación web.',
      'El límite de 3 clics de ratón por hora.',
    ], 0,
    'En Classic, una sesión se dividía al alcanzar 200 acciones; la experiencia moderna en Latest elimina esa fragmentación arbitraria gracias al almacenamiento en Grail.'),

  g(76, 'synthetic', 'synthetic-maintenance-windows', 'scenario',
    'Un monitor sintético ejecuta comprobaciones cada 5 minutos contra una tienda online. Durante una noche de mantenimiento de base de datos, ¿cómo se evita que se abran Problems innecesarios de disponibilidad?',
    [
      'Eliminando el monitor sintético y volviendo a programarlo desde cero al día siguiente.',
      'Asociando el monitor a una Maintenance Window configurada para desactivar la ejecución o suprimir la generación de alertas durante esa franja horaria.',
      'Apagando los servidores de Dynatrace.',
      'Cambiando la URL del monitor a una página web pública externa.',
    ], 1,
    'Las Maintenance Windows aplican a monitores sintéticos para silenciar alertas o pausar la ejecución de pruebas durante paradas técnicas programadas.'),

  g(77, 'businessbasic', 'real-time-bizevents', 'knowledge',
    '¿Con qué inmediatez temporal están disponibles los Business Events en Grail para su consulta con DQL tras ser ingeridos?',
    [
      'Tardan 24 horas debido a procesos batch nocturnos.',
      'Están disponibles en tiempo real (en cuestión de milisegundos a pocos segundos tras su recepción).',
      'Tardan 7 días laborables.',
      'Solo se pueden consultar una vez al año.',
    ], 1,
    'Los datos en Grail se ingieren mediante pipelines de streaming en tiempo real, estando listos para consulta analítica segundos después de su recepción.'),

  g(78, 'rum', 'session-properties-privacy', 'precision',
    'Al capturar propiedades de sesión (Session Properties) como el nombre de usuario o el identificador de cliente, ¿qué consideración de gobierno es obligatoria?',
    [
      'Publicar la lista de usuarios en redes sociales corporativas.',
      'Cumplir con las normativas de privacidad y protección de datos (RGPD / CCPA), evitando capturar información personal identificable (PII) sin consentimiento o enmascarándola adecuadamente.',
      'Las propiedades de sesión no requieren ninguna medida de privacidad.',
      'Solo se permite capturar números enteros pares.',
    ], 1,
    'Gobierno de datos: capturar atributos de usuario exige enmascarar o filtrar datos sensibles para cumplir con normativas de protección de datos personales.'),

  g(79, 'synthetic', 'synthetic-on-demand', 'knowledge',
    '¿Qué permite la función "On-demand execution" en Synthetic Monitoring?',
    [
      'Ejecutar inmediatamente una prueba sintética fuera de su programación habitual para verificar una corrección en producción sin esperar al siguiente ciclo programado.',
      'Pedir comida a domicilio para el equipo de guardia.',
      'Comprar más servidores en la nube.',
      'Eliminar permanentemente todos los monitores sintéticos del tenant.',
    ], 0,
    'La ejecución bajo demanda permite lanzar un monitor sintético al instante para validar de inmediato la disponibilidad tras un despliegue o cambio de configuración.'),

  g(80, 'businessbasic', 'summary-business', 'knowledge',
    '¿Cuál es el impacto estratégico de unir Business Analytics con telemetría técnica en Dynatrace?',
    [
      'Permite justificar por qué los servidores fallan sin tener que repararlos.',
      'Permite cuantificar el impacto económico real de las averías técnicas (ej. pérdidas en euros por hora de caída del servicio de pagos) para alinear TI con los objetivos del negocio.',
      'Obliga a los ingenieros de sistemas a estudiar economía bancaria.',
      'Reemplaza por completo el departamento de contabilidad de la empresa.',
    ], 1,
    'Unir telemetría con negocio permite traducir degradaciones técnicas en impacto de facturación y experiencia, demostrando el valor de la observabilidad ante la dirección ejecutiva.'),

  // =========================================================================
  // DOMINIO 5: DATA, REPORTING & ANALYSIS (G-081 a G-100)
  // =========================================================================
  g(81, 'retention', 'bucket-permissions-write', 'precision',
    '¿Qué permiso IAM es indispensable para crear nuevos buckets en Grail o para modificar las políticas de retención de almacenamiento?',
    [
      'storage:bucket-definitions:write',
      'storage:logs:read',
      'storage:buckets:delete',
      'app-engine:storage:install',
    ], 0,
    'El permiso IAM oficial para crear y modificar la configuración de retención de buckets en Grail es `storage:bucket-definitions:write`.'),

  g(82, 'retention', 'default-logs-retention', 'precision',
    '¿Cuál es la retención por defecto del bucket estándar `default_logs` en Grail en Latest Dynatrace?',
    [
      '10 días.',
      '35 días.',
      '15 meses.',
      '5 años.',
    ], 1,
    'El bucket por defecto de almacenamiento de logs (`default_logs`) cuenta con una retención predeterminada de 35 días (configurable hasta 10 años).'),

  g(83, 'metricanalysis', 'grail-metrics-retention', 'precision',
    '¿Cuál es la retención incluida por defecto para Metrics powered by Grail con una granularidad de 1 minuto?',
    [
      '35 días.',
      '15 meses.',
      '5 años.',
      '10 días.',
    ], 1,
    'Las métricas en Grail incluyen 15 meses de retención general con granularidad de 1 minuto sin muestreo previo (ampliables hasta 10 años según suscripción).'),

  g(84, 'metricanalysis', 'timeseries-default-zero', 'precision',
    'En una consulta DQL con el comando `timeseries`, ¿qué efecto tiene añadir el modificador `default:0`?',
    [
      'Borra todas las métricas que tengan un valor igual a cero.',
      'Sustituye los intervalos de tiempo en los que no se han registrado muestras (valores `null`) por el valor numérico 0, evitando huecos en la gráfica.',
      'Establece el intervalo temporal de la consulta en 0 segundos.',
      'Reinicia el contador de métricas a cero en los servidores.',
    ], 1,
    'El parámetro `default:0` en `timeseries` rellena los huecos temporales vacíos (`null`) con el número 0 para trazar líneas continuas en visualizaciones.'),

  g(85, 'retention', 'classic-vs-grail-metrics', 'precision',
    '¿Qué retención histórica proporcionaba la arquitectura clásica de Metrics Classic frente a la arquitectura moderna de Metrics on Grail?',
    [
      'Classic proporcionaba 5 años agregados en series multidimensionales separadas; Grail proporciona 15 meses incluidos con 1 minuto de resolución unificados en el lakehouse.',
      'Classic proporcionaba 24 horas y Grail proporciona 100 años.',
      'Ambas arquitecturas comparten exactamente la misma base de datos sin ninguna diferencia.',
      'Classic no permitía guardar métricas de más de 3 días.',
    ], 0,
    'Diferencia histórica de examen: Metrics Classic conservaba datos agregados hasta 5 años; Metrics on Grail unifica las series con 15 meses de retención base a 1 minuto de resolución.'),

  g(86, 'retention', 'default-spans-retention', 'precision',
    'En Grail, ¿cuál es la retención por defecto del bucket estándar para trazas distribuidas (`default_spans`)?',
    [
      '10 días.',
      '35 días.',
      '15 meses.',
      '5 años.',
    ], 0,
    'El bucket de trazas distribuidas `default_spans` en Grail se configura inicialmente con una retención por defecto de 10 días (configurable de 10 días a 10 años).'),

  g(87, 'retention', 'system-buckets-protection', 'precision',
    '¿Por qué la plataforma impide a los administradores reducir la retención de ciertos buckets del sistema (como los buckets de eventos de Davis) por debajo de sus límites base?',
    [
      'Porque para reducir la retención es necesario reiniciar físicamente el clúster.',
      'Para proteger la integridad de las líneas base de IA y auditoría que Davis necesita para la correlación causal a largo plazo (14 meses de retención base).',
      'Porque los buckets de sistema solo pueden ser leídos por ordenadores cuánticos.',
      'Para obligar a los clientes a consumir más disco duro innecesario.',
    ], 1,
    'Los datos de Davis Events y Problems requieren retención suficiente (14 meses) para permitir comparaciones estacionales de incidentes y cálculo de baselines históricos.'),

  g(88, 'metricanalysis', 'timeseries-vs-summarize', 'precision',
    '¿Cuándo se debe utilizar el comando `timeseries` en lugar de `summarize` en un análisis de rendimiento con DQL?',
    [
      'Cuando se necesita generar una serie temporal homogénea con intervalos regulares (`interval:1m`) para representarla en gráficos de líneas temporales.',
      'Cuando se desea generar una lista de los 10 usuarios con mayor número de compras.',
      'Cuando solo se van a consultar archivos de texto sin formato.',
      'Cuando se desea borrar los registros de la base de datos.',
    ], 0,
    '`timeseries` es el comando especializado para series temporales de métricas; `summarize` genera tablas agregadas agrupadas por dimensiones categóricas.'),

  g(89, 'metricsfaq', 'key-requests-purpose', 'knowledge',
    'En la monitorización de servicios, ¿qué ventaja operativa aporta marcar una petición web específica como "Key Request"?',
    [
      'Hace que esa petición web sea atendida al doble de velocidad por los servidores.',
      'Permite establecer reglas de detección de anomalías personalizadas independientes, umbrales de alerta específicos y retención extendida para transacciones críticas de negocio.',
      'Desactiva el cifrado SSL en esa transacción para ahorrar CPU.',
      'Bloquea la petición para que nadie pueda ejecutarla en producción.',
    ], 1,
    'Marcar una petición como Key Request permite definir umbrales de baselines personalizados, alertas dedicadas y políticas de retención particulares para llamadas críticas.'),

  g(90, 'retention', 'shortening-retention-impact', 'troubleshooting',
    'Un administrador modifica la retención de un bucket custom de logs de 90 días a 30 días para reducir costes. ¿Qué consecuencia irreversible tiene este cambio sobre los datos existentes?',
    [
      'Los datos anteriores a 30 días se comprimen en archivos ZIP en el disco duro.',
      'Todos los datos almacenados cuya antigüedad supere los 30 días se purgan de forma inmediata e irreversible de Grail.',
      'Los datos antiguos se transfieren automáticamente al bucket `default_logs`.',
      'No tiene ningún efecto hasta que transcurran 5 años.',
    ], 1,
    'Reducir la retención de un bucket ejecuta una purga permanente de todos los datos que excedan el nuevo límite temporal establecido.'),

  g(91, 'metricslimits', 'cardinality-limits', 'knowledge',
    '¿Qué sucede si una aplicación envía métricas personalizadas generando millones de combinaciones únicas de dimensiones (explosión de cardinalidad)?',
    [
      'La plataforma compra automáticamente servidores adicionales en la nube.',
      'Puede alcanzarse el límite de series temporales activas por métrica, degradando el rendimiento de las consultas y aumentando significativamente el consumo de recursos de almacenamiento.',
      'Dynatrace formatea el disco duro del servidor causante.',
      'No ocurre nada porque Grail admite infinitas dimensiones por microsegundo sin ningún impacto.',
    ], 1,
    'La proliferación descontrolada de dimensiones de alta cardinalidad multiplica las series temporales activas y satura los límites de ingesta y cálculo de métricas.'),

  g(92, 'metricanalysis', 'by-dimensions-grouping', 'precision',
    'En una consulta DQL `timeseries avg(dt.host.cpu.usage), by:{dt.entity.host}`, ¿qué genera la cláusula `by:{...}`?',
    [
      'Una única línea que suma la CPU de todos los servidores del mundo.',
      'Una serie temporal independiente para cada Host individual presente en el dataset analizado.',
      'Una lista alfabética de los administradores de sistemas.',
      'Un archivo de texto plano guardado en el servidor.',
    ], 1,
    'La cláusula `by:{...}` en `timeseries` desglosa el cálculo de la métrica generando una serie temporal separada para cada valor único de las dimensiones especificadas.'),

  g(93, 'retention', 'oneagent-diagnostics-retention', 'knowledge',
    '¿Cuál es la retención general asignada en la plataforma para los archivos de diagnóstico y soporte de OneAgent (Support archives)?',
    [
      '30 días.',
      '15 meses.',
      '5 años.',
      '24 horas.',
    ], 0,
    'Los archivos de diagnóstico y registros de soporte generados por OneAgent tienen una retención predeterminada de 30 días.'),

  g(94, 'retention', 'security-data-grail-retention', 'precision',
    '¿Cuál es la retención documentada en Grail para los datos de seguridad generados por Dynatrace (Security data powered by Grail)?',
    [
      '35 días.',
      'Hasta 3 años para datos generados por Dynatrace (y 1 año para datos de terceros).',
      '10 días.',
      '50 años inmutables.',
    ], 1,
    'En Latest Dynatrace, la telemetría de Application Security en Grail tiene una retención extendida de hasta 3 años para auditoría de vulnerabilidades y eventos de seguridad.'),

  g(95, 'metriccost', 'metric-cost-optimization', 'scenario',
    'Una compañía desea optimizar su consumo de crédito en métricas personalizadas. ¿Cuál es la mejor recomendación técnica?',
    [
      'Desinstalar OneAgent de todos los servidores.',
      'Revisar las dimensiones de las métricas personalizadas eliminando identificadores efímeros (como UUIDs, timestamps o tokens de sesión) y agregando previamente en el origen.',
      'Cambiar el color de los gráficos en los dashboards a escala de grises.',
      'Apagar los servidores durante la noche.',
    ], 1,
    'La optimización de costes de métricas se basa en el control de cardinalidad: erradicar identificadores únicos que multiplican innecesariamente el número de series temporales.'),

  g(96, 'metricexploration', 'metric-command-exploratory', 'precision',
    '¿Cuál es la limitación documentada del comando exploratorio `metrics` en DQL y por qué no debe utilizarse para cuadros de mando en producción?',
    [
      'Está limitado a un máximo de 100.000 series temporales y una ventana temporal máxima de los últimos 10 días, diseñado solo para exploración rápida de catálogo.',
      'Solo funciona los lunes por la mañana.',
      'Exige que el usuario escriba la consulta en latín.',
      'No tiene ninguna limitación y es el comando recomendado para producción.',
    ], 0,
    'El comando `metrics` es puramente exploratorio para descubrir el catálogo de métricas (máximo 10 días y 100k series); para producción y cuadros de mando se utiliza siempre `timeseries`.'),

  g(97, 'retention', 'rum-session-retention', 'knowledge',
    '¿Cuál es la retención general por defecto para eventos y sesiones de usuario de RUM en Grail?',
    [
      '10 días.',
      '35 días.',
      '14 meses.',
      '5 años.',
    ], 1,
    'Los datos de experiencia digital (user events, user sessions y Synthetic) se conservan con una retención base predeterminada de 35 días en Grail.'),

  g(98, 'metricanalysis', 'resolution-vs-retention', 'precision',
    '¿Por qué no deben confundirse los conceptos de "Resolución temporal" y "Retención de almacenamiento" en métricas?',
    [
      'Porque resolución es el intervalo de muestreo temporal entre puntos de datos (ej. cada 1 minuto); retención es el tiempo total que los datos permanecen guardados en el bucket.',
      'Porque resolución se mide en kilogramos y retención en litros.',
      'No hay confusión: significan exactamente lo mismo en cualquier base de datos.',
      'Porque la resolución solo aplica a monitores de televisión.',
    ], 0,
    'Resolución temporal = granularidad de los puntos temporales (1s, 1m, 1h); Retención = horizonte temporal máximo que los datos permanecen en almacenamiento antes de ser purgados.'),

  g(99, 'retention', 'davis-problems-retention', 'knowledge',
    '¿Cuál es la retención general documentada para Davis Problems y eventos en la plataforma?',
    [
      '35 días.',
      '14 meses.',
      '10 días.',
      '5 años.',
    ], 1,
    'Los Problems y Davis events cuentan con 14 meses de retención en la plataforma para permitir análisis interanual de incidencias y estabilidad.'),

  g(100, 'retention', 'summary-retention', 'knowledge',
    'En conclusión, ¿cuál es la ventaja del modelo de retención basado en buckets de Grail frente a sistemas monolíticos clásicos?',
    [
      'Que obliga a que todos los datos se borren cada fin de semana.',
      'Que permite asignar políticas de retención y control de acceso granulares e independientes para cada tipo de dato y equipo, optimizando costes y cumplimiento regulatorio.',
      'Que el almacenamiento es gratuito para siempre sin importar el volumen.',
      'Que no requiere utilizar redes de ordenadores para consultar datos.',
    ], 1,
    'Los buckets de Grail aportan flexibilidad absoluta: cada tipo de dato (auditoría, logs de depuración, métricas) tiene su propia retención optimizada según su valor de negocio.'),

  // =========================================================================
  // DOMINIO 6: DQL - DYNATRACE QUERY LANGUAGE (G-101 a G-120)
  // =========================================================================
  g(101, 'dql', 'explicit-timeframe-syntax', 'precision',
    'En una consulta DQL, ¿cómo se fija explícitamente una ventana temporal para que la consulta sea reproducible e independiente del selector de la interfaz gráfica?',
    [
      'Mediante parámetros en el comando de carga, por ejemplo: `fetch logs, from:now()-2h, to:now()`',
      'Escribiendo la fecha en un comentario al final del script.',
      'Cambiando el reloj del sistema operativo en el panel de control de Windows.',
      'DQL no admite fijar el tiempo dentro de la consulta.',
    ], 0,
    'El timeframe se define formalmente en el primer comando mediante `from:now()-2h`, `from:now()-7d`, etc., garantizando reproducibilidad en automatizaciones y scripts.'),

  g(102, 'dqlcommands', 'k8s-fields-standard', 'knowledge',
    'Al consultar logs de contenedores de Kubernetes en DQL, ¿cuáles son los nombres semánticos oficiales de los campos para filtrar por contenedor y pod?',
    [
      'k8s.container.name y k8s.pod.name',
      'kubernetes_container y kubernetes_pod',
      'docker.name y pod.title',
      'cgroup.container_id y linux.process',
    ], 0,
    'Los atributos estándar de OpenTelemetry y Dynatrace en Grail para Kubernetes utilizan la convención semántica `k8s.container.name`, `k8s.pod.name` y `k8s.namespace.name`.'),

  g(103, 'dqltypes', 'array-size-function', 'precision',
    'En DQL, ¿qué función se utiliza para obtener el número de elementos contenidos en un campo de tipo array?',
    [
      'count(array)',
      'arraySize(array)',
      'lengthOf(array)',
      'size(array)',
    ], 1,
    'La función nativa de DQL para calcular la longitud o cantidad de elementos en una lista es `arraySize(array)`.'),

  g(104, 'dqltypes', 'array-contains-function', 'precision',
    'Para filtrar registros donde un array de etiquetas (`tags`) contenga el elemento "production", ¿qué expresión DQL es la correcta?',
    [
      'filter tags == "production"',
      'filter arrayContains(tags, "production")',
      'filter in_array("production", tags)',
      'filter tags.has("production")',
    ], 1,
    'La función canónica de DQL para comprobar la pertenencia de un elemento en un array es `arrayContains(array, value)`.'),

  g(105, 'dqltypes', 'expand-command', 'precision',
    '¿Qué comando de DQL se utiliza para aplanar o desanidar un array creando una fila independiente para cada elemento de la lista (operación unwind)?',
    [
      'flatten',
      'expand',
      'unwind',
      'splitArray',
    ], 1,
    'El comando `expand` desanida un array: toma una fila con una lista de N elementos y genera N filas individuales en la salida del pipeline.'),

  g(106, 'dqlcommands', 'fields-add-vs-remove', 'knowledge',
    '¿Cuál es la diferencia entre los comandos de proyección `fieldsAdd` y `fieldsKeep` en DQL?',
    [
      '`fieldsAdd` incorpora nuevas columnas calculadas conservando las existentes; `fieldsKeep` conserva únicamente las columnas especificadas y descarta el resto.',
      '`fieldsAdd` borra la base de datos y `fieldsKeep` la restaura.',
      'No existe diferencia: son sinónimos absolutos.',
      '`fieldsKeep` solo funciona en números enteros.',
    ], 0,
    '`fieldsAdd` añade campos derivados a la tabla sin alterar las columnas existentes; `fieldsKeep` (o `fields`) realiza una proyección estricta conservando solo las declaradas.'),

  g(107, 'dqlbest', 'filter-early-principle', 'scenario',
    'Un analista escribe una consulta DQL que primero realiza un `parse` complejo sobre millones de logs y al final ejecuta un `filter loglevel == "ERROR"`. ¿Por qué esta consulta viola las buenas prácticas de DQL?',
    [
      'Porque DQL prohíbe usar `parse` en la misma consulta con `filter`.',
      'Porque procesar expresiones regulares en millones de registros antes de filtrar desperdicia CPU y tiempo; se debe filtrar temprano por `loglevel` para parsear solo los registros relevantes.',
      'Porque los errores nunca deben parsearse.',
      'Porque el comando `filter` solo puede usarse después de un `limit`.',
    ], 1,
    'Regla de oro de rendimiento en DQL: "Filter early". Reducir el dataset con filtros sobre campos directos antes de ejecutar operaciones computacionalmente costosas como parsing o joins.'),

  g(108, 'dqljoins', 'lookup-vs-join', 'precision',
    'En DQL, ¿cuál es la ventaja del comando `lookup` frente a un `join` complejo para enriquecer eventos con metadatos de entidades?',
    [
      '`lookup` está optimizado para enriquecer registros cruzando una clave contra una tabla de referencia secundaria (como `dt.entity.host`), requiriendo menor sobrecarga que un join relacional completo.',
      '`lookup` borra los registros que no coinciden y `join` los duplica por cien.',
      '`lookup` solo puede ejecutarse en ordenadores portátiles.',
      'No existe el comando `lookup` en DQL.',
    ], 0,
    '`lookup` es el comando idiomático y eficiente para enriquecimiento dimensional: busca valores por clave en una tabla dimensional sin la sobrecarga de un join general.'),

  g(109, 'dqlcommands', 'sort-position-best-practice', 'precision',
    '¿En qué posición del pipeline de una consulta analítica de gran volumen debe colocarse habitualmente el comando `sort`?',
    [
      'Inmediatamente después de `fetch` antes de cualquier filtro.',
      'Cerca del final del pipeline, después de haber filtrado y agregado los datos con `summarize`, para no ordenar millones de filas innecesariamente.',
      'El comando `sort` debe colocarse antes de cada uno de los comandos de la consulta.',
      'DQL prohíbe ordenar datos que tengan más de 10 filas.',
    ], 1,
    'Ordenar (`sort`) es una operación en memoria costosa; debe aplicarse sobre el conjunto ya reducido y agregado, habitualmente justo antes de `limit`.'),

  g(110, 'dqltypes', 'data-types-strongly-typed', 'knowledge',
    '¿Qué significa que DQL sea un lenguaje con tipado fuerte (strongly typed)?',
    [
      'Que exige escribir todas las consultas con letras mayúsculas.',
      'Que cada campo tiene un tipo definido (string, long, double, timestamp, boolean, duration, array, record) y no se permiten operaciones incoherentes entre tipos incompatibles sin conversión explícita.',
      'Que el teclado del ordenador debe tener teclas mecánicas.',
      'Que las consultas se bloquean si el usuario no tiene contraseña de 20 caracteres.',
    ], 1,
    'Tipado fuerte en DQL: las funciones y operadores son estrictos con los tipos (ej. no se puede sumar un string con un timestamp sin usar funciones de conversión de tipos).'),

  g(111, 'dqlcommands', 'limit-before-summarize-trap', 'troubleshooting',
    'Un estudiante escribe: `fetch logs | limit 100 | summarize total_errors = count()`. ¿Cuál es el grave error metodológico de esta consulta para calcular el total de errores?',
    [
      'La consulta solo contará los errores que se encuentren dentro de la muestra arbitraria de los primeros 100 registros leídos, en lugar de calcular el total del entorno.',
      'La consulta no compilará porque `limit` no admite números mayores de 10.',
      'La consulta borrará los logs de los servidores.',
      'No hay ningún error: es la forma recomendada de calcular totales.',
    ], 0,
    'Trampa clásica de examen: colocar `limit` antes de una agregación trunca el conjunto de datos de entrada, calculando estadísticas solo sobre una pequeña muestra aleatoria.'),

  g(112, 'dqlcommands', 'search-vs-filter', 'precision',
    '¿Cuál es la diferencia de uso en DQL entre el comando `filter` y el comando `search`?',
    [
      '`filter` evalúa condiciones lógicas sobre campos específicos estructurados; `search` realiza búsquedas textuales libres en todo el contenido del registro.',
      '`filter` es para números y `search` para fechas exclusivamente.',
      'No hay diferencia: son comandos intercambiables con idéntico rendimiento.',
      '`search` solo funciona si el servidor tiene acceso a Google.',
    ], 0,
    '`filter` es preciso y eficiente contra campos estructurados (`loglevel == "ERROR"`); `search` escanea texto libre buscando términos en todo el contenido del registro.'),

  g(113, 'dqlmetrics', 'timeseries-interval-parameter', 'precision',
    'En el comando `timeseries`, ¿qué define el parámetro `interval:5m`?',
    [
      'Que la consulta tardará 5 minutos en ejecutarse.',
      'La resolución de los intervalos temporales (time bins) en los que se agrupan los puntos de datos de la serie temporal (un punto cada 5 minutos).',
      'Que solo se consultarán los servidores que lleven 5 minutos encendidos.',
      'Que los datos se borrarán pasados 5 minutos.',
    ], 1,
    '`interval` especifica la granularidad de los puntos de la serie temporal en `timeseries`: agrupa las muestras en bloques de 5 minutos.'),

  g(114, 'dqltypes', 'record-field-access', 'precision',
    'Si un campo `json_data` es de tipo `record` tras ser parseado, ¿cómo se accede al valor de la propiedad `status` en DQL?',
    [
      'json_data[status]',
      'json_data->status',
      'get(json_data, "status")',
      'json_data.status()',
    ], 0,
    'En DQL, las propiedades de un tipo `record` se acceden mediante la sintaxis de corchetes: `record_field[property_name]`.'),

  g(115, 'dqlcommands', 'fields-rename-syntax', 'knowledge',
    '¿Qué comando de DQL permite cambiar el nombre visible de una o varias columnas en la tabla de resultados?',
    [
      'fieldsRename nuevo_nombre = nombre_anterior',
      'alterColumn nombre_anterior to nuevo_nombre',
      'changeFieldName(nombre_anterior, nuevo_nombre)',
      'renameTable(nuevo_nombre)',
    ], 0,
    'La sintaxis oficial para renombrar columnas en la proyección de salida de DQL es `fieldsRename nuevo_nombre = nombre_anterior`.'),

  g(116, 'dqlbest', 'scan-limit-gbytes', 'precision',
    '¿Qué parámetro opcional en el comando `fetch` permite establecer un límite estricto de gigabytes escaneados para prevenir consultas excesivamente costosas en entornos productivos?',
    [
      'maxScanMemory',
      'scanLimitGBytes',
      'limitGB',
      'stopAtBytes',
    ], 1,
    'El parámetro `scanLimitGBytes` en el comando `fetch` limita el volumen máximo de datos que la consulta puede escanear en Grail antes de abortar por seguridad de coste.'),

  g(117, 'dqltypes', 'to-string-conversion', 'precision',
    'Si se necesita concatenar un número entero con una cadena de texto en DQL, ¿qué función de conversión debe aplicarse?',
    [
      'toString(campo_numerico)',
      'castToText(campo_numerico)',
      'string(campo_numerico)',
      'convert(campo_numerico, "string")',
    ], 0,
    'La función estándar de DQL para convertir cualquier tipo a cadena de texto es `toString(valor)`.'),

  g(118, 'dqlcommands', 'count-distinct-aggregation', 'knowledge',
    '¿Qué función de agregación se utiliza dentro de un `summarize` para contar la cantidad de direcciones IP únicas que han generado errores?',
    [
      'count(ip)',
      'countDistinct(ip)',
      'unique(ip)',
      'distinctCount(ip)',
    ], 1,
    'La función de agregación en DQL para calcular cardinalidad de valores únicos no repetidos es `countDistinct(campo)`.'),

  g(119, 'dqlmetrics', 'timeseries-multiple-metrics', 'scenario',
    '¿Permite el comando `timeseries` calcular simultáneamente la media y el máximo de una métrica en la misma serie temporal?',
    [
      'No, DQL exige escribir dos consultas separadas en diferentes pestañas.',
      'Sí, se pueden declarar múltiples agregaciones separadas por comas, por ejemplo: `timeseries cpu_avg = avg(dt.host.cpu.usage), cpu_max = max(dt.host.cpu.usage), interval:1h`',
      'Solo si el ordenador tiene dos procesadores físicos.',
      'Solo los fines de semana.',
    ], 1,
    '`timeseries` soporta múltiples expresiones de cálculo en la misma invocación, generando series sincronizadas en el mismo eje temporal.'),

  g(120, 'dql', 'summary-dql', 'knowledge',
    'En resumen, ¿cuál es el principio de diseño fundamental que diferencia a DQL de los lenguajes SQL tradicionales?',
    [
      'Que DQL no permite utilizar números en las consultas.',
      'Que DQL utiliza un modelo lineal de canalización por pipes (`|`) donde cada comando transforma de forma predecible el dataset para la siguiente fase sin subconsultas anidadas complejas.',
      'Que DQL solo funciona si se imprime en papel antes de ejecutarlo.',
      'Que DQL está escrito íntegramente en lenguaje binario.',
    ], 1,
    'DQL es declarativo y canalizado por pipelines: los datos fluyen de izquierda a derecha a través de pipes (`|`), simplificando la lectura, depuración y composición modular de consultas.'),

  // =========================================================================
  // DOMINIO 7: SECURITY & APPLICATION SECURITY (G-121 a G-140)
  // =========================================================================
  g(121, 'security', 'third-party-vs-code-level', 'precision',
    '¿Cuál es la distinción técnica exacta entre una vulnerabilidad Third-Party y una vulnerabilidad Code-Level en Dynatrace?',
    [
      'Third-party afecta a sistemas operativos Windows y Code-level a Linux.',
      'Third-party detecta librerías y dependencias externas vulnerables (CVEs) cargadas en memoria; Code-level detecta debilidades en el código fuente propio (CWEs) como inyecciones SQL por falta de validación de inputs.',
      'No hay diferencia: ambas se refieren exclusivamente a fallos de hardware en routers.',
      'Code-level solo se detecta si el desarrollador sube su código a GitHub público.',
    ], 1,
    'Third-party analiza componentes de terceros cargados en runtime (CVEs); Code-level analiza el flujo de ejecución de inputs en el código desarrollado internamente (CWEs).'),

  g(122, 'seceval', 'dss-factors', 'precision',
    '¿Cuáles son los tres factores determinantes del entorno de producción que pondera el Davis Security Score (DSS) sobre la severidad teórica CVSS?',
    [
      'La marca del procesador, la cantidad de memoria RAM y el color del rack.',
      'Public internet exposure (exposición pública), Reachable data assets (acceso a almacenes de datos sensibles) y Public exploit availability (disponibilidad de exploit público).',
      'La antigüedad de la empresa, el número de empleados y el país del centro de datos.',
      'La velocidad de la conexión de red, la temperatura ambiente y el sistema de ventilación.',
    ], 1,
    'DSS contextualiza el riesgo ponderando CVSS con: exposición a internet, alcance a bases de datos y existencia de exploit público funcional en circulación.'),

  g(123, 'vulnapp', 'dt-security-vulnerabilities-table', 'precision',
    'En Latest Dynatrace, ¿qué tabla de Grail permite auditar y consultar mediante DQL el inventario en tiempo real de todas las vulnerabilidades detectadas?',
    [
      'dt.security.vulnerabilities',
      'security.cve_inventory',
      'appsec.findings_table',
      'dt.system.security',
    ], 0,
    'La tabla oficial de Grail para consultar el inventario unificado de vulnerabilidades de seguridad es `dt.security.vulnerabilities`.'),

  g(124, 'vulnconcepts', 'mute-rules-purpose', 'precision',
    '¿Cuál es la función de las reglas de silenciado (Mute Rules) en la gestión de vulnerabilidades de Application Security?',
    [
      'Eliminar automáticamente el archivo JAR vulnerable del disco duro del servidor.',
      'Silenciar o suprimir justificadamente alertas sobre vulnerabilidades evaluadas como falso positivo o riesgo temporalmente aceptado sin alterar la detección real en Grail.',
      'Apagar el sistema de sonido del centro de datos.',
      'Impedir que los usuarios inicien sesión en la aplicación.',
    ], 1,
    'Las Mute Rules permiten documentar excepciones de seguridad y silenciar hallazgos que no representan un riesgo inmediato o son falsos positivos aprobados por auditoría.'),

  g(125, 'thirdparty', 'memory-load-requirement', 'scenario',
    'Un escáner estático de código (SAST) alerta de que una imagen de contenedor contiene una librería vulnerable `log4j`. Sin embargo, Dynatrace Application Security no emite ningún hallazgo activo en producción. ¿Por qué ocurre esto?',
    [
      'Porque Dynatrace no es compatible con librerías de Java.',
      'Porque OneAgent reporta vulnerabilidades third-party en runtime únicamente cuando el proceso carga la librería en memoria; si la aplicación nunca invoca ni carga esa librería, no existe riesgo en ejecución.',
      'Porque la librería solo es vulnerable los días festivos.',
      'Porque Dynatrace borra automáticamente las librerías viejas del contenedor.',
    ], 1,
    'Principio clave de Runtime Vulnerability Analytics: OneAgent detecta componentes cuando se cargan en ejecución en memoria; una dependencia inerte en disco no supone un vector activo en runtime.'),

  g(126, 'seceval', 'auto-resolution-concept', 'knowledge',
    '¿En qué situación se marca automáticamente una vulnerabilidad como "Resolved" en la plataforma Dynatrace?',
    [
      'Cuando transcurren 24 horas sin que ningún usuario haga clic en la pantalla.',
      'Cuando desaparece la causa raíz en el entorno monitorizado (por ejemplo, se actualiza la librería vulnerable, se detiene el proceso o se desmantela el host afectado).',
      'Cuando el administrador cambia la contraseña de su usuario.',
      'Las vulnerabilidades nunca se marcan como resueltas automáticamente.',
    ], 1,
    'Resolución automática: Davis detecta de forma continua el entorno; si el proceso se actualiza y deja de cargar la versión vulnerable, el hallazgo pasa a estado Resolved de forma autónoma.'),

  g(127, 'codelevel', 'code-level-sinks', 'knowledge',
    '¿Qué tipo de vulnerabilidad de código detecta Code-Level Vulnerability Analytics al rastrear entradas no saneadas que llegan a un método de base de datos SQL?',
    [
      'Saturación de memoria RAM en el servidor.',
      'Inyección SQL (SQL Injection - CWE-89).',
      'Rotura del cable de red de fibra óptica.',
      'Fallo en la tarjeta de sonido del cliente.',
    ], 1,
    'Code-Level Vulnerability Analytics analiza fuentes de entrada (sources) y puntos críticos de ejecución (sinks) para detectar fallos como SQL Injection o Command Injection.'),

  g(128, 'security', 'monitoring-modes-appsec', 'precision',
    '¿Qué modo de OneAgent proporciona la mayor profundidad de contexto ambiental para la detección y mitigación de vulnerabilidades de seguridad?',
    [
      'Discovery Monitoring mode.',
      'Full-Stack Monitoring mode.',
      'Infrastructure Monitoring mode.',
      'Hardware-Only mode.',
    ], 1,
    'Full-Stack Monitoring aporta la visión integral: tracing de peticiones, contexto de topología de servicios y detección profunda de librerías y código en ejecución.'),

  g(129, 'investigations', 'investigations-app-role', 'knowledge',
    '¿Qué permite la aplicación Investigations en el contexto de Application Security?',
    [
      'Comprar licencias de software en una tienda web.',
      'Crear un escenario colaborativo de investigación forense, encadenando consultas DQL, extrayendo patrones con DPL y almacenando evidencias de auditoría compartibles.',
      'Despedir empleados que cometan errores en el código.',
      'Apagar el router de salida a internet de la empresa.',
    ], 1,
    'La app Investigations está diseñada para el análisis forense de seguridad: permite construir un árbol de investigación con consultas DQL, extraer IOCs y conservar evidencias reproducibles.'),

  g(130, 'seceval', 'dss-vs-cvss-scenario', 'scenario',
    'Una vulnerabilidad tiene un CVSS teórico de 9.8 (Critical). Sin embargo, el proceso afectado se ejecuta en una red interna aislada sin acceso a internet, no tiene acceso a bases de datos y no existen exploits públicos. ¿Cómo reflejará Davis Security Score (DSS) esta situación?',
    [
      'Mantendrá obligatoriamente la puntuación en 10.0.',
      'Calculará un DSS significativamente más bajo (Medium o Low) reflejando que la falta de exposición y la ausencia de activos alcanzables reduce drásticamente el riesgo real de explotación.',
      'Bloqueará el servidor inmediatamente de forma preventiva.',
      'Borrará el clúster de Dynatrace.',
    ], 1,
    'DSS prioriza con inteligencia contextual: al no existir exposición pública ni datos alcanzables, el riesgo real en producción se reduce frente a la severidad teórica del CVE.'),

  g(131, 'codelevelrules', 'monitoring-rules-clv', 'knowledge',
    '¿Para qué sirven las reglas de monitorización de Code-Level Vulnerabilities (CLV)?',
    [
      'Para definir qué Process Groups o servicios deben ser incluidos o excluidos del análisis profundo de vulnerabilidades a nivel de código.',
      'Para cambiar el tipo de letra del código fuente de los desarrolladores.',
      'Para evitar que los programadores utilicen comentarios en sus scripts.',
      'Para apagar los servidores los dominios pares.',
    ], 0,
    'Las reglas de monitorización de CLV permiten acotar el alcance del análisis de código propio a los Process Groups relevantes de la organización.'),

  g(132, 'security', 'api-permission-security', 'precision',
    'En la API de Dynatrace (Environment API), ¿qué token scope se utiliza habitualmente para consultar los problemas de seguridad detectados?',
    [
      'securityProblems.read',
      'vulnerabilities.delete',
      'appsec.write_all',
      'admin.super_token',
    ], 0,
    'El scope de API oficial para lectura de incidencias y problemas de seguridad es `securityProblems.read`.'),

  g(133, 'investigationtime', 'timeframe-investigation', 'knowledge',
    'Al realizar una investigación forense de seguridad tras un incidente, ¿por qué es fundamental acotar una ventana temporal estricta?',
    [
      'Porque los ordenadores explotan si se analiza más de un día.',
      'Para concentrar el análisis en el periodo exacto del compromiso, reduciendo el ruido de telemetría y optimizando el volumen de datos escaneados en Grail.',
      'Porque la ley prohíbe analizar datos de más de 1 hora.',
      'Para evitar que los atacantes sepan qué hora es.',
    ], 1,
    'Fijar un timeframe estricto limita la búsqueda a la ventana temporal del ataque, facilitando la correlación de logs y trazas y minimizando el procesamiento de datos innecesarios.'),

  g(134, 'thirdparty', 'cve-details-in-app', 'knowledge',
    'Al inspeccionar una vulnerabilidad Third-Party en la UI de Dynatrace, ¿qué detalles técnicos proporciona la plataforma?',
    [
      'El CVE ID, enlace a la base de datos NVD, versiones de la librería afectadas, entidades en las que se está ejecutando y recomendación de actualización.',
      'La dirección postal del creador de la librería de código abierto.',
      'El número de teléfono móvil de los hackers que descubrieron el fallo.',
      'El precio que costó programar esa librería.',
    ], 0,
    'La vista de detalle de vulnerabilidad reúne toda la información técnica necesaria para la remediación: identificador CVE, puntuación DSS, librerías y Process Groups afectados y versión de parche recomendada.'),

  g(135, 'security', 'process-restart-after-appsec-enable', 'troubleshooting',
    'Tras activar Application Security en un tenant existente, el administrador observa que no se detectan vulnerabilidades en los procesos Java que llevan 30 días encendidos. ¿Qué debe hacerse?',
    [
      'Comprar más licencias de software.',
      'Reiniciar los procesos de las aplicaciones para que OneAgent inicialice los módulos de instrumentación de seguridad en tiempo de ejecución.',
      'Desinstalar el sistema operativo del servidor.',
      'Desconectar el cable de red.',
    ], 1,
    'La instrumentación de Application Security requiere que el proceso cargue el módulo de seguridad al iniciarse; los procesos en ejecución persistente deben reiniciarse para que comience la inspección.'),

  g(136, 'vulnconcepts', 'security-score-trend', 'knowledge',
    '¿Qué indica la tendencia temporal del Security Score en el cuadro de mando de Application Security de una empresa?',
    [
      'La evolución de la postura global de seguridad: si las acciones de remediación y actualización de software están reduciendo con éxito el riesgo acumulado en el entorno.',
      'El número de empleados que han llegado tarde a la oficina.',
      'La cantidad de gigabytes de memoria RAM comprados en el mes.',
      'El tiempo que falta para que caduque el contrato de Dynatrace.',
    ], 0,
    'La métrica agregada del Security Score refleja la evolución de la madurez de seguridad: una mejora sostenida demuestra que los equipos remedian las vulnerabilidades críticas más rápido de lo que aparecen.'),

  g(137, 'investigations', 'dpl-in-investigations', 'precision',
    '¿Cómo asiste DPL (Dynatrace Pattern Language) al analista de seguridad en la aplicación Investigations?',
    [
      'Permite escribir expresiones de reconocimiento de patrones estructurados para extraer IPs sospechosas, usuarios y comandos ejecutados a partir de texto de logs no estructurado.',
      'Encripta los archivos del servidor para pedir un rescate.',
      'Desinstala las herramientas de desarrollo del equipo de seguridad.',
      'Envía los logs por correo electrónico a un periódico.',
    ], 0,
    'DPL permite crear patrones de extracción en caliente con matchers (`IPADDR`, `TIMESTAMP`, etc.) para convertir texto plano de logs de seguridad en campos consultables y correlacionables.'),

  g(138, 'seceval', 'public-exploit-impact', 'precision',
    'Si un exploit funcional público para un CVE crítico aparece publicado en repositorios como Exploit-DB o GitHub, ¿cómo reacciona automáticamente Davis AI?',
    [
      'Borra la base de datos de la empresa de inmediato.',
      'Actualiza el factor de "Public exploit availability", elevando de forma automática el Davis Security Score (DSS) para priorizar la remediación urgente en los cuadros de mando.',
      'Ignora la noticia porque solo lee información en papel.',
      'Apaga el monitor del administrador de sistemas.',
    ], 1,
    'La inteligencia de amenazas de Dynatrace actualiza en tiempo real el estado de los exploits públicos: si un CVE pasa a tener exploit funcional disponible, el DSS sube automáticamente.'),

  g(139, 'thirdparty', 'vulnerable-functions', 'knowledge',
    '¿Qué valor aporta la capacidad de "Vulnerable functions detection" en el análisis de vulnerabilidades de terceros?',
    [
      'Permite saber no solo si la librería vulnerable está cargada en memoria, sino si la aplicación está ejecutando activamente la función o método específico vulnerable dentro de esa librería.',
      'Prohíbe a los programadores escribir funciones matemáticas en el código.',
      'Obliga a los servidores a usar solo una función por aplicación.',
      'No tiene ninguna utilidad práctica en seguridad.',
    ], 0,
    'La detección de funciones vulnerables aporta máxima precisión: confirma si el código propio está invocando el método exacto comprometido de la dependencia o si es código muerto.'),

  g(140, 'security', 'summary-appsec', 'knowledge',
    'En conclusión, ¿cuál es la ventaja diferencial de Dynatrace Application Security frente a los escáneres estáticos de código tradicionales?',
    [
      'Que Dynatrace analiza el riesgo real en tiempo de ejecución (runtime) con contexto topológico vivo de producción, eliminando el ruido de falsos positivos teóricos que nunca se ejecutan.',
      'Que Dynatrace no necesita servidores para funcionar.',
      'Que Dynatrace solo analiza aplicaciones escritas en lenguaje HTML.',
      'Que Dynatrace es un software gratuito sin soporte.',
    ], 0,
    'La observabilidad aplicada a la seguridad: al evaluar en runtime con el grafo Smartscape, Dynatrace erradica el 90% del ruido de escáneres estáticos y prioriza lo que está verdaderamente expuesto.'),

  // =========================================================================
  // DOMINIO 8: AUTOMATION & WORKFLOWS (G-141 a G-160)
  // =========================================================================
  g(141, 'workflowsecurity', 'service-user-permission', 'precision',
    '¿Qué permiso IAM es indispensable para poder configurar un Service User como actor de ejecución en un Workflow corporativo desatendido?',
    [
      'iam:service-users:use',
      'automation:workflows:run',
      'app-engine:apps:install',
      'storage:bucket-definitions:write',
    ], 0,
    'Para vincular un Service User como actor de un workflow y asegurar que se ejecute de forma desatendida se requiere el permiso IAM `iam:service-users:use`.'),

  g(142, 'workflowsecurity', 'workflows-write-permission', 'precision',
    '¿Qué permiso IAM se requiere para crear, editar la estructura de tareas o actualizar un Workflow en AutomationEngine?',
    [
      'automation:workflows:write',
      'automation:workflows:execute',
      'app-engine:functions:write',
      'iam:roles:assign',
    ], 0,
    'El permiso IAM para diseñar, modificar y guardar flujos de trabajo en AutomationEngine es `automation:workflows:write`.'),

  g(143, 'workflowevents', 'filter-length-limit', 'precision',
    'En la configuración de un Event Trigger para activar un Workflow automáticamente, ¿cuál es el límite máximo estricto de longitud de la expresión de filtrado DQL compilada?',
    [
      '100 caracteres.',
      '1.000 caracteres.',
      '10.000 caracteres.',
      'No hay límite de caracteres.',
    ], 1,
    'La expresión de filtrado DQL compilada dentro de un Event Trigger en AutomationEngine tiene un límite máximo de 1.000 caracteres.'),

  g(144, 'workflowevents', 'hourly-execution-limit', 'precision',
    '¿Cuál es el límite máximo documentado de ejecuciones automáticas por hora que puede disparar un Event Trigger en un Workflow?',
    [
      '10 ejecuciones por hora.',
      '1.000 ejecuciones por hora.',
      '100.000 ejecuciones por hora.',
      'Ilimitadas ejecuciones simultáneas.',
    ], 1,
    'Los Event Triggers tienen un límite de seguridad de 1.000 ejecuciones automáticas por hora por cada trigger para prevenir bucles de disparo descontrolados.'),

  g(145, 'workflowsimple', 'simple-workflow-definition', 'knowledge',
    '¿Cuáles son las dos características técnicas que definen a un Simple Workflow en AutomationEngine?',
    [
      'Está compuesto exactamente por 1 trigger y 1 única task directa, y no consume horas de workflow (workflow hours) de la suscripción.',
      'Solo funciona los fines de semana y se escribe en lenguaje ensamblador.',
      'Puede contener hasta 500 tareas simultáneas ejecutadas sin conexión a internet.',
      'Solo puede enviar mensajes por fax a números de teléfono fijos.',
    ], 0,
    'Un Simple Workflow está limitado a 1 trigger y 1 task directa (ej. enviar notificación al abrirse un problema); no computa consumo directo de workflow hours.'),

  g(146, 'workflowjs', 'jinja-in-javascript-task', 'precision',
    'En una acción de tipo "Run JavaScript" dentro de un Workflow, ¿por qué está explícitamente prohibido el uso de expresiones de plantillas Jinja (`{{ ... }}`) en su código de entrada?',
    [
      'Porque Jinja solo funciona en servidores con sistema operativo macOS.',
      'Por razones de seguridad técnica para prevenir inyecciones de código malicioso en runtime; el acceso a datos de tareas previas se gestiona a través de los SDKs nativos de AppEngine.',
      'Porque JavaScript no permite utilizar llaves `{}` en su sintaxis.',
      'Porque Jinja aumenta el tamaño del código fuente en un 500%.',
    ], 1,
    'Seguridad de ejecución: las tareas JavaScript no admiten Jinja para evitar code injection; los parámetros se reciben mediante variables tipadas y llamadas a la API de ejecución.'),

  g(147, 'workflowdql', 'dql-action-result-structure', 'precision',
    'Cuando una tarea de tipo "Execute DQL Query" finaliza con éxito en un Workflow, ¿qué propiedades estructuradas devuelve en su objeto de resultado?',
    [
      '`records` (los registros devueltos), `types` (los tipos de datos de las columnas) y `metadata` (metadatos de ejecución).',
      'Un archivo PDF adjunto con imágenes de gráficos.',
      'Únicamente un número entero con el código de error HTTP.',
      'Una cadena de texto con la biografía del creador de la consulta.',
    ], 0,
    'La acción Execute DQL Query expone `records`, `types` y `metadata`, permitiendo a las tareas sucesoras inspeccionar los registros devueltos mediante expresiones dinámicas.'),

  g(148, 'workflowrun', 'action-result-size-limit', 'precision',
    '¿Cuál es el límite máximo de tamaño permitido para el resultado de ejecución de una acción individual (Action result) en un Workflow?',
    [
      '6 MB (menos el tamaño de los logs generados por la ejecución).',
      '1 GB de datos binarios.',
      '100 KB estrictos.',
      '50 MB de archivos comprimidos.',
    ], 0,
    'El resultado de salida de una acción individual no puede superar 6 MB (restando el volumen de logs de ejecución asociados).'),

  g(149, 'workflowrun', 'workflow-result-size-limit', 'precision',
    '¿Cuál es el tamaño máximo total permitido para el resultado global consolidado de un Workflow (Workflow result)?',
    [
      '1 MB.',
      '10 MB.',
      '500 MB.',
      '1 GB.',
    ], 1,
    'El resultado final consolidado de una ejecución de Workflow (Workflow result) no puede exceder los 10 MB; si lo supera, la ejecución falla.'),

  g(150, 'workflowtriggers', 'problem-vs-davis-trigger', 'precision',
    '¿Cuándo se debe configurar un Problem Trigger en lugar de un Davis Event Trigger en un Workflow?',
    [
      'Cuando se desea reaccionar ante cada anomalía individual aislada de cualquier entidad.',
      'Cuando se desea que el Workflow se active ante la situación agregada y correlacionada del incidente, cuando este se abre, cambia de severidad o se resuelve.',
      'Cuando el servidor está apagado de forma planificada.',
      'Cuando solo se van a consultar métricas de discos duros.',
    ], 1,
    'Problem Trigger reacciona al ciclo de vida del incidente consolidado (open, update, resolve); Davis Event Trigger reacciona ante cada anomalía individual no agrupada.'),

  g(151, 'workflowtriggers', 'draft-vs-live', 'knowledge',
    '¿Cuál es la diferencia de comportamiento entre la versión "Draft" y la versión "Live" de un Workflow?',
    [
      'Draft se ejecuta automáticamente ante eventos y Live solo de forma manual.',
      'Live es la versión publicada oficial que responde a los triggers automáticos (eventos, problemas, horarios); Draft es el borrador en edición que solo puede ejecutarse manualmente para pruebas.',
      'Draft cuesta dinero y Live es gratuito.',
      'No hay diferencia: se ejecutan al mismo tiempo generando resultados duplicados.',
    ], 1,
    'Los triggers automáticos solo disparan la versión Live publicada; la versión Draft permite iterar y realizar pruebas de ejecución manuales sin afectar a producción.'),

  g(152, 'workflowchild', 'run-workflow-action', 'knowledge',
    '¿Qué capacidad permite la acción nativa "Run Workflow" dentro de un flujo de trabajo?',
    [
      'Desinstalar AutomationEngine de la plataforma.',
      'Invocar la ejecución de otro sub-workflow modular hijo pasándole parámetros dinámicos, facilitando el diseño de automatizaciones reutilizables.',
      'Apagar el ordenador del administrador.',
      'Crear una nueva cuenta bancaria para la empresa.',
    ], 1,
    'La acción Run Workflow permite modularizar la automatización invocando sub-workflows hijos como si fueran funciones reutilizables con parámetros propios.'),

  g(153, 'workflowrun', 'task-execution-states', 'knowledge',
    '¿Cuáles de los siguientes son estados posibles en los que puede encontrarse una tarea (Task) dentro de una ejecución de Workflow?',
    [
      'Running, Success, Error, Skipped, Waiting for approval.',
      'Feliz, Triste, Enfadada, Dormida.',
      'Comprada, Vendida, Alquilada, Hipotecada.',
      'Azul, Verde, Roja, Amarilla.',
    ], 0,
    'Estados oficiales del ciclo de vida de una task: Idle, Running, Success, Error, Skipped, Discarded, Canceled y Waiting for approval.'),

  g(154, 'workflowsecurity', 'first-execution-consent', 'scenario',
    'Un usuario ejecuta un Workflow nuevo por primera vez y la plataforma muestra un cuadro de diálogo solicitando consentimiento de autorización. ¿Por qué ocurre esto?',
    [
      'Porque el navegador web sospecha que el usuario no es humano.',
      'Porque AutomationEngine necesita que el usuario autorice explícitamente qué permisos y scopes de su cuenta podrá ejercer el motor de automatización al ejecutar las tareas del flujo.',
      'Porque el usuario debe pagar una tasa en metálico antes de cada ejecución.',
      'Es un fallo de seguridad que obliga a reiniciar el tenant.',
    ], 1,
    'Principio de consentimiento en AutomationEngine: en la primera ejecución interactiva, el usuario debe autorizar los permisos que el motor ejercerá en su nombre.'),

  g(155, 'workflowevents', 'schedule-triggers-timezone', 'scenario',
    'Un equipo de operaciones en Tokio (UTC+9) programa un Workflow para generar un informe diario a las 08:00 AM hora local. ¿Qué precaución de configuración debe verificarse?',
    [
      'Cambiar el idioma del teclado del servidor a japonés.',
      'Configurar explícitamente el huso horario (Timezone) en la definición del Schedule Trigger para evitar que se ejecute a las 08:00 AM UTC (lo que equivaldría a las 17:00 en Tokio).',
      'Esperar a que cambie la estación del año.',
      'Los workflows solo pueden ejecutarse a medianoche.',
    ], 1,
    'Los triggers programados por horario (Schedule) exigen definir el huso horario adecuado para asegurar que la tarea se lance en la hora local deseada del equipo responsable.'),

  g(156, 'workflowsimple', 'simple-workflow-upgrade', 'precision',
    'Si un usuario añade una segunda tarea a un Simple Workflow existente, ¿qué sucede con la clasificación y consumo de ese flujo?',
    [
      'El workflow se borra de forma automática e irreversible.',
      'Deja de ser un Simple Workflow y pasa a ser un Workflow estándar con todas sus capacidades de orquestación, computando el consumo correspondiente en la suscripción.',
      'El tenant se bloquea hasta final de mes.',
      'Se prohíbe añadir segundas tareas en cualquier caso.',
    ], 1,
    'En el momento en que un Simple Workflow incorpora una segunda tarea o lógica de bifurcación, asciende a Workflow estándar.'),

  g(157, 'workflowdql', 'jinja-conditional-execution', 'precision',
    'En la configuración de condiciones de una tarea posterior a una consulta DQL, ¿qué expresión Jinja evalúa si la consulta devolvió al menos un registro?',
    [
      '{{ result("query_task")["records"] | length > 0 }}',
      '{{ query_task.hasRecords == true }}',
      'if query_task > 0 then true',
      'eval(records > 0)',
    ], 0,
    'La sintaxis Jinja oficial para evaluar la cantidad de registros devueltos por una tarea DQL previa es `{{ result("query_task")["records"] | length > 0 }}`.'),

  g(158, 'workflowrun', 'execution-retries', 'knowledge',
    '¿Cómo gestiona AutomationEngine las tareas que fallan temporalmente debido a errores de red en peticiones HTTP hacia servicios externos?',
    [
      'Borra el workflow del sistema.',
      'Permite configurar políticas de reintento automático (Retries) con número máximo de intentos e intervalos de espera exponenciales antes de marcar la tarea como fallida.',
      'Apaga el servidor que aloja la aplicación externa.',
      'Envía una carta al proveedor de internet.',
    ], 1,
    'Las políticas de reintento (Retries) en tareas de AutomationEngine gestionan fallos transitorios reintentando la ejecución con retroceso exponencial de forma controlada.'),

  g(159, 'workflowsecurity', 'prevent-runaway-loops', 'scenario',
    'Un desarrollador diseña un Workflow que se activa cuando entra un Business Event y su acción principal genera otro Business Event del mismo tipo. ¿Qué riesgo grave existe y cómo lo previene la plataforma?',
    [
      'No hay ningún riesgo; es la arquitectura recomendada por Dynatrace.',
      'Riesgo de bucle infinito descontrolado; la plataforma lo previene mediante el límite estricto de 1.000 ejecuciones automáticas por hora por trigger y auditoría de eventos de sistema.',
      'El ordenador cliente se queda sin espacio de almacenamiento.',
      'El navegador web cierra la sesión del usuario.',
    ], 1,
    'Los bucles de disparo autorreferenciales (trigger loop) son prevenidos activamente por los límites de seguridad de AutomationEngine (máximo 1.000 ejecuciones/hora por trigger).'),

  g(160, 'automation', 'summary-automation', 'knowledge',
    'En conclusión, ¿por qué Workflows y AutomationEngine están diseñados para orquestación y no como herramientas de ingestión o exportación masiva de datos?',
    [
      'Porque están pensados para ejecutar lógica operativa, remediación y notificaciones con cargas de datos acotadas; para movimiento y transformación masiva de petabytes de datos se debe utilizar OpenPipeline.',
      'Porque los workflows no tienen conexión a internet.',
      'Porque solo pueden ejecutarse en ordenadores portátiles con batería completa.',
      'Porque Dynatrace prohíbe automatizar procesos en producción.',
    ], 0,
    'Separación de responsabilidades de arquitectura: Workflows es un orquestador de decisiones y acciones operativas; OpenPipeline es el motor de procesamiento en streaming para grandes volúmenes de datos.'),

  // =========================================================================
  // DOMINIO 9: INGESTION & OPENPIPELINE (G-161 a G-180)
  // =========================================================================
  g(161, 'openstage', 'openpipeline-three-stages', 'precision',
    '¿Cuáles son las tres etapas secuenciales de procesamiento que estructuran el ciclo de vida de los datos en OpenPipeline?',
    [
      'Download → Compile → Run.',
      'Ingest → Process → Route.',
      'Read → Write → Delete.',
      'Filter → Search → Display.',
    ], 1,
    'OpenPipeline organiza el procesamiento de datos entrantes en tres etapas obligatorias y secuenciales: Ingest (admisión y metadata), Process (transformación y enmascaramiento) y Route (destino en buckets).'),

  g(162, 'openpipeline', 'injected-attributes-source', 'precision',
    'Durante el tránsito de la telemetría a través de OpenPipeline, ¿qué atributos del sistema se inyectan para permitir auditoría y reglas condicionales?',
    [
      'Atributos con el prefijo `dt.openpipeline.source.*` y `dt.openpipeline.stage`.',
      'Variables de entorno de Windows NT.',
      'La dirección postal del remitente del paquete.',
      'El número de serie del disco duro del servidor SaaS.',
    ], 0,
    'OpenPipeline inyecta metadatos de auditoría como `dt.openpipeline.source.type` y `dt.openpipeline.stage` para identificar el origen y fase del dato.'),

  g(163, 'logapi', 'payload-limits-log-ingest', 'precision',
    'En la ingestión de logs a través de la Log Ingest API mediante peticiones HTTP POST, ¿cuál es el límite estándar de registros por solicitud y qué compresión se recomienda?',
    [
      'Máximo 10 registros sin compresión.',
      'Hasta 1.000 registros por payload HTTP POST, recomendando el uso de compresión `gzip`.',
      'Exactamente 1 millón de registros en formato XML plano.',
      'Ilimitados registros en conexiones UDP sin cifrar.',
    ], 1,
    'El endpoint de Log Ingest API soporta hasta 1.000 registros por payload HTTP POST y recomienda `Content-Encoding: gzip` para optimizar ancho de banda.'),

  g(164, 'logapi', 'token-scope-logs-ingest', 'precision',
    '¿Qué scope de API Token es obligatorio para autenticar peticiones contra la Log Ingest API de Dynatrace?',
    [
      'logs.ingest',
      'storage.write',
      'agent.install',
      'admin.super_user',
    ], 0,
    'El scope de token requerido para autorizar la ingestión de logs vía API HTTP REST es estrictamente `logs.ingest`.'),

  g(165, 'logoa', 'syslog-activegate-port', 'precision',
    '¿En qué puerto de red estándar escucha el receptor de Syslog integrado en un ActiveGate para recibir logs de dispositivos de red y reenviarlos a Grail?',
    [
      'Puerto 53 (DNS).',
      'Puerto 514 (UDP/TCP).',
      'Puerto 80 (HTTP).',
      'Puerto 3389 (RDP).',
    ], 1,
    'ActiveGate puede configurarse como receptor de Syslog de red en el puerto estándar RFC 514 (UDP y TCP) para ingestar logs de switches, firewalls y routers.'),

  g(166, 'openflow', 'complete-data-path', 'knowledge',
    '¿Cuál es el recorrido secuencial completo de un dato de telemetría desde su generación hasta su análisis en Dynatrace?',
    [
      'Origen/Agente → Transporte seguro (HTTPS 443) → Autenticación/Endpoint → OpenPipeline (Ingest, Process, Route) → Persistencia en Buckets de Grail → Consulta y visualización con DQL.',
      'Navegador web → Cable de corriente → Teclado → Base de datos.',
      'Servidor → Disco de copia de seguridad → Papelera de reciclaje → DQL.',
      'OneAgent → Impresora de red → Escáner → Grail.',
    ], 0,
    'El camino del dato: Origen → Transporte TLS → Endpoint → Procesamiento en streaming en OpenPipeline → Almacenamiento columnar en Grail → Consulta analítica con DQL.'),

  g(167, 'openpipeline', 'masking-in-openpipeline', 'scenario',
    'Una organización bancaria necesita asegurar que ningún número de tarjeta de crédito (PAN) o dato personal sensible llegue jamás a persistirse en los buckets de logs de Grail. ¿En qué etapa debe aplicarse el enmascaramiento?',
    [
      'En la consulta DQL que escriben los analistas en los Notebooks.',
      'En la etapa `Process` de OpenPipeline mediante reglas de masking de datos en tiempo de streaming antes del almacenamiento.',
      'En el monitor de la pantalla del usuario mediante un filtro de privacidad físico.',
      'No se puede enmascarar datos en streaming en Dynatrace.',
    ], 1,
    'El enmascaramiento de datos sensibles (PII/PCI-DSS) debe realizarse en la etapa `Process` de OpenPipeline para que los datos confidenciales nunca toquen el almacenamiento permanente.'),

  g(168, 'openpipeline', 'drop-rules-cost', 'scenario',
    'Un servidor de pruebas genera millones de líneas de log de depuración (DEBUG) que no tienen utilidad en producción y consumen almacenamiento innecesario. ¿Cómo se gestiona esto en OpenPipeline?',
    [
      'Apagando el servidor físico.',
      'Definiendo una regla de descarte (`Drop`) en OpenPipeline para descartar registros con `loglevel == "DEBUG"` procedentes de ese entorno antes de la persistencia.',
      'Creando 50 dashboards para leer todos los logs.',
      'Cambiando el idioma de los logs a español.',
    ], 1,
    'Las reglas de descarte (`Drop`) en OpenPipeline filtran y eliminan tráfico prescindible en streaming sin incurrir en costes de retención en Grail.'),

  g(169, 'logingest', 'timestamp-rejection-windows', 'troubleshooting',
    'Un sistema batch envía logs históricos a la Log Ingest API con marcas de tiempo (timestamps) de hace 6 meses. La API devuelve códigos de error o descarta los registros. ¿Por qué ocurre esto?',
    [
      'Porque la API no permite enviar números impares.',
      'Porque la ingestión de logs tiene ventanas de tiempo límite de aceptación hacia el pasado y el futuro para evitar la corrupción de índices temporales en streaming.',
      'Porque los servidores de Dynatrace solo funcionan en tiempo presente absoluto.',
      'Porque los logs antiguos están prohibidos por la ley de telecomunicaciones.',
    ], 1,
    'La ingestión de logs valida la marca de tiempo: eventos con timestamps excesivamente desfasados en el pasado o en el futuro son rechazados o ajustados según las reglas del endpoint.'),

  g(170, 'otel', 'otel-endpoints-protocol', 'knowledge',
    '¿Qué protocolos de transporte estándar soporta Dynatrace para recibir telemetría OpenTelemetry Protocol (OTLP)?',
    [
      'OTLP sobre gRPC y OTLP sobre HTTP (con payloads protobuf o JSON).',
      'Únicamente mensajes SMS de telefonía móvil.',
      'Transferencia de archivos por disquete magnético.',
      'Protocolo IRC de chat de internet.',
    ], 0,
    'Dynatrace expone endpoints nativos compatibles con OTLP tanto para transporte gRPC como para HTTP/protobuf y HTTP/JSON.'),

  g(171, 'pipelinegroups', 'pipeline-groups-purpose', 'knowledge',
    '¿Qué función cumplen los Pipeline Groups en la configuración de OpenPipeline?',
    [
      'Agrupar múltiples pipelines lógicos para facilitar la delegación de permisos de administración (Owner-based access control) y gobernar reglas por dominios o equipos.',
      'Cambiar el color de los cables de red del centro de datos.',
      'Unificar los teclados de los administradores en un solo USB.',
      'Desconectar el cortafuegos cada 10 minutos.',
    ], 0,
    'Pipeline Groups organizan las canalizaciones de datos y permiten aplicar control de acceso basado en propietarios (owner-based access control) por equipo de trabajo.'),

  g(172, 'logrules', 'custom-bucket-assignment', 'precision',
    '¿En qué etapa de OpenPipeline se evalúan las condiciones para dirigir un registro hacia un bucket de almacenamiento específico (ej. `security_logs` en vez de `default_logs`)?',
    [
      'En la etapa `Route`.',
      'En el navegador web del usuario al iniciar sesión.',
      'En la BIOS de la placa base del host monitorizado.',
      'Después de que el log haya sido borrado.',
    ], 0,
    'La asignación del bucket de destino se decide y ejecuta formalmente en la etapa `Route` de OpenPipeline.'),

  g(173, 'logautodiscovery', 'autodiscovery-oneagent', 'knowledge',
    '¿Cómo descubre OneAgent los archivos de log en un servidor para su monitorización automática?',
    [
      'Exige que el administrador escriba la ruta absoluta de cada archivo en un formulario en papel.',
      'Escanea los descriptores de archivos abiertos por los procesos monitorizados y analiza directorios estándar del sistema operativo según reglas de autodescubrimiento.',
      'OneAgent no puede descubrir archivos de log de forma automática.',
      'Borra los archivos de log para comprobar cuáles vuelven a crearse.',
    ], 1,
    'OneAgent analiza los procesos en ejecución y los file handles abiertos para autodescubrir archivos de log activos sin configuración manual exhaustiva.'),

  g(174, 'pipelineforward', 'forwarding-destinations', 'knowledge',
    '¿Qué capacidad ofrece la función de Forwarding en OpenPipeline?',
    [
      'Permite reenviar una copia de los datos procesados en streaming hacia destinos externos (como buckets de Amazon S3 o sistemas SIEM) además de persistirlos en Grail.',
      'Reenvía correos personales a los teléfonos de los empleados.',
      'Cambia la dirección IP del router de salida a internet.',
      'Borra los datos de la competencia.',
    ], 0,
    'Data Forwarding en OpenPipeline permite enrutar telemetría hacia destinos de almacenamiento externo o plataformas de seguridad secundarias en tiempo real.'),

  g(175, 'otel', 'otel-troubleshooting-context', 'troubleshooting',
    'Una aplicación instrumentada con OpenTelemetry envía trazas y métricas, pero en la interfaz de Dynatrace no se relacionan con ningún Host o Service de Smartscape. ¿Cuál es la causa técnica más probable?',
    [
      'Dynatrace es incompatible con OpenTelemetry.',
      'El exportador de OpenTelemetry no está enviando los resource attributes semánticos estándar (como `service.name`, `host.id` o `k8s.pod.name`) necesarios para vincular el span a la entidad.',
      'El servidor tiene demasiada memoria RAM instalada.',
      'Falta pagar una licencia en metálico por cada traza.',
    ], 1,
    'Para que Dynatrace vincule la telemetría OTLP con las entidades de Smartscape, el SDK o Collector debe propagar los Resource Attributes estándar de OpenTelemetry (`service.name`, etc.).'),

  g(176, 'logoa', 'log-enrichment-metadata', 'precision',
    '¿Qué atributo añade automáticamente OneAgent a los logs capturados de un contenedor de Kubernetes que facilita su búsqueda en DQL?',
    [
      'El precio del contenedor en el mercado internacional.',
      'Atributos como `k8s.pod.name`, `k8s.container.name` y `k8s.namespace.name`.',
      'El número de teléfono del desarrollador que compiló la imagen Docker.',
      'La temperatura del procesador del cliente.',
    ], 1,
    'OneAgent enriquece automáticamente los logs de contenedores con los metadatos contextuales de Kubernetes (`k8s.pod.name`, `k8s.container.name`, etc.).'),

  g(177, 'openpipeline', 'matcher-order-importance', 'precision',
    'En una lista de reglas de procesamiento dentro de OpenPipeline, ¿por qué es fundamental el orden en que están colocadas las reglas?',
    [
      'El orden no importa porque se ejecutan en orden alfabético.',
      'Porque las reglas se evalúan de arriba a abajo secuencialmente; una regla más general colocada antes puede interceptar o descartar un registro antes de que alcance una regla más específica.',
      'Porque las reglas pares solo funcionan los días pares.',
      'Porque OpenPipeline solo ejecuta la última regla de la lista.',
    ], 1,
    'Evaluación secuencial: OpenPipeline procesa las reglas en estricto orden de prioridad descendente; una regla mal ordenada puede bloquear transformaciones posteriores.'),

  g(178, 'openstage', 'openpipeline-test-records', 'knowledge',
    'Antes de desplegar una regla compleja de extracción o enmascaramiento en OpenPipeline en producción, ¿qué herramienta proporciona la UI para validar su comportamiento?',
    [
      'Un entorno de simulación interactivo donde probar la regla contra registros de telemetría reales o sintéticos de muestra antes de guardarla.',
      'No existe ninguna forma de probar reglas antes de producción.',
      'Enviar los datos a un servidor de videojuegos para comprobar si falla.',
      'Imprimir la regla en una hoja de papel.',
    ], 0,
    'OpenPipeline incluye una herramienta interactiva de test/preview para verificar el resultado exacto de la transformación o máscara sobre registros de prueba antes de publicarla.'),

  g(179, 'otel', 'w3c-trace-propagation', 'knowledge',
    '¿Qué estándar de propagación de contexto en cabeceras HTTP (`traceparent`) utiliza Dynatrace para mantener la continuidad del distributed tracing entre servicios?',
    [
      'W3C Trace Context.',
      'El protocolo de ficheros NFS.',
      'Las cookies de sesión de Netscape Navigator.',
      'El código Morse por pulsos de red.',
    ], 0,
    'Dynatrace utiliza de forma nativa la especificación abierta W3C Trace Context (`traceparent` y `tracestate`) para la interoperabilidad de trazas distribuidas.'),

  g(180, 'openflow', 'summary-ingestion', 'knowledge',
    'En conclusión, ¿por qué OpenPipeline es considerado un pilar de gobernanza y eficiencia de costes en la plataforma?',
    [
      'Porque permite a las organizaciones decidir en tiempo de streaming qué datos se enriquecen, qué datos sensibles se enmascaran, qué ruido se descarta y dónde se almacena cada señal antes de facturar.',
      'Porque elimina la necesidad de tener ingenieros de sistemas en la plantilla.',
      'Porque bloquea todas las conexiones salientes a internet.',
      'Porque duplica el tamaño de los datos de forma obligatoria.',
    ], 0,
    'OpenPipeline otorga control absoluto sobre el ciclo de vida del dato: filtra ruido, protege la privacidad con masking y asigna buckets y retención según el valor real de la información.'),

  // =========================================================================
  // DOMINIO 10: OTHER - SMARTSCAPE, ENTITIES & HUB (G-181 a G-200)
  // =========================================================================
  g(181, 'entityquery', 'entities-permission-read', 'precision',
    '¿Qué permiso IAM es indispensable para consultar el catálogo de entidades monitorizadas y sus relaciones topológicas en Grail mediante DQL?',
    [
      'storage:entities:read',
      'app-engine:apps:install',
      'automation:workflows:run',
      'storage:logs:write',
    ], 0,
    'Para consultar las tablas de entidades (`fetch dt.entity.*`) en Grail se requiere estrictamente el permiso IAM `storage:entities:read`.'),

  g(182, 'entityquery', 'fetch-entity-syntax', 'knowledge',
    '¿Cuál es la sintaxis canónica de DQL en Latest Dynatrace para consultar la lista de todos los servidores físicos y virtuales monitorizados?',
    [
      'fetch dt.entity.host',
      'get all hosts from infrastructure',
      'select * from hosts_table',
      'query.entities.server_list',
    ], 0,
    'En Grail, las entidades de infraestructura de tipo Host se consultan con el comando oficial `fetch dt.entity.host`.'),

  g(183, 'smartscape', 'runs-service-instance-relation', 'precision',
    'En el registro de una entidad de tipo Service en Grail, ¿qué campo de tipo array modela las relaciones topológicas hacia las instancias que lo ejecutan?',
    [
      'runs[dt.entity.service_instance]',
      'instances.list',
      'service_to_pgi_mapping',
      'topology.children',
    ], 0,
    'El modelo de entidades en Grail representa las relaciones topológicas en atributos tipados como `runs[dt.entity.service_instance]` para indicar las instancias que sirven ese servicio.'),

  g(184, 'smartscape', 'five-layers-strict-order', 'knowledge',
    '¿Cuál es el orden estricto de las 5 capas de Smartscape desde la infraestructura física hasta la experiencia final de usuario?',
    [
      'Data Center → Host → Process Group → Service → Application.',
      'Application → Service → Process Group → Host → Data Center.',
      'Node → Pod → Container → Process → OS.',
      'Internet → Router → Switch → Cable → Pantalla.',
    ], 0,
    'La jerarquía de 5 capas en Smartscape fluye de abajo a arriba: Data Center → Host → Process Group → Service → Application.'),

  g(185, 'topologyview', 'vertical-vs-horizontal', 'precision',
    'En la visualización de topología de Smartscape, ¿qué indican las líneas de conexión verticales frente a las horizontales?',
    [
      'Las verticales indican alojamiento o dependencia de infraestructura (ej. un servicio que corre en un proceso); las horizontales representan comunicaciones de red o llamadas de servicio (calls).',
      'Las verticales son de color azul y las horizontales no existen.',
      'Las horizontales indican que el servidor está apagado.',
      'No hay diferencia: se dibujan al azar según la resolución de la pantalla.',
    ], 0,
    'Relaciones en Smartscape: Vertical = pertenencia/hospedaje (`runs on`); Horizontal = flujo de tráfico y llamadas transaccionales (`calls` / `network communication`).'),

  g(186, 'entityquery', 'entity-lookup-enrichment', 'scenario',
    'Un analista tiene una consulta de logs que contiene el campo `dt.entity.host`. Desea añadir el nombre legible del servidor y la versión del sistema operativo en el mismo reporte. ¿Qué comando DQL debe utilizar?',
    [
      'Un `lookup` cruzando `dt.entity.host` contra la tabla `dt.entity.host`.',
      'Un `delete` para borrar los logs sin nombre.',
      'Un `format-disk` en el servidor.',
      'Escribir los nombres de los servidores a mano en una hoja de papel.',
    ], 0,
    'El enriquecimiento topológico se realiza con `lookup`: cruza el identificador de entidad con la tabla `dt.entity.host` para extraer atributos como `entity.name` u `os.type`.'),

  g(187, 'smartscapeongrail', 'smartscape-evolution-grail', 'knowledge',
    '¿Cuál es la ventaja de la evolución de Smartscape on Grail frente a la topología Classic?',
    [
      'Que permite consultar el grafo completo de entidades, sus cambios históricos de relaciones y su estado mediante consultas DQL directamente en Notebooks y Dashboards.',
      'Que convierte la topología en un archivo de imagen estático no interactivo.',
      'Que solo funciona si los servidores están apagados.',
      'Que prohíbe el uso de Kubernetes.',
    ], 0,
    'Smartscape on Grail transforma el grafo topológico en datos vivos consultables mediante DQL, permitiendo auditar la evolución de dependencias y cambios de infraestructura en el tiempo.'),

  g(188, 'hubextensions', 'extensions-2-lifecycle', 'knowledge',
    '¿Cuáles son los pasos que componen el ciclo de vida de una extensión Extensions 2.0 desplegada desde Dynatrace Hub?',
    [
      'Descubrimiento en catálogo → Instalación en el tenant → Configuración de credenciales y endpoints en Settings → Asignación a ActiveGate group → Ingestión y consulta de métricas en Grail.',
      'Descargar el código, compilarlo con un compilador de C++ y copiarlo en un disquete.',
      'Mirar la pantalla durante 15 minutos sin pulsar ninguna tecla.',
      'Reiniciar el clúster de Dynatrace cada mañana.',
    ], 0,
    'El ciclo de Extensions 2.0: descubrimiento en Hub, instalación declarativa, configuración de settings y endpoints hacia un ActiveGate group y verificación de métricas producidas.'),

  g(189, 'logsapp', 'facets-filtering', 'knowledge',
    'En la aplicación Logs de Dynatrace, ¿qué función cumplen los "Facets" situados en el panel lateral izquierdo?',
    [
      'Mostrar anuncios publicitarios de tiendas online.',
      'Permitir el filtrado interactivo rápido por atributos frecuentes (loglevel, host.name, k8s.container.name, service.name) mostrando el recuento de ocurrencias de cada valor.',
      'Cambiar el fondo de pantalla del sistema operativo.',
      'Borrar los archivos de log del servidor.',
    ], 1,
    'Los Facets en la Logs App proporcionan agregaciones interactivas por dimensiones comunes (loglevel, host, service) para filtrar con un solo clic.'),

  g(190, 'smartscape', 'problem-graph-root-cause', 'scenario',
    'Al abrir la vista de Problem Graph durante un incidente, la entidad causante se muestra resaltada en el centro del grafo con flechas dirigidas hacia los servicios afectados. ¿Qué representa esta visualización?',
    [
      'El árbol de propagación de impacto de Davis AI, que demuestra visualmente cómo el fallo en la entidad raíz degradó a las entidades dependientes.',
      'Un mapa de carreteras de la ciudad de Viena.',
      'Un esquema de cableado eléctrico de la oficina.',
      'Un fallo gráfico del monitor que requiere reiniciar el ordenador.',
    ], 0,
    'Problem Graph ilustra el razonamiento causal de Davis AI: muestra la entidad culpable (Root Cause) y la cascada de dependencias afectadas en el grafo de Smartscape.'),

  g(191, 'entityquery', 'is-instance-of-relation', 'precision',
    'En el modelo de datos de Grail, ¿qué relación topológica vincula a una Process Group Instance (PGI) con su Process Group (PG) padre?',
    [
      'is_instance_of',
      'belongs_to_hardware',
      'runs_inside',
      'parent_switch',
    ], 0,
    'El atributo de relación topológica que vincula una PGI con su definición de grupo lógico en Grail es `is_instance_of`.'),

  g(192, 'logsapp', 'log-content-analysis', 'knowledge',
    '¿Qué ventaja ofrece el análisis de contenido de logs con schema-on-read en la Logs App?',
    [
      'Permite buscar patrones textuales o extraer campos en caliente con DPL sin necesidad de haber predefinido índices de base de datos antes de la ingestión del log.',
      'Obliga a los logs a no tener más de 10 palabras.',
      'Permite borrar los logs sin que nadie se entere.',
      'Impide el uso de expresiones regulares.',
    ], 0,
    'Schema-on-read en la Logs App permite analizar y extraer campos dinámicamente sobre cualquier texto de log en el momento de la consulta.'),

  g(193, 'smartscape', 'service-to-service-calls', 'knowledge',
    'En Smartscape, si el servicio `FrontendApp` realiza peticiones HTTP al servicio `BackendAPI`, ¿cómo se representa esta relación horizontal?',
    [
      '`FrontendApp` calls `BackendAPI`.',
      '`FrontendApp` runs on `BackendAPI`.',
      '`FrontendApp` deletes `BackendAPI`.',
      '`FrontendApp` contains `BackendAPI`.',
    ], 0,
    'Las llamadas entre servicios se modelan mediante la relación horizontal `calls` (`Service calls Service`).'),

  g(194, 'entityquery', 'cross-app-drilldown', 'scenario',
    'Un operador está analizando un log de error en la Logs App y desea investigar las métricas de CPU del Host donde se originó ese log. ¿Cómo debe proceder?',
    [
      'Copiar el ID del host a mano en una hoja de papel y apagar el ordenador.',
      'Hacer clic en el enlace contextual de la entidad `host.name` o `dt.entity.host` para realizar un drilldown directo hacia la vista detallada del Host preservando el timeframe.',
      'Reinstalar OneAgent en el host.',
      'Borrar el registro de log para que no cause confusión.',
    ], 1,
    'La navegación contextual de Dynatrace permite hacer drilldown directo haciendo clic sobre el nombre o ID de la entidad para abrir su análisis detallado manteniendo el timeframe activo.'),

  g(195, 'hubextensions', 'activegate-extensions-requirement', 'precision',
    'Al instalar una extensión en Hub para monitorizar dispositivos de red vía SNMP o bases de datos remotas, ¿qué componente de infraestructura es indispensable asignar para ejecutar las comprobaciones?',
    [
      'Un ActiveGate perteneciente a un ActiveGate Group configurado con conectividad de red hacia los dispositivos de destino.',
      'Una tarjeta de red inalámbrica Bluetooth.',
      'Un teléfono móvil inteligente.',
      'Un monitor de televisión con resolución 4K.',
    ], 0,
    'Las extensiones que realizan monitorización remota sin agente (SNMP, bases de datos remotas, vCenter) se ejecutan sobre un ActiveGate Group con acceso de red a los objetivos.'),

  g(196, 'smartscape', 'entity-lifetime-concept', 'precision',
    'Si un contenedor o pod efímero de Kubernetes finaliza su ejecución, ¿qué ocurre con su representación en la topología de Smartscape?',
    [
      'Se borra en el mismo milisegundo de toda la base de datos de Dynatrace.',
      'Permanece visible en el grafo durante su ventana de vida histórica (lifetime) para permitir investigaciones forenses de problemas ocurridos mientras estaba activo, marcándose como inactivo tras un periodo de gracia.',
      'Provoca la caída de todos los servidores del clúster.',
      'Se convierte automáticamente en un servidor físico de metal.',
    ], 1,
    'Las entidades efímeras conservan su presencia histórica en el grafo durante su lifetime para no destruir el contexto de análisis de incidentes pasados.'),

  g(197, 'logsapp', 'log-query-export', 'knowledge',
    '¿Qué acción permite la Logs App para trasladar una investigación de logs interactiva hacia un análisis más profundo y reproducible?',
    [
      'Pulsar el botón "Open in Notebook" o "View in DQL" para exportar la consulta exacta con sus filtros hacia un Notebook colaborativo.',
      'Imprimir todos los logs en una impresora matricial de agujas.',
      'Guardar los logs en una cinta VHS de vídeo.',
      'No se puede exportar la consulta de ninguna forma.',
    ], 0,
    'El botón "Open in Notebook" traslada inmediatamente la consulta de logs con sus filtros temporales a un Notebook para continuar la investigación forense.'),

  g(198, 'entityquery', 'process-group-vs-instance-dql', 'precision',
    'En DQL, ¿cuál es la diferencia entre consultar `fetch dt.entity.process_group` y consultar `fetch dt.entity.process_group_instance`?',
    [
      '`dt.entity.process_group` devuelve las agrupaciones lógicas de procesos; `dt.entity.process_group_instance` devuelve cada una de las instancias de ejecución concretas de esos procesos en hosts específicos.',
      '`process_group` solo existe para Windows y `instance` para Linux.',
      'No existe la entidad `process_group_instance` en Grail.',
      'Son exactamente idénticas sin ninguna diferencia.',
    ], 0,
    '`dt.entity.process_group` agrupa la definición lógica (ej. clúster Tomcat); `dt.entity.process_group_instance` identifica la instancia física ejecutándose en un nodo concreto.'),

  g(199, 'smartscape', 'datacenter-mapping-cloud', 'knowledge',
    'En entornos de nube pública como AWS o Azure, ¿a qué entidad de infraestructura suele corresponder un Data Center en Smartscape?',
    [
      'A una Availability Zone (Zona de Disponibilidad) o región cloud donde se aprovisionan las máquinas virtuales.',
      'A la sede central del banco donde se pagan las facturas de la nube.',
      'A la cuenta de correo electrónico del arquitecto cloud.',
      'Al cable submarino de fibra óptica intercontinental.',
    ], 0,
    'En entornos cloud, la capa inferior Data Center mapea las Availability Zones o regiones geográficas del proveedor cloud donde residen las instancias.'),

  g(200, 'smartscapeongrail', 'summary-smartscape-hub', 'knowledge',
    'En resumen, ¿cómo completan Smartscape, la gestión de logs y Dynatrace Hub la visión unificada de la plataforma?',
    [
      'Proporcionando el mapa vivo de dependencias (Smartscape), la capacidad de análisis forense textual sin esquemas rígidos (Logs) y el catálogo de extensibilidad continua (Hub) para cualquier arquitectura moderna.',
      'Obligando a las empresas a utilizar un único sistema operativo.',
      'Reemplazando a los programadores de software por inteligencia artificial.',
      'Eliminando la necesidad de almacenar datos en servidores.',
    ], 0,
    'Smartscape, Logs en Grail y Dynatrace Hub cierran el círculo de la observabilidad unificada: contexto topológico vivo, profundidad forense textual y extensibilidad ilimitada sobre una base de datos común.'),
]
