import type { LessonSupplement } from './types'

const doc = (title: string, url: string) => ({ title, url, kind: 'official-docs' as const })

const SRC = {
  sog: doc('Smartscape on Grail', 'https://docs.dynatrace.com/docs/platform/grail/smartscape-on-grail'),
  sscmd: doc('DQL Smartscape commands', 'https://docs.dynatrace.com/docs/platform/grail/dynatrace-query-language/commands/smartscape-commands'),
  sscore: doc('Smartscape core entities (Semantic Dictionary)', 'https://docs.dynatrace.com/docs/semantic-dictionary/model/smartscape/core'),
  concepts: doc('Smartscape concepts', 'https://docs.dynatrace.com/docs/analyze-explore-automate/smartscape/smartscape-concepts'),
  views: doc('Smartscape views', 'https://docs.dynatrace.com/docs/analyze-explore-automate/smartscape/smartscape-views'),
  viewtopology: doc('View topology', 'https://docs.dynatrace.com/docs/analyze-explore-automate/smartscape/smartscape-in-context-views/smartscape-view-topology'),
  problemgraph: doc('Problem graph', 'https://docs.dynatrace.com/docs/analyze-explore-automate/smartscape/smartscape-views/problem-graph'),
  classic: doc('Smartscape Classic', 'https://docs.dynatrace.com/docs/analyze-explore-automate/smartscape-classic'),
  entities: doc('Query monitored entities in Grail (Classic)', 'https://docs.dynatrace.com/docs/platform/grail/querying-monitored-entities'),
  pg: doc('Process groups', 'https://docs.dynatrace.com/docs/observe/infrastructure-observability/process-groups'),
  logs: doc('Log Management and Analytics', 'https://docs.dynatrace.com/docs/analyze-explore-automate/logs'),
  logsapp: doc('Logs app', 'https://docs.dynatrace.com/docs/analyze-explore-automate/logs/lma-logs-app'),
  facets: doc('Logs app: facets', 'https://docs.dynatrace.com/docs/analyze-explore-automate/logs/lma-logs-app/facets'),
  queryfilter: doc('Logs app: query and filter', 'https://docs.dynatrace.com/docs/analyze-explore-automate/logs/lma-logs-app/query-and-filter'),
  surrounding: doc('Surrounding logs', 'https://docs.dynatrace.com/docs/analyze-explore-automate/logs/lma-logs-app/surrounding-logs'),
  patterns: doc('Log patterns', 'https://docs.dynatrace.com/docs/analyze-explore-automate/logs/lma-logs-app/patterns'),
  parse: doc('DQL extraction and parsing commands', 'https://docs.dynatrace.com/docs/platform/grail/dynatrace-query-language/commands/extraction-and-parsing-commands'),
  hub: doc('Dynatrace Hub', 'https://docs.dynatrace.com/docs/manage/hub'),
  manageext: doc('Manage extensions', 'https://docs.dynatrace.com/docs/ingest-from/extensions/manage-extensions'),
  snmp: doc('SNMP extensions', 'https://docs.dynatrace.com/docs/ingest-from/extensions/supported-extensions/data-sources/snmp'),
}

export const otherSupplement: LessonSupplement = {
  moduleId: 'other',
  extend: {
    'deep-smartscape-graph': {
      reason: 'El apartado describía una "jerarquía estricta de 5 capas" con Process Group y relaciones no documentadas (is_instance_of, contained_in). Se corrige a los 5 tiers documentados de Smartscape Classic (G-184, G-185, G-199) y se separa del modelo actual de nodos y edges. Auditoría final: en el tier Processes cada nodo es un proceso, cuya vista Classic más cercana es dt.entity.process_group_instance.',
      corrections: [
        // Primero: solo existe en la celda de la tabla original (antes de que otras correcciones introduzcan instance_of[dt.entity.process_group]).
        { find: 'dt.entity.process_group', replace: 'dt.entity.process_group_instance (ejecución concreta; agrupada en dt.entity.process_group)' },
        { find: 'Smartscape como grafo de entidades y jerarquía de 5 capas', replace: 'Smartscape Classic: 5 tiers y entidades dt.entity.*' },
        { find: 'La topología responde cómo se relacionan componentes en el modelo de datos de Grail.', replace: 'Smartscape Classic organizaba la topología en tiers; las vistas dt.entity.* de Grail exponen esas entidades Classic.' },
        {
          find: 'La topología de Smartscape modela el entorno monitorizado en una jerarquía estricta de 5 capas: Data Center → Host → Process Group → Service → Application. Las relaciones verticales indican alojamiento (`runs on`), mientras que las relaciones horizontales representan comunicaciones de red o llamadas de servicio (`calls`).',
          replace: 'Smartscape Classic presenta el entorno en 5 tiers, de arriba abajo: Applications, Services, Processes, Hosts y Data centers; de la infraestructura a la experiencia de usuario el orden es Data centers → Hosts → Processes → Services → Applications. El eje vertical muestra las dependencias full-stack entre tiers (por ejemplo, servicio → proceso → host) y el eje horizontal muestra las relaciones de llamada entrantes y salientes dentro de cada tier. El tier Data centers indica dónde residen los hosts: ciudades para servidores físicos y, en infraestructura virtual o cloud, nodos etiquetados como VMware data center, AWS Availability Zone o Azure region. El Smartscape actual (app Smartscape y Smartscape on Grail) no se organiza en estos tiers: es un grafo de nodos y edges.',
        },
        {
          find: 'En Grail, las entidades se consultan con comandos dedicados como `fetch dt.entity.host` o `fetch dt.entity.service`. Las relaciones topológicas entre entidades se modelan en atributos de tipo array como `runs[dt.entity.service_instance]` o `is_instance_of`. Para poder consultar el inventario de entidades en Grail mediante DQL se requiere el permiso IAM explícito `storage:entities:read`.',
          replace: 'En el modelo Classic de Grail, las entidades se consultan con vistas como `fetch dt.entity.host` o `fetch dt.entity.service`, y las relaciones se exponen como campos con el nombre de la relación y el tipo de destino (por ejemplo, `instance_of[dt.entity.process_group]` en una process group instance). Consultarlas requiere el permiso `storage:entities:read`. En Latest, la topología se consulta con Smartscape on Grail (`smartscapeNodes`, `smartscapeEdges`, `traverse`).',
        },
        { find: 'Capa Smartscape', replace: 'Tier de Smartscape Classic' },
        { find: 'Entidad Grail Representativa', replace: 'Vista Classic aproximada' },
        { find: 'Atributo de Relación Topológica', replace: 'Qué representa' },
        { find: 'Capa 5: Application', replace: 'Applications' },
        { find: 'calls[dt.entity.service]', replace: 'Experiencia de usuario que llama a servicios' },
        { find: 'Capa 4: Service', replace: 'Services' },
        { find: 'runs[dt.entity.service_instance]', replace: 'Servicios que se ejecutan en procesos' },
        { find: 'Capa 3: Process Group', replace: 'Processes' },
        { find: 'runs_on[dt.entity.host]', replace: 'Procesos que se ejecutan en hosts' },
        { find: 'Capa 2: Host', replace: 'Hosts' },
        { find: 'contained_in[dt.entity.data_center]', replace: 'Máquinas físicas o virtuales' },
        { find: 'Capa 1: Data Center', replace: 'Data centers' },
        { find: 'dt.entity.data_center', replace: '—' },
        { find: 'Ubicación física o cloud region', replace: 'Ciudad, VMware data center, AWS Availability Zone o Azure region' },
      ],
    },
    logs: {
      reason: 'Auditoría final: el ejemplo usa dt.entity.service (ID Classic) sin aclararlo y la nota final era vaga.',
      corrections: [
        { find: 'La función y el campo exactos pueden variar; valida el esquema visible en tu entorno.', replace: 'dt.entity.service contiene el entity ID Classic del servicio. En Smartscape on Grail, el origen topológico de la señal está en campos dt.smartscape.<type> (para un servicio, dt.smartscape.service) y su nombre se obtiene con getNodeName(dt.smartscape.service).' },
      ],
    },
    'deep-entities-query': {
      reason: 'El ejemplo atribuía runs[dt.entity.service_instance] al servicio; la documentación lo muestra en el host (inversa de runs_on). Auditoría final: el código 403 no está documentado.',
      corrections: [
        { find: 'serán rechazadas con un error de autorización 403.', replace: 'serán rechazadas por falta de permisos.' },
        { find: 'fetch dt.entity.service\n| fields id, entity.name, runs[dt.entity.service_instance]', replace: 'fetch dt.entity.host\n| fieldsAdd runs[dt.entity.service_instance]' },
        { find: 'Consulta de servicios en Grail extrayendo los identificadores de las instancias que los ejecutan.', replace: 'Consulta Classic de hosts que añade los IDs de las service instances que ejecutan (runs es la inversa de runs_on). Para traer sus detalles necesitas expand y lookup (ver el apartado de entidades Classic).' },
      ],
    },
    'dql-dpl': {
      reason: 'R-OTH-11: comportamiento de parse cuando el pattern no coincide.',
      paragraphs: [
        'Si el pattern DPL de `parse` no coincide en un registro, parse no elimina ese registro: los campos extraídos quedan en null (con preserveFieldsOnFailure: true se conservan los valores previos de esos campos). Es un `filter` posterior sobre el campo, como filter status >= 500, el que descarta los registros con null; un fallo de parseo no aborta la consulta.',
      ],
    },
  },
  precision: {
    reason: 'Auditoría final: fetch dt.entity.* es el modelo Classic (no Latest), is_instance_of no existe (instance_of / instantiates), el código 403 no está documentado, la fila de 5 capas no era Classic ni usaba los tiers documentados (Processes, no Process Group) y el producto se llama Log Management and Analytics.',
    remove: ['Consultas de Entidades en Grail', 'Smartscape 5-Layer Hierarchy', 'Log Analytics'],
    corrections: [
      { topic: 'Campos de Relación Topológica', find: 'Las relaciones entre entidades se modelan en atributos array como `runs[dt.entity.service_instance]` y `is_instance_of`.', replace: 'En el modelo Classic, las relaciones entre entidades se exponen como campos con el nombre de la relación y el tipo de destino, como `runs[dt.entity.service_instance]` en un host o `instance_of[dt.entity.process_group]` en una process group instance.' },
      { topic: 'Campos de Relación Topológica', find: 'Permiten navegar desde un Host hacia los Process Groups y Servicios que hospeda en una única query DQL.', replace: 'Cada relación tiene un nombre en el origen y otro en el destino (runs_on / runs, instance_of / instantiates); un campo de relación devuelve IDs, y para traer sus detalles hacen falta expand y lookup.' },
      { topic: 'Permiso storage:entities:read', find: 'Sin este permiso, las consultas `fetch dt.entity.*` devuelven un error de autorización 403.', replace: 'Sin este permiso, las consultas `fetch dt.entity.*` fallan por falta de permisos.' },
    ],
    add: [
      { topic: 'Entidades Classic en Grail', fact: 'Las entidades Classic se consultan con `fetch dt.entity.host`, `fetch dt.entity.service` o `fetch dt.entity.process_group` (requiere `storage:entities:read`).', examNote: 'Desde la versión 1.334 Dynatrace está en transición a Smartscape on Grail: en Latest, la topología se consulta con smartscapeNodes, smartscapeEdges y traverse.', source: { title: 'Query monitored entities in Grail (Classic)', url: 'https://docs.dynatrace.com/docs/platform/grail/querying-monitored-entities' } },
      { topic: 'Smartscape Classic: 5 tiers', fact: 'Data centers → Hosts → Processes → Services → Applications (en el tier Processes cada nodo es un proceso).', examNote: 'Eje vertical: dependencias full-stack entre tiers; eje horizontal: llamadas entrantes y salientes dentro de cada tier. El Smartscape actual es un grafo de nodos y edges, sin tiers.', source: { title: 'Smartscape Classic', url: 'https://docs.dynatrace.com/docs/analyze-explore-automate/smartscape-classic' } },
      { topic: 'Log Management and Analytics / Logs app', fact: 'Permite explorar logs sin exigir un esquema fijo de antemano y analizarlos con DQL y schema-on-read.', examNote: 'Que no haya esquema previo no elimina la necesidad de tipos y parsing.', source: { title: 'Log Management and Analytics', url: 'https://docs.dynatrace.com/docs/analyze-explore-automate/logs' } },
    ],
  },
  sections: [
    {
      id: 'sup-smartscape-app',
      after: 'smartscape',
      title: 'App Smartscape: nodos, grupos, búsqueda, filtros y layouts',
      lead: 'La app Smartscape dibuja la topología como un grafo que puedes buscar, filtrar y reorganizar sin cambiar los datos.',
      paragraphs: [
        'En la app Smartscape, los nodes representan entidades (hosts, procesos, servicios…) y se dibujan como círculos; los edges representan relaciones o dependencias entre nodos y se dibujan como líneas; los groups son colecciones de nodos que comparten una característica o contexto común, y nodos y grupos admiten varios niveles de anidamiento. Las vistas de Smartscape solo muestran entidades nuevas de Smartscape on Grail: los entity types de Smartscape Classic no se muestran ni se soportan.',
        'Para localizar una entidad, la búsqueda admite un nombre completo o parcial (está tokenizada: elastic cache y elasticcache devuelven lo mismo) o un ID completo o parcial, como AWS_ELASTICACHE_USERGROUP-2759FE0518A12C3B. Los nodos coincidentes se resaltan en el grafo y los no coincidentes se atenúan; no se eliminan.',
        'Los filtros acotan la vista a los nodos, edges o problems relevantes sin modificar los datos: Filter by nodes admite claves como name, hostname o id; Filter by edges usa las claves estándar source_id, source_type, target_id, target_type y type; Filter by problems usa event.name, event.status, event.category, event.id y display_id. La práctica recomendada es aplicar segmentos para reducir el grafo a los datos de tu equipo. Los segmentos solo filtran nodos, y en vistas anidadas, si el segmento filtra un grupo padre, no verás sus nodos hijos aunque el segmento no les afecte directamente.',
        'La leyenda ofrece tres layouts: Force (distribución física que reparte las entidades para reducir solapes), Vertical (capas de arriba abajo) y Horizontal (capas de izquierda a derecha). En View topology, en los modos Related nodes y Direct calls con layout horizontal, el trigger node aparece resaltado en el centro; el grupo source (izquierda) contiene las entidades que llaman o usan el trigger node y el grupo target (derecha), las entidades que el trigger node llama o usa. En los modos de call chain el trigger node se coloca en un extremo: a la izquierda (horizontal) o arriba (vertical) en Downstream call chain, y a la derecha o abajo en Upstream call chain. View topology no aplica los filtros al trigger node, que siempre permanece visible.',
        'Los nodos y edges de la app no siempre se corresponden 1:1 con los de Smartscape on Grail: las vistas pueden adaptar relaciones y enriquecerse con datos de otras fuentes, como AI Observability, Security Enrichment o apps de negocio. Una arista de la vista que no existe tal cual en Smartscape on Grail no es necesariamente un error.',
      ],
      bullets: [
        'Search: nombre o ID, completo o parcial; resalta y atenúa.',
        'Filters: nodes, edges (source_id, source_type, target_id, target_type, type) y problems.',
        'Segments: filtran nodos; un padre filtrado oculta a sus hijos.',
        'Layouts: Force, Vertical y Horizontal.',
      ],
      sourceRefs: [SRC.concepts, SRC.views, SRC.viewtopology, SRC.sog],
    },
    {
      id: 'sup-problem-graph',
      after: 'sup-smartscape-app',
      title: 'Problem graph: alcance de los Problems activos',
      lead: 'El Problem graph superpone los Problems activos sobre la topología para ver alcance y concentración.',
      paragraphs: [
        'El Problem graph muestra los Problems detectados con sus affected nodes, related nodes y root causes, pero solo Problems con estado ACTIVE: los Problems CLOSED no aparecen en el grafo, aunque sigan en el histórico de la app Problems. Los affected nodes son los elementos de Smartscape directamente impactados (hosts, procesos, servicios, aplicaciones, workloads de Kubernetes); los related nodes son nodos de Smartscape conectados de forma indirecta que aportan contexto para el troubleshooting.',
        'Dos lecturas son clave. Los Problems de alto impacto son los que afectan al mayor número de entidades. Los nodos afectados por varios Problems (problem-heavy nodes) concentran incidencias y ayudan a priorizar las áreas que requieren atención inmediata: en el grafo se ven como un mismo nodo afectado conectado a varios Problems. Para acotar el grafo a tu área, selecciona uno o varios segmentos y verás solo los Problems y nodos del área de responsabilidad de tu equipo. Para el análisis detallado, la root cause y las recomendaciones de resolución, abre el Problem en la app Problems.',
      ],
      sourceRefs: [SRC.problemgraph],
    },
    {
      id: 'sup-smartscape-on-grail',
      after: 'deep-smartscape-graph',
      title: 'Smartscape on Grail: IDs, lifetime, edges y retención',
      lead: 'Smartscape on Grail es el almacenamiento nativo de Grail para la topología, y sus reglas difieren de las de logs o spans.',
      paragraphs: [
        'Smartscape on Grail registra automáticamente datos topológicos, como entidades monitorizadas y sus relaciones, y permite consultarlos con DQL (smartscapeNodes, smartscapeEdges, traverse) desde Notebooks y Dashboards. A diferencia de los registros de buckets tradicionales (logs, events, spans o data points de métricas), que se ingieren para un timestamp y nunca cambian, los nodos y edges de Smartscape son mutables y pueden cambiar con el tiempo.',
        'Un Smartscape ID combina el entity type y un número de 16 símbolos, por ejemplo HOST-000000000000007B. El tipo Smartscape ID es totalmente compatible con su representación string, así que puedes comparar un string con un Smartscape ID. Por convención, los node types se escriben siempre en mayúsculas, como HOST, K8S_NAMESPACE o AWS_EC2_INSTANCE. El campo id_classic contiene el entity ID de la entidad Classic correspondiente, cuando existe.',
        'Cada nodo tiene dos campos de lifetime: lifetime.start (la primera vez que se descubrió) y lifetime.end (la última vez que se observó), que se actualiza con cada upsert mientras el nodo se sigue observando. Una consulta solo devuelve los nodos cuyo lifetime solapa el timeframe consultado: un nodo con lifetime.end de ayer no aparece al consultar las últimas 2 horas. Los timeframes que empiezan hace menos de 15 minutos se amplían automáticamente a 15 minutos. La retención es fija de 35 días: se borran los nodos cuyo lifetime.end tiene más de 35 días, con todas sus static edges, y las dynamic edges también se limpian a los 35 días.',
        'Las edges pueden ser static, que heredan el lifetime del nodo (por ejemplo, un disco conectado a un host según su configuración), o dynamic, que se registran para un momento concreto (por ejemplo, llamadas entre servicios reveladas por trazas). Todas las static edges se pueden consultar desde el nodo origen con el campo references, que se muestra con fieldsAdd references. Por ejemplo, smartscapeNodes CONTAINER | summarize by:references[runs_on.host], count() resume los contenedores por el host en el que se ejecutan.',
        'Las señales (logs, spans, eventos…) se conectan con la topología mediante campos dt.smartscape.<type> (en la documentación, dt.smartscape.__type__; por ejemplo, dt.smartscape.host) que contienen Smartscape IDs e indican que la señal se originó en ese nodo. Para enriquecerlas, getNodeName(dt.smartscape.host) devuelve el nombre del nodo y getNodeField(dt.smartscape.host, "tags") otros campos.',
        'Otros límites: solo los nodos se pueden filtrar con segmentos, las edges no; Smartscape on Grail está incluido en la licencia DPS, así que los datos devueltos por consultas de Smartscape no tienen coste adicional; los nodos tienen un campo dt.security_context que puede contener varios valores, y puedes configurar fieldsets sobre la tabla smartscape; los tags solo se fijan en la fuente de datos (Kubernetes añade labels y annotations, cloud monitoring añade tags de AWS, OneAgent añade agent tags). Los tags cloud de las señales cambian de notación en el nodo: aws.tags.* pasa a ser tags:aws[*], de modo que aws.tags.team aparece como tags:aws[team].',
      ],
      comparison: {
        headers: ['Aspecto', 'Smartscape on Grail', 'Logs, events, spans'],
        rows: [
          ['Mutabilidad', 'Nodos y edges mutables (upserts)', 'Registro fijo a su timestamp'],
          ['Tiempo', 'lifetime.start / lifetime.end; solapamiento con el timeframe', 'timestamp puntual'],
          ['Retención', 'Fija: 35 días desde lifetime.end', 'La del bucket'],
          ['Coste de consulta', 'Incluido en DPS', 'Según rate card'],
        ],
      },
      sourceRefs: [SRC.sog],
    },
    {
      id: 'sup-smartscape-dql',
      after: 'sup-smartscape-on-grail',
      title: 'Consultar la topología: smartscapeNodes, smartscapeEdges y traverse',
      lead: 'Tres comandos DQL cubren nodos, aristas y navegación; el modelo core define qué aristas existen.',
      paragraphs: [
        'smartscapeNodes carga nodos por patrón de tipo (usa "*" para todos), por ejemplo smartscapeNodes HOST; es el inicio equivalente al migrar una consulta fetch dt.entity.host de la vista Classic. smartscapeEdges carga aristas por patrón de tipo de edge y devuelve registros con source_id, source_type, target_id, target_type y type. Por eso, smartscapeEdges "*" | filter source_type == "K8S_POD" | summarize by:{type, target_type}, edges = count() cuenta aristas por tipo y tipo de destino, no nodos destino distintos.',
        'traverse recorre desde los nodos de origen hasta los nodos destino siguiendo tipos de edge: traverse edgeType, targetType [, direction] [, fieldsKeep]. La dirección por defecto es forward y la alternativa es backward. El resultado son los nodos destino, con un campo adicional dt.traverse.history: un array de records con información de los nodos de origen; fieldsKeep indica qué campos del origen se conservan en él. En smartscapeNodes SERVICE | filter tags[owner] == "Joe" | traverse runs_on, HOST | fields id, el filter se aplica a los servicios y el resultado son los IDs de los HOST en los que corren.',
        'El Semantic Dictionary define node types como HOST, PROCESS, SERVICE, CONTAINER, DISK, FRONTEND, NETWORK_INTERFACE u OS_SERVICE; PROCESS_GROUP y PROCESS_GROUP_INSTANCE no son node types. Entre las aristas documentadas están SERVICE calls SERVICE (dynamic), SERVICE runs_on PROCESS, HOST o CONTAINER, PROCESS runs_on HOST, CONTAINER runs_on HOST, CONTAINER belongs_to K8S_CLUSTER o K8S_NAMESPACE, DISK belongs_to HOST y FRONTEND calls SERVICE. La dirección importa: el servicio corre sobre procesos o hosts (runs_on), no al revés; calls modela comunicación y belongs_to, pertenencia.',
      ],
      code: 'smartscapeNodes CONTAINER\n| filter k8s.workload.kind == "daemonset"\n| traverse {runs_on, belongs_to}, {HOST, K8S_CLUSTER}, fieldsKeep: name\n| fields container_name = dt.traverse.history[0][name],\n         node_name = name, node_type = type',
      codeNote: 'Tras traverse, name y type son los del nodo destino (HOST o K8S_CLUSTER); el name del contenedor de origen se recupera de dt.traverse.history[0] porque fieldsKeep: name lo conservó.',
      sourceRefs: [SRC.sscmd, SRC.sscore, SRC.sog],
    },
    {
      id: 'sup-smartscape-events',
      after: 'sup-smartscape-dql',
      title: 'Smartscape events: upserts parciales y borrado con null',
      lead: 'Los eventos de topología actualizan nodos; no se guardan como registros.',
      paragraphs: [
        'Los Smartscape events se ingieren por el endpoint de Smartscape events (/platform/ingest/v1/smartscape.events), pasan por el pipeline de Smartscape events de OpenPipeline y se transforman en upserts de Smartscape; los eventos en sí no se persisten como registros. Los eventos no necesitan contener todos los campos del nodo: solo los campos presentes en el evento entran en el upsert, así que un campo omitido conserva su valor anterior. Para borrar un campo de un nodo, inclúyelo en el evento con el valor null.',
        'Esto tiene una trampa al copiar valores de tags a primary_tags: si usas true como matching condition, el processor se ejecuta en cada registro; cuando falta el tag de origen, el origen se resuelve a null y el upsert escribe null en el campo destino, borrándolo. Limita el matcher a los registros que tienen el tag de origen. Los primary_tags también se pueden fijar en la etapa compartida Primary Grail tags, que se aplica a todos los datos del pipeline.',
      ],
      sourceRefs: [SRC.sog],
    },
    {
      id: 'sup-classic-entities',
      after: 'deep-entities-query',
      title: 'Entidades Classic en DQL: fetch dt.entity.*, relaciones y límites',
      lead: 'Las vistas dt.entity.* siguen presentes en muchos entornos, pero desde la versión 1.334 Dynatrace está en transición hacia Smartscape on Grail.',
      paragraphs: [
        'Consultar entidades Classic en Grail requiere el permiso storage:entities:read. Grail no aplica filtros de management zone: quien tiene storage:entities:read puede consultar todas las entidades. fetch dt.entity.host devuelve por defecto el ID y el nombre de la entidad sin configurar nada más. Un process group es un cluster lógico de procesos que realizan la misma función en varios hosts (por ejemplo, un clúster Tomcat); cada process group instance (dt.entity.process_group_instance) es la ejecución de ese grupo en un host concreto y enlaza con su grupo mediante instance_of.',
        'Las relaciones legacy se exponen con un nombre en el origen y otro en el destino: isInstanceOf → instance_of / instantiates; runsOn → runs_on / runs; isProcessOf → belongs_to / contains; calls → calls / called_by; hostsComputeNode → hosts / hosted_by. Así, dt.entity.service_instance tiene runs_on[dt.entity.host] y el host tiene runs[dt.entity.service_instance]; dt.entity.process_group_instance tiene instance_of[dt.entity.process_group]. Las relaciones 1:n solo devuelven 100 entity IDs por tipo y por registro; si necesitas más, usa classicEntitySelector().',
        'Para enriquecer registros con datos de una entidad se usa lookup: lookup sourceField:dt.entity.host, lookupField:id, [fetch dt.entity.host] añade a cada registro los campos del host cuyo id coincide, sin agrupar ni multiplicar filas. Por ejemplo, fetch dt.entity.service_instance | fieldsAdd runs_on[dt.entity.host] | lookup … [fetch dt.entity.host] devuelve una fila por service instance con los campos del host en el que corre. Si el campo de relación es un array de IDs (runs[dt.entity.service_instance] en el host), primero hay que aplicar expand para obtener un registro por ID y después lookup. append añade filas, no columnas, y dedup elimina duplicados. En Latest, el nombre de un host referenciado por un Smartscape ID se obtiene con getNodeName(dt.smartscape.host).',
      ],
      code: 'fetch dt.entity.host\n| fieldsAdd runs[dt.entity.service_instance]\n| expand runs[dt.entity.service_instance]\n| lookup sourceField:`runs[dt.entity.service_instance]`, lookupField:id,\n    [ fetch dt.entity.service_instance ]',
      codeNote: 'expand convierte el array de IDs en registros individuales; solo entonces lookup puede traer los detalles de cada service instance.',
      sourceRefs: [SRC.entities, SRC.pg],
    },
    {
      id: 'sup-logs-app',
      after: 'deep-log-investigation',
      title: 'Logs app: permisos, facetas, filtros y continuidad',
      lead: 'La Logs app permite investigar sin escribir DQL, pero sus facetas, sugerencias y búsquedas tienen reglas precisas.',
      paragraphs: [
        'La Logs app permite buscar, filtrar y analizar logs sin dominar DQL. Necesita storage:logs:read y storage:buckets:read para leer logs, y storage:files:read para joins con lookup tables. Gracias a schema on read y DQL no hace falta decidir qué vas a consultar durante la ingesta: los atributos nuevos se exploran al leer, y DQL permite filtrar y agregar los logs de Grail (por ejemplo, contar errores por servicio con summarize count()) antes de abrir los registros. Desde los detalles de un registro puedes navegar a los hosts, clusters de Kubernetes y traces relacionados, y puedes continuar el análisis en Notebooks, Dashboards o Investigations, o automatizarlo con Workflows.',
        'En las facetas, varios valores de una misma faceta se combinan con OR y facetas distintas con AND: un log debe cumplir al menos un valor de cada faceta seleccionada. Los recuentos son aproximados según los últimos filtros; el símbolo ~ indica que Dynatrace usa sampling al leer los logs para mejorar la respuesta. Los primary Grail tags aparecen en un grupo de facetas Primary tags (campos primary_tags.*), pero la lista se refresca cada 24 horas, así que un tag configurado recientemente puede tardar en aparecer. Los tags de AWS, Azure, GCP y Kubernetes (aws.tags.*, azure.tags.*, gcp.labels.*, k8s.*) son facetas ocultas por defecto, agrupadas por origen; puedes desocultarlas en la configuración de facetas y usarlas como los primary tags.',
        'En el filtro, un atributo JSON anidado se escribe fieldname$.attributename = value, por ejemplo content$.loyalty_level = "silver"; si el atributo lleva puntos, se usan corchetes: content$["process.technology"] = "nodejs". Search in results filtra la tabla con tu palabra clave sin ejecutar una nueva consulta: solo busca en los resultados ya devueltos y cargados en el navegador. Las sugerencias de valores devuelven hasta 100 valores distintos por campo, del timeframe seleccionado (hasta las últimas 24 horas), y no funcionan para el campo content; que un valor no aparezca en la sugerencia no prueba que no exista.',
        'Consultar logs consume según tu modelo de rate card, pero las sugerencias de facetas y filtros, la log distribution chart y la búsqueda en los resultados ya devueltos no tienen coste. Volver a ejecutar la consulta o cargar más registros sí son consultas nuevas.',
      ],
      sourceRefs: [SRC.logsapp, SRC.facets, SRC.queryfilter, SRC.logs],
    },
    {
      id: 'sup-log-patterns',
      after: 'sup-logs-app',
      title: 'Surrounding logs y pattern analysis',
      lead: 'Dos funciones para pasar de un registro aislado a contexto y tendencias.',
      paragraphs: [
        'Show surrounding logs reúne el contexto de un registro. Si el registro tiene trace_id, verás otros registros con el mismo trace ID (requiere la conexión de logs con trazas). Si no hay trace ID, se correlacionan los logs de la misma entidad de topología, por ejemplo el mismo host. Para ampliar, Run query for 15 logs before y Run query for 15 logs after cargan los registros anteriores o posteriores al timestamp del original.',
        'Pattern analysis agrupa los registros en patterns a partir del campo content. Es una vista de lectura (read-time) sobre los logs que cumplen los filtros y el timeframe: el resultado no se reingiere ni se almacena. Si la consulta supera 50.000 registros o 100 MB se aplica sampling, y los patterns pequeños pueden quedar fuera. Los registros cuyo content supera 1.500 caracteres se excluyen, y las estructuras JSON dentro de content se tratan como un único token, sin parsear sus elementos. Para reducir el sampling, aplica un filtro por un Grail primary field o primary tag, acota el timeframe a 30 minutos y filtra un único status.',
      ],
      sourceRefs: [SRC.surrounding, SRC.patterns],
    },
    {
      id: 'sup-hub-extensions-setup',
      after: 'deep-hub-extensions',
      title: 'Hub y extensiones SNMP: permisos y pasos de configuración',
      lead: 'Instalar una app y configurar una extensión son procesos distintos, con permisos y componentes distintos.',
      paragraphs: [
        'Instalar apps desde Dynatrace Hub requiere el permiso app-engine:apps:install, y desinstalarlas, app-engine:apps:delete; las Hub subscriptions requieren lectura y escritura del schema de settings builtin:hub-channel.subscriptions. Las apps se instalan en segundos y todas las apps instaladas desde Hub se actualizan automáticamente. Las apps son piezas autocontenidas basadas en AppEngine; las extensions (Extensions 2.0) incorporan métricas de forma declarativa desde fuentes propias y se gestionan en la Extensions app.',
        'Para usar una extensión, primero se añade al entorno: Extensions > Discover, selecciona su tile y Add to environment. Después se crea su monitoring configuration, cuyos pasos dependen de la fuente de datos. Las extensiones SNMP se ejecutan en remoto en un ActiveGate group (no en OneAgent), y todos los ActiveGates de cada grupo designado deben poder conectarse a los dispositivos SNMP. La configuración SNMP sigue cuatro pasos: elegir el ActiveGate group; definir los dispositivos con IP o hostname, puerto y credenciales SNMP (v2c o v3); ajustar, si hace falta, propiedades avanzadas como timeouts o retries; y activar la configuración con su descripción y feature sets. Tras unos minutos, verifica las métricas en el metric browser.',
      ],
      bullets: [
        'Add to environment (Extensions > Discover).',
        'Monitoring configuration: ActiveGate group.',
        'Dispositivos: IP o hostname, puerto, SNMP v2c/v3 y credenciales.',
        'Activar con feature sets y verificar métricas.',
      ],
      sourceRefs: [SRC.hub, SRC.manageext, SRC.snmp],
    },
  ],
}
