import type { LessonSupplement } from './types'
import { welcomeSupplement } from './welcome'
import { instructionsSupplement } from './instructions'
import { platformSupplement } from './platform'
import { observabilitySupplement } from './observability'
import { notebooksSupplement } from './notebooks'
import { businessSupplement } from './business'
import { dataSupplement } from './data'
import { dqlSupplement } from './dql'
import { securitySupplement } from './security'
import { automationSupplement } from './automation'
import { ingestionSupplement } from './ingestion'
import { otherSupplement } from './other'

export const lessonSupplements: LessonSupplement[] = [
  welcomeSupplement, instructionsSupplement, platformSupplement, observabilitySupplement, notebooksSupplement, businessSupplement, dataSupplement, dqlSupplement, securitySupplement, automationSupplement, ingestionSupplement, otherSupplement,
]
