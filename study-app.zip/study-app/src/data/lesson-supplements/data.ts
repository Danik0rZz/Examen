import type { SourceRef } from '../types'
import type { LessonSupplement } from './types'

const doc = (title: string, url: string): SourceRef => ({ title, url, kind: 'official-docs' })
const ORG = doc('Organize data in Grail', 'https://docs.dynatrace.com/docs/platform/grail/organize-data')
const PERM = doc('Permissions in Grail', 'https://docs.dynatrace.com/docs/platform/grail/organize-data/assign-permissions-in-grail')
const OPP = doc('OpenPipeline processing', 'https://docs.dynatrace.com/docs/platform/openpipeline/concepts/processing')
const SRC = doc('DQL data source commands', 'https://docs.dynatrace.com/docs/platform/grail/dynatrace-query-language/commands/data-source-commands')
const MET = doc('DQL metric commands', 'https://docs.dynatrace.com/docs/platform/grail/dynatrace-query-language/commands/metric-commands')
const AGG = doc('DQL aggregation commands', 'https://docs.dynatrace.com/docs/platform/grail/dynatrace-query-language/commands/aggregation-commands')
const LIM = doc('Metrics limits', 'https://docs.dynatrace.com/docs/analyze-explore-automate/metrics/limits')
const BPM = doc('Optimize metrics cost', 'https://docs.dynatrace.com/docs/analyze-explore-automate/metrics/best-practices-metrics')
const UBA = doc('User behavior analysis in RUM Classic', 'https://docs.dynatrace.com/docs/observe/digital-experience/rum-classic/web-applications/analyze-and-use/user-behavior-analysis')
const PERF = doc('Performance analysis in RUM Classic', 'https://docs.dynatrace.com/docs/observe/digital-experience/rum-classic/web-applications/analyze-and-use/performance-analysis')
const USQL = doc('Custom queries, segmentation, and aggregation of session data', 'https://docs.dynatrace.com/docs/observe/digital-experience/session-segmentation/custom-queries-segmentation-and-aggregation-of-session-data')

export const dataSupplement: LessonSupplement = {
  moduleId: 'data-analysis',
  extend: {
    correlation: {
      paragraphs: [
        'Antes de declarar una root cause, combina una segunda señal independiente con la relación entre entidades. Los spans de las requests lentas muestran dónde se consume el tiempo; Smartscape muestra qué entidad depende de cuál y permite comprobar qué señal empezó primero. Un coeficiente de correlación alto o una relación que se repite en el tiempo siguen siendo correlación: la hipótesis causal se apoya en la topología, las dependencias y la secuencia temporal, que es también el enfoque de la root cause analysis de Dynatrace.',
      ],
      reason: 'R-DAT-19 necesita la combinación de spans y dependencia/secuencia en Smartscape como evidencia causal.',
    },
    reporting: {
      paragraphs: [
        'Los dashboard reports de Dashboards Classic se envían weekly (cada lunes por la mañana), monthly (el primer lunes de cada mes) o con ambas frecuencias. Cada email contiene un enlace público al report, con el timeframe de la frecuencia elegida; no adjunta un PDF. Para que el enlace se abra sin credenciales hay que activar Allow anonymous access en Settings > Dashboards > General settings, y las personas sin cuenta de Dynatrace se añaden como destinatarias mediante la Reports API.',
        'La documentación describe el Notebook como algo que se lee y el Dashboard como algo que se mira. Los Notebooks encajan en el análisis ad hoc, el troubleshooting, la investigación de incidentes complejos que combinan métricas, logs y traces, la documentación y la colaboración; los Dashboards, en la monitorización continua en tiempo real, el seguimiento de KPIs y SLOs y la visión general de la salud del sistema. Además, los datos de un notebook se almacenan dentro del notebook, mientras que los datos de un dashboard se consultan al abrirlo.',
      ],
      corrections: [
        { find: 'diferente del de una métrica muestreada', replace: 'diferente del de una métrica agregada' },
      ],
      reason: 'R-DAT-04, R-DAT-05, R-DAT-32 y R-DAT-33 (dashboard reports Classic y diferencia Notebooks/Dashboards). Las métricas de Grail se agregan por minuto, no se muestrean: «muestreada» se corrige a «agregada».',
    },
    'sampling-completeness': {
      paragraphs: [
        'En DQL, el parámetro samplingRatio de fetch se aplica solo a logs y admite 1 (valor por defecto, sin muestreo), 10, 100, 1000 y 10000. Con samplingRatio:100 se devuelve aproximadamente 1/100 de los registros de todo el timeframe, así que un count() no es el total real. El ratio aplicado queda en el campo oculto dt.system.sampling_ratio, que solo se ve si lo seleccionas con fields.',
        'El parámetro bucket acepta un nombre, una lista o un patrón con comodín *, por ejemplo bucket:{"default_logs", "logs_365_*"}; acota qué buckets se leen, pero no amplía su retención. scanLimitGBytes limita la cantidad de datos sin comprimir que lee fetch: su valor por defecto es 500 GB y con -1 se analizan todos los datos del timeframe; si se alcanza el límite, el resultado es parcial.',
      ],
      reason: 'R-DAT-10, R-DAT-11 y R-DAT-21 (samplingRatio, scanLimitGBytes, bucket y dt.system.sampling_ratio).',
    },
    'metric-retention': {
      paragraphs: [
        'En Metrics Classic la granularidad disminuye con la antigüedad: 1 minuto de 0 a 14 días, 5 minutos de 14 a 28 días, 1 hora de 28 a 400 días y 1 día de 400 días a 5 años. Metrics powered by Grail mantiene 1 minuto durante todo el historial; un interval:1h en un Dashboard cambia la agregación consultada, no los datos almacenados.',
        'Metrics Classic y Metrics powered by Grail son bases de datos separadas, con almacenamiento separado: el historial Classic no se migra a Grail y sigue disponible en Data Explorer y en Dashboards Classic. Data Explorer Classic usa metric selectors, mientras que Notebooks y Dashboards usan DQL; los metric keys siguen otra convención de nombres en Grail, a menudo con correspondencia uno a uno. Ingerir en ambos sistemas no duplica el cargo: solo aplica el consumo de la licencia activa.',
      ],
      comparisonRows: [
        ['Metrics Classic (granularidad)', '1 min (0–14 días) · 5 min (14–28 días) · 1 h (28–400 días) · 1 día (hasta 5 años)', 'Grail mantiene 1 minuto en todo el historial'],
      ],
      corrections: [
        { find: 'La tenant y el bucket pueden cambiar el alcance', replace: 'La ampliación hasta 10 años es una opción de retención de métricas, no un bucket personalizado (no existen buckets personalizados de métricas)' },
      ],
      reason: 'v5: el matiz de la fila de Grail decía que el bucket cambia el alcance, pero no hay buckets personalizados de métricas (Organize data; Metrics limits: 15 meses incluidos, opción de ampliar a 10 años). R-DAT-15, R-DAT-16, R-DAT-22, G-085, G-098 y FD-012 (tramos de Classic, almacenes separados, DQL frente a metric selectors).',
    },
    'key-requests': {
      paragraphs: [
        'En Services Classic, marcar una request como key request le da métricas dedicadas (gestionables desde la UI o la API), tiles propios en los dashboards, custom thresholds y alerting siempre activo, incluso cuando aporta menos del 1 % del throughput. Sus niveles de retención son: detailed code-level data, 10 días; aggregated code-level data, 35 días; long-term metric history, 5 años. Los dashboard tiles de una key request incluyen solo los datos recogidos después de marcarla. Cada servicio admite 100 key requests y cada entorno, 500 en total.',
      ],
      reason: 'R-DAT-08 y R-DAT-09 (ventajas, retención por nivel, tiles desde el marcado y límites).',
    },
    'sessions-problems': {
      paragraphs: [
        'En RUM (Latest Dynatrace) para web frontends, una user session se registra cuando se captura al menos un evento que indique actividad del usuario, como una user action o una navigation; las request events por sí solas no bastan. La sesión termina tras 30 minutos de inactividad del navegador, cuando el usuario cierra el navegador, al alcanzar 6 horas de duración o cuando el código llama a dtrum.endSession() desde la RUM JavaScript API. RUM no limita el número de acciones o eventos por sesión; el corte a las 200 acciones era propio de RUM Classic.',
        'Una sesión con una sola user action o navigation se etiqueta como bounced. En Grail, default_user_events y default_user_sessions, las user replays y los buckets de Synthetic conservan 35 días; Davis problems y Davis events se conservan 14 meses.',
      ],
      reason: 'R-DAT-01, R-DAT-02, R-DAT-03, G-097 y G-099 (ciclo de vida de sesiones RUM, bounce y retenciones).',
    },
    'deep-reporting-analysis': {
      paragraphs: [
        'Para que una herramienta externa lea data points de métricas Classic se usa Metrics API v2: GET /api/v2/metrics/query con un token con el scope metrics.read (metrics.ingest sirve para enviar métricas). El parámetro metricSelector admite hasta 10 métricas separadas por comas. La respuesta es JSON por defecto, o CSV si se pide con la cabecera Accept. Si no indicas resolution, la API devuelve por defecto 120 data points por serie, y si no indicas from, el timeframe empieza en now-2h. Límites por consulta: 20 millones de data points en total y 10.080 data points por tupla de dimensiones. storage:metrics:read, en cambio, es un permiso IAM de Grail para leer métricas con DQL, no un token scope de esta API.',
      ],
      reason: 'R-DAT-06, R-DAT-07 y R-DAT-30 (endpoint, scope, resolution, from, metricSelector y formato).',
    },
    'deep-metric-design': {
      corrections: [
        { find: 'se utiliza el modificador `default:0` (por ejemplo: `timeseries cpu = avg(dt.host.cpu.usage), default:0, interval:5m`)', replace: 'se utiliza el parámetro `default:0` de la función de agregación (por ejemplo: `timeseries cpu = avg(dt.host.cpu.usage, default:0), interval:5m`)' },
        { find: 'Esto asegura que cada intervalo temporal tenga un valor numérico definido.', replace: 'Esto asegura que cada intervalo de una serie existente tenga un valor numérico definido; si no hay ningún dato, hace falta además nonempty:true para obtener una serie.' },
        { find: 'timeseries requests = sum(dt.service.request.count), default:0, interval:1m, by:{dt.entity.service}', replace: 'timeseries requests = sum(dt.service.request.count, default:0), interval:1m, by:{dt.entity.service}' },
      ],
      reason: 'Sintaxis corregida: default es un parámetro de la agregación (sum(metric, default:0)), no del comando timeseries (DQL metric commands); coherente con D-017.',
    },
    'deep-retention-reference': {
      corrections: [
        { find: 'Para crear buckets nuevos o alterar la retención de un bucket existente se requiere', replace: 'Para crear buckets personalizados o cambiar la retención de uno existente se requiere' },
        { find: 'El bucket `default_logs` tiene una retención por defecto de 35 días (ampliable según el plan de DPS hasta 10 años), mientras que', replace: 'El bucket integrado `default_logs` tiene una retención de 35 días que no se puede modificar (para conservar logs hasta 10 años se envían a un bucket personalizado de logs), mientras que' },
        { find: 'Distributed traces en Grail (`default_spans`) se configuran desde 10 días hasta 10 años.', replace: 'Los distributed traces en Grail se guardan por defecto en `default_spans` con 10 días; un bucket personalizado de spans permite ampliar la retención hasta 10 años.' },
        { find: 'Requisito para Modificar', replace: 'Permiso de gestión de buckets' },
        { find: '35 días por defecto (hasta 10 años)', replace: '35 días, no editable (bucket personalizado de logs: hasta 10 años)' },
        { find: '10 días por defecto (hasta 10 años)', replace: '10 días, no editable (bucket personalizado de spans: hasta 10 años)' },
        { find: 'En cuanto a métricas, Metrics powered by Grail cuentan con', replace: 'En cuanto a métricas, las métricas almacenadas en Grail (default_metrics) cuentan con' },
        { find: 'Metrics powered by Grail', replace: 'Bucket personalizado (logs, spans, events, bizevents o security events)' },
        { find: '15 meses incluidos (1 min resolución)', replace: 'De 1 día a 10 años (más una semana adicional), elegida al crearlo y modificable' },
        { find: 'Modificar la retención hacia un valor menor purga de forma permanente los datos más antiguos que el nuevo límite.', replace: 'Acortar la retención de un bucket personalizado elimina los datos que superan el nuevo periodo.' },
        { find: 'buckets del sistema como `security.events` y los eventos de Davis tienen retenciones estándar de 14 meses a 3 años.', replace: 'los security events se guardan en los buckets integrados `default_securityevents` (1 año, fuentes de terceros) y `default_securityevents_builtin` (3 años, generados por Dynatrace), y los Davis problems y events se conservan 14 meses.' },
        { find: 'que históricamente almacenaba 5 años agregados', replace: 'que conserva 5 años, no configurable, con granularidad decreciente con la antigüedad' },
        { find: '`storage:bucket-definitions:write`. El bucket', replace: 'storage:bucket-definitions:write. El bucket' },
        { find: 'storage:bucket-definitions:write', replace: 'storage:bucket-definitions:write (solo buckets personalizados; los integrados no son editables)' },
        { find: 'Configuración de bucket de spans', replace: 'storage:bucket-definitions:write (solo para el bucket personalizado de spans; el integrado no es editable)' },
        { find: 'security.events', replace: 'default_securityevents_builtin' },
        { find: '365 días (1 año) a 3 años según tipo', replace: '3 años, no editable (security events generados por Dynatrace)' },
        { find: 'Bucket de sistema gobernado', replace: 'No aplica (bucket integrado)' },
      ],
      comparisonRows: [
        ['default_securityevents', '1 año, no editable (security events de fuentes de terceros)', 'No aplica (bucket integrado)'],
        ['Metrics powered by Grail (default_metrics)', '15 meses incluidos a 1 minuto; ampliable hasta 10 años como opción de retención de métricas', 'No aplica (no hay buckets personalizados de métricas)'],
      ],
      paragraphs: [
        'La retención es una propiedad del bucket donde se almacenaron los datos, no del timeframe de la consulta: un selector de 90 días sobre default_logs solo devuelve lo que sigue dentro de sus 35 días. Por eso, en una consulta de 12 meses sin buckets personalizados puedes encontrar métricas (default_metrics, 15 meses) y no logs (default_logs, 35 días) de la misma fecha.',
      ],
      reason: 'El texto afirmaba que default_logs y default_spans se amplían hasta 10 años y que la retención de métricas se modifica con storage:bucket-definitions:write; los buckets integrados no se modifican. A-061, B-033 y G-082 necesitan la relación retención/timeframe. Auditoría final: security.events es una tabla, no un bucket (se separa en default_securityevents, 1 año, y default_securityevents_builtin, 3 años); el permiso de gestión no aplica a métricas ni a buckets integrados; Metrics Classic sigue conservando 5 años. v5: la fila de métricas ya no nombra un permiso que no le aplica (pasa a «No aplica»), la tabla incluye la fila del bucket personalizado, que es donde sí aplica storage:bucket-definitions:write, y la celda de spans nombra ese permiso en vez de una «configuración» que no es un permiso (Organize data).',
    },
  },
  sections: [
    {
      id: 'sup-grail-buckets',
      after: 'deep-retention-reference',
      title: 'Buckets, tablas y vistas en Grail',
      lead: 'La tabla es lógica; el bucket decide la retención y el acceso.',
      paragraphs: [
        'Grail organiza los registros en tres niveles. Los buckets son las unidades lógicas de almacenamiento donde se guardan los registros, y cada bucket está asociado a un único tipo de registro (logs, events, bizevents, security events o spans, por ejemplo). Las tablas agrupan los registros por tipo: fetch logs recupera los registros de todos los buckets de logs a los que tienes acceso, sean default_logs o buckets personalizados, en una única salida. Las vistas son tablas virtuales definidas por consultas sobre tablas existentes: ofrecen una perspectiva filtrada o transformada, pero no copian datos, así que los registros siguen sujetos a la retención y a los permisos de sus buckets.',
        'Si OpenPipeline no asigna un bucket explícito, el default pipeline procesa los datos no asignados y los guarda en el bucket predeterminado de su tipo; para logs, default_logs, cuya retención es la de ese bucket. Los buckets integrados (los que empiezan por default_ y los de sistema que empiezan por dt_) no se pueden modificar: si necesitas otra retención o separar accesos, creas buckets personalizados y diriges hacia ellos los datos. Como excepción en preview, la documentación menciona un programa (Extended retention for RUM and Synthetic) que permite conservar los datos de RUM y Synthetic más allá de los 35 días estándar, hasta 13 meses. Los buckets personalizados se pueden crear para events, security events, bizevents, logs y spans; metrics no figura en esa lista, de modo que default_metrics (15 meses) no admite un bucket propio.',
        'En un bucket personalizado defines el tipo de registro y la retención, que puede ir de 1 día a 10 años (más una semana adicional). Para guardar logs y Business Events con la misma retención hacen falta dos buckets, uno de logs y otro de bizevents. El nombre del bucket no se puede editar ni cambiar después de crearlo; el display name es un campo aparte para describir el bucket. El límite predeterminado es de 250 buckets personalizados por entorno, sin contar los buckets integrados como default_logs; para volúmenes de ingesta mayores se pueden solicitar más buckets con el equipo de cuenta de Dynatrace. Para inventariar los buckets y su retención real se consulta la tabla dt.system.buckets.',
      ],
      comparison: {
        headers: ['Bucket integrado', 'Retención', 'Datos'],
        rows: [
          ['default_logs', '35 días', 'Logs'],
          ['default_spans', '10 días', 'Spans (distributed traces)'],
          ['default_metrics', '15 meses', 'Metrics powered by Grail'],
          ['default_events y default_bizevents', '35 días', 'Events y Business Events'],
          ['default_user_events y default_user_sessions', '35 días', 'RUM'],
          ['default_synthetic_user_events y demás buckets de Synthetic', '35 días', 'Synthetic'],
          ['default_securityevents_builtin', '3 años', 'Security events'],
          ['default_securityevents', '1 año', 'Security events'],
        ],
      },
      code: 'fetch dt.system.buckets\n| filter startsWith(name, "default_") or startsWith(name, "dt_")',
      codeNote: 'Lista los buckets integrados del entorno con sus metadatos, entre ellos la retención configurada.',
      sourceRefs: [ORG, OPP, SRC],
    },
    {
      id: 'sup-bucket-lifecycle',
      after: 'sup-grail-buckets',
      title: 'Permisos y ciclo de vida de un bucket',
      lead: 'Leer datos y administrar buckets son autorizaciones distintas.',
      paragraphs: [
        'Para consultar registros necesitas dos permisos a la vez: acceso al bucket (storage:buckets:read) y acceso a la tabla (storage:logs:read para logs, storage:spans:read para spans, storage:metrics:read para métricas). Ambos se pueden acotar con condiciones WHERE: storage:bucket-name limita los buckets y un campo como storage:dt.security_context limita los registros de la tabla. Si una policy concede storage:buckets:read WHERE storage:bucket-name="default_logs" y storage:logs:read WHERE storage:dt.security_context="TeamA", el usuario ve solo los logs de default_logs cuyo dt.security_context es TeamA; los de otros buckets quedan fuera.',
        'Administrar buckets es otra familia de permisos: storage:bucket-definitions:read permite ver las definiciones, storage:bucket-definitions:write crear buckets y cambiar su retención, storage:bucket-definitions:truncate vaciarlos y storage:bucket-definitions:delete eliminarlos. Poder leer los logs de un bucket no autoriza a cambiar su retención. Cuando dos equipos necesitan retenciones y permisos distintos, el diseño correcto es separar sus flujos en buckets personalizados y conceder permisos sobre cada bucket y sobre la tabla; dt.security_context separa el acceso, pero dentro de un único bucket todos los registros comparten retención.',
        'Acortar la retención de un bucket elimina los datos que superan el nuevo periodo. Truncate borra de forma permanente todos los registros de un bucket sin eliminar el bucket, que puede seguir recibiendo datos; Delete elimina el bucket personalizado junto con todos sus datos, sin necesidad de truncate previo. Si un processor de OpenPipeline todavía referencia el bucket, la petición de borrado devuelve un estado 409 conflict con la lista de processors afectados y no se elimina nada. El borrado es una tarea asíncrona: mientras se vacían los datos el estado es deleting, y puede seguirse en el campo status de GET bucket definitions.',
      ],
      bullets: [
        'Leer logs: storage:buckets:read + storage:logs:read.',
        'Ver definiciones: storage:bucket-definitions:read.',
        'Crear buckets o cambiar retención: storage:bucket-definitions:write.',
        'Vaciar: storage:bucket-definitions:truncate. Eliminar: storage:bucket-definitions:delete.',
      ],
      warning: 'Reducir la retención, truncar o eliminar un bucket borra datos de forma permanente; evalúa antes la necesidad histórica y qué pipelines lo usan.',
      sourceRefs: [PERM, ORG],
    },
    {
      id: 'sup-timeseries-params',
      after: 'deep-metric-design',
      title: 'Parámetros de timeseries que cambian el resultado',
      lead: 'Cada parámetro responde a una pregunta distinta sobre la serie.',
      paragraphs: [
        'timeseries produce series homogéneas: todas las series de la respuesta comparten los timestamps de inicio y fin, el intervalo y el número de elementos. Cada fila incluye una columna timeframe, una columna interval y un array de valores por agregación. Si no indicas interval ni bins, el intervalo se calcula automáticamente dividiendo el timeframe en slots adecuados para graficar. interval (duración de cada slot) y bins (número de slots) son parámetros mutuamente excluyentes. Con by:{...} obtienes una serie por cada valor de la dimensión, cada una con su array temporal; los slots sin datos aparecen como null y no excluyen esa serie.',
        'filter puede ser global o ir dentro de una agregación concreta: dentro de una agregación limita solo esa serie, lo que permite calcular en la misma consulta un numerador filtrado (por ejemplo, solo errores 5xx) y un denominador sin filtrar. default:0 rellena con 0 los slots vacíos de una serie que existe, pero no crea series; nonempty:true devuelve resultado aunque no existan datos, y combinado con default:0 permite representar 0 en lugar de una salida vacía. union:false, el valor por defecto, combina las agregaciones como un INNER JOIN y conserva solo las series comunes; union:true aplica un OUTER JOIN y conserva las series presentes en cualquiera de ellas.',
        'scalar:true calcula un único valor que abarca todo el timeframe. rate normaliza con la fórmula (valor / intervalo) × rate: 300 solicitudes en un slot de 5 minutos con rate:1s dan 1 solicitud por segundo. shift desplaza el timeframe de una serie para compararla con otro periodo y la mapea a los timestamps originales; shift:-7d dibuja la misma ventana de la semana anterior.',
        'Las agregaciones tienen semántica propia. count(metric) calcula el número de series distintas de la métrica en cada slot (cardinalidad), no la suma de valores ni el número de muestras. percentile(metric, 99) estima un percentil y percentRank(metric, umbral) devuelve la fracción (de 0,0 a 1,0) de valores que quedan por debajo del umbral. Ambas se aplican a métricas histogram; para métricas gauge o count exigen el parámetro rollup. dt.service.request.response_time admite percentile sin rollup.',
      ],
      code: 'timeseries p99 = percentile(dt.service.request.response_time, 99), by:{dt.entity.service}',
      codeNote: 'Ejemplo de la documentación: percentil 99 del response time por servicio; avg ocultaría las peticiones más lentas.',
      sourceRefs: [MET],
    },
    {
      id: 'sup-metrics-exploration',
      after: 'sup-timeseries-params',
      title: 'Explorar métricas frente a graficarlas',
      lead: 'Descubrir qué series existen no es lo mismo que leer sus valores.',
      paragraphs: [
        'El comando metrics sirve para descubrir qué series de métricas existen: devuelve claves de métrica y dimensiones, pero no timestamps ni valores, así que no sirve para graficar; para eso se usa timeseries, que devuelve los valores agregados por intervalo. El rango temporal de metrics llega como máximo a los últimos 10 días y cada consulta está limitada a 100.000 series de métrica, de modo que en un entorno muy grande un inventario puede quedar incompleto.',
        'timeseries lee métricas, no registros. Para dibujar en el tiempo datos de registros como logs o events se usa makeTimeseries después de fetch: crea series a partir de los registros del stream (si no indicas interval ni bins, usa 120 bins). Así, fetch logs | filter loglevel == "ERROR" | makeTimeseries count() grafica los errores de log, mientras que timeseries no puede leer la tabla logs. Para un ranking o un total por dimensión, sin array temporal, la herramienta es summarize.',
      ],
      bullets: [
        'metrics: inventario de claves y dimensiones (últimos 10 días, hasta 100.000 series).',
        'timeseries: valores de métricas en intervalos homogéneos para graficar.',
        'makeTimeseries: series a partir de registros (logs, events).',
        'summarize: tabla de agregados, una fila por grupo.',
      ],
      sourceRefs: [MET, AGG],
    },
    {
      id: 'sup-metric-limits',
      after: 'sup-metrics-exploration',
      title: 'Límites, cardinalidad y coste de las métricas',
      lead: 'Las dimensiones multiplican series, y las series multiplican data points.',
      paragraphs: [
        'Cada combinación única de clave de métrica y valores de dimensión forma una serie: la cardinalidad es el número de series que produce una métrica, así que añadir dimensiones como servicio, región y status multiplica las combinaciones. En Metrics powered by Grail las dimensiones no tienen un límite fijo, excepto las muy volátiles: usar timestamps o IDs únicos como valor de dimensión dispara las series, y Dynatrace puede restringir o rechazar esas configuraciones. Metrics Classic limita a 1 millón las dimensiones por métrica.',
        'El consumo de métricas se factura por los data points realmente ingeridos y almacenados, no por cada combinación posible ni por serie activa; los 15 meses de retención incluidos y las consultas no tienen cargo adicional. Las métricas recogidas con más frecuencia que un minuto se agregan en intervalos fijos, de modo que se factura como máximo un data point por minuto y serie. La palanca más eficaz es eliminar dimensiones volátiles (user IDs, request IDs, UUIDs) en origen, por ejemplo con el transform processor del OTel Collector, o con el processor Remove fields de OpenPipeline; consultar con un interval mayor no cambia lo ingerido.',
        'Otros límites documentados: hasta 100.000 claves de métricas personalizadas, por lo que crear una clave por pedido o por usuario agota ese espacio y el identificador debería evaluarse como dimensión con control de cardinalidad. El prefijo dt. está reservado para métricas controladas por Dynatrace y los datos ingeridos con ese prefijo se descartan. Una consulta de Metrics powered by Grail puede leer hasta 500 millones de data points, frente a 20 millones en Metrics Classic.',
      ],
      comparison: {
        headers: ['Aspecto', 'Metrics powered by Grail', 'Metrics Classic'],
        rows: [
          ['Data points por consulta', '500 millones', '20 millones'],
          ['Claves de métricas personalizadas', '100.000', '100.000'],
          ['Dimensiones', 'Sin límite fijo, excepto las muy volátiles', '1 millón por métrica'],
          ['Granularidad', '1 minuto en todo el historial', '1 minuto los primeros 14 días; después, menor'],
          ['Retención', '15 meses incluidos, ampliable hasta 10 años', '5 años'],
        ],
      },
      sourceRefs: [LIM, BPM],
    },
    {
      id: 'sup-user-behavior',
      after: 'sessions-problems',
      title: 'Comportamiento de usuario y sesiones en RUM Classic',
      lead: 'Bounces, conversiones, entry y exit actions responden a preguntas de negocio distintas.',
      paragraphs: [
        'El análisis de comportamiento de RUM Classic resume métricas como bounces, páginas de entrada y salida y conversiones. Un usuario se considera returning gracias a una cookie persistente en el navegador, válida durante 2 años. Los user types separan Real users, tráfico de Synthetic monitoring y Robots como Googlebot. Una sesión convertida es la que cumple al menos uno de los conversion goals definidos. La entry action es la primera page load o XHR action de la sesión (la página de llegada) y la exit action, la última page load o XHR action; revisar las exit actions ayuda a ver si problemas de rendimiento hacen que los usuarios abandonen. Las other actions son las que no son ni la primera ni la última.',
        'En la performance analysis de RUM Classic, la métrica principal de una load action es Visually complete y la de una XHR action, Response end; Speed index y time to first byte forman parte de las métricas compuestas. El top 3 de user actions más lentas se ordena por prioridad (las de prioridad alta primero) y por total time consumed (duración × número de acciones), de modo que una acción algo lenta y muy frecuente puede superar a otra muy lenta y rara.',
        'Para segmentar sesiones en RUM Classic se usa User Sessions Query Language (USQL), desde la página Query User Sessions o la Environment API. USQL no es SQL y Dynatrace no guarda los datos de sesión en una base relacional; consulta tablas como usersession y useraction (además de userevent y usererror) con la estructura SELECT … FROM … WHERE … GROUP BY … ORDER BY. Solo se consultan user sessions cerradas, así que las live sessions no aparecen. Por defecto devuelve 50 resultados y con LIMIT llega a 5.000; en timeframes grandes los datos pueden extrapolarse a partir de una muestra.',
      ],
      bullets: [
        'Returning user: cookie persistente de 2 años.',
        'Conversión: al menos un conversion goal cumplido.',
        'Entry action: primera; exit action: última.',
        'Top 3 más lentas: prioridad y total time consumed (duración × número de acciones).',
        'USQL: solo sesiones cerradas; 50 resultados por defecto, 5.000 con LIMIT.',
      ],
      sourceRefs: [UBA, PERF, USQL],
    },
  ],
  precision: {
    corrections: [
      { topic: 'timeseries default:0', find: 'En DQL, la cláusula `default:0` dentro del comando `timeseries` sustituye los intervalos temporales vacíos (null) por el valor numérico 0.', replace: 'En DQL, `default:0` es un parámetro de la función de agregación (p. ej. `sum(m, default:0)`), no del comando `timeseries`: sustituye por 0 los intervalos vacíos (null) de una serie existente; para obtener 0 cuando no hay ningún dato se combina con `nonempty:true`.' },
      { topic: 'Retención de Buckets del Sistema', find: 'El bucket `default_logs` tiene 35 días por defecto; `security.events` y los eventos de Davis tienen retenciones preconfiguradas extendidas (1 año o más).', replace: '`default_logs`: 35 días; `default_securityevents`: 1 año; `default_securityevents_builtin`: 3 años; Davis problems y events: 14 meses.' },
      { topic: 'Retención de Buckets del Sistema', find: 'Los buckets de sistema no permiten reducir su retención por debajo de los mínimos operativos de la plataforma.', replace: 'Los buckets integrados (default_ y dt_) no son editables: para otra retención se usa un bucket personalizado (salvo el programa preview de retención extendida para RUM y Synthetic, hasta 13 meses).' },
      { topic: 'Distributed traces en Grail', find: 'Retención configurable de 10 días a 10 años; el bucket “default_spans” aparece con 10 días.', replace: '`default_spans`: 10 días, no editable. Un bucket personalizado de spans amplía la retención hasta 10 años (Data retention periods indica para tracing un rango de 10 días a 10 años; Organize data, de 1 día a 10 años para cualquier bucket personalizado).' },
      { topic: 'Distributed traces en Grail', find: 'No confundas el mínimo incluido de tracing con la retención ampliada de DPS.', replace: 'Distingue la retención fija del bucket integrado (10 días) de la de un bucket personalizado de spans (hasta 10 años).' },
    ],
    reason: 'Auditoría final: default:0 va dentro de la agregación (DQL metric commands); security.events es una tabla, no un bucket, y los buckets integrados no son editables (Organize data); rangos de spans aclarados (Data retention periods). v5: se matiza que existe un programa preview para ampliar la retención de RUM y Synthetic (Organize data; Preview releases).',
  },
}
