import type { LessonSupplement } from './types'

const src = (title: string, url: string) => ({ title, url, kind: 'official-docs' as const })
const NB = src('Notebooks', 'https://docs.dynatrace.com/docs/analyze-explore-automate/dashboards-and-notebooks/notebooks')
const DB = src('Dashboards', 'https://docs.dynatrace.com/docs/analyze-explore-automate/dashboards-and-notebooks/dashboards-new')
const VAR = src('Dashboard variables', 'https://docs.dynatrace.com/docs/analyze-explore-automate/dashboards-and-notebooks/dashboards-new/components/dashboard-component-variable')
const ANN = src('Add annotations to dashboards', 'https://docs.dynatrace.com/docs/analyze-explore-automate/dashboards-and-notebooks/dashboards-new/components/dashboard-component-annotation')
const DOC = src('Dashboard document structure', 'https://docs.dynatrace.com/docs/analyze-explore-automate/dashboards-and-notebooks/document-api/document-structure-dashboards')
const DRILL = src('Drilldowns and navigation', 'https://docs.dynatrace.com/docs/analyze-explore-automate/dashboards-and-notebooks/drilldowns-and-navigation')
const SHARE = src('Share documents', 'https://docs.dynatrace.com/docs/discover-dynatrace/get-started/dynatrace-ui/share')
const DIFF = src('Differences between Dashboards and Notebooks', 'https://docs.dynatrace.com/docs/analyze-explore-automate/dashboards-and-notebooks/differences-dashboards-notebooks')
const REPORTS = src('Dashboard reports (Classic)', 'https://docs.dynatrace.com/docs/shortlink/dashboard-reports')
const DQLBP = src('DQL best practices', 'https://docs.dynatrace.com/docs/platform/grail/dynatrace-query-language/dql-best-practices')
const DQLDATA = src('DQL data source commands', 'https://docs.dynatrace.com/docs/platform/grail/dynatrace-query-language/commands/data-source-commands')
const VIS = src('Visualizations', 'https://docs.dynatrace.com/docs/analyze-explore-automate/dashboards-and-notebooks/edit-visualizations')
const SV = src('Single value visualization', 'https://docs.dynatrace.com/docs/analyze-explore-automate/dashboards-and-notebooks/edit-visualizations/visualization-chart-single-value')
const HC = src('Honeycomb visualization', 'https://docs.dynatrace.com/docs/analyze-explore-automate/dashboards-and-notebooks/edit-visualizations/visualization-honeycomb')
const HIST = src('Histogram visualization', 'https://docs.dynatrace.com/docs/analyze-explore-automate/dashboards-and-notebooks/edit-visualizations/visualization-histogram')

export const notebooksSupplement: LessonSupplement = {
  moduleId: 'notebooks',
  extend: {
    choose: {
      paragraphs: [
        'La comparación oficial lo resume así: los Notebooks se leen y los Dashboards se ven. Los Notebooks encajan en training y enablement, documentación, análisis ad hoc y troubleshooting, investigación de incidentes complejos que requieren un análisis más profundo y colaboración para compartir análisis. Los Dashboards encajan en la monitorización continua en tiempo real, el seguimiento de métricas clave y KPIs, la visión general de la salud del sistema y el seguimiento regular de SLOs.',
        'También cambia dónde vive el dato: los datos de un Notebook se almacenan dentro del Notebook, mientras que los datos de un Dashboard se consultan cuando se abre el Dashboard. Por eso un Notebook sirve como evidencia de una investigación pasada y un Dashboard como vista viva.',
      ],
      reason: 'R-NOT-08 y R-NOT-16 (casos de uso y almacenamiento de datos según la comparación oficial).',
    },
    'deep-notebook-sections': {
      corrections: [
        { find: 'JavaScript/TypeScript', replace: 'JavaScript' },
        { find: 'Las variables reactivas (`$variable`) permiten parametrizar consultas de modo que cambiar un menú desplegable actualice instantáneamente todos los bloques DQL vinculados.', replace: 'Las variables (`$variable`) son una función de Dashboards: la documentación de Notebooks no describe variables, así que en un Notebook el contexto se ajusta con el timeframe y los segments de cada sección.' },
        { find: 'Variables ($var): parámetros interactivos para filtrar consultas DQL.', replace: 'Timeframe y segments por sección: el contexto que filtra cada consulta.' },
        { find: 'Markdown: explicación, anotaciones y documentación reproducible.', replace: 'Markdown: explicación, notas y documentación reproducible.' },
      ],
      bullets: ['Prompt: una pregunta en lenguaje natural que la IA generativa traduce a una consulta DQL.'],
      reason: 'La lección atribuía variables a Notebooks y TypeScript a las secciones Code; la documentación de Notebooks describe secciones Code en JavaScript y no documenta variables. Auditoría final: faltaba la sección Prompt y "anotaciones" en Markdown se confundía con Annotations (que se configuran sobre gráficos).',
    },
    'deep-dashboard-model': {
      corrections: [
        { find: 'Markdown tiles (para añadir títulos, notas explicativas y anotaciones operativas)', replace: 'Markdown tiles (para añadir títulos y notas explicativas; las anotaciones de eventos se configuran sobre los gráficos, no en tiles Markdown)' },
        { find: 'Anotaciones y texto enriquecido', replace: 'Títulos, notas y texto enriquecido' },
        { find: 'El nombre de una variable no puede', replace: 'La clave de una variable no puede' },
        { find: 'soportan diversos tipos de tiles: Query tiles', replace: 'soportan diversos tipos de tiles: Explore tiles (exploración point-and-click sin DQL), Code tiles (JavaScript ejecutado como Dynatrace function), Query tiles' },
        { find: 'y componentes especializados.', replace: 'y componentes como Service-Level Objectives, Image y Variables.' },
      ],
      reason: 'Las anotaciones no son tiles Markdown (se superponen a gráficos Line, Area y Bar) y la restricción dt_ se aplica a la clave de la variable. Auditoría final: la lista de tipos de tile omitía Explore y Code.',
    },
    'deep-analysis-recipe': {
      corrections: [
        { find: 'Un Dashboard puede reutilizar un tile de Notebook', replace: 'Un Dashboard puede reutilizar una sección de Notebook (Add to dashboard)' },
      ],
      reason: 'Un Notebook tiene secciones, no tiles; la acción documentada es Add to dashboard.',
    },
    'deep-document-sharing': {
      corrections: [
        { find: 'el owner anterior puede perder acceso inmediatamente', replace: 'el owner anterior pierde el acceso inmediatamente' },
      ],
      reason: 'La documentación afirma que al cambiar el owner pierdes el acceso de inmediato (R-NOT-18).',
    },
  },
  precision: {
    corrections: [
      { topic: 'Tile Types en Dashboards', find: 'Los Dashboards soportan tiles de DQL query, tiles de Markdown con texto/anotaciones y componentes de visualización estructurada.', replace: 'Los Dashboards ofrecen tiles Explore, Query (DQL), Code (JavaScript) y Markdown, además de Service-Level Objectives, Image y Variables.' },
      { topic: 'Tile Types en Dashboards', find: 'Las anotaciones y notas explicativas se incorporan mediante tiles Markdown dedicados.', replace: 'Las anotaciones no son tiles: se configuran sobre gráficos Line, Area o Bar (con DQL, código o alertas).' },
      { topic: 'Variables y Parámetros ($var)', find: 'Tanto Notebooks como Dashboards admiten variables reactivas referenciadas como `$variable` en queries DQL para parametrizar vistas.', replace: 'Las variables (`$variable`) son una función de Dashboards (tipos DQL, Code, List y Free Text). Notebooks no documenta variables: el contexto se ajusta con el timeframe y los segments de cada sección.' },
      { topic: 'Variables y Parámetros ($var)', find: 'Al cambiar el selector de variable, todas las queries asociadas se reejecutan automáticamente.', replace: 'Al cambiar una variable se recalculan las variables que dependen de ella y se actualizan los tiles que la usan.' },
      { topic: 'Drilldowns y Enlaces de Contexto', find: 'Los tiles de Dashboard admiten acciones de drilldown que transmiten timeframe, entity ID y variables hacia Notebooks u otras vistas.', replace: 'Open with y los Suggested app links pasan el contexto de la selección (campos, entidades, timeframe y filtros); los custom links pueden usar placeholders como {{:from}}, {{:to}} o variables del Dashboard ({{$variable}}).' },
    ],
    reason: 'Auditoría final: la ficha decía que las anotaciones son tiles Markdown, que Notebooks tiene variables y que los drilldowns pasan variables; se alinea con la documentación de Dashboards, variables, anotaciones y Drilldowns and navigation.',
  },
  sections: [
    {
      id: 'sup-notebook-section-actions',
      after: 'deep-notebook-sections',
      title: 'Secciones de Notebook: acciones, resultados y análisis',
      lead: 'Cada sección se ejecuta, oculta, exporta o reutiliza de forma independiente.',
      paragraphs: [
        'Un Notebook admite secciones Explore (exploración point-and-click de logs, métricas y business events, sin escribir DQL), Query (muestra datos consultados en Grail con DQL), Code (muestra datos devueltos por JavaScript ejecutado como Dynatrace function, por ejemplo tras llamar a una API externa) y Markdown (contenido estático editado en Markdown, ideal para la narrativa), además de la sección Prompt, que usa IA generativa para traducir preguntas en lenguaje natural a consultas DQL. No existe un tipo de sección Custom Function. Desde una sección Explore, Create DQL section crea una sección Query con la DQL equivalente para seguir trabajando con la consulta explícita.',
        'Run ejecuta una sección y Run all, en el menú x sections de la esquina superior derecha del Notebook, ejecuta todas las secciones del Notebook; desde ese menú también puedes fijar el timeframe de todas las secciones seleccionadas. Clear result borra el resultado de la sección pero conserva su consulta, así que basta con volver a ejecutarla; Delete section elimina la sección entera. Hide input oculta la consulta o el código de la sección y deja visible solo el resultado, lo que permite presentar un informe sin mostrar la DQL. Duplicate section copia la sección para reutilizarla.',
        'Cada sección Query tiene su propio selector de timeframe; si el timeframe se define en la propia consulta, el selector queda deshabilitado y manda el intervalo de la consulta. Cada sección tiene también su propio selector de segments: un segment aplicado en una sección solo filtra esa sección.',
        'El menú de la sección incluye Download result con tres formatos: CSV (con las columnas visibles y su formato), CSV (raw) (todos los datos, sin formato) y JSON; no hay exportación de resultados a XLSX ni a PDF. Add to dashboard lleva la sección a un Dashboard y Open with abre la sección en otra app de Dynatrace. Para enlazar desde Markdown a una sección concreta de otro Notebook se usa la ruta del Notebook seguida de # y el identificador de la sección.',
        'En una serie temporal puedes elegir la visualización Davis AI analysis. El analyzer Forecast (Prediction) predice la evolución de la serie, por ejemplo cuándo se llenará un disco; los analyzers de anomaly detection (Static threshold, Auto adaptive threshold y Seasonal baseline) detectan desviaciones, no predicen. El analyzer admite análisis de hasta 1000 series: con un split por miles de entidades hay que filtrar o reducir el split antes de analizar.',
        'Para probar una expresión (por ejemplo un parse) sin ingerir nada, una sección Query puede empezar con el comando data, que genera datos de ejemplo en tiempo de consulta a partir de record() o de un JSON. En cambio, fetch lee datos ingeridos en Grail, load carga datos de lookup almacenados y el comando lookup enriquece registros existentes.',
      ],
      bullets: [
        'Explore → Create DQL section → Query con la DQL equivalente.',
        'Clear result: borra el resultado, conserva la consulta.',
        'Hide input: oculta la consulta, conserva el resultado.',
        'Download result: CSV, CSV (raw) o JSON.',
        'Davis AI analysis: Forecast predice; anomaly detection detecta; hasta 1000 series.',
      ],
      code: '[Ver el análisis](/ui/apps/dynatrace.notebooks/notebook/<notebookid>#<sectionid>)\n\ndata record(content = "2026-10-01 ERROR user=42 code=500"),\n     record(content = "2026-10-01 INFO user=7 code=200")\n| fieldsAdd isError = contains(content, "ERROR")',
      codeNote: 'Primera línea: enlace Markdown a una sección concreta de otro Notebook. Después: una sección Query que prueba una expresión con datos de ejemplo generados por data, sin leer Grail.',
      sourceRefs: [NB, DQLDATA],
    },
    {
      id: 'sup-dashboard-tiles-timeframe',
      after: 'deep-dashboard-model',
      title: 'Dashboards: tiles, timeframe, refresco y segments',
      lead: 'Saber qué intervalo y qué filtro usa cada tile evita cifras que no cuadran.',
      paragraphs: [
        'Desde el menú Add de un Dashboard creas tiles Explore (exploración point-and-click de logs, métricas y business events, sin conocimientos de DQL ni de código), Query (DQL), Code (JavaScript ejecutado como Dynatrace function) y Markdown, además de Service-Level Objectives, Image y Variables. La consulta o el código de un tile se definen en su pestaña Data. Un tile Query admite cualquier DQL, por eso es la opción cuando necesitas una transformación que Explore no ofrece. Las anotaciones no son un tile: se configuran sobre un gráfico.',
        'El Dashboard tiene un timeframe global que siguen los tiles sin override. Un tile puede definir su propio Custom timeframe, que prevalece sobre el global para ese tile aunque cambies el selector del Dashboard. Si la DQL del tile define el timeframe (por ejemplo, fetch events, from: now()-7d), el selector de timeframe queda deshabilitado y se usa el intervalo de la consulta. El timeframe por defecto que configuras en Settings se aplica solo a una nueva sesión con el Dashboard; la vista abierta conserva su selección.',
        'La primera vez que abres un Dashboard, el refresh rate está en Off (sin refresco automático). Si lo cambias, ese valor se recuerda la próxima vez que abras el Dashboard. Un refresco más frecuente no acelera nada: vuelve a ejecutar las consultas y aumenta la carga.',
        'Los segments se seleccionan a nivel de Dashboard y a nivel de tile, y las selecciones de segment del tile sustituyen (override) a las del Dashboard para ese tile; no se combinan. Los segments se aplican automáticamente sobre las consultas de los tiles y conviene usarlos cuando quieres reutilizar el mismo filtro entre Dashboards. Si necesitas más control sobre cómo se aplica el filtro, como elegir el operador (==, startsWith, in) o cómo depende de otros filtros, usa variables, que referencias explícitamente en la DQL.',
        'Si la misma DQL devuelve cifras distintas en un Notebook y en un Dashboard, comprueba primero el contexto de ejecución: el timeframe efectivo y los valores de variables, filtros y segments aplicados. La visualización, la posición del tile o el owner del documento no cambian los registros que devuelve la consulta.',
        'Si editas un Dashboard en el que no tienes permiso de escritura, los cambios son temporales: puedes guardarlos con Save as new, que crea una copia nueva con tus cambios, o descartarlos. Cuando ejecutas un tile o una sección Code escritos por otra persona, Dynatrace ejecuta ese JavaScript con tu cuenta de usuario y tus permisos; por eso, antes de ejecutarlo, puedes revisarlo en la página Review code y aprobarlo solo esta vez con Accept and run o de forma permanente marcando Always trust code in this document antes de Accept and run.',
        'Dashboards guarda versiones automáticamente: puedes acceder a las 50 versiones más recientes y cada versión está disponible hasta 30 días. Desde el historial, Preview muestra una versión, Restore cambia el Dashboard a la versión elegida, Make a copy crea un Dashboard nuevo a partir de esa versión y deja el original sin cambios, y Download guarda el JSON de la versión. Un tile de Dashboard se copia a un Notebook como sección con Add to notebook (nuevo o existente); en sentido inverso, una sección de Notebook llega a un Dashboard con Add to dashboard.',
        'Para que un Dashboard cargue rápido, aplica las DQL best practices en cada tile: acota el timeframe (una ventana más corta rinde mejor con los mismos datos), filtra lo antes posible con filter o search, selecciona campos pronto con fields, fieldsKeep o fieldsRemove y coloca sort al final de la consulta, porque ordenar justo después de fetch y seguir procesando reduce el rendimiento.',
      ],
      comparison: {
        headers: ['Configuración del tile', 'Intervalo que usa', 'Al cambiar el selector global'],
        rows: [
          ['Sin override', 'El timeframe global del Dashboard', 'Sigue al selector global'],
          ['Custom timeframe del tile', 'El del tile', 'Lo conserva: el tile prevalece'],
          ['Timeframe en la DQL (from:)', 'El de la consulta', 'Selector del tile deshabilitado'],
        ],
      },
      sourceRefs: [DB, DQLBP],
    },
    {
      id: 'sup-dashboard-variables',
      after: 'sup-dashboard-tiles-timeframe',
      title: 'Variables de Dashboard: tipos, claves y uso',
      lead: 'Una variable es un parámetro explícito que tú decides dónde y cómo aplicar.',
      paragraphs: [
        'Una variable de Dashboard puede ser de cuatro tipos: DQL (el valor lo devuelve una consulta que escribes al definir la variable, útil para descubrir valores actuales como los servicios existentes), Code (el valor lo devuelve código que escribes, por ejemplo tras llamar a una API externa), List (una lista de valores separados por comas, CSV, para un conjunto fijo y controlado) y Free Text (texto libre que escribe el lector, con un Default value opcional).',
        'Dynatrace deriva la clave de la variable a partir de su nombre sustituyendo cualquier carácter que no sea letra o número por _ (por ejemplo, Error Rate da Error_Rate), y la clave no puede empezar por el prefijo reservado dt_. En consultas, código, Markdown y títulos se referencia con el prefijo $, como $Error_Rate.',
        'Para ofrecer un conjunto fijo de valores y permitir elegir varios a la vez, usa una variable List con Multi-select activado. Con Multi-select, el lector puede elegir varios valores a la vez; en DQL hay que envolver la variable con array() y usar in(), por ejemplo filter in(host.name, array($Host)). Si no defines un Default value, se selecciona el primer valor disponible.',
        'Display as filter on dashboard controla si la variable se muestra como filtro: al desactivarlo se oculta el selector, pero los tiles siguen usando la variable. Una variable oculta resuelve su valor automáticamente a partir de las opciones disponibles: una multi-select oculta se resuelve a * (todas las opciones) y una single-select oculta, a la primera opción disponible.',
        'Las variables sirven para filtrar el contenido del Dashboard o para actuar como valores en tiles Code. Se usan en tiles DQL, en tiles Code (por seguridad, solo dentro de la default function), en tiles Markdown y en títulos de tile, y también en la DQL o el código de las anotaciones. En tiles Explore solo funcionan las variables single-select combinadas con el operador =.',
        'Una variable puede referirse a otra en su definición (por ejemplo, Servicio según Región): el valor de una variable se recalcula si su definición se refiere a otra variable que cambia. No se permiten bucles: si A depende de B, B no puede depender de A. Los valores seleccionados viajan en la URL del Dashboard, pero si los valores de las variables superan 30 KB no pueden almacenarse en la URL.',
      ],
      code: 'fetch logs\n| filter in(host.name, array($Host))   // $Host con Multi-select\n| makeTimeseries count(), by:{ host.name }',
      codeNote: 'Con single-select basta host.name == $Host; con Multi-select la variable contiene varios valores y se usa in() con array().',
      sourceRefs: [VAR, ANN],
    },
    {
      id: 'sup-dashboard-json',
      after: 'sup-dashboard-variables',
      title: 'El documento JSON de un Dashboard',
      lead: 'tiles define el contenido; layouts, la posición en una cuadrícula de 24 columnas.',
      paragraphs: [
        'Un Dashboard de Latest Dynatrace es un documento JSON que se gestiona de forma programática con la Document API. Sus propiedades raíz obligatorias son version, variables, tiles y layouts; settings es opcional. Desde la versión 1.344 de Dynatrace, un dashboard que no supera la validación no se carga.',
        'Los IDs de los tiles en tiles deben coincidir con los IDs en layouts: un tile sin una entrada en layouts con su mismo ID no queda colocado. La cuadrícula tiene 24 columnas y x, y, w y h son posición horizontal, posición vertical, ancho y alto en unidades de cuadrícula: dos tiles con w: 12 en x: 0 y x: 12 de la misma fila quedan uno junto al otro, cada uno con la mitad del ancho.',
        'Un data tile requiere title, query, visualization y los objetos visualizationSettings y querySettings, que pueden estar vacíos. Un tile markdown guarda su texto en content y no ejecuta DQL. Si un solo tile necesita otra ventana de tiempo, se expresa en la propiedad timeframe del data tile, que debe ser un objeto y no una cadena. Un tile también puede llevar su propio filtro de segments.',
      ],
      code: '"tiles": {\n  "1": { "type": "data", "title": "Errores", "query": "fetch logs | filter loglevel == \\"ERROR\\"",\n         "visualization": "lineChart", "visualizationSettings": {}, "querySettings": {},\n         "timeframe": { "tileTimeframeEnabled": true,\n                        "tileTimeframe": { "from": "now()-24h", "to": "now()" } } },\n  "2": { "type": "markdown", "content": "# Notas del turno" }\n},\n"layouts": {\n  "1": { "x": 0,  "y": 0, "w": 12, "h": 6 },\n  "2": { "x": 12, "y": 0, "w": 12, "h": 6 }\n}',
      codeNote: 'Los IDs "1" y "2" coinciden en tiles y layouts. Con 24 columnas, w: 12 es medio ancho: los dos tiles quedan lado a lado.',
      sourceRefs: [DOC],
    },
    {
      id: 'sup-annotations',
      after: 'visualizations',
      title: 'Anotaciones sobre gráficos',
      lead: 'Una anotación sitúa un evento, como un despliegue, sobre la serie temporal.',
      paragraphs: [
        'Las anotaciones marcan eventos sobre un gráfico de series temporales para correlacionarlos con cambios de la serie. Solo se admiten en las visualizaciones Line, Area y Bar; Single value o Pie chart no tienen eje temporal. Se definen con una consulta DQL que devuelva timestamps y metadatos, con código JavaScript o seleccionando alertas del entorno. Existen en Dashboards y en Notebooks; en un Notebook, las anotaciones son específicas de la sección a la que se añaden.',
        'En el mapeo de campos, name (texto que se muestra en el gráfico) y start (punto de anclaje) son obligatorios; description (tooltip) y end son opcionales, y end convierte el punto en un rango. Con alertas, el mapeo por defecto es event.name para el nombre, event.description para la descripción y event.start y event.end para el intervalo. En la DQL o el código de una anotación puedes usar variables del Dashboard igual que en los tiles, con el prefijo $ (por ejemplo $Host).',
      ],
      comparison: {
        headers: ['Campo', 'Obligatorio', 'Uso'],
        rows: [
          ['name', 'Sí', 'Texto que se muestra en el gráfico'],
          ['start', 'Sí', 'Punto de anclaje'],
          ['description', 'No', 'Tooltip'],
          ['end', 'No', 'Convierte el punto en un rango'],
        ],
      },
      sourceRefs: [ANN, NB],
    },
    {
      id: 'sup-visualization-types',
      after: 'sup-annotations',
      title: 'Tipos de visualización y cuándo usarlos',
      lead: 'Cada visualización responde a una forma de pregunta distinta.',
      paragraphs: [
        'Single value muestra una única medida agregada y su tendencia en el tiempo; es la opción para KPIs de negocio o SLOs críticos. Puede añadir una sparkline (área, línea o barras) y un trend, que calcula la diferencia entre el primer y el último elemento de la serie, en valor absoluto o en porcentaje. Si el resultado tiene varias filas, Single value cambia a vista de cuadrícula y muestra hasta 25 valores individuales.',
        'Honeycomb ofrece una vista compacta y de alta densidad de métricas sobre muchas entidades, ideal para monitorizar infraestructura y detectar hotspots; los colores se aplican con reglas condicionales evaluadas de arriba abajo. Histogram visualiza la distribución de valores numéricos en bins, cada uno un rango continuo, por ejemplo la distribución de tiempos de respuesta.',
        'Line, Area y Bar muestran evolución temporal; Table, Raw y Record list muestran registros; Pie y Donut, proporciones; y los mapas (Choropleth, Dot, Connection y Bubble map), datos geográficos. Si eliges una visualización no adecuada para la consulta, un mensaje te pide elegir otra visualización o modificar la consulta.',
      ],
      sourceRefs: [VIS, SV, HC, HIST],
    },
    {
      id: 'sup-navigation-links',
      after: 'dashboard-operations',
      title: 'Open with, enlaces y navegación con contexto',
      lead: 'Pasar de un tile a otra app sin perder el contexto acelera el drill-down.',
      paragraphs: [
        'Open with muestra acciones que puedes realizar en otras apps de Dynatrace con los datos seleccionados. Los Suggested app links aparecen sin configuración manual cuando los datos lo permiten: por ejemplo, si el resultado contiene un host ID se ofrece Go to Host. Ambos pasan el contexto de la selección (campos y entidades, timeframe y filtros aplicados); no reenvían la DQL del tile. Cuanto más concreta es la selección, más acotado es el contexto: seleccionar un punto de datos transmite un contexto más específico que seleccionar todo el tile.',
        'En enlaces manuales a un Dashboard o Notebook, una ruta relativa (/ui/dashboards/...) abre en la misma pestaña y una URL absoluta (https://<environment>/ui/dashboards/...) abre una pestaña nueva. Los custom links se crean desde el menú de la visualización, pero las visualizaciones de mapa (Choropleth, Dot, Connection y Bubble map) no admiten custom links. Las tablas admiten columnas Markdown con enlaces: una URL sin más, un enlace con nombre [Display](URL) o enlaces basados en intents.',
      ],
      sourceRefs: [DRILL],
    },
    {
      id: 'sup-sharing-methods',
      after: 'deep-document-sharing',
      title: 'Métodos de sharing y niveles Can view y Can edit',
      lead: 'Elige el método y el nivel que cubren la necesidad sin dar más capacidad de la necesaria.',
      paragraphs: [
        'Dashboards y Notebooks se comparten de tres formas: Access for all (view-only), que da acceso de solo lectura a todo el entorno; Share access, para elegir usuarios o grupos con Can view o Can edit; y Share links, URLs con permiso de view o edit que los destinatarios pueden reenviar a otras personas del entorno, que reciben el mismo nivel de permiso. Un Share link no lo puede usar nadie fuera del entorno de Dynatrace.',
        'Can view permite mostrar el documento, ajustar timeframe y filtros, refrescar, maximizar tiles, copiar tiles, guardar una copia y exportar la definición JSON; no permite guardar cambios en el original. Can edit añade modificar el contenido, el layout y el nombre, añadir o cambiar datos, código y Markdown, y gestionar variables y filtros, pero no puede compartir, cambiar el owner ni eliminar el documento. Compartir queda reservado al owner salvo que active Allow editors to share, que permite compartir también a los editores.',
        'Cambiar el owner es una transferencia: al cambiar el owner del documento pierdes el acceso inmediatamente y solo lo recuperas si el nuevo owner lo comparte contigo.',
        'En Dashboards Classic existían los Dashboard reports: están desactivados por defecto y, si se activan para un dashboard, los usuarios con acceso pueden suscribirse a reports semanales (cada lunes) o mensuales (el primer lunes del mes). El email no contiene el contenido del report, sino un enlace público que no requiere credenciales. Dynatrace recomienda migrar a la nueva app Dashboards.',
      ],
      comparison: {
        headers: ['Acción', 'Can view', 'Can edit', 'Owner'],
        rows: [
          ['Ajustar timeframe y filtros, exportar JSON, guardar una copia', 'Sí', 'Sí', 'Sí'],
          ['Guardar cambios en el original', 'No', 'Sí', 'Sí'],
          ['Compartir', 'No', 'Solo con Allow editors to share', 'Sí'],
          ['Cambiar el owner o eliminar', 'No', 'No', 'Sí'],
        ],
      },
      sourceRefs: [SHARE, NB, REPORTS],
    },
  ],
}
