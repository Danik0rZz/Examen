import type { LessonSupplement } from './types'

type Ref = { title: string; url: string; kind: 'official-docs' }
const ref = (title: string, url: string): Ref => ({ title, url, kind: 'official-docs' })

const DATA_FLOW = ref('Data flow in OpenPipeline', 'https://docs.dynatrace.com/docs/platform/openpipeline/concepts/data-flow')
const PROC_STAGE = ref('Processing stage in OpenPipeline', 'https://docs.dynatrace.com/docs/platform/openpipeline/concepts/processing-stage')
const PROCESSING = ref('Processing in OpenPipeline', 'https://docs.dynatrace.com/docs/platform/openpipeline/concepts/processing')
const GROUPS = ref('OpenPipeline pipeline groups', 'https://docs.dynatrace.com/docs/platform/openpipeline/concepts/pipeline-groups')
const ACCESS = ref('OpenPipeline access control', 'https://docs.dynatrace.com/docs/platform/openpipeline/concepts/access-control')
const FORWARDING = ref('Forwarding data via OpenPipeline', 'https://docs.dynatrace.com/docs/platform/openpipeline/concepts/forwarding')
const LOG_OP = ref('Log processing with OpenPipeline', 'https://docs.dynatrace.com/docs/analyze-explore-automate/logs/lma-log-processing/lma-openpipeline')
const LOG_API = ref('Log ingestion API', 'https://docs.dynatrace.com/docs/analyze-explore-automate/logs/lma-log-ingestion/lma-log-ingestion-via-api')
const POST_LOGS = ref('Log Monitoring API v2 - POST ingest logs', 'https://docs.dynatrace.com/docs/dynatrace-api/environment-api/log-monitoring-v2/post-ingest-logs')
const LMA_LIMITS = ref('Log Management and Analytics default limits', 'https://docs.dynatrace.com/docs/analyze-explore-automate/logs/lma-limits')
const LOG_INGESTION = ref('Log ingestion', 'https://docs.dynatrace.com/docs/analyze-explore-automate/logs/lma-log-ingestion')
const OA_LOGS = ref('Log ingestion via OneAgent', 'https://docs.dynatrace.com/docs/analyze-explore-automate/logs/lma-log-ingestion/lma-log-ingestion-via-oa')
const AUTODISCOVERY = ref('Log content autodiscovery', 'https://docs.dynatrace.com/docs/analyze-explore-automate/logs/lma-log-ingestion/lma-log-ingestion-via-oa/lma-autodiscovery')
const INGEST_RULES = ref('Log ingest rules', 'https://docs.dynatrace.com/docs/analyze-explore-automate/logs/lma-log-ingestion/lma-log-ingestion-via-oa/lma-log-storage-configuration')
const SYSLOG = ref('Syslog ingestion', 'https://docs.dynatrace.com/docs/analyze-explore-automate/logs/lma-log-ingestion/lma-log-ingestion-syslog')
const CLOUD_LOGS = ref('Cloud provider log forwarding', 'https://docs.dynatrace.com/docs/analyze-explore-automate/logs/lma-log-ingestion/lma-cloud-provider-log-forwarding')
const OTLP = ref('Dynatrace OTLP API endpoints', 'https://docs.dynatrace.com/docs/ingest-from/opentelemetry/otlp-api')
const OTEL = ref('OpenTelemetry and Dynatrace', 'https://docs.dynatrace.com/docs/ingest-from/opentelemetry')
const OTEL_TS = ref('OpenTelemetry troubleshooting', 'https://docs.dynatrace.com/docs/ingest-from/opentelemetry/troubleshooting')

export const ingestionSupplement: LessonSupplement = {
  moduleId: 'ingestion',
  extend: {
    'deep-activegate-integrations': {
      paragraphs: [
        'VMware vSphere monitoring requiere un Environment ActiveGate, con la propiedad vmware_monitoring_enabled=true en custom.properties (es el valor por defecto, no hay que activarla), conectado a vCenter o a un ESXi standalone. Basta con un usuario con acceso de solo lectura a vCenter: no se requieren privilegios de administrador. El ActiveGate recoge los datos de la capa de virtualización (CPU, memoria, almacenamiento, migraciones vMotion y nuevas VM) y los envía a Dynatrace; OneAgent instalado en cada VM aporta la visibilidad del sistema operativo y de los procesos.',
        'La monitorización de la capa de gestión de virtualización está soportada para VMware; con otros hipervisores se usa OneAgent en los hosts.',
      ],
      reason: 'R-ING-11, R-ING-12 y R-ING-23 necesitan el contrato de VMware vSphere monitoring (ActiveGate, solo lectura, capas y otros hipervisores). Auditoría v4: vmware_monitoring_enabled está en custom.properties y vale true por defecto.',
    },
    openpipeline: {
      corrections: [
        {
          find: 'El scope puede ser global, por tenant, tipo de datos o contexto de configuración.',
          replace: 'En OpenPipeline, los configuration scopes son tipos de datos (logs, events, spans, metrics…): cada uno tiene sus propias ingest sources, rutas y pipelines. No hay que confundirlos con los scopes de las log ingest rules de OneAgent (Host, Kubernetes cluster, Host group, Environment).',
        },
      ],
      reason: 'Auditoría v4: «global, por tenant, … contexto de configuración» no corresponde al modelo documentado; los pipelines son específicos de cada configuration scope (tipo de datos), según Data flow in OpenPipeline.',
    },
    'retention-storage': {
      paragraphs: [
        'Los logs se guardan por defecto en el bucket default_logs, con 35 días de retención; los buckets custom admiten retenciones de 10 días a 10 años. La retención es una propiedad del bucket: para conservar más tiempo ciertos logs se crea un bucket custom y se asignan con un processor de la etapa Bucket assignment del pipeline. Ni el routing ni las log ingest rules fijan la retención.',
      ],
      reason: 'R-ING-08 y R-ING-27 necesitan la retención de default_logs, el rango de los buckets custom y dónde se asigna el bucket.',
    },
  },
  precision: {
    corrections: [
      {
        topic: 'Syslog Receiver en ActiveGate',
        find: 'Dispositivos de red e hipervisores que no admiten agentes se integran habitualmente vía syslog.',
        replace: 'Dispositivos de red (firewalls, routers…) que no admiten agentes se integran habitualmente vía syslog; VMware se integra con un Environment ActiveGate conectado a vCenter y los demás hipervisores con OneAgent en los hosts.',
      },
    ],
    remove: ['Timestamp de logs'],
    add: [
      {
        topic: 'Timestamp de logs (Log ingestion API)',
        fact: 'Los registros con timestamp anterior a la hora actual menos 24 horas se descartan (la API responde 400 si todos están fuera de rango y 200 si solo una parte); los que superan en más de 10 minutos la hora actual se ingieren con el timestamp reseteado a la hora de ingesta.',
        examNote: 'Un registro futuro no se descarta: se reajusta. Ante datos ausentes revisa el timestamp original, no solo la hora de la query.',
        source: { title: LMA_LIMITS.title, url: LMA_LIMITS.url },
      },
    ],
    reason: 'Auditoría v4: syslog no es la vía habitual para hipervisores (VMware vSphere monitoring); la regla de timestamp era vaga y se sustituye por la documentada en Log Management and Analytics default limits.',
  },
  sections: [
    {
      id: 'sup-op-sources-routing',
      after: 'deep-openpipeline',
      title: 'Ingest sources, routing y forwarding en OpenPipeline',
      lead: 'Antes de que un pipeline toque un registro, OpenPipeline ya sabe por qué fuente entró y a qué pipeline va.',
      paragraphs: [
        'El flujo documentado es: ingest source → primary Grail tags → pre-processing (solo en custom ingest sources) → routing → pipeline → almacenamiento en un bucket de Grail, con forwarding opcional. Cada ingest source se define por un nombre y una ruta, y esa ruta se identifica con el atributo dt.openpipeline.source.',
        'Las reglas de primary Grail tags se evalúan para cada registro elegible antes del pre-processing de la ingest source y del routing; promueven campos existentes a primary_tags.* para que puedan usarse como condiciones de routing. El pre-processing de una custom ingest source también precede al routing, así que puede normalizar estructuras distintas de varios proveedores antes de evaluar las rutas. En cambio, los campos que crea la etapa Processing de un pipeline todavía no existen cuando se evalúa el routing.',
        'Hay tres tipos de ingest source. Las built-in pertenecen a OpenPipeline, son view-only, no tienen pre-processing configurable y solo admiten routing dinámico. Las ready-made pertenecen a la extensión que las crea, son view-only para los usuarios (settings:read), no tienen pre-processing configurable y admiten routing estático y dinámico. Las custom las crea el usuario, tienen pre-processing configurable, admiten routing estático y dinámico y usan owner-based access control.',
        'Con routing estático, los datos de la ingest source van a un pipeline concreto, que permanece fijo hasta que se cambie manualmente: no se evalúan rutas dinámicas ni se duplica el registro. Con routing dinámico, cada ruta tiene como condición de coincidencia una consulta DQL; la posición en la lista establece el orden de ejecución y el registro va al pipeline de la primera ruta que coincide. Si ninguna coincide, el registro sigue la Default route hacia el pipeline built-in (el default pipeline), que asegura su almacenamiento en Grail.',
        'Los logs que una ruta dinámica envía a un pipeline custom no son procesados por el default pipeline; solo los que no se enrutan a pipelines custom pasan por él. Por eso, al crear una ruta nueva, las reglas del default pipeline dejan de aplicarse a los registros desviados.',
        'El almacenamiento y la retención de los system events no son configurables. Forwarding es un paso del flujo que envía registros a cloud object storage soportado mediante un Dynatrace AWS o Azure Connector: puede reenviar registros sin procesar, inmediatamente después de la ingesta, o procesados, tras el procesamiento del pipeline. Los registros pueden seguir almacenados en Grail mientras se reenvía solo lo que necesitan los sistemas externos.',
      ],
      comparison: {
        headers: ['Tipo de ingest source', 'Propietario y acceso', 'Pre-processing', 'Routing'],
        rows: [
          ['Built-in', 'OpenPipeline · view-only (settings:read)', 'No configurable', 'Solo dinámico'],
          ['Ready-made', 'Extensión · view-only (settings:read)', 'No configurable', 'Estático y dinámico'],
          ['Custom', 'Usuario · owner-based access control', 'Configurable', 'Estático y dinámico'],
        ],
      },
      sourceRefs: [DATA_FLOW, LOG_OP, FORWARDING],
    },
    {
      id: 'sup-op-stages-processors',
      after: 'sup-op-sources-routing',
      title: 'Stages y processors dentro de un pipeline',
      lead: 'El orden de las etapas es fijo; lo que configuras son los processors de cada etapa.',
      paragraphs: [
        'Cada pipeline ejecuta sus stages en un orden fijo que no se puede alterar: Processing, Smartscape node, Smartscape edge, Permission, Product allocation, Cost allocation, Bucket assignment, Metric extraction, Davis y Data extraction. Por eso Metric extraction se ejecuta después de Bucket assignment, y ambas después de Processing. El routing solo elige el pipeline; el bucket se decide en la etapa Bucket assignment con un processor y su matcher.',
        'Un processor combina un matcher, una sentencia DQL que delimita los registros objetivo, y una processing definition, que transforma o modifica los datos filtrados. Los processors se aplican en el orden de la lista: la salida de cada processor es la entrada del siguiente, de modo que un processor posterior ve el registro ya transformado. En Processing, Smartscape, Metric extraction, Davis y Data extraction se ejecutan todos los processors que coinciden; en Permission, Product allocation, Cost allocation y Bucket assignment solo se ejecuta el primer processor que coincide (first match only), así que el orden decide el resultado.',
        'La etapa Processing ofrece los processors DQL, Add fields, Remove fields, Rename fields, Drop record, Inline lookup, GeoIP lookup (Early Access) y Technology bundle, que aplica parsers predefinidos a los logs de tecnologías soportadas. Drop record elimina los registros completos que cumplen el matcher, que no llegan a almacenarse en Grail; Remove fields quita campos concretos y conserva el registro; Rename fields solo cambia el nombre (el valor se sigue guardando); Inline lookup mapea valores con una tabla clave-valor definida en el processor. Para enmascarar un identificador sensible antes de almacenarlo, la transformación se hace en un processor de Processing. Con logs de OneAgent sin valor hay dos puntos de corte: una log ingest rule Exclude impide que OneAgent los envíe, y un Drop record en Processing los elimina antes del almacenamiento; un bucket con retención corta, en cambio, los sigue almacenando.',
        'Los campos con prefijo dt.temp. son temporales: están disponibles para los processors posteriores del mismo pipeline, se eliminan antes del almacenamiento y no se guardan en Grail ni se reenvían a Workflows. Sirven, por ejemplo, para parsear un valor que solo se necesita para extraer una métrica.',
        'El procesamiento se basa en los registros disponibles y no tiene en cuenta el enriquecimiento desde servicios externos. Antes de guardar la configuración puedes seleccionar Run sample data para probarla con datos de ejemplo y ver el resultado. Para cuentas nuevas creadas desde septiembre de 2026, Classic pipeline no está disponible y los logs se procesan con OpenPipeline.',
        'Las ready-made pipelines pertenecen a la extensión que las crea y son view-only para los usuarios: la extensión define sus processors y los actualiza automáticamente cuando se actualiza, y la pipeline solo se elimina al desinstalar la extensión. Para añadir procesamiento propio sin editarlas se usan pipeline groups.',
      ],
      sourceRefs: [PROCESSING, PROC_STAGE, LOG_OP],
    },
    {
      id: 'sup-op-groups-access',
      after: 'sup-op-stages-processors',
      title: 'Pipeline groups y owner-based access control',
      lead: 'Un equipo central puede imponer reglas a muchos pipelines sin editarlos uno a uno.',
      paragraphs: [
        'Los pipeline groups permiten gestionar la configuración de varios pipelines a la vez y aplicar estándares globales de seguridad y operación. La composición del grupo define base pipelines y la posición del placeholder de member pipelines: las base pipelines situadas antes del placeholder se ejecutan primero, los member pipelines se ejecutan en la posición del placeholder y las base pipelines situadas después se ejecutan a continuación. Así, un administrador puede imponer que la etapa Permission de una base pipeline se ejecute antes que cualquier definición de los equipos.',
        'Cuando una base pipeline y un member pipeline tienen la misma etapa activa, se ejecutan ambas: las etapas no son mutuamente excluyentes. Para impedir que los miembros ejecuten una etapa, como Permission (que fija dt.security_context), se excluye de los member pipelines con memberStages, que indica qué etapas de los miembros pueden ejecutarse (includeAll o include). Una pipeline pertenece a un solo pipeline group a la vez y los pipeline groups no pueden anidarse. Las ready-made pipelines pueden actuar como base pipelines, y tanto las custom como las ready-made pueden ser member pipelines.',
        'Las custom pipelines y las custom ingest sources usan owner-based access control; el routing no está sujeto a él. Los permisos settings:objects:read y settings:objects:write a nivel de entorno no bastan: el owner debe compartir acceso de lectura o edición con usuarios o grupos concretos, y los administradores pueden acceder a cualquier configuración. El owner puede transferir la propiedad a otro usuario o grupo en cualquier momento, sin intervención de un administrador. Las built-in pipelines e ingest sources son view-only y se ven con settings:read.',
      ],
      bullets: [
        'Base antes del placeholder: se ejecuta primero (p. ej., Permission global).',
        'Member pipelines: se ejecutan en la posición del placeholder.',
        'Base después del placeholder: se ejecuta al final.',
        'memberStages: decide qué etapas pueden ejecutar los miembros.',
      ],
      sourceRefs: [GROUPS, ACCESS],
    },
    {
      id: 'sup-log-api-contract',
      after: 'deep-log-ingestion',
      title: 'Log ingestion API: contrato, respuestas y ActiveGate',
      lead: 'Un cliente fiable respeta límites, ventanas de timestamp y códigos retryable.',
      paragraphs: [
        'La Log ingestion API está pensada para cuando no se puede instalar OneAgent, por ejemplo en entornos serverless, y recibe datos de log shippers como Fluent Bit, Fluentd, Logstash o el OpenTelemetry Collector. Endpoint SaaS: https://{environment-id}.live.dynatrace.com/api/v2/logs/ingest; a través de un Environment ActiveGate: https://{activegate}:9999/e/{environment-id}/api/v2/logs/ingest. El ActiveGate sirve el endpoint, recoge los datos y los reenvía a Dynatrace en lotes. Con un Classic access token (cabecera Authorization: Api-Token) el scope es logs.ingest; con un platform token (Bearer) u OAuth el scope es openpipeline:logs:ingest (storage:logs:write figura como legacy).',
        'Cada request admite hasta 10 MB de payload y 50.000 log records; tras el procesamiento un lote puede expandirse hasta 16 MB, y por encima la API responde 413. Cada log event admite hasta 500 atributos. Los registros con timestamp anterior a la hora actual menos 24 horas se descartan: si todos están fuera de rango la API responde 400 y si solo una parte, 200. Los registros con timestamp más de 10 minutos en el futuro se ingieren con el timestamp reseteado a la hora de ingesta.',
        'Respuestas: 204 indica éxito; 200, ingesta parcial por eventos inválidos; 400, entrada inválida; 413, payload demasiado grande. Son retryable con exponential backoff 429 (Too Many Requests), 502, 503 y 504; 400 y 413 no lo son: hay que corregir o dividir el lote. Si la cola en disco del ActiveGate se llena, responde 503 "Usable space limit reached", normalmente de forma temporal en picos de tráfico; si persiste, se aumenta disk_queue_max_size_mb en custom.properties (300 MB por defecto).',
        'Con log processing en un pipeline custom de OpenPipeline, la API admite todos los tipos de datos JSON para los valores de atributos desde SaaS 1.295+ o ActiveGate 1.295+; en los demás casos todos los valores ingeridos se convierten a string.',
      ],
      sourceRefs: [LOG_API, POST_LOGS, LMA_LIMITS],
    },
    {
      id: 'sup-oneagent-logs',
      after: 'sup-log-api-contract',
      title: 'OneAgent: autodiscovery, log ingest rules y Kubernetes',
      lead: 'Detectar un archivo, decidir si se envía y enriquecerlo son tres pasos distintos.',
      paragraphs: [
        'OneAgent es el método de ingesta de logs recomendado: descubre logs automáticamente, centraliza la configuración y aporta masking de datos sensibles, vinculación con entidades y metadatos de Kubernetes. El autodiscovery detecta archivos de log abiertos por procesos en ejecución, ubicaciones conocidas (Windows Event Logs, /var/log/messages, /var/log/syslog), logs de contenedores y journald, y se repite cada 60 segundos. Para autodetectarse, un archivo debe cumplir todos estos requisitos: lo mantiene abierto un proceso en ejecución, existe desde hace al menos un minuto, se ha escrito en los últimos 7 días, está en una carpeta log o logs (o sus subcarpetas) o su nombre contiene log precedido o seguido de punto o guion bajo (.log, _log), y usa una codificación soportada (UTF-8 por defecto; también UTF-8 BOM y, si llevan byte-order mark, UTF-16LE y UTF-16BE). Además, los archivos binarios se excluyen salvo que se configuren como custom log source con formato binario.',
        'Detectar un archivo no implica ingerirlo: que se almacene depende de las log ingest rules, y si ninguna regla coincide el archivo no se envía. Las reglas no amplían la detección: para un archivo que no cumple los criterios del autodiscovery se define un custom log source (Add missing log sources). Las reglas son de tipo Include (almacenar) o Exclude (bloquear), se procesan de arriba abajo y, si una regla superior coincide, las inferiores se omiten. Los matchers distinguen mayúsculas y minúsculas, salvo el atributo Log source en Windows; en Log source se admiten comodines con asterisco (*).',
        'Las log ingest rules se configuran en cuatro scopes, de mayor a menor prioridad: Host, Kubernetes cluster, Host group y Environment; el scope más específico prevalece. Process group, Log source o el nivel de log son atributos del matcher, no scopes de configuración.',
        'En Kubernetes, el método recomendado es OneAgent desplegado con Dynatrace Operator, que enriquece los logs con topología y metadatos como k8s.namespace.name, k8s.pod.name, k8s.container.name, k8s.deployment.name, dt.entity.kubernetes_cluster y dt.source_entity. Otras opciones son Fluent Bit, el OpenTelemetry Collector, Logstash o Fluentd; con la Log ingestion API, el contexto Kubernetes hay que añadirlo en el propio envío.',
      ],
      sourceRefs: [LOG_INGESTION, OA_LOGS, AUTODISCOVERY, INGEST_RULES],
    },
    {
      id: 'sup-syslog-cloud',
      after: 'sup-oneagent-logs',
      title: 'Syslog en ActiveGate y logs de proveedores cloud',
      lead: 'Cuando el origen no admite agentes, el canal lo decide el tipo de origen.',
      paragraphs: [
        'La ingesta de syslog la realiza un Environment ActiveGate 1.295+ en Linux mediante un OpenTelemetry Collector embebido; los ActiveGate multi-environment no admiten syslog. Se habilita añadiendo syslogenabled=true en extensionsuser.conf. Por defecto escucha en 514/UDP y 601/TCP (RFC 5424); el listener 6514 con TLS aparece comentado y requiere certificado. El receptor admite los formatos RFC 3164 y RFC 5424: los listeners por defecto esperan RFC 5424, y para RFC 3164 hay que ajustar la configuración del receiver. Es la vía habitual para dispositivos de red, como firewalls, que no admiten agentes. La Log ingestion API es HTTP y no actúa como receptor syslog.',
        'Para servicios cloud en los que no se puede instalar OneAgent se usan las integraciones del proveedor: en Azure, los logs se transmiten desde Azure Event Hubs mediante una Azure Function App, o con Azure Native Dynatrace Service; en AWS, desde CloudWatch, S3 o Amazon Data Firehose; en Google Cloud, mediante una suscripción de Pub/Sub. Forwarding de OpenPipeline va en sentido contrario: envía datos desde Dynatrace hacia cloud object storage.',
      ],
      sourceRefs: [SYSLOG, CLOUD_LOGS, LOG_INGESTION],
    },
    {
      id: 'sup-otlp',
      after: 'deep-otel-signals',
      title: 'OTLP en Dynatrace: endpoints, protocolo y correlación',
      lead: 'Endpoint, protocolo, token y temporalidad deciden si la telemetría OTel llega y se correlaciona.',
      paragraphs: [
        'Los endpoints OTLP de Dynatrace solo aceptan HTTP con payload binario Protocol Buffers: gRPC no está soportado y JSON tampoco. La base URL en SaaS es https://{environment-id}.live.dynatrace.com/api/v2/otlp y a través de un Environment ActiveGate es https://{activegate}:9999/e/{environment-id}/api/v2/otlp; a la base se añaden /v1/traces, /v1/metrics y /v1/logs. En un SDK se configura OTEL_EXPORTER_OTLP_PROTOCOL=http/protobuf; en el Collector se usa el exporter otlphttp, porque el exporter otlp usa gRPC. Si una fuente solo exporta gRPC, un OpenTelemetry Collector la recibe y la reenvía por HTTP.',
        'Scopes: con platform token, openpipeline:traces:ingest, openpipeline:metrics:ingest y openpipeline:logs:ingest; con Classic access token (Api-Token), openTelemetryTrace.ingest, metrics.ingest y logs.ingest. Dynatrace requiere delta temporality en las métricas OTLP: una suma monótona acumulativa se rechaza con UNSUPPORTED_METRIC_TYPE_MONOTONIC_CUMULATIVE_SUM.',
        'OpenTelemetry no tiene una especificación estable de RUM: la captura automática de user actions, el análisis de user journeys, Session Replay y la puntuación de Core Web Vitals no están especificados. Dynatrace recomienda combinar el backend instrumentado con OTel con RUM JavaScript (o OneAgent for Mobile). El enlace frontend-backend usa W3C Trace Context: los Collectors y demás intermediarios deben reenviar sin cambios las cabeceras traceparent y tracestate, o la correlación se rompe.',
      ],
      bullets: [
        'Exportación directa: OTLP sobre HTTP con Protocol Buffers binario y, con platform token, scope openpipeline:traces:ingest para trazas.',
        'Collector: exporter otlphttp hacia la base URL /api/v2/otlp.',
        'Métricas: delta temporality.',
        'Correlación con RUM: traceparent y tracestate sin modificar.',
      ],
      sourceRefs: [OTLP, OTEL, OTEL_TS],
    },
  ],
}
