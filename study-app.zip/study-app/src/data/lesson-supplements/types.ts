import type { StudySection } from '../study-content'

/** Contenido que se añade a un apartado existente de la lección. */
export type SectionExtension = {
  paragraphs?: string[]
  bullets?: string[]
  /** Filas nuevas para la tabla del apartado (mismo número de columnas que sus headers). */
  comparisonRows?: string[][]
  warning?: string
  /** Correcciones literales dentro del apartado (lead, párrafos, bullets, tabla, código, nota). `find` debe existir. */
  corrections?: { find: string; replace: string }[]
  /** Por qué se amplía (qué preguntas lo necesitan). */
  reason: string
}

/** Apartado nuevo de la lección. `title` sin número: la numeración se calcula al montar el capítulo. */
export type SupplementSection = StudySection & {
  /** Id del apartado tras el que se inserta; si falta, va al final. */
  after?: string
}

/** Cambios en la ficha de hechos de precisión del módulo. */
export type PrecisionSupplement = {
  /** Corrección literal dentro de la fila `topic` (en fact o examNote). `find` debe existir. */
  corrections?: { topic: string; find: string; replace: string }[]
  /** Topics a retirar de la ficha (con el motivo en `reason`). */
  remove?: string[]
  add?: { topic: string; fact: string; examNote: string; source: { title: string; url: string } }[]
  reason?: string
}

export type LessonSupplement = {
  moduleId: string
  extend: Record<string, SectionExtension>
  sections: SupplementSection[]
  precision?: PrecisionSupplement
}
