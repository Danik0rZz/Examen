import type { SourceRef } from '../types'
import type { LessonSupplement } from './types'

const ref = (title: string, url: string): SourceRef => ({ title, url, kind: 'official-docs' })
const UI = ref('Navigate the Dynatrace platform', 'https://docs.dynatrace.com/docs/discover-dynatrace/get-started/dynatrace-ui')
const SEARCH = ref('Platform search', 'https://docs.dynatrace.com/docs/discover-dynatrace/get-started/dynatrace-ui/search')
const WHAT = ref('What is Dynatrace', 'https://docs.dynatrace.com/docs/discover-dynatrace/what-is-dynatrace')
const APPENGINE = ref('AppEngine', 'https://docs.dynatrace.com/docs/platform/appengine')
const DEM = ref('Digital Experience', 'https://docs.dynatrace.com/docs/observe/digital-experience')
const SRG = ref('Site Reliability Guardian', 'https://docs.dynatrace.com/docs/deliver/site-reliability-guardian')
const GRAIL = ref('Grail data model', 'https://docs.dynatrace.com/docs/platform/grail/organize-data')
const PART = ref('Partition data in Grail', 'https://docs.dynatrace.com/docs/platform/grail/organize-data/partition-data')
const PROC = ref('OpenPipeline processing', 'https://docs.dynatrace.com/docs/platform/openpipeline/concepts/processing')
const PERM = ref('Permissions in Grail', 'https://docs.dynatrace.com/docs/platform/grail/organize-data/assign-permissions-in-grail')
const SYSEV = ref('dt.system.events (Semantic Dictionary)', 'https://docs.dynatrace.com/docs/semantic-dictionary/model/dt-system-events')
const HUB = ref('Dynatrace Hub', 'https://docs.dynatrace.com/docs/manage/hub')
const EXT = ref('Manage extensions', 'https://docs.dynatrace.com/docs/ingest-from/extensions/manage-extensions')
const SHARE = ref('Share documents', 'https://docs.dynatrace.com/docs/discover-dynatrace/get-started/dynatrace-ui/share')
const DASH = ref('Dashboards', 'https://docs.dynatrace.com/docs/analyze-explore-automate/dashboards-and-notebooks/dashboards-new')
const PROB = ref('Problems app', 'https://docs.dynatrace.com/docs/dynatrace-intelligence/problems-app')

export const platformSupplement: LessonSupplement = {
  moduleId: 'platform',
  extend: {
    'deep-problems-platform': {
      corrections: [
        {
          find: 'Además, los campos personalizados que se propagan o asocian a un Problem solo admiten valores de tipo string (texto); no admiten estructuras anidadas ni números flotantes sin parsear.',
          replace: 'Además, los Problem fields personalizados solo se pueden definir para campos de origen con valores de tipo string; los campos con valores de otros tipos no están admitidos.',
        },
        {
          find: 'No se pueden enviar payloads JSON complejos en propiedades directas del Problem.',
          replace: 'Un campo de origen numérico, booleano o de tipo record no se puede configurar como Problem field.',
        },
      ],
      reason: 'La frase sobre "números flotantes sin parsear" no procede de la documentación; se alinea con Problems app (FP-018).',
    },
    'ui-navigation': {
      corrections: [
        { find: 'UI, Launcher y búsqueda', replace: 'UI, Dock y búsqueda' },
        {
          find: 'Launcher y las experiencias de la plataforma te llevan a aplicaciones, entidades y análisis.',
          replace: 'El Dock (Search, Apps y las apps fijadas) y los Launchpads te llevan a aplicaciones, entidades y análisis.',
        },
      ],
      reason: 'Terminología alineada con Navigate the Dynatrace platform y con sup-ui-dock: la navegación de Latest se hace desde el Dock; los Launchpads son páginas de inicio.',
    },
    'grail-hub': {
      corrections: [
        {
          find: 'Support Center y la documentación aportan procedimientos, requisitos y límites.',
          replace: 'El Support hub (Help & Support, en el menú Support del Dock) y la documentación aportan procedimientos, requisitos y límites.',
        },
      ],
      reason: 'En la UI actual Help & Support lleva al Support hub (Navigate the Dynatrace platform); coherente con sup-ui-dock.',
    },
    permissions: {
      corrections: [
        {
          find: 'Un resultado vacío puede deberse a falta de datos, una consulta incorrecta, un filtro de management zone, un permiso de lectura o un campo restringido.',
          replace: 'Un resultado vacío o menor de lo esperado puede deberse a falta de datos, a una consulta o un timeframe incorrectos, a un segment o a una condición WHERE por registro en los permisos (por ejemplo sobre dt.security_context). Leer tablas almacenadas en buckets (logs, events, spans, bizevents, security.events, métricas) necesita storage:buckets:read y el permiso de la tabla: sin ellos no se obtienen esos registros; un fieldset sin permiso oculta los campos sensibles.',
        },
        { find: 'Scope, management zone o filtro.', replace: 'Condición WHERE por registro, segment o filtro.' },
      ],
      reason: 'Coherencia con sup-grail-permissions y R-PLA-08; management zone es un concepto Classic (Permissions in Grail). v5: la doc no especifica si la falta de permiso de tabla o de bucket produce un error o un resultado vacío; se usa la redacción documentada (sin permisos no se pueden consultar los datos), igual que en welcome.',
    },
  },
  precision: {
    corrections: [
      {
        topic: 'Tablas de Sistema en Grail',
        find: 'Consultar `dt.system.buckets` requiere permisos de administración de almacenamiento.',
        replace: 'Ver la información de los buckets (lo que muestra `dt.system.buckets`) corresponde a `storage:bucket-definitions:read`; no hace falta ningún permiso de escritura ni `storage:buckets:read`, que es para leer los datos.',
      },
      {
        topic: 'Hub Tabs Structure',
        find: 'Los artefactos que acompañan a una extensión se consultan en la pestaña `Contents`.',
        replace: 'Los Dashboards, Notebooks y workflow actions que incluye una app se consultan en la pestaña `Contents` de su ficha.',
      },
      {
        topic: 'IAM',
        find: 'Un resultado vacío puede ser scope, management zone o permiso, no ausencia de datos.',
        replace: 'Un resultado vacío o menor puede deberse a un segment o a un WHERE por registro en los permisos, no a ausencia de datos; leer tablas almacenadas en buckets necesita storage:buckets:read y el permiso de la tabla, y sin ellos no se obtienen esos registros.',
      },
    ],
    reason: 'Auditoría final: permiso de dt.system.buckets precisado (storage:bucket-definitions:read, Grail data model), Contents es de la ficha de una app (Dynatrace Hub) y management zone es Classic (Permissions in Grail). v5: IAM ya no afirma que falte un permiso produzca un error, que la doc no especifica.',
  },
  sections: [
    {
      id: 'sup-ui-dock',
      after: 'ui-navigation',
      title: 'Dock, Apps, Launchpads y menús de la UI',
      lead: 'El Dock es la barra lateral desde la que se llega a la búsqueda, las apps, el soporte y los ajustes de usuario.',
      paragraphs: [
        'El Dock reúne, de arriba abajo: Dynatrace (vuelve a tu página de inicio), Search (siempre disponible en el Dock y con el atajo Ctrl/Cmd+K), Apps (lista y lanza las apps instaladas, por categoría o filtrando por nombre) y una sección central con las apps predeterminadas, las que has fijado y las usadas recientemente. Al pie están Collapse, Support y el menú de usuario. Collapse oculta las etiquetas y deja una columna estrecha de iconos para ganar espacio para los datos.',
        'Para fijar una app al Dock, ábrela desde Search o Apps (su icono aparece en el Dock) y después, en el Dock, pasa el cursor sobre ella y selecciona Pin to dock; queda fijada hasta que eliges Unpin from dock. Fijar apps personaliza tu propio Dock: no es un ajuste compartido con el equipo ni algo que se haga desde Hub.',
        'Un Launchpad es una página de inicio personalizada con listas de apps, documentos, enlaces y texto informativo elegidos a mano. La página de inicio predeterminada es el Launchpad Getting started with Dynatrace, y puedes crear Launchpads adicionales. Como Dashboards y Notebooks, los Launchpads son documentos y se comparten con los mismos controles de acceso.',
        'El menú Support agrupa Documentation, Release notes, Community (Dynatrace Community), University (Dynatrace University), Help & Support (enlace al Support hub) y recursos de desarrollo como Dynatrace Developer, Dynatrace API y Developer Forum. El menú de usuario (tus iniciales y tu nombre al pie del Dock) contiene User settings (idioma, zona horaria y modo claro/oscuro), Environments, Appearance (cambio rápido entre tema claro, oscuro o el del navegador), Account Management, el toggle Latest Dynatrace, que activa o desactiva la experiencia Latest, y Sign out.',
      ],
      comparison: {
        headers: ['Necesidad', 'Dónde se resuelve', 'Confusión típica'],
        rows: [
          ['Tener una app siempre a mano', 'Dock: hover sobre la app y Pin to dock', 'Buscarlo en Hub o en un Launchpad'],
          ['Página de inicio común con apps, documentos, enlaces y texto', 'Launchpad (documento compartible)', 'Usar un Dashboard o un segment'],
          ['Cursos, Community, documentación y soporte', 'Menú Support del Dock', 'Buscarlo en Settings o en Account Management'],
          ['Volver a la experiencia anterior', 'Menú de usuario: toggle Latest Dynatrace', 'Desinstalar apps o cambiar un ajuste global'],
        ],
      },
      sourceRefs: [UI],
    },
    {
      id: 'sup-platform-search',
      after: 'sup-ui-dock',
      title: 'Platform search: qué busca y con qué límites',
      lead: 'Platform search encuentra apps, documentos, settings, métricas y entidades, pero cada categoría se busca por campos concretos.',
      paragraphs: [
        'Platform search está siempre disponible en el Dock (Search) y se abre también con Ctrl/Cmd+K; entre otras cosas, encuentra métricas por key y por nombre. Las categorías apps, settings y documents son obligatorias y no se pueden quitar; puedes añadir hasta 25 categorías predeterminadas más (por ejemplo, tipos de entidad), y esa configuración es personal de tu cuenta.',
        'Cada categoría se busca por campos distintos: las apps instaladas por nombre y descripción; Dashboards, Notebooks y Workflows por nombre (no por el texto de sus consultas); los settings por nombre y ubicación; las fichas de Hub por nombre, descripción y tags; las métricas por key y por nombre; y las entidades monitorizadas por nombre, ID y tags.',
        'Por defecto, la búsqueda de entidades solo refleja las entidades vistas en las últimas 72 horas. Que un host inactivo desde hace días no aparezca no demuestra que se haya borrado: simplemente queda fuera de esa ventana.',
      ],
      comparison: {
        headers: ['Categoría', 'Se busca por', 'Ojo con'],
        rows: [
          ['Dashboards, Notebooks y Workflows', 'Nombre del documento', 'Una palabra que solo está en una consulta DQL no lo encuentra'],
          ['Métricas', 'Key y nombre', 'No hace falta abrir una app de métricas para localizarlas'],
          ['Entidades monitorizadas', 'Nombre, ID y tags', 'Por defecto, solo las vistas en las últimas 72 horas'],
          ['Apps, settings y documents', 'Categorías obligatorias', 'No se pueden eliminar de la búsqueda'],
        ],
      },
      sourceRefs: [SEARCH, UI],
    },
    {
      id: 'sup-platform-components',
      after: 'grail-hub',
      title: 'Las piezas de la plataforma y cómo se reparten el trabajo',
      lead: 'Cada componente tiene un papel: capturar, almacenar, relacionar, analizar, construir apps o actuar.',
      paragraphs: [
        'OneAgent descubre, activa e instrumenta automáticamente aplicaciones, microservicios, infraestructura y sus dependencias. OpenPipeline, junto con OneAgent y OpenTelemetry, recoge y procesa la telemetría en la ingesta. Grail es el data lakehouse unificado que guarda y correlaciona logs, métricas, trazas y eventos. Smartscape mapea de forma dinámica las relaciones entre todos los componentes de la aplicación en cada capa.',
        'Dynatrace Intelligence (Davis) combina IA predictiva e IA causal para casos de uso de observabilidad, seguridad y negocio: detecta anomalías y explica su root cause. AutomationEngine ejecuta Workflows y respuestas automatizadas a partir de lo que detecta Dynatrace Intelligence, por ejemplo una acción de remediación cuando se abre un Problem.',
        'AppEngine permite construir apps a medida sobre los datos de observabilidad, seguridad y negocio. Su backend son app functions escritas en TypeScript que se ejecutan en el JavaScript runtime de Dynatrace; las apps interactúan con otras apps mediante intents y, a través de EdgeConnect (que se ejecuta en tu red corporativa), con sistemas on-premises. AppEngine mantiene la lógica y los datos dentro de los límites de seguridad de la plataforma.',
        'Dynatrace Hub es el catálogo para explorar, activar y ejecutar apps y extensiones: lista las tecnologías que OneAgent soporta de serie, los frameworks de observabilidad abiertos soportados, las extensiones creadas por Dynatrace y las apps de Dynatrace basadas en AppEngine.',
      ],
      comparison: {
        headers: ['Componente', 'Papel', 'No es'],
        rows: [
          ['OneAgent', 'Descubre e instrumenta automáticamente apps, infraestructura y dependencias', 'El almacén de datos'],
          ['OpenPipeline', 'Procesa y enruta los datos en la ingesta', 'El motor que ejecuta acciones'],
          ['Grail', 'Almacena y correlaciona logs, métricas, trazas y eventos', 'Un mapa de topología'],
          ['Smartscape', 'Mapea las relaciones dinámicas entre componentes de todas las capas', 'Un catálogo de apps'],
          ['Dynatrace Intelligence', 'IA predictiva y causal: detecta y explica', 'El ejecutor de Workflows'],
          ['AutomationEngine', 'Ejecuta Workflows y respuestas automatizadas', 'El entorno de desarrollo de apps'],
          ['AppEngine', 'Construye y ejecuta apps (app functions en TypeScript)', 'El motor de Workflows'],
        ],
      },
      sourceRefs: [WHAT, APPENGINE, HUB],
    },
    {
      id: 'sup-dem-resilience',
      after: 'experience',
      title: 'RUM, Synthetic, Session Replay y Site Reliability Guardian',
      lead: 'Usuarios reales, pruebas simuladas y validación de cambios responden a preguntas distintas.',
      paragraphs: [
        'Real User Monitoring (RUM) observa a los usuarios reales que interactúan con la aplicación: comportamiento y rendimiento del frontend. Synthetic Monitoring ejecuta pruebas automatizadas y programadas desde ubicaciones de todo el mundo, a cualquier hora, por lo que verifica disponibilidad y rendimiento aunque no haya tráfico real. Session Replay captura y reproduce visualmente la experiencia digital completa de los usuarios para depurar lo que vieron.',
        'Para la resiliencia ante cambios, Site Reliability Guardian automatiza el análisis del impacto de un cambio validando objetivos de disponibilidad, rendimiento y capacidad: ayuda a tomar la decisión de release y permite aplicar Service-Level Objectives (SLOs) a los servicios críticos. Puede lanzarse automáticamente desde Workflows, y sus resultados de validación (Pass, Warning, Fail, entre otros) informan la decisión del pipeline de entrega.',
      ],
      bullets: [
        'RUM: ¿qué experimentan los usuarios reales ahora?',
        'Synthetic Monitoring: ¿está disponible el flujo aunque nadie lo use?',
        'Session Replay: ¿qué vio exactamente un usuario concreto?',
        'Site Reliability Guardian: ¿cumple este release sus objetivos antes de promocionarlo?',
      ],
      sourceRefs: [DEM, SRG],
    },
    {
      id: 'sup-grail-buckets',
      after: 'deep-grail-records',
      title: 'Buckets, tables y views en Grail',
      lead: 'La retención y el aislamiento se deciden en el bucket; la tabla agrupa por tipo y la view es virtual.',
      paragraphs: [
        'Los buckets son unidades lógicas de almacenamiento donde se guardan los registros; cada bucket se asocia a un tipo de registro (logs, events, spans…) y fija su retención. Las tables agrupan los registros por tipo: un fetch de una tabla recupera los registros de todos sus buckets que el usuario puede leer, sin nombrarlos. Las views son tablas virtuales definidas por consultas sobre tablas existentes, como las vistas dt.entity.* para consultar entidades classic. Las tablas de sistema, como dt.system.buckets, dt.system.data_objects y dt.system.files, representan información que no se guarda en buckets. En resumen: la tabla agrupa los registros por tipo y su lectura exige storage:<tabla>:read; el bucket fija la retención y su lectura exige storage:buckets:read.',
        'Los buckets integrados no se pueden modificar: los default buckets (prefijo default_) y los system buckets (prefijo dt_). Por eso, si los logs de un servicio necesitan 90 días y default_logs retiene 35, la solución es crear un bucket custom con esa retención y enrutar allí esos registros con la bucket assignment de OpenPipeline. Si ninguna regla asigna bucket, la pipeline predeterminada asigna los registros al bucket por defecto (default_logs para logs) para que no se pierdan.',
        'Un bucket custom admite una retención de 1 día a 10 años más una semana (1–3657 días). Su nombre tiene entre 3 y 100 caracteres, empieza por una letra y solo usa minúsculas alfanuméricas, guiones bajos y guiones; no se puede cambiar después. Acortar la retención en una actualización borra los datos que superan el nuevo periodo, y cualquier operación que borra datos es un proceso de larga duración. Truncate borra todos los registros de un bucket sin eliminar el bucket; solo se pueden borrar los buckets definidos por el usuario (no los default_ ni los dt_) y el borrado es irreversible.',
        'Gestionar buckets exige los permisos storage:bucket-definitions:read, storage:bucket-definitions:write, storage:bucket-definitions:delete y storage:bucket-definitions:truncate, distintos de storage:buckets:read, que da acceso a leer los datos del bucket. Cada creación, actualización, truncate o borrado de un bucket registra un audit event con el usuario, el estado (éxito o fallo) y la descripción del cambio; en una actualización incluye la configuración anterior y la nueva. Para la configuración vigente se consulta dt.system.buckets; para el historial, dt.system.events filtrando event.kind == "AUDIT_EVENT" y event.category == "BUCKET_MANAGEMENT", que requiere storage:system:read.',
        'Partition data in Grail da cinco motivos para crear buckets custom: retención propia, atribución de costes a centros de coste (cross-charging), rendimiento de consulta (pocos buckets por consulta), control de acceso por bucket mediante políticas IAM y propiedad de los datos (data ownership: quién responde de su ciclo de vida y su gestión).',
      ],
      comparison: {
        headers: ['Bucket integrado', 'Tabla', 'Retención'],
        rows: [
          ['default_logs', 'logs', '35 días'],
          ['default_spans', 'spans', '10 días'],
          ['default_metrics', 'metrics', '15 meses'],
          ['default_events', 'events', '35 días'],
          ['default_securityevents_builtin', 'security.events', '3 años'],
          ['dt_system_events', 'dt.system.events', '1 año'],
        ],
      },
      code: 'fetch dt.system.buckets\n| filter startsWith(name, "default_") or startsWith(name, "dt_")\n\nfetch dt.system.events\n| filter event.kind == "AUDIT_EVENT" and event.category == "BUCKET_MANAGEMENT"\n| sort timestamp desc',
      codeNote: 'La primera consulta muestra la definición actual de los buckets integrados (nombre, tabla, retención); la segunda, el historial auditado de cambios, con los más recientes arriba.',
      warning: 'El timeframe de una consulta o de un Dashboard nunca alarga la retención: los datos que el bucket ya eliminó no vuelven.',
      sourceRefs: [GRAIL, PART, PROC, SYSEV],
    },
    {
      id: 'sup-grail-permissions',
      after: 'sup-grail-buckets',
      title: 'Permisos en Grail: bucket, tabla, registro y campo',
      lead: 'Para leer un registro hacen falta dos llaves: la del bucket y la de la tabla; los WHERE y los fieldsets recortan aún más.',
      paragraphs: [
        'Sin permisos, un usuario no puede consultar datos de Grail. Leer una tabla almacenada en buckets (logs, events, spans, bizevents, security.events o métricas) necesita storage:buckets:read para los buckets que contienen los datos y, además, el permiso de la tabla que se consulta; para las vistas de entidades Classic (fetch dt.entity.*) la documentación solo pide storage:entities:read. Con solo uno de los dos no se obtienen esos registros (la documentación no detalla si se muestra un error o un resultado vacío). El resultado es la intersección: por ejemplo, ALLOW storage:buckets:read WHERE storage:bucket-name MATCH ("default_*", "common_logs") junto con ALLOW storage:logs:read WHERE storage:k8s.namespace.name="namespace1" devuelve solo logs de namespace1 que estén en buckets default_* o common_logs.',
        'Los permisos de tabla admiten condiciones WHERE por registro con campos como storage:dt.security_context, storage:k8s.namespace.name, storage:k8s.cluster.name, storage:host.name o storage:event.kind; por ejemplo, ALLOW storage:logs:read WHERE storage:dt.security_context="TeamA". Las políticas se suman: si otra política del usuario concede el mismo permiso de tabla sin condición, el WHERE es irrelevante y el usuario verá siempre todos los registros de esa tabla.',
        'Los field permissions ocultan campos sensibles aunque se pueda leer la tabla. Los fieldsets predefinidos (builtin-sensitive-spans, builtin-request-attributes-spans y builtin-sensitive-user-events-and-sessions) se aplican a spans, user.events y user.sessions; para usar sus campos hace falta ALLOW storage:fieldsets:read WHERE storage:fieldset-name="<fieldset>". Sin ese permiso, los campos sensibles no se muestran en el resultado ni se pueden usar para filtrar o agrupar.',
        'Los permisos de un documento y los de los datos son capas distintas: Can view en un Dashboard da acceso al documento, pero sus tiles DQL se ejecutan con los permisos storage de quien lo abre. Mínimo privilegio en Latest significa Can view en los documentos más storage:<tabla>:read acotado con WHERE (por ejemplo por dt.security_context) y el acceso a los buckets necesarios.',
      ],
      comparison: {
        headers: ['Tabla', 'Permiso de tabla', 'Comandos DQL afectados'],
        rows: [
          ['logs', 'storage:logs:read', 'fetch'],
          ['events', 'storage:events:read', 'fetch'],
          ['metrics', 'storage:metrics:read', 'timeseries'],
          ['spans', 'storage:spans:read', 'fetch'],
          ['bizevents', 'storage:bizevents:read', 'fetch'],
          ['security.events', 'storage:security.events:read', 'fetch'],
          ['entities', 'storage:entities:read', 'fetch, classicEntitySelector, entityAttr, entityName'],
          ['smartscape', 'storage:smartscape:read', 'smartscapeNodes, smartscapeEdges, getNodeName(), getNodeField()'],
          ['dt.system.events', 'storage:system:read', 'fetch'],
        ],
      },
      warning: 'Un WHERE filtra registros, no columnas: para ocultar campos sensibles se usan fieldsets. Y un filtro DQL guardado en un Notebook no es control de acceso.',
      sourceRefs: [PERM, SHARE],
    },
    {
      id: 'sup-hub-extensions',
      after: 'deep-hub-lifecycle',
      title: 'Instalar apps y activar extensiones desde Hub',
      lead: 'Una app se instala en segundos para todo el entorno; una extensión necesita además su monitoring configuration.',
      paragraphs: [
        'Con app-engine:apps:install, instalar una app desde Hub es automático y tarda unos segundos; después la app está disponible para todos los usuarios del entorno, y las apps instaladas desde Hub se mantienen actualizadas automáticamente. Desinstalarla exige app-engine:apps:delete. Que la app esté instalada no basta para usar todas sus funciones: cada usuario necesita los permisos que su ficha enumera en Technical information.',
        'Las extensiones amplían la captura de datos de tecnologías no cubiertas por OneAgent (por ejemplo, una base de datos o un dispositivo SNMP) y aportan métricas de forma declarativa, que se analizan como las demás métricas de la plataforma, por ejemplo con timeseries en un Notebook. Las apps, en cambio, ofrecen experiencias de análisis orientadas a un caso de uso.',
        'Activar una extensión sigue una secuencia: revisar sus requisitos, añadirla al entorno con Add to environment (permiso extensions:definitions:write, que permite subir y retirar extensiones), crear su monitoring configuration para los hosts o dispositivos (permiso extensions:configurations:write) y comprobar que llegan sus métricas. Que la extensión aparezca en Hub no significa que esté activa ni que produzca datos.',
      ],
      bullets: [
        'Instalar app: app-engine:apps:install.',
        'Desinstalar app: app-engine:apps:delete.',
        'Añadir extensión al entorno: extensions:definitions:write.',
        'Crear o actualizar monitoring configuration: extensions:configurations:write.',
      ],
      sourceRefs: [HUB, EXT],
    },
    {
      id: 'sup-document-sharing',
      after: 'deep-documents-permissions',
      title: 'Compartir documentos: Share access, enlaces y propiedad',
      lead: 'Hay tres formas de compartir y cada una se revoca de forma distinta.',
      paragraphs: [
        'Dashboards, Notebooks y Launchpads se comparten de tres maneras. Visible to anyone in your environment (Read only) da lectura a todos los usuarios del entorno y es fácil de revertir. Share access concede Can view o Can edit a usuarios o grupos concretos, de modo que puedes cambiar o retirar el acceso de un destinatario sin afectar al resto. Un enlace compartido (Can view o Can edit) lo puede usar cualquiera del entorno que lo reciba, nadie de fuera del entorno, y los destinatarios pueden reenviarlo.',
        'El acceso concedido por un enlace no se puede revocar de forma individual: solo se puede borrar el enlace entero, y entonces deja de funcionar para todos los que lo tenían; habría que crear uno nuevo para quienes sí deben seguir. Por defecto solo el owner comparte; si activa Allow editors to share, las personas con Can edit también pueden compartir.',
        'Can view permite ver el documento, ajustar el timeframe, refrescar y su frecuencia, ajustar filtros, maximizar tiles, copiar tiles, guardar una copia propia y exportar la definición JSON. Can edit añade editar, renombrar y modificar el contenido. Solo el owner puede compartir (salvo Allow editors to share), transferir la propiedad y eliminar el documento. Al transferir la propiedad, el owner anterior pierde el acceso de inmediato, salvo que el nuevo owner se lo vuelva a conceder.',
        'Cuando ejecutas una sección o tile de código escrito por otra persona, Dynatrace ejecuta su JavaScript con tu cuenta de usuario y tus permisos, y ese código puede llamar a APIs externas en tu nombre. Revisa el código antes de aprobar su ejecución.',
      ],
      comparison: {
        headers: ['Acción', 'Can view', 'Can edit', 'Owner'],
        rows: [
          ['Ver, timeframe, refrescar, filtrar', 'Sí', 'Sí', 'Sí'],
          ['Guardar una copia, exportar JSON', 'Sí', 'Sí', 'Sí'],
          ['Editar, renombrar, cambiar contenido', 'No', 'Sí', 'Sí'],
          ['Compartir', 'No', 'Solo con Allow editors to share', 'Sí'],
          ['Transferir la propiedad o eliminar', 'No', 'No', 'Sí'],
        ],
      },
      sourceRefs: [SHARE, DASH],
    },
    {
      id: 'sup-problems-app',
      after: 'deep-problems-platform',
      title: 'La app Problems: lista, filtros, detalles y cierre',
      lead: 'Un Problem reúne los eventos correlacionados, su impacto y la causa propuesta; la app permite filtrarlo, investigarlo y cerrarlo.',
      paragraphs: [
        'Cuando varios Davis events relacionados se correlacionan, Dynatrace Intelligence los reúne en un Problem: el objeto que se investiga, con sus entidades afectadas, la root cause propuesta y el impacto. Los eventos individuales son la evidencia, y el array dt.davis.event_ids del registro del Problem guarda sus identificadores. Los Problems se almacenan como eventos en Grail (event.kind = "DAVIS_PROBLEM"), por lo que leerlos depende de storage:events:read; davis:analyzers:execute ejecuta el analizador de detalles del Problem.',
        'La lista muestra por defecto los Problems de las últimas 2 horas, con los Problems abiertos arriba aunque empezaran antes. La barra de filtros ofrece Status (Active o Closed), Category (naturaleza: slowdown, error, resource, availability) e Impact (área afectada: frontends, services, infrastructure, environments); los criterios se combinan con AND por defecto y se pueden usar operadores booleanos explícitos. Como los Problems son eventos, un segment para filtrarlos debe definir un event filter, por ejemplo cloud.region = "us-east-1c" AND event.kind = "DAVIS_PROBLEM". Un segment solo acota la vista: que un Problem no aparezca no significa que esté resuelto.',
        'En los detalles, Root cause se centra en la causa del incidente y su deployment stack, y la deployment que contiene la root cause se marca con un red root cause badge; Impact muestra todas las entidades de Smartscape impactadas con un breve detalle por entidad. En el Visual resolution path, cada nodo es una entidad donde se detectó un problema de salud, y los nodos grises son entidades relacionadas usadas en el análisis pero no impactadas directamente. La pestaña Logs reúne las líneas de log recogidas durante el incidente, con referencias a las entidades afectadas y a sus entidades relacionadas, como los hosts padre.',
        'Puedes cerrar Problems manualmente de uno en uno o hasta 50 a la vez, y siempre hay que escribir un comentario de cierre, que se guarda en Grail como un nuevo annotation event. Tras enviar el cierre, el Status pasa a Closing...; si refrescas, puede volver a mostrar Active hasta que el cierre quede registrado en Grail. El registro del Problem no se borra.',
        'Un evento personalizado puede llevar propiedades que la app usa: dt.query guarda la consulta DQL que permite reconstruir el gráfico del evento en un Notebook o Dashboard, y dt.settings.object_id enlaza con el objeto de Settings que lo originó. Dynatrace propaga al Problem un conjunto de campos integrados junto con los campos de permisos por registro, como dt.host_group.id, k8s.namespace.name o k8s.cluster.name; un campo personalizado de los eventos solo llega al Problem si se configura como Problem field en Settings > Dynatrace Intelligence > Root cause analysis > Problem fields. Solo se pueden definir Problem fields para campos de origen de tipo string, y renombrar o quitar un Problem field cambia los registros de Problems actuales y futuros y puede romper consultas DQL.',
      ],
      comparison: {
        headers: ['Elemento', 'Qué aporta', 'Confusión típica'],
        rows: [
          ['Root cause', 'Entidad causal propuesta (red root cause badge)', 'Tomarla por la entidad con más eventos o la primera en alertar'],
          ['Impact', 'Todas las entidades de Smartscape impactadas', 'Creer que calcula la prioridad del Problem'],
          ['Nodo gris del Visual resolution path', 'Entidad relacionada usada en el análisis, no impactada', 'Leerlo como causa pendiente o entidad ya recuperada'],
          ['Pestaña Logs', 'Logs del incidente de las entidades afectadas y relacionadas', 'Pensar que solo muestra la root cause o todo el entorno'],
          ['dt.query', 'Consulta DQL para reconstruir el gráfico del evento', 'Confundirla con un enlace a Settings'],
          ['dt.settings.object_id', 'Enlace al objeto de Settings de origen', 'Usar event.id para ese fin'],
        ],
      },
      sourceRefs: [PROB, PERM],
    },
  ],
}
