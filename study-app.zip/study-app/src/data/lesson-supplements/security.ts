import type { LessonSupplement } from './types'
import type { SourceRef } from '../types'

const d = (title: string, url: string): SourceRef => ({ title, url, kind: 'official-docs' })

const VE = d('Vulnerability evaluation', 'https://docs.dynatrace.com/docs/secure/application-security/vulnerability-analytics/vulnerability-evaluation')
const VC = d('Vulnerabilities concepts', 'https://docs.dynatrace.com/docs/secure/vulnerabilities/concepts')
const VA = d('Vulnerabilities app', 'https://docs.dynatrace.com/docs/secure/vulnerabilities')
const PRIO = d('Prioritize vulnerabilities', 'https://docs.dynatrace.com/docs/secure/vulnerabilities/prioritize')
const RVA = d('Runtime Vulnerability Analytics', 'https://docs.dynatrace.com/docs/secure/application-security/vulnerability-analytics')
const GS = d('Get started with Runtime Vulnerability Analytics', 'https://docs.dynatrace.com/docs/secure/application-security/vulnerability-analytics/get-started-with-vulnerability-analytics')
const MODES = d('Application Security and monitoring modes', 'https://docs.dynatrace.com/docs/secure/application-security/getting-started/monitoring-modes')
const RAP = d('Runtime Application Protection', 'https://docs.dynatrace.com/docs/secure/application-security/application-protection')
const CLVR = d('Code-level monitoring rules', 'https://docs.dynatrace.com/docs/secure/application-security/vulnerability-analytics/code-level-vulnerabilities/define-monitoring-rules-clv')
const TPVR = d('Third-party monitoring rules', 'https://docs.dynatrace.com/docs/secure/application-security/vulnerability-analytics/third-party-vulnerabilities/define-monitoring-rules-tpv')
const DQLEX = d('DQL examples for security data', 'https://docs.dynatrace.com/docs/secure/threat-observability/dql-examples')
const SEMV = d('Semantic Dictionary: vulnerability events', 'https://docs.dynatrace.com/docs/semantic-dictionary/model/security-events/vulnerability')
const TOC = d('Threat Observability concepts', 'https://docs.dynatrace.com/docs/secure/threat-observability/concepts')
const RET = d('Data retention periods', 'https://docs.dynatrace.com/docs/manage/data-privacy-and-security/data-privacy/data-retention-periods')
const POL = d('Dynatrace default policies', 'https://docs.dynatrace.com/docs/manage/identity-access-management/use-cases/built-in-policies')
const INV = d('Investigations app', 'https://docs.dynatrace.com/docs/secure/investigations')
const INVC = d('Investigations concepts', 'https://docs.dynatrace.com/docs/secure/investigations/concepts')
const INVT = d('Manage investigation time', 'https://docs.dynatrace.com/docs/secure/investigations/define-timeframes')
const DSA = d('Davis Security Advisor API', 'https://docs.dynatrace.com/docs/dynatrace-api/environment-api/application-security/davis-security-advice')
const DSAG = d('Davis Security Advisor', 'https://docs.dynatrace.com/docs/secure/application-security/vulnerability-analytics/third-party-vulnerabilities/davis-security-advisor')
const DSSC = d('Davis Security Score (classic)', 'https://docs.dynatrace.com/docs/secure/application-security/vulnerability-analytics/third-party-vulnerabilities/davis-security-score')
const SPAPI = d('Vulnerabilities API - List vulnerabilities', 'https://docs.dynatrace.com/docs/dynatrace-api/environment-api/application-security/vulnerabilities/get-vulnerabilities')

export const securitySupplement: LessonSupplement = {
  moduleId: 'security',
  extend: {
    'advisor-investigations': {
      corrections: [
        {
          find: 'Security Advisor puede orientar prioridades y acciones según señales y contexto.',
          replace: 'Davis Security Advisor recomienda qué librerías actualizar: agrupa las third-party vulnerabilities abiertas y no silenciadas por librería y ordena el consejo por severidad según el DSS.',
        },
      ],
      reason: 'La definición vaga de Security Advisor contradecía sup-security-advisor (solo recomienda actualizaciones de librerías).',
    },
    'security-evidence': {
      corrections: [
        {
          find: 'Security Advisor y las vistas de Investigations ayudan a organizar señales y contexto, pero debes conservar',
          replace: 'Davis Security Advisor recomienda actualizaciones de librerías e Investigations organiza la evidencia de una investigación con DQL y DPL, pero debes conservar',
        },
      ],
      reason: 'Misma precisión sobre Davis Security Advisor frente a Investigations.',
    },
    rva: {
      corrections: [{ find: 'código-module injection', replace: 'code-module injection' }],
      reason: 'Término de producto en inglés (code-module injection).',
    },
    'deep-third-party-code-level': {
      corrections: [
        {
          find: 'Code-level vulnerability analysis examina el código fuente propio desarrollado por la organización. Analiza cómo fluyen los datos de entrada del usuario a través de la aplicación en busca de fallos como SQL Injection, Command Injection o Cross-Site Scripting (CWEs) producidos por falta de validación o saneamiento de inputs.',
          replace: 'Code-level vulnerability analysis examina en runtime el código propio desarrollado por la organización. Analiza cómo fluyen los datos de entrada del usuario a través de la aplicación para identificar rutas de código inseguras que podrían explotarse: SQL injection, command injection, improper input validation (por ejemplo, JNDI lookups) y server-side request forgery (SSRF). Cross-site scripting (XSS) y path traversal no figuran entre los tipos detectados.',
        },
        { find: 'Runtime Attack Analysis', replace: 'Runtime Application Protection' },
        { find: 'Mute Rule (Silenciado)', replace: 'Mute (silenciar)' },
        { find: 'Regla de gestión en la UI para suprimir alertas sin borrar código', replace: 'Acción sobre entidades afectadas en la app Vulnerabilities: no corrige ni excluye (excluir = monitoring rules)' },
      ],
      paragraphs: [
        'Para distinguirlas, fíjate en la evidencia: una third-party vulnerability se apoya en un componente vulnerable en uso (librería cargada por un proceso y su CVE); una code-level vulnerability, en un flujo de datos explotable desde un entry point hasta una función peligrosa. Una code-level vulnerability se reporta aunque nadie la haya atacado; detectar o bloquear ataques reales es tarea de Runtime Application Protection.',
      ],
      reason: 'Corrige XSS (no es un tipo code-level documentado), el nombre de Runtime Application Protection y el término "Mute Rule" (la documentación Latest habla de mute, y las reglas son monitoring rules); añade el criterio de evidencia (A-051, A-052, G-127, R-SEC-09).',
    },
    'deep-security-prioritization': {
      paragraphs: [
        'Por tanto, sin public internet exposure ni reachable data assets el DSS de una third-party vulnerability puede quedar por debajo del CVSS base, nunca por encima: los modificadores ambientales solo reducen o mantienen la puntuación. En un CVSS 9.8 con impacto alto en confidencialidad e integridad, la falta de ambos factores reduce el DSS; con ambos factores presentes se mantiene en el valor base. Un exploit público disponible o el uso de vulnerable functions ayudan a decidir el orden de trabajo, pero no cambian el DSS.',
      ],
      corrections: [
        {
          find: 'Mute rules: permiten documentar excepciones de seguridad y silenciar alertas aprobadas.',
          replace: 'Mute (silenciar vulnerabilidades o entidades afectadas): documenta una aceptación de riesgo sin corregir ni dejar de detectar; para excluir procesos del análisis se usan monitoring rules.',
        },
      ],
      reason: 'Explicita el efecto de la ausencia de exposición y datos sin absolutos (G-130, G-122); la documentación Latest habla de mute de vulnerabilidades/entidades, no de "mute rules".',
    },
  },
  precision: {
    corrections: [
      {
        topic: 'Third-party',
        find: 'Un paquete presente en un artefacto pero no cargado puede no generar el mismo resultado.',
        replace: 'Un paquete presente en disco o en un artefacto pero no cargado por ningún proceso no genera una third-party vulnerability.',
      },
    ],
    remove: ['Reglas de Silenciado (Mute Rules)'],
    add: [
      {
        topic: 'Mute (silenciar)',
        fact: 'En la app Vulnerabilities se silencian (mute) vulnerabilidades o entidades afectadas: Muted (Affected) para una entidad silenciada, Muted (Open) cuando todas las entidades afectadas de una vulnerabilidad activa están silenciadas y Muted (Resolved) cuando una entidad silenciada se cierra automáticamente.',
        examNote: 'Silenciar documenta una aceptación de riesgo: no corrige el código ni deja de detectar. No es una "regla": para excluir procesos del análisis se usan monitoring rules (Monitor / Do not monitor).',
        source: { title: 'Vulnerabilities concepts', url: 'https://docs.dynatrace.com/docs/secure/vulnerabilities/concepts' },
      },
    ],
    reason: 'La ficha hablaba de "mute rules", término no documentado en Latest que se confunde con las monitoring rules, y matizaba con "puede no" que un paquete no cargado no genera third-party vulnerability.',
  },
  sections: [
    {
      id: 'sup-security-events-grail',
      after: 'deep-security-capabilities',
      title: 'security.events en Grail: tipos de evento, buckets y permisos',
      lead: 'Para consultar vulnerabilidades con DQL hay que saber qué registro es un snapshot, cuál un cambio y cuál un finding externo.',
      paragraphs: [
        'Los security events se guardan en la tabla security.events. Los generados por Dynatrace a partir del entorno monitorizado van al bucket default_securityevents_builtin y se retienen tres años; los ingeridos desde fuentes de terceros van al bucket default_securityevents y se retienen un año. Los findings externos se ingieren a través de OpenPipeline; el endpoint de ingesta por defecto es /platform/ingest/v1/security.events. Las vulnerabilidades no están en las tablas events, dt.davis.events ni logs.',
        'Los vulnerability events generados por Dynatrace se clasifican por event.level y event.group_label, que juntos determinan el event.type. event.level vale ENTITY (estado de la vulnerabilidad en una entidad afectada, con campos affected_entity.*) o VULNERABILITY (agregación global en todo el entorno); event.group_label vale STATE_REPORT (snapshots) o CHANGE_EVENT (cambios). Los findings y escaneos ingeridos de terceros no se clasifican así: no tienen event.level ni event.group_label, y su event.provider es la herramienta de origen (Snyk, Amazon ECR, Tenable, Qualys, Amazon Inspector).',
        'VULNERABILITY_STATE_REPORT_EVENT es un snapshot periódico del estado actual de cada vulnerabilidad por entidad, exportado a Grail de forma regular. Como cada snapshot es un registro, contar sin deduplicar multiplica el resultado: la consulta oficial usa dedup {vulnerability.display_id, affected_entity.id}, sort:{timestamp desc} para quedarse con el snapshot más reciente de cada par vulnerabilidad–entidad y después cuenta con countDistinctExact(vulnerability.display_id). Para abiertas y no silenciadas filtra vulnerability.resolution.status=="OPEN" (valores OPEN o RESOLVED) y vulnerability.mute.status!="MUTED" (valores MUTED o NOT_MUTED); vulnerability.risk.level contiene LOW, MEDIUM, HIGH, CRITICAL o NONE.',
        'Para reconstruir la historia usa los change events. Threat Observability los describe por separado: VULNERABILITY_STATUS_CHANGE_EVENT recoge los cambios de estado de la vulnerabilidad o de una entidad afectada, incluidos los estados de resolución y de mute (por ejemplo, al resolverse o silenciarse), y VULNERABILITY_ASSESSMENT_CHANGE_EVENT, los cambios de assessment (Dynatrace Security Score y Dynatrace Assessment). El Semantic Dictionary define VULNERABILITY_STATUS_CHANGE_EVENT de forma más amplia: Runtime Vulnerability Analytics lo genera cuando cambia el status o el assessment de una vulnerabilidad, a nivel de entidad (cada par vulnerabilidad–entidad) y a nivel de vulnerabilidad (el cambio agregado en todas las entidades afectadas). En ambas fuentes, el evento que registra cuándo se resolvió o se silenció una vulnerabilidad es STATUS_CHANGE. VULNERABILITY_EXTERNAL_ID_CHANGE_EVENT se emite cuando cambian los identificadores del proveedor externo. VULNERABILITY_COVERAGE_REPORT_EVENT es un informe periódico de cobertura. VULNERABILITY_FINDING es una vulnerabilidad concreta identificada en un proceso en un momento dado, y VULNERABILITY_SCAN, el análisis de los paquetes detectados en un proceso en un momento dado; ambos aparecen tanto en Runtime Vulnerability Analytics como en escáneres de terceros ingeridos.',
        'Permisos: storage:security.events:read da acceso de lectura a la tabla security.events, y storage:logs:read es necesario cuando se consultan logs ingeridos que se usan como datos de seguridad. La política Read Security Events concede storage:security.events:read y storage:events:read (tablas events y security.events); la política Read Logs concede storage:logs:read.',
      ],
      code: 'fetch security.events\n| filter dt.system.bucket=="default_securityevents_builtin"\n     AND event.provider=="Dynatrace"\n     AND event.type=="VULNERABILITY_STATE_REPORT_EVENT"\n     AND event.level=="ENTITY"\n| dedup {vulnerability.display_id, affected_entity.id}, sort:{timestamp desc}\n| filter vulnerability.resolution.status=="OPEN"\n     AND vulnerability.mute.status!="MUTED"\n| summarize {`Open vulnerabilities`=countDistinctExact(vulnerability.display_id)}',
      codeNote: 'Consulta oficial de Threat Observability: snapshots por entidad, dedup al más reciente y recuento de vulnerabilidades abiertas no silenciadas.',
      warning: 'Un filtro event.provider=="Dynatrace" excluye los findings de Snyk u otras herramientas, y un filtro por event.level los excluye también, porque los datos externos no llevan ese campo.',
      sourceRefs: [TOC, DQLEX, SEMV, RET, POL],
    },
    {
      id: 'sup-third-party-evaluation',
      after: 'deep-third-party-code-level',
      title: 'Cómo se evalúan las third-party vulnerabilities',
      lead: 'Qué componentes se comparan, con qué feed, cada cuánto y cuándo una vulnerabilidad se resuelve o se reabre.',
      paragraphs: [
        'La evaluación third-party compara dos clases de componentes con los vulnerability feeds: las librerías, que OneAgent reporta cuando un proceso las carga, y los paquetes runtime de Kubernetes que usa el clúster (en el control plane, kube-apiserver, etcd, kube-scheduler, kube-controller-manager y cloud-controller-manager; en los worker nodes, kubelet y kube-proxy). Un JAR que solo está en disco, en una imagen de contenedor, en un manifiesto o en el inventario de paquetes del host, pero que ningún proceso carga, no genera una third-party vulnerability. La evaluación no comprueba configuraciones, runtime information ni sistemas operativos.',
        'Los feeds dependen del tipo de componente: el Dynatrace Vulnerability feed cubre los componentes de software y los componentes runtime de Kubernetes, y el NVD feed cubre los runtimes .NET, Java y Node.js. Dynatrace comprueba si hay actualizaciones del feed cada cinco minutos, los feeds actualizados se importan al Dynatrace Cluster en un plazo de dos horas y la búsqueda de nuevas vulnerabilidades en los componentes del entorno se hace cada minuto. Por eso un CVE recién publicado puede tardar hasta dos horas en reflejarse, sin reiniciar nada.',
        'Resolución third-party: cuando ningún process group ha reportado el componente vulnerable durante más de dos horas, la vulnerabilidad se marca como Resolved. Ese silencio puede deberse a que el componente se actualizó o eliminó, pero también a que el proceso está detenido o aún no ha cargado la librería por falta de tráfico, así que Resolved no confirma por sí solo la versión instalada. Si el proceso vuelve a ejecutarse y carga otra vez el componente vulnerable, la vulnerabilidad se reabre.',
        'Resolución code-level: una code-level vulnerability se resuelve cuando el proceso vulnerable se ha reiniciado y OneAgent ya no detecta flujos de datos que puedan conducir a la vulnerabilidad.',
        'Vulnerable functions es un dato exclusivo de third-party: muestra qué funciones de la librería afectada están implicadas y si la aplicación las usa, para afinar la priorización. No modifica el DSS, no muestra flujos de datos (eso es code-level) y en Java requiere activar Java vulnerable function reporting.',
      ],
      comparison: {
        headers: ['Componente', 'Ejemplos', 'Feed'],
        rows: [
          ['Librerías cargadas por procesos', 'Librerías de Java, .NET, Node.js, Python, Go o PHP', 'Dynatrace Vulnerability feed'],
          ['Paquetes runtime de Kubernetes', 'kube-apiserver, etcd, kubelet, kube-proxy', 'Dynatrace Vulnerability feed'],
          ['Runtimes', '.NET, Java, Node.js', 'NVD feed'],
        ],
      },
      warning: 'Resolved por ausencia de reportes no es una prueba de remediación: comprueba la versión cuando el proceso vuelva a recibir tráfico.',
      sourceRefs: [VE, RVA, VC],
    },
    {
      id: 'sup-code-level-details',
      after: 'sup-third-party-evaluation',
      title: 'Code-level vulnerabilities: tipos, tecnologías y detalle',
      lead: 'El detalle de una code-level vulnerability apunta al código que hay que cambiar, no a una librería.',
      paragraphs: [
        'Code-level vulnerability detection identifica cuatro tipos: SQL injection, command injection, improper input validation (por ejemplo, una JNDI lookup con datos no confiables) y SSRF. La detección third-party está soportada en Java, .NET, Node.js, Python, Go y PHP; la code-level, en Java 8+, .NET (.NET Framework 4.5+ y .NET Core 3.0+, procesos de 64 bits) y Go. PHP, Python y Node.js no tienen code-level detection.',
        'El entry point describe por dónde entra el atacante: la URL path de la petición HTTP, el untrusted input que llega a la función vulnerable y los Payloads, el input controlado por el usuario que podría explotarla, que aparece resaltado. En Payloads se ve la parte de la sentencia SQL (SQL injection), el comando (command injection), el nombre de la JNDI lookup (improper input validation) o la request URL (SSRF). La code location muestra desde dónde se llama a la función vulnerable, por ejemplo SQL injection at DatabaseManager.updateBio():82.',
        'La puntuación de una code-level vulnerability es siempre 10 y su riesgo Critical, porque se considera explotable en cualquier momento; no tiene CVE ni depende del CVSS de una librería. Como todas puntúan igual, para priorizarlas se mira el contexto de las entidades relacionadas: public internet exposure y reachable data assets.',
      ],
      comparison: {
        headers: ['Tipo', 'Qué resalta Payloads'],
        rows: [
          ['SQL injection', 'La parte de la sentencia SQL'],
          ['Command injection', 'El comando'],
          ['Improper input validation', 'El nombre de la JNDI lookup'],
          ['SSRF', 'La request URL'],
        ],
      },
      sourceRefs: [VC, RVA, GS],
    },
    {
      id: 'sup-monitoring-rules',
      after: 'sup-code-level-details',
      title: 'Monitoring rules de third-party y de code-level',
      lead: 'Las dos familias de reglas incluyen o excluyen entidades, pero difieren en reinicio y en su relación con el control global.',
      paragraphs: [
        'Las third-party monitoring rules incluyen o excluyen entidades del análisis de Runtime Vulnerability Analytics con el control Monitor o Do not monitor. Se recomienda basarlas en resource attributes (host name, process group ID, Kubernetes namespace, atributos propios o indicadores de tecnología como java.main.class); las reglas clásicas por process group tags, host tags o management zones están deprecadas. El orden importa: en cuanto una regla coincide con una entidad, las reglas posteriores ya no se consideran para ella, así que las reglas específicas deben ir antes que las generales. El control por defecto se aplica a las entidades que no coinciden con ninguna regla. Activar o desactivar una third-party monitoring rule no requiere reiniciar.',
        'Aunque no haga falta reiniciar, el cambio no es instantáneo: puede tardar hasta 10 minutos en aplicarse en todo el sistema, y hasta 70 minutos cuando se excluye una entidad que antes se monitorizaba. Las reglas de procesos se definen con resource attributes, que aplican a process groups; las reglas de Kubernetes nodes y hosts necesitan Kubernetes labels, y si solo configuras reglas de resource attributes, los Kubernetes nodes pueden seguir monitorizados aunque sus process groups estén excluidos. En entornos creados en la versión 1.313 o posterior, las reglas clásicas por process group tag, host tag y management zone no están disponibles.',
        'Con Do not monitor no se crean vulnerabilidades nuevas para los procesos que cumplen la regla y las vulnerabilidades existentes que solo afectan a esos procesos se resuelven; si la regla se elimina o deja de aplicarse, se reabren. Una regla no silencia (mute) ni borra datos.',
        'Las code-level monitoring rules usan resource attributes como dt.entity.process_group o aws.region para aplicar Monitor o Do not monitor, y sobrescriben el control global de code-level vulnerability detection de la tecnología seleccionada. Están ordenadas y se aplica la primera regla que coincide. Tras crear o cambiar code-level monitoring rules hay que reiniciar los procesos.',
      ],
      comparison: {
        headers: ['Aspecto', 'Third-party rules', 'Code-level rules'],
        rows: [
          ['Orden', 'La primera que coincide; específicas antes que generales', 'La primera que coincide'],
          ['Relación con el control global', 'El control por defecto cubre lo no coincidente', 'Sobrescriben el control global de la tecnología'],
          ['Reinicio', 'No requiere reinicio', 'Reiniciar los procesos'],
        ],
      },
      sourceRefs: [TPVR, CLVR],
    },
    {
      id: 'sup-rva-setup',
      after: 'deep-security-modes',
      title: 'Prerrequisitos de Runtime Vulnerability Analytics por tecnología y modo',
      lead: 'Cuando no aparecen componentes o hallazgos, recorre los prerrequisitos de la tecnología antes de culpar al análisis.',
      paragraphs: [
        'Runtime Vulnerability Analytics necesita deep monitoring del process group (Settings > Process and contextualize > Process groups > Process group monitoring). Para .NET, Go y Python el deep monitoring automático está deshabilitado por defecto y hay que activarlo manualmente. Para Python hay que activar Monitor Python (Settings > Collect and capture > General monitoring settings > Monitoring technologies) y Python software component reporting (Settings > Collect and capture > General monitoring settings > OneAgent features), y reiniciar los procesos. En Java, vulnerable functions es opcional y requiere activar Java vulnerable function reporting; la detección de SSRF code-level requiere activar Java SSRF code-level vulnerability and attack evaluation. Tras activar code-level detection o cambiar OneAgent features hay que reiniciar los procesos.',
        'Los tres monitoring modes admiten Application Security, con diferencias. Full-Stack es el recomendado y aporta todo el contexto. En Infrastructure Monitoring faltan datos ambientales como reachable data assets o public internet exposure, y la información de entidades relacionadas (bases de datos, servicios) es limitada; por eso el DSS no puede adaptarse al entorno y estos factores suelen aparecer como Not available. En Discovery mode, tras activarlo hay que habilitar también code-module injection (y reiniciar los procesos para cargar el módulo), y Dynatrace no puede adaptar el DSS.',
        'Excepción documentada: en hosts Linux en Discovery mode, la public internet exposure se detecta vía eBPF, con los estados Public network y Not detected.',
      ],
      bullets: [
        'Python: Monitor Python (Monitoring technologies) + Python software component reporting (OneAgent features) + reinicio.',
        '.NET, Go y Python: deep monitoring manual por host.',
        'Java vulnerable functions: Java vulnerable function reporting + reinicio.',
        'Java SSRF: Java SSRF code-level vulnerability and attack evaluation + reinicio.',
        'Discovery mode: code-module injection + reinicio.',
      ],
      sourceRefs: [GS, MODES],
    },
    {
      id: 'sup-rap',
      after: 'sup-rva-setup',
      title: 'Runtime Application Protection',
      lead: 'Detectar una vulnerabilidad no es lo mismo que detectar o bloquear un ataque.',
      paragraphs: [
        'Runtime Application Protection detecta ataques reales de SQL injection, JNDI injection, command injection y SSRF. Java admite los cuatro tipos; .NET y Go detectan SQL injection y command injection, y JNDI injection y SSRF están limitados a Java. Está soportada en los tres monitoring modes (Full-Stack, Infrastructure y Discovery) para detectar y bloquear ataques.',
        'Cada tecnología tiene tres controles: Off (no se reportan ataques), Monitor (se reportan ataques sin bloquear ninguno) y Block (se reportan y se bloquean en runtime). Para empezar en producción sin riesgo de bloquear peticiones legítimas se usa Monitor. Do not monitor no es un modo de protección: es un control de las monitoring rules de vulnerability analytics. Los exploit attempts que muestra la app Vulnerabilities requieren configurar Runtime Application Protection.',
      ],
      sourceRefs: [RAP, MODES, PRIO],
    },
    {
      id: 'sup-dss-assessment',
      after: 'deep-security-prioritization',
      title: 'DSS y Dynatrace Assessment en detalle',
      lead: 'Versión de CVSS, métricas que se modifican, factores del entorno, escala de riesgo y modos de assessment.',
      paragraphs: [
        'CVSS v4 está disponible actualmente solo para las vulnerabilidades del Dynatrace Vulnerability feed; cuando existe un vector v4 se usa para el DSS y, si no, se usa CVSS v3. Como los runtimes .NET, Java y Node.js se evalúan con NVD, su DSS parte previsiblemente de v3. El DSS modifica métricas ambientales: con CVSS v3, Modified Confidentiality (MC) y Modified Integrity (MI); con CVSS v4, Modified Vulnerable Confidentiality (MVC) y Modified Vulnerable Integrity (MVI). El DSS nunca supera el CVSS Base Score: los modificadores solo pueden reducirlo o mantenerlo.',
        'Ojo con las versiones de la documentación: la página Latest (Vulnerabilities concepts) solo cita MC/MI (v3) y MVC/MVI (v4); la página clásica del Davis Security Score, de la app deprecada Third-Party Vulnerabilities, describía además una rebaja del Modified Attack Vector (MAV) cuando no hay exposición pública. En el examen, responde con la versión Latest.',
        'Public internet exposure: Dynatrace analiza si las peticiones entrantes a servicios web y las llamadas a web services del último día proceden de una IP pública. Reachable data assets: se revisan los servicios relacionados y los servicios a los que estos llaman directamente; si alguno es una base de datos, hay un reachable data asset afectado. El examen se limita a esos dos niveles: si el servicio del proceso vulnerable llama directamente a una base de datos, cuenta; una base de datos a la que solo llama un servicio intermedio queda fuera de lo que describe la documentación. Public exploit availability y vulnerable functions se consideran en la evaluación de riesgo, pero no en el DSS.',
        'Escala de riesgo: Low 0.1–3.9, Medium 4.0–6.9, High 7.0–8.9 y Critical 9.0–10.0. Las severidades de findings externos sin puntuación se normalizan a Critical 10.0, High 8.9, Medium 6.9, Low 3.9 y Other 0.0.',
        'En la app Vulnerabilities, el DSS de una vulnerabilidad se evalúa a partir del DSS de sus entidades afectadas dentro del segmento seleccionado y se toma el más alto; la app clásica Third-Party Vulnerabilities agrega los factores de riesgo de las entidades afectadas dentro de la management zone, lo que puede dar una severidad mayor.',
        'Dynatrace Assessment tiene tres modos: Full, cuando todas las process instances afectadas están monitorizadas en Full-Stack; Reduced, cuando al menos una no está en Full-Stack y la evaluación detallada se limita (exposición y activos de datos no se pueden examinar, así que el DSS no se reduce); y Not available, cuando la vulnerabilidad está resuelta.',
      ],
      comparison: {
        headers: ['Factor', '¿Entra en el DSS?', 'Para qué sirve'],
        rows: [
          ['Public internet exposure', 'Sí', 'Sin exposición, el DSS se reduce'],
          ['Reachable data assets', 'Sí', 'Sin bases de datos alcanzables, el DSS se reduce'],
          ['Public exploit availability', 'No', 'Priorizar dentro de la evaluación de riesgo'],
          ['Vulnerable functions', 'No', 'Saber si se usan las funciones afectadas (third-party)'],
        ],
      },
      sourceRefs: [VC, VE, DSSC],
    },
    {
      id: 'sup-vulnerabilities-app',
      after: 'sup-dss-assessment',
      title: 'La app Vulnerabilities: entidades, mute y priorización',
      lead: 'Qué muestra la app, qué estados existen y qué señales usar para decidir el orden de remediación.',
      paragraphs: [
        'La app Vulnerabilities muestra vulnerabilidades de dos fuentes: Dynatrace Runtime Vulnerability Analytics y findings ingeridos de herramientas de seguridad externas. Para acceder, el grupo vulnerability-service necesita las políticas Read Entities y Read Security Events (esta incluye storage:security.events:read y un storage:buckets:read acotado a los buckets de security events), más una política de usuario (Admin User, Pro User o Standard User).',
        'Las entidades afectadas son los procesos, process groups o Kubernetes nodes que contienen directamente la vulnerabilidad; las entidades relacionadas son la infraestructura conectada: aplicaciones, servicios, hosts, Kubernetes workloads y clusters, e imágenes de contenedor.',
        'El mute se aplica a las entidades afectadas y no corrige ni deja de detectar la vulnerabilidad. Muted (Affected): la entidad sigue afectada, pero se silenció a petición. Muted (Open): la vulnerabilidad sigue activa, pero todas sus entidades afectadas se silenciaron. Muted (Resolved): una entidad silenciada que se cerró automáticamente porque la causa raíz desapareció no pasa a Resolved, sino a Muted (Resolved). Para excluir procesos del análisis se usan monitoring rules, no el mute.',
        'Para priorizar, la app combina DSS, Dynatrace Assessment, entidades afectadas y relacionadas, exploit attempts (requieren configurar Runtime Application Protection), vulnerability evolution y el CISA KEV catalog. Las vulnerabilidades del CISA KEV catalog cuya fecha límite de remediación ha pasado muestran la etiqueta Overdue. Los eventos de vulnerability evolution se guardan un año y solo pueden consultarse hasta el timestamp de la primera detección. Para ver vulnerable functions se abre el apartado Details de una third-party vulnerability. La vista de coverage muestra cómo de bien monitoriza Runtime Vulnerability Analytics los procesos y hosts del entorno, para detectar huecos.',
      ],
      bullets: [
        'Mayor DSS + exposición + activos de datos + CISA KEV Overdue = candidata clara a remediar primero.',
        'Mismo CVSS no implica mismo riesgo: compara el DSS.',
        'El mute documenta una aceptación de riesgo; no es una remediación.',
      ],
      sourceRefs: [VA, VC, PRIO],
    },
    {
      id: 'sup-security-advisor',
      after: 'sup-vulnerabilities-app',
      title: 'Davis Security Advisor y APIs de seguridad',
      lead: 'Recomendaciones de actualización agrupadas por librería y acceso programático a vulnerabilidades.',
      paragraphs: [
        'Davis Security Advisor agrupa las librerías que provocan vulnerabilidades para simplificar la remediación y recomienda actualizarlas. Evalúa todas las third-party vulnerabilities abiertas y no silenciadas; las resueltas o silenciadas no se tienen en cuenta. Al calcular el consejo ignora la versión concreta de la librería y recomienda actualizar a la última versión cualquier librería con vulnerabilidades conocidas; las recomendaciones se ordenan por severidad según el DSS.',
        'Por API, /api/v2/davis/securityAdvices lista las recomendaciones de Davis sobre vulnerabilidades abiertas y no silenciadas, agrupadas por tecnología y componente vulnerable (adviceType UPGRADE), y /api/v2/securityProblems lista vulnerabilidades. Ambos endpoints requieren un token con el scope securityProblems.read.',
      ],
      sourceRefs: [DSAG, DSA, SPAPI],
    },
    {
      id: 'sup-investigations-details',
      after: 'deep-investigations',
      title: 'Investigations: query tree, evidencia, tiempo y enriquecimiento',
      lead: 'Las piezas concretas de la app que aparecen en preguntas de escenario.',
      paragraphs: [
        'Investigations es una app para investigaciones basadas en evidencia en seguridad, operaciones, compliance y fraude, con DQL sobre datos de Grail. Requiere logs ingeridos y conocer DQL y DPL. Con DPL Architect se extraen campos concretos de los logs (por ejemplo IP, usuarios o comandos). La investigación puede compartirse con otros usuarios y los cambios se guardan automáticamente.',
        'El query tree representa el recorrido: el root node se crea al ejecutar la primera consulta DQL, cada vez que modificas y ejecutas una consulta se añade un query node, y una query branch es la cadena de nodos que forma un camino de investigación, a la que puedes volver. Las evidence lists guardan fragmentos de logs y direcciones IP relevantes para usarlos después al buscar y filtrar.',
        'Tiempo: si no indicas periodo, se aplica el timeframe por defecto -2h (las últimas dos horas). El timeframe se define con los parámetros timeframe o from/to de fetch (que prevalecen sobre la selección manual), con el timeframe selector junto al botón Run, desde los resultados o desde el resumen de la consulta. Al seleccionar varios timestamps con shift y hacer clic derecho, Add to custom timeframes crea un timeframe con el mínimo y el máximo seleccionados. Set as reference time (clic derecho en un timestamp) añade una columna virtual con el offset entre cada evento y la referencia; puede sustituirse en cualquier momento y los offsets se recalculan.',
        'Enriquecimiento: IP enrichment añade datos de reputación externa a las direcciones IP con fuentes de threat intelligence como AbuseIPDB o VirusTotal. Las lookup tables son datasets estructurados guardados en Grail que enriquecen la investigación con contexto externo o de comportamiento y permiten correlacionar eventos con patrones conocidos, comportamiento de usuarios o metadatos de activos (por ejemplo, el inventario de activos de la empresa).',
      ],
      bullets: [
        'Query tree: volver a una rama anterior.',
        'Evidence lists: conservar fragmentos de log e IP.',
        'Add to custom timeframes: ventana reutilizable desde timestamps.',
        'Set as reference time: offsets respecto al incidente.',
        'IP enrichment: reputación externa; lookup tables: contexto propio.',
      ],
      sourceRefs: [INV, INVC, INVT],
    },
  ],
}
