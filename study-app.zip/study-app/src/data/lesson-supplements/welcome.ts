import type { SourceRef } from '../types'
import type { LessonSupplement } from './types'

const doc = (title: string, url: string): SourceRef => ({ title, url, kind: 'official-docs' })

const GRAIL = doc('Grail data lakehouse', 'https://docs.dynatrace.com/docs/platform/grail')
const GRAIL_C = doc('Dynatrace Grail (schema-on-read, sin índices)', 'https://docs.dynatrace.com/docs/platform/grail/dynatrace-grail')
const DQL = doc('Dynatrace Query Language', 'https://docs.dynatrace.com/docs/platform/grail/dynatrace-query-language')
const DQLG = doc('DQL guide', 'https://docs.dynatrace.com/docs/platform/grail/dynatrace-query-language/dql-guide')
const DQLM = doc('DQL metric commands', 'https://docs.dynatrace.com/docs/platform/grail/dynatrace-query-language/commands/metric-commands')
const ORG = doc('Data organization in Grail (buckets, tables, views)', 'https://docs.dynatrace.com/docs/platform/grail/organize-data')
const PERM = doc('Assign permissions in Grail', 'https://docs.dynatrace.com/docs/platform/grail/organize-data/assign-permissions-in-grail')
const SEG = doc('From management zones to segments', 'https://docs.dynatrace.com/docs/platform/upgrade/foundations/upgrade-guide-segments')
const OPP = doc('OpenPipeline', 'https://docs.dynatrace.com/docs/platform/openpipeline')
const OPPPROC = doc('OpenPipeline processing', 'https://docs.dynatrace.com/docs/platform/openpipeline/concepts/processing')
const SMART_C = doc('Smartscape Classic', 'https://docs.dynatrace.com/docs/analyze-explore-automate/smartscape-classic')
const SMART_G = doc('Smartscape on Grail', 'https://docs.dynatrace.com/docs/discover-dynatrace/platform/grail/smartscape-on-grail')
const PG = doc('Process groups', 'https://docs.dynatrace.com/docs/observe/infrastructure-observability/process-groups')
const SFLOW = doc('Service flow', 'https://docs.dynatrace.com/docs/observe/application-observability/services-classic/service-flow')
const SFLOWF = doc('Service flow filtering', 'https://docs.dynatrace.com/docs/observe/application-observability/services-classic/service-flow/service-flow-filtering')
const OAWORKS = doc('How OneAgent works', 'https://docs.dynatrace.com/docs/platform/oneagent/how-one-agent-works')
const OALINUX = doc('Install OneAgent on Linux (reinicio de procesos)', 'https://docs.dynatrace.com/docs/ingest-from/dynatrace-oneagent/installation-and-operation/linux/installation/install-oneagent-on-linux')
const MODES = doc('OneAgent monitoring modes', 'https://docs.dynatrace.com/docs/platform/oneagent/monitoring-modes/monitoring-modes')
const LOGENR = doc('Automatic log enrichment', 'https://docs.dynatrace.com/docs/analyze-explore-automate/logs/lma-log-ingestion/lma-log-ingestion-via-oa/lma-log-data-transformation-oa')
const AG = doc('Dynatrace ActiveGate', 'https://docs.dynatrace.com/docs/ingest-from/dynatrace-activegate')
const OTLP = doc('OTLP API ingest', 'https://docs.dynatrace.com/docs/ingest-from/opentelemetry/otlp-api')
const W3C = doc('Span and trace context propagation', 'https://docs.dynatrace.com/docs/observe/application-observability/distributed-tracing/tracking-transactions')
const DPS = doc('Dynatrace Platform Subscription', 'https://docs.dynatrace.com/docs/manage/subscriptions-and-licensing/dynatrace-platform-subscription')
const UNITS = doc('DPS capabilities and units', 'https://docs.dynatrace.com/docs/license/capabilities-and-units')
const SUBOV = doc('Subscription overview (DPS)', 'https://docs.dynatrace.com/docs/manage/account-management/license-subscription/subscription-overview-dps')
const ATM = doc('Adaptive Traffic Management with DPS', 'https://docs.dynatrace.com/docs/ingest-from/dynatrace-oneagent/adaptive-traffic-management/adaptive-traffic-management-saas-dps')
const DI = doc('Dynatrace Intelligence', 'https://docs.dynatrace.com/docs/dynatrace-intelligence')
const RCA = doc('Root cause analysis concepts (problem lifecycle)', 'https://docs.dynatrace.com/docs/dynatrace-intelligence/root-cause-analysis/concepts')
const CAT = doc('Event categories', 'https://docs.dynatrace.com/docs/dynatrace-intelligence/root-cause-analysis/event-analysis-and-correlation/event-categories')
const PROB = doc('Problems app', 'https://docs.dynatrace.com/docs/dynatrace-intelligence/problems-app')
const SEM = doc('Semantic Dictionary: Davis events and problems', 'https://docs.dynatrace.com/docs/discover-dynatrace/references/semantic-dictionary/model/davis')
const ALERT = doc('Problem alerting profiles', 'https://docs.dynatrace.com/docs/analyze-explore-automate/notifications-and-alerting/alerting-profiles')
const MW = doc('Maintenance windows', 'https://docs.dynatrace.com/docs/analyze-explore-automate/alerting-and-notifications/maintenance-windows')
const STATIC = doc('Static thresholds', 'https://docs.dynatrace.com/docs/dynatrace-intelligence/anomaly-detection/static-thresholds')
const AAT = doc('Auto-adaptive thresholds for anomaly detection', 'https://docs.dynatrace.com/docs/dynatrace-intelligence/anomaly-detection/auto-adaptive-threshold')
const SEAS = doc('Seasonal baseline', 'https://docs.dynatrace.com/docs/dynatrace-intelligence/reference/ai-models/seasonal-baseline')
const FORE = doc('Forecast analysis', 'https://docs.dynatrace.com/docs/dynatrace-intelligence/reference/ai-models/forecast-analysis')
const GENAI = doc('Agentic and generative AI (Dynatrace Assist)', 'https://docs.dynatrace.com/docs/dynatrace-intelligence/agentic-and-generative-ai')
const UI = doc('Navigate the Dynatrace platform', 'https://docs.dynatrace.com/docs/discover-dynatrace/get-started/dynatrace-ui')
const SEARCH = doc('Platform search', 'https://docs.dynatrace.com/docs/discover-dynatrace/get-started/dynatrace-ui/search')
const LAUNCH = doc('Launchpads', 'https://docs.dynatrace.com/docs/discover-dynatrace/get-started/dynatrace-ui/launchpads')
const EXT = doc('Manage extensions', 'https://docs.dynatrace.com/docs/ingest-from/extensions/manage-extensions')
const DN = doc('When to use Dashboards or Notebooks', 'https://docs.dynatrace.com/docs/analyze-explore-automate/dashboards-and-notebooks/differences-dashboards-notebooks')
const WFT = doc('Workflow triggers', 'https://docs.dynatrace.com/docs/analyze-explore-automate/workflows/trigger')
const APPENG = doc('Dynatrace AppEngine', 'https://docs.dynatrace.com/docs/platform/appengine')
const APPSEC = doc('Application Security', 'https://docs.dynatrace.com/docs/secure/application-security')
const BIZ = doc('Business Observability', 'https://docs.dynatrace.com/docs/observe/business-observability')
const SYN = doc('Synthetic Monitoring', 'https://docs.dynatrace.com/docs/observe/digital-experience/synthetic-monitoring')

export const welcomeSupplement: LessonSupplement = {
  moduleId: 'welcome',
  extend: {
    'deep-dynatrace-101': {
      corrections: [
        {
          find: 'La jerarquía de entidades se estructura verticalmente: Host (máquina virtual o física) → Process Group (agrupación lógica de procesos) → Process Group Instance / PGI (ejecución concreta de un proceso o contenedor) → Service (interfaz lógica de llamadas y endpoints) → Application (interfaz web, móvil o servicio consumido por el usuario final). Smartscape mapea estas entidades en 5 capas y mantiene sus conexiones horizontales de tráfico de red y llamadas entre servicios.',
          replace: 'La jerarquía de entidades se estructura verticalmente: Host (máquina virtual o física) → Process Group Instance / PGI (ejecución concreta de un proceso en ese host, que pertenece a un Process Group, la agrupación lógica de procesos equivalentes) → Service (interfaz lógica de llamadas y endpoints) → Application (interfaz web o móvil usada por el usuario final). Smartscape Classic mapea estas entidades en 5 tiers (Data centers, Hosts, Processes, Services y Applications) y muestra además las relaciones horizontales de llamada dentro de cada tier.',
        },
        { find: 'Davis AI Causal Engine', replace: 'Dynatrace Intelligence (antes Davis AI)' },
        {
          find: 'Opera sobre el grafo topológico Smartscape, no mediante machine learning probabilístico tipo caja negra.',
          replace: 'Su causal AI aplica un análisis determinista sobre el grafo topológico de Smartscape (no una correlación estadística de caja negra); además ofrece predictive AI (forecast analysis) y generative AI (Dynatrace Assist).',
        },
        {
          find: 'Inyecta telemetría sin código y OpenPipeline transforma y enruta datos antes de persistir.',
          replace: 'OneAgent captura telemetría sin cambios de código (inyecta code modules en los procesos) y OpenPipeline transforma y enruta los datos antes de guardarlos.',
        },
        {
          find: 'Permite utilizar cualquier capability de la plataforma sin licencias perpetuas rígidas.',
          replace: 'Un compromiso anual único que se consume por capability según un rate card, en lugar de cuotas fijas por producto (Host Units, DEM units…).',
        },
      ],
      reason: 'Corrige el orden PG/PGI de la jerarquía, nombra los 5 tiers documentados de Smartscape Classic y actualiza el nombre Dynatrace Intelligence (W-004, W-006, W-012). Auditoría v4: la tabla ya no niega la AI probabilística (seasonal baseline usa quantile regression y existe predictive AI), describe OneAgent como captura sin cambios de código mediante code modules y define DPS por su compromiso anual y rate card (el licenciamiento anterior tampoco era perpetuo).',
    },
  },
  precision: {
    corrections: [
      {
        topic: 'Smartscape 5 Layers',
        find: 'La topología Smartscape modela 5 capas: Data Center, Host, Process Group, Service y Application, conectadas mediante relaciones verticales y horizontales.',
        replace: 'Smartscape Classic muestra 5 tiers: Data centers, Hosts, Processes, Services y Applications, conectados mediante relaciones verticales (dependencias entre tiers) y horizontales (llamadas dentro de un tier).',
      },
      {
        topic: 'DPS Licensing Model',
        find: 'Dynatrace Platform Subscription (DPS) es un modelo de consumo unificado basado en valor donde las capacidades se tarifican por uso real sin silos de licencias perpetuas.',
        replace: 'Dynatrace Platform Subscription (DPS) es un compromiso anual único que se consume por capability según un rate card, en lugar de cuotas fijas por producto (Host Units, DEM units…).',
      },
      {
        topic: 'DPS Licensing Model',
        find: 'DPS permite activar y desactivar capacidades sin renegociar contratos de licencias individuales.',
        replace: 'Todas las capabilities consumen del mismo compromiso, cada una con su unidad; las Host Units y las licencias separadas por producto no forman parte de DPS.',
      },
    ],
    remove: ['Dynatrace Launcher', 'Davis AI Causal vs ML'],
    add: [
      {
        topic: 'Causal AI de Dynatrace Intelligence',
        fact: 'El causal AI de Dynatrace Intelligence (antes Davis AI) identifica la root cause con un análisis determinista sobre las dependencias reales de Smartscape, no por coincidencia temporal. Dynatrace Intelligence incluye además predictive AI (forecast analysis) y generative AI (Dynatrace Assist), y el seasonal baseline usa una predicción probabilística para su banda de confianza.',
        examNote: 'La root cause sale de las dependencias topológicas, no de la alerta que se disparó primero ni de una correlación estadística de alertas.',
        source: { title: 'Dynatrace Intelligence', url: 'https://docs.dynatrace.com/docs/dynatrace-intelligence' },
      },
      {
        topic: 'Launcher, Dock y Hub',
        fact: 'Launcher permite crear launchpads: páginas de inicio personalizables (propias o compartidas) con bloques Links, Markdown y Cards. Las apps se abren y anclan desde el Dock; se descubren e instalan en Hub.',
        examNote: 'Para abrir o anclar una app se usa el Dock (Pin to dock), no Launcher.',
        source: { title: 'Launchpads', url: 'https://docs.dynatrace.com/docs/discover-dynatrace/get-started/dynatrace-ui/launchpads' },
      },
    ],
    reason: 'Auditoría v4: Launcher crea launchpads (no es el panel de apps, que es el Dock: coherente con sup-platform-apps y W-018); la ficha de Davis negaba la AI probabilística (el seasonal baseline usa quantile regression) y usaba el nombre antiguo; los tiers de Smartscape Classic son Processes, no Process Group; DPS se define por compromiso anual y rate card, no por oposición a licencias perpetuas.',
  },
  sections: [
    {
      id: 'sup-platform-apps',
      after: 'deep-data-to-decision',
      title: 'Navegación y apps clave de la plataforma',
      lead: 'Dónde está cada cosa y para qué sirve cada app de Latest Dynatrace.',
      paragraphs: [
        'El Dock es el panel lateral desde el que se abren las apps; con Pin to dock se anclan las más usadas. La búsqueda de la plataforma se abre con Ctrl+K (Windows/Linux) o Cmd+K (Mac) y encuentra apps instaladas, Dashboards, Notebooks, Workflows, settings, métricas y entidades monitorizadas como hosts, process groups o services. Launcher permite crear launchpads: páginas de inicio personalizables, propias o compartidas, con bloques Links, Markdown y Cards. Dynatrace Hub es el catálogo donde se descubren e instalan apps y extensiones.',
        'Que una extensión aparezca en Hub no significa que recopile datos: hay que añadirla al entorno (Add to environment) y crear su monitoring configuration según su origen de datos (SNMP, WMI, Prometheus, bases de datos…). Hasta entonces no hay ingesta.',
        'Notebooks está pensado para el análisis ad hoc, el troubleshooting de incidentes complejos, la documentación y la colaboración: combina DQL y Markdown en un documento que se comparte con el equipo y que otros pueden volver a ejecutar. Dashboards sirve para la monitorización continua y en tiempo real: una visión de alto nivel de la salud del sistema, el seguimiento de KPIs y el cumplimiento de SLOs. Ambos se pueden compartir y ambos visualizan métricas, logs y eventos.',
        'AutomationEngine es el motor que ejecuta Workflows. Un workflow se dispara con un event trigger (un Problem, un Davis event u otro evento ingerido en OpenPipeline), con un schedule trigger (a intervalos o a una hora fija, por ejemplo un informe nocturno) o on-demand, cuando alguien o una llamada a la API lo lanza. Para ejecutarse sin intervención humana sirven los triggers de evento y de horario.',
        'AppEngine permite construir apps personalizadas sobre los datos de la plataforma: el Dynatrace App Toolkit sirve para crearlas, construirlas y desplegarlas, con TypeScript, React y el design system Strato, y las apps se ejecutan en el runtime de la plataforma, no en servidores del cliente.',
      ],
      comparison: {
        headers: ['Necesidad', 'Dónde', 'No confundir con'],
        rows: [
          ['Abrir y anclar apps', 'Dock (Pin to dock)', 'Launcher'],
          ['Página de inicio personalizada', 'Launcher (launchpads)', 'Dock'],
          ['Descubrir e instalar apps y extensiones', 'Hub', 'Platform search'],
          ['Encontrar un host, una app o un Notebook', 'Platform search (Ctrl/Cmd+K)', 'Hub'],
          ['Investigación ad hoc documentada', 'Notebooks', 'Dashboards'],
          ['Monitorización continua de KPIs y SLOs', 'Dashboards', 'Notebooks'],
        ],
      },
      sourceRefs: [UI, SEARCH, LAUNCH, EXT, DN, WFT, APPENG],
    },
    {
      id: 'sup-grail-dql',
      after: 'deep-dynatrace-101',
      title: 'Grail y DQL: un único almacén y un lenguaje en pipeline',
      lead: 'Grail guarda todas las señales juntas y DQL las consulta sin esquema previo.',
      paragraphs: [
        'Grail es el data lakehouse de Dynatrace diseñado para datos de observabilidad: logs, métricas, trazas (spans), eventos y Business Events se guardan en un único almacenamiento y quedan interconectados con el modelo de topología del entorno. No hay un backend separado para logs ni una unificación que ocurra solo en la capa visual: todo se consulta con DQL junto a su contexto de entidad, y los registros originales se conservan. Esta es la gran diferencia con Dynatrace Classic, que no tenía Grail: Latest Dynatrace se apoya en Grail, en DQL y en las apps de AppEngine, y sigue usando OneAgent, Smartscape y Problems.',
        'Grail aplica schema-on-read: los datos entran sin definir un esquema previo y sin índices, y la estructura (campos y tipos) se aplica al consultar, por ejemplo con el comando parse de DQL. Lo contrario es schema-on-write, donde hay que definir el esquema o los índices antes de ingerir. Grail no necesita ningún índice y permite buscar en cualquier campo o texto, esté o no estructurado.',
        'DQL (Dynatrace Query Language) es el lenguaje de consulta de Grail. Todos los comandos se encadenan con | (pipe): los datos fluyen de un comando al siguiente y se filtran o transforman en cada paso. Como el procesamiento es secuencial, el orden de los comandos importa y afecta tanto al resultado como al rendimiento. DQL se usa en Notebooks, Dashboards y Workflows.',
        'fetch carga registros de una tabla (logs, spans, events, bizevents…). Las métricas se consultan con timeseries, un comando de inicio que carga, filtra y agrega datos de métricas en series temporales; el comando metrics solo sirve para explorar claves y dimensiones de métricas, no para dibujar gráficos ni calcular. No confundas DQL con DPL (Dynatrace Pattern Language), el lenguaje de patrones que usan parse y los procesadores para extraer campos, ni con la sintaxis de statements de las políticas IAM.',
        'Cada señal tiene su forma: una métrica es una serie temporal de valores numéricos (por ejemplo, CPU por minuto); un evento registra un hecho puntual con timestamp y atributos (un deployment, un reinicio, una alerta); un log es un registro emitido por un proceso; y una trace distribuida muestra el recorrido de una petición entre servicios en spans, con la duración de cada llamada (también a bases de datos).',
      ],
      code: 'fetch logs\n| filter loglevel == "ERROR"\n| summarize errores = count(), by: {host.name}\n| sort errores desc',
      codeNote: 'Cada comando recibe la salida del anterior: se cargan logs, se filtran los ERROR, se cuentan por host y se ordenan.',
      comparison: {
        headers: ['Necesidad', 'Comando o lenguaje', 'No confundir con'],
        rows: [
          ['Leer registros de logs, spans o eventos', 'fetch', 'timeseries (métricas)'],
          ['Series temporales de métricas', 'timeseries', 'metrics (solo explorar claves)'],
          ['Extraer campos con patrones', 'DPL dentro de parse', 'DQL'],
          ['Conceder acceso a datos', 'Políticas IAM', 'Segments (solo filtran)'],
        ],
      },
      sourceRefs: [GRAIL, GRAIL_C, DQL, DQLG, DQLM],
    },
    {
      id: 'sup-buckets-permissions',
      after: 'sup-grail-dql',
      title: 'Buckets, retención y permisos en Grail',
      lead: 'La retención la decide el bucket; lo que ve cada usuario, sus políticas.',
      paragraphs: [
        'Grail organiza los datos en buckets, tables y views. Cada bucket está asociado a un único tipo de registro (logs, events, spans…) y tiene una retención propia; la tabla logs, por ejemplo, lee de todos los buckets de logs. OpenPipeline asigna cada registro a un bucket durante la ingesta (bucket assignment), así que el tiempo que se conserva un log lo define la retención del bucket al que va: ni OneAgent, ni el timeframe de una consulta DQL, ni las políticas IAM fijan la retención.',
        'Los buckets built-in (los default_ y los de sistema dt_) no se pueden modificar. Si necesitas otra retención, creas un bucket custom, que admite retenciones de 1 día a 10 años, más una semana adicional. Con la configuración por defecto, default_logs, default_bizevents y default_events guardan 35 días, default_spans 10 días y default_metrics 15 meses: unas métricas de hace tres semanas siguen disponibles, pero sus spans ya no.',
        'Para consultar datos hacen falta dos capas de permisos: el permiso de tabla (storage:logs:read para fetch logs, storage:spans:read para spans o storage:metrics:read para timeseries) y el permiso de bucket storage:buckets:read, que puede limitarse a ciertos buckets. En las tablas almacenadas en buckets, la lectura necesita los dos: sin storage:buckets:read sobre los buckets que contienen los datos, o sin el permiso de la tabla, no se obtienen esos registros, aunque exista el otro permiso. Además, las políticas pueden restringir registros concretos con condiciones sobre campos como dt.security_context, y storage:fieldsets:read controla el acceso a los campos sensibles agrupados en fieldsets. Por eso la misma consulta, con el mismo timeframe, puede devolver 0 registros a un usuario y miles a otro.',
        'En Classic, las management zones servían a la vez para filtrar vistas y para restringir accesos. En Latest, los segments filtran los datos de forma dinámica al consultar, pero no sustituyen el control de acceso de las management zones: el acceso lo deciden las políticas IAM, apoyadas en atributos como dt.security_context.',
      ],
      comparison: {
        headers: ['Bucket built-in', 'Tabla', 'Retención por defecto'],
        rows: [
          ['default_logs', 'logs', '35 días'],
          ['default_spans', 'spans', '10 días'],
          ['default_metrics', 'metrics', '15 meses'],
          ['default_bizevents', 'bizevents', '35 días'],
          ['default_events', 'events', '35 días'],
        ],
      },
      warning: 'Un resultado vacío no prueba que no haya datos: revisa el timeframe, la retención del bucket y los permisos de tabla y de bucket.',
      sourceRefs: [ORG, PERM, SEG],
    },
    {
      id: 'sup-openpipeline',
      after: 'sup-buckets-permissions',
      title: 'OpenPipeline: procesar antes de almacenar',
      lead: 'Lo que se transforma, enmascara o enruta ocurre en la ingesta, no al consultar.',
      paragraphs: [
        'OpenPipeline es la solución de Dynatrace para ingerir y procesar datos de distintas fuentes antes de guardarlos en Grail. Actúa en la ingesta, dentro de la plataforma: no es un módulo de OneAgent, no se aplica cuando DQL lee los datos y no mueve registros entre buckets cuando caducan. Cuando un registro termina de recorrer el pipeline, se envía a almacenamiento y queda disponible para el análisis.',
        'Un pipeline se compone de stages que se ejecutan en orden: Processing, Smartscape node, Smartscape edge, Permission, Product allocation, Cost allocation, Bucket assignment, Metric extraction, Davis y Data extraction. Processing prepara los datos (parsear valores en campos, transformar, filtrar o enmascarar) antes de almacenarlos; por eso es el lugar para enmascarar datos sensibles que no deben llegar a Grail. No existen stages de índices ni de retención: Grail no usa índices y la retención es una propiedad del bucket.',
      ],
      bullets: [
        'Processing: parsear, transformar, filtrar y enmascarar antes de guardar.',
        'Permission: aplica security context a los registros.',
        'Bucket assignment: decide en qué bucket (y, por tanto, con qué retención) se guarda el registro.',
        'Metric extraction, Davis y Data extraction: derivan métricas, Davis events u otros tipos de datos a partir de los registros.',
      ],
      warning: 'Reemplazar un valor en una consulta DQL o restringir un fieldset oculta el dato al leerlo, pero el valor original sigue almacenado en Grail.',
      sourceRefs: [OPP, OPPPROC, PERM],
    },
    {
      id: 'sup-smartscape',
      after: 'sup-openpipeline',
      title: 'Smartscape: entidades, tiers y relaciones',
      lead: 'La topología explica por qué un fallo en un host acaba afectando a una aplicación.',
      paragraphs: [
        'Smartscape Classic muestra cinco tiers verticales: Applications, Services, Processes, Hosts y Data centers; de abajo arriba, Data centers → Hosts → Processes → Services → Applications. El tier Data centers indica dónde residen los hosts: una ubicación física, un data center de VMware, una Availability Zone de AWS o una región de Azure.',
        'Las relaciones horizontales son las llamadas entrantes y salientes dentro de cada tier, como un Service que llama a otro Service. Las relaciones verticales muestran la dependencia full-stack entre tiers: una aplicación usa servicios, los servicios los atienden procesos y los procesos corren en hosts. Por eso, si un host cae, caen las Process Group Instances que ejecutaba y el impacto sube hacia los Services y Applications que dependen de ellas.',
        'Un Process Group es un clúster lógico de procesos que pertenecen a la misma aplicación o unidad de despliegue y cumplen la misma función en varios hosts; una Process Group Instance (PGI) es una ejecución concreta de ese grupo en un host. Un Service representa la funcionalidad que se invoca (peticiones web, RPC, consultas) y lo atienden los procesos de un Process Group, estén en el host o nodo que estén: un microservicio desplegado en 10 pods repartidos en 3 nodos sigue siendo un único Service atendido por varias instancias.',
        'La topología no se dibuja a mano: se construye con lo que observa OneAgent (procesos y su comunicación proceso a proceso), las APIs de las plataformas cloud y las stages Smartscape node y Smartscape edge de OpenPipeline. Para ver qué servicios y bases de datos llama un servicio y con qué volumen se usa Service flow (desde Services Classic, View service flow): muestra la secuencia de llamadas que desencadena cada petición, incluidas las llamadas a database services, el número de peticiones analizadas, el porcentaje de ellas que llega a cada servicio o base de datos y cómo contribuye cada llamada al response time. Smartscape indica con flechas si las llamadas de un servicio son entrantes o salientes, pero no muestra su volumen.',
        'En Latest, Smartscape on Grail guarda las entidades como nodos y las relaciones (runs_on, calls, relates_to…) como aristas, y se consultan con DQL mediante smartscapeNodes y smartscapeEdges.',
      ],
      comparison: {
        headers: ['Relación', 'Dirección', 'Ejemplo'],
        rows: [
          ['Llamada', 'Horizontal (mismo tier)', 'Service → Service'],
          ['Ejecución', 'Vertical (entre tiers)', 'Process Group Instance → Host'],
          ['Agrupación', 'Lógica', 'Process Group → sus PGIs'],
        ],
      },
      sourceRefs: [SMART_C, SMART_G, PG, SFLOW, SFLOWF, OAWORKS],
    },
    {
      id: 'sup-oneagent',
      after: 'sup-smartscape',
      title: 'OneAgent, ActiveGate y OpenTelemetry',
      lead: 'Un agente por host, comunicación saliente y modos que deciden la profundidad.',
      paragraphs: [
        'OneAgent es un conjunto de procesos especializados que se instala una vez por host: monitoriza el sistema operativo, detecta los procesos y se inyecta (code modules) en tecnologías compatibles como Java, Node.js o .NET para obtener visibilidad a nivel de código. También inyecta un tag de JavaScript en las páginas que sirven los servidores web monitorizados para obtener datos de Real User Monitoring, y monitoriza ficheros de log. Tras instalarlo, hay que reiniciar los procesos que ya estaban en marcha para poder monitorizarlos en profundidad.',
        'La comunicación de OneAgent con Dynatrace es solo saliente: Dynatrace nunca inicia la comunicación con OneAgent, de modo que no hay que abrir puertos entrantes. OneAgent puede conectar directamente con Dynatrace o a través de uno o varios ActiveGates opcionales. Un Environment ActiveGate actúa como proxy seguro entre los OneAgents y Dynatrace (útil en redes aisladas), monitoriza tecnologías por API de forma remota (AWS, VMware, Azure, Kubernetes, SNMP, Prometheus…) y puede ejecutar synthetic monitors desde ubicaciones privadas; no almacena datos de Grail ni ejecuta Workflows.',
        'Los modos de monitorización deciden la profundidad. Full-Stack ofrece visibilidad a nivel de código, tracing y profiling, además de la monitorización de infraestructura. Infrastructure Monitoring cubre infraestructura física y virtual (métricas de host, procesos, disco, red y memoria), log monitoring y AIOps, pero excluye tracing y profiling: un host que pasa de Full-Stack a Infrastructure pierde distributed tracing, la visibilidad a nivel de código y el profiling. Discovery mode da métricas básicas para descubrir hosts y procesos, solo está disponible con DPS y consume la capability Foundation & Discovery (host-hours).',
        'Cuando OneAgent captura logs, los enriquece automáticamente con atributos generales (host.name, log.source, loglevel…), atributos del modelo de entidades (dt.entity.host, dt.entity.process_group, dt.source_entity…) y trace_id y span_id, que conectan cada log con la traza de la petición que lo generó. host.name, dt.entity.process_group o dt.source_entity relacionan el log con entidades; para saltar a la traza concreta se usa trace_id.',
        'Dynatrace también acepta OpenTelemetry: la API OTLP recibe trazas, métricas y logs en /api/v2/otlp por HTTP con protobuf binario (http/protobuf); gRPC y JSON no están soportados. OneAgent y OpenTelemetry usan el formato W3C Trace Context, lo que permite propagar el contexto de traza en entornos mixtos.',
        'Para confirmar que un método concreto es lento hace falta visibilidad de código (Full-Stack): las trazas distribuidas del servicio con desglose por método (method hotspots en Classic) muestran el tiempo de cada método, algo que no ofrecen la vista de host, los logs ni Service flow, que muestra relaciones entre servicios.',
      ],
      comparison: {
        headers: ['Modo', 'Incluye', 'Excluye'],
        rows: [
          ['Full-Stack', 'Código, tracing, profiling e infraestructura', '—'],
          ['Infrastructure', 'Métricas de host, procesos, red, disco, logs y AIOps', 'Tracing y profiling'],
          ['Discovery (solo DPS)', 'Métricas básicas para descubrir hosts y procesos', 'Tracing, profiling y la mayoría de analíticas de infraestructura'],
        ],
      },
      sourceRefs: [OAWORKS, OALINUX, MODES, LOGENR, AG, OTLP, W3C],
    },
    {
      id: 'sup-dps',
      after: 'sup-oneagent',
      title: 'Dynatrace Platform Subscription (DPS): consumo por capability',
      lead: 'Un compromiso anual, un rate card y una unidad de medida por capability.',
      paragraphs: [
        'Con DPS la organización firma un acuerdo (normalmente de 1 a 3 años) con un compromiso anual mínimo, y el consumo se acumula contra ese compromiso según un rate card que fija el precio por unidad de cada capability. Todas las capabilities —Full-Stack Monitoring, Log – Ingest & Process, Automation Workflow, Runtime Application Protection…— se consumen contra el mismo compromiso, cada una con su unidad. Las Host Units, las tarifas por usuario y las licencias separadas por producto no forman parte de DPS.',
        'Si el uso crece (por ejemplo, más logs durante Black Friday), la ingesta sigue: el consumo extra se descuenta del compromiso y, una vez alcanzado, se puede seguir usando Dynatrace con consumo on-demand sin overage premiums. Como el compromiso se consume por capability y no por máquinas concretas, una migración de servidores on-premises a Kubernetes desplaza el consumo hacia capabilities como Kubernetes Platform Monitoring (pod-hours) sin cambiar de contrato.',
        'Full-Stack Monitoring se mide en GiB-hours (memoria de cada host monitorizado por hora), así que un host con más memoria consume más; Infrastructure Monitoring se mide en host-hours. Las métricas se facturan en Metrics – Ingest & Process por data point ingerido: cada combinación distinta de valores de dimensiones crea una serie nueva, así que dimensiones de alta cardinalidad (order_id, user_id) disparan series y data points; esos identificadores encajan mejor como atributos de logs, spans o Business Events. Las consultas de logs consumen Log – Query por GiB escaneado y conservar logs más tiempo consume Log – Retain en GiB-days.',
        'Con DPS, Adaptive Traffic Management ajusta automáticamente cada 15 minutos la tasa de muestreo de trazas para que el volumen capturado no supere el volumen de trazas incluido con Full-Stack (calculado por GiB de memoria monitorizada); el recuento total de peticiones se mantiene con alta precisión estadística. El coste y el uso se consultan en Account Management > Subscription > Overview: resumen de presupuesto con previsión, desglose de coste y uso de los últimos 30 días por capability y entorno, y análisis con filtros.',
      ],
      comparison: {
        headers: ['Capability', 'Unidad', 'Qué mide'],
        rows: [
          ['Full-Stack Monitoring', 'GiB-hour', 'Memoria por host monitorizado y hora'],
          ['Infrastructure Monitoring', 'host-hour', 'Host monitorizado por hora'],
          ['Foundation & Discovery', 'host-hour', 'Host en modo ligero (Discovery) por hora'],
          ['Kubernetes Platform Monitoring', 'pod-hour', 'Pods de Kubernetes por hora'],
          ['Log – Ingest & Process', 'GiB ingested', 'Bytes comprimidos ingeridos'],
          ['Log – Retain', 'GiB-day', 'Bytes almacenados × días de retención'],
          ['Log – Query', 'GiB scanned', 'Datos escaneados por cada consulta DQL'],
          ['Metrics – Ingest & Process', 'data point', 'Data points de métricas ingeridos'],
          ['Automation Workflow', 'workflow-hour', 'Workflows activos por hora'],
        ],
      },
      sourceRefs: [DPS, UNITS, SUBOV, ATM],
    },
    {
      id: 'sup-problems-lifecycle',
      after: 'deep-problem-davis',
      title: 'Problems: correlación, severidad y ciclo de vida',
      lead: 'Cómo nace, crece y se cierra un Problem, y cómo se investiga.',
      paragraphs: [
        'Dynatrace Intelligence (antes Davis AI) aplica un análisis determinista basado en causalidad sobre Grail y el grafo de dependencias de Smartscape: no agrupa alertas solo porque coincidan en el tiempo ni elige como causa la primera que se disparó, sino que usa las dependencias reales para determinar qué anomalía explica a las demás. Combina las anomalías relacionadas en un único Problem, lo que reduce drásticamente la carga de alertas: ante una caída de red que afecta a cientos de servicios y hosts se abre un solo Problem con el fallo de red como root cause, en lugar de una alerta por entidad.',
        'Los Davis events representan incidencias individuales: un umbral superado, una degradación respecto al baseline o un hecho puntual como la caída de un proceso. Un Problem agrupa todos los eventos que comparten la misma root cause en una única situación rastreable. En la app Problems, la root cause aparece resaltada y la sección Affected entities lista las entidades afectadas (frontends, services, infrastructure…): la root cause es la entidad que, según las dependencias, explica la degradación de las demás, no la que más eventos acumula ni la primera en el tiempo.',
        'Las categorías de evento, de mayor a menor severidad, son: Monitoring unavailable, Availability, Error, Slowdown, Resource, Custom, Info y Warning. Un Problem adopta la severidad más alta de sus eventos y puede escalar durante su vida: si a un Problem de Slowdown se le fusiona un evento Availability, pasa a Availability. Los eventos Info (deployments, cambios de configuración, acciones administrativas) no abren Problems, pero aportan contexto: Dynatrace Intelligence correlaciona cambios de código, deployments y configuración para explicar qué cambió.',
        'Un Problem se cierra cuando se cierran todos sus Davis events o cuando alguien lo cierra manualmente. Un Problem cerrado nunca se reabre: si vuelven eventos relacionados activos, se abre un Problem nuevo. Si un Problem dura más de 90 minutos, a partir de ese momento no se le fusionan eventos nuevos y se abre otro Problem. Para cerrarlo a mano en la app Problems (uno a uno o hasta 50 en bloque) siempre hay que escribir un comentario de cierre, que se guarda en Grail como annotation event; cerrar no borra datos.',
        'En DQL, dt.davis.problems es una vista con el estado actual de cada Problem (deduplicado), mientras que dt.davis.problems.snapshots guarda una instantánea cada vez que el Problem se actualiza; contar filas de snapshots sobrestima el número de Problems. dt.davis.events contiene Davis events, no Problems.',
        'Ante un Problem abierto, la secuencia más eficaz es revisar su impacto y timeframe, ir a la root cause que señala y confirmarla con trazas y logs de esa entidad. Recorrer Smartscape o las trazas a mano repite la correlación que el Problem ya hizo, y notificar a los dueños de cada entidad afectada actúa sobre los efectos en lugar de sobre la causa.',
        'Los problem alerting profiles no detectan anomalías ni agrupan eventos: filtran qué notificaciones de Problems se entregan y por qué canal (Slack, PagerDuty, Opsgenie…) según severidad, duración, management zones, eventos y tags. Para un cambio planificado se define una maintenance window (puntual o recurrente), que suprime las notificaciones de alerta durante el trabajo, excluye la interrupción planificada de los cálculos de disponibilidad y conserva los datos en Grail.',
      ],
      comparison: {
        headers: ['Pregunta', 'Respuesta documentada'],
        rows: [
          ['¿Cuándo se cierra un Problem?', 'Al cerrarse todos sus Davis events, o manualmente con comentario'],
          ['¿Se reabre?', 'No: los nuevos eventos activos crean otro Problem'],
          ['¿Hasta cuándo se le fusionan eventos?', 'Hasta 90 minutos después de abrirse'],
          ['¿Qué severidad muestra?', 'La más alta de sus eventos'],
          ['¿Abre Problem un evento Info?', 'No; aporta contexto de cambio'],
        ],
      },
      sourceRefs: [DI, RCA, CAT, PROB, SEM, ALERT, MW],
    },
    {
      id: 'sup-anomaly-ai',
      after: 'sup-problems-lifecycle',
      title: 'Detección de anomalías y las AI de Dynatrace Intelligence',
      lead: 'Elegir el modelo de umbral adecuado y saber qué hace cada tipo de AI.',
      paragraphs: [
        'Los custom anomaly detectors admiten tres modelos. Un static threshold es un límite fijo que la métrica no debe superar; como no cambia con el tiempo, es el adecuado para límites críticos y para problemas que crecen poco a poco, como una fuga de memoria lenta, que un umbral adaptativo acabaría acompañando. Un auto-adaptive threshold usa los datos de los últimos siete días: el percentil 99 de las medidas por minuto es el baseline y se le suma n veces la signal fluctuation (el rango intercuartílico entre p25 y p75); el umbral se recalcula cada día.',
        'El seasonal baseline aprende el comportamiento estacional de la métrica con los valores por minuto de los últimos 14 días y crea automáticamente una banda de confianza: tolera los picos previsibles, como los del horario laboral, y detecta desviaciones fuera de ese patrón.',
        'Además del causal AI, Dynatrace Intelligence ofrece predictive AI: la forecast analysis predice valores futuros de cualquier serie temporal numérica (por ejemplo, para anticipar cuándo se llenará un disco) y se puede lanzar desde Notebooks. Dynatrace Assist (antes Davis CoPilot) es el asistente de AI generativa: traduce preguntas en lenguaje natural a DQL (y puede ejecutarla), explica consultas existentes y resume Problems con su root cause y pasos de remediación. Sus respuestas deben contrastarse con datos observables.',
      ],
      comparison: {
        headers: ['Modelo', 'Cómo fija el umbral', 'Cuándo encaja'],
        rows: [
          ['Static threshold', 'Valor fijo definido por el usuario', 'Límites críticos y degradaciones lentas (fugas de memoria)'],
          ['Auto-adaptive threshold', 'p99 de los últimos 7 días + n × rango intercuartílico', 'Métricas sin patrón estacional claro'],
          ['Seasonal baseline', 'Banda de confianza aprendida con 14 días', 'Métricas con picos previsibles (horario laboral)'],
        ],
      },
      sourceRefs: [STATIC, AAT, SEAS, FORE, GENAI],
    },
    {
      id: 'sup-security-business-dem',
      after: 'sup-anomaly-ai',
      title: 'Seguridad, negocio y experiencia digital en la misma plataforma',
      lead: 'El mismo agente y el mismo almacén sirven para seguridad, negocio y experiencia de usuario.',
      paragraphs: [
        'Application Security usa el mismo OneAgent en runtime. Runtime Vulnerability Analytics identifica vulnerabilidades de terceros y a nivel de código en producción, y el Dynatrace Security Score ajusta el riesgo de cada una con el contexto de topología, más allá del CVSS base. Runtime Application Protection detecta y bloquea en tiempo real ataques como la inyección SQL con información a nivel de código. Security Posture Management evalúa configuraciones frente a estándares de hardening. No es un escáner aparte ni un análisis de código fuente durante el build (SAST).',
        'Los Business Events aportan datos de negocio (importe, ID de producto, tipo de póliza) con la precisión que exigen los casos de negocio, sin depender del muestreo, y se guardan en la tabla bizevents. Se obtienen con reglas de captura de OneAgent, por API desde sistemas externos, con OpenPipeline o desde RUM.',
        'Real User Monitoring (RUM) mide la experiencia de los usuarios reales en navegadores y apps móviles; Synthetic Monitoring ejecuta monitores programados desde ubicaciones públicas o privadas que comprueban disponibilidad y rendimiento aunque no haya tráfico real. Son complementarios.',
      ],
      sourceRefs: [APPSEC, BIZ, SYN, OAWORKS],
    },
  ],
}
