import type { StudyChapter, StudySection } from '../study-content'
import type { PrecisionFactSheet } from '../precision-facts'
import type { LessonSupplement } from './types'

const stripNumber = (title: string) => title.replace(/^\d+\.\s*/, '')

/**
 * Aplica las ampliaciones de lección por módulo y renumera los apartados de forma correlativa.
 */
export function applyLessonSupplements(chapters: Record<string, StudyChapter>, supplements: LessonSupplement[]): Record<string, StudyChapter> {
  const byModule = new Map(supplements.map((supplement) => [supplement.moduleId, supplement]))
  return Object.fromEntries(Object.entries(chapters).map(([moduleId, chapter]) => {
    const supplement = byModule.get(moduleId)
    let sections: StudySection[] = chapter.sections.map((original) => {
      let section = original
      const extension = supplement?.extend[section.id]
      if (!extension) return section
      const fix = (text: string) => (extension.corrections ?? []).reduce((current, { find, replace }) => current.split(find).join(replace), text)
      section = {
        ...section,
        title: fix(section.title),
        lead: fix(section.lead),
        paragraphs: section.paragraphs.map(fix),
        bullets: section.bullets?.map(fix),
        comparison: section.comparison ? { headers: section.comparison.headers.map(fix), rows: section.comparison.rows.map((row) => row.map(fix)) } : undefined,
        code: section.code === undefined ? undefined : fix(section.code),
        codeNote: section.codeNote === undefined ? undefined : fix(section.codeNote),
        warning: section.warning === undefined ? undefined : fix(section.warning),
      }
      return {
        ...section,
        paragraphs: [...section.paragraphs, ...(extension.paragraphs ?? [])],
        bullets: extension.bullets?.length ? [...(section.bullets ?? []), ...extension.bullets] : section.bullets,
        comparison: section.comparison && extension.comparisonRows?.length
          ? { ...section.comparison, rows: [...section.comparison.rows, ...extension.comparisonRows] }
          : section.comparison,
        warning: extension.warning ? [section.warning, extension.warning].filter(Boolean).join(' ') : section.warning,
      }
    })
    for (const { after, ...added } of supplement?.sections ?? []) {
      const index = after ? sections.findIndex((section) => section.id === after) : -1
      sections = index >= 0 ? [...sections.slice(0, index + 1), added, ...sections.slice(index + 1)] : [...sections, added]
    }
    sections = sections.map((section, index) => ({ ...section, title: `${index + 1}. ${stripNumber(section.title)}` }))
    return [moduleId, { ...chapter, sections }]
  }))
}

/** Aplica correcciones, retiradas y altas a las fichas de hechos de precisión. */
export function applyPrecisionSupplements(sheets: Record<string, PrecisionFactSheet>, supplements: LessonSupplement[]): Record<string, PrecisionFactSheet> {
  const byModule = new Map(supplements.map((supplement) => [supplement.moduleId, supplement.precision]))
  return Object.fromEntries(Object.entries(sheets).map(([moduleId, sheet]) => {
    const precision = byModule.get(moduleId)
    if (!precision) return [moduleId, sheet]
    const removed = new Set(precision.remove ?? [])
    const rows = sheet.rows
      .filter((row) => !removed.has(row.topic))
      .map((row) => {
        const fixes = (precision.corrections ?? []).filter((correction) => correction.topic === row.topic)
        if (!fixes.length) return row
        const fix = (text: string) => fixes.reduce((current, { find, replace }) => current.split(find).join(replace), text)
        return { ...row, fact: fix(row.fact), examNote: fix(row.examNote) }
      })
    return [moduleId, { ...sheet, rows: [...rows, ...(precision.add ?? [])] }]
  }))
}
