import type { SourceRef } from '../types'
import type { LessonSupplement } from './types'

const ref = (title: string, url: string): SourceRef => ({ title, url, kind: 'official-docs' })
const MODES = ref('OneAgent monitoring modes', 'https://docs.dynatrace.com/docs/platform/oneagent/monitoring-modes/monitoring-modes')
const ENABLE = ref('Enable OneAgent monitoring modes', 'https://docs.dynatrace.com/docs/platform/oneagent/monitoring-modes/enable-monitoring-modes')
const AGENT = ref('How OneAgent works', 'https://docs.dynatrace.com/docs/platform/oneagent/how-one-agent-works')
const CAPS = ref('OneAgent monitoring capabilities', 'https://docs.dynatrace.com/docs/platform/oneagent/supported-monitoring-types')
const CLI = ref('OneAgent configuration via command-line interface', 'https://docs.dynatrace.com/docs/ingest-from/dynatrace-oneagent/oneagent-configuration-via-command-line-interface')
const AG = ref('Dynatrace ActiveGate', 'https://docs.dynatrace.com/docs/ingest-from/dynatrace-activegate')
const CONNECT = ref('Supported connectivity schemes for ActiveGates', 'https://docs.dynatrace.com/docs/ingest-from/dynatrace-activegate/supported-connectivity-schemes-for-activegates')
const NETZONES = ref('Network zones', 'https://docs.dynatrace.com/docs/manage/network-zones/network-zones-basic-info')
const VSPHERE = ref('VMware vSphere monitoring', 'https://docs.dynatrace.com/docs/observe/infrastructure-observability/vmware-vsphere-monitoring')
const HOSTGROUPS = ref('Organize your environment using host groups', 'https://docs.dynatrace.com/docs/observe/infrastructure-observability/hosts/configuration/organize-your-environment-using-host-groups')
const PGDETECT = ref('Process group detection', 'https://docs.dynatrace.com/docs/observe/infrastructure-observability/process-groups/configuration/pg-detection')
const RCA = ref('Root cause analysis concepts', 'https://docs.dynatrace.com/docs/dynatrace-intelligence/root-cause-analysis/concepts')
const K8SAPP = ref('Kubernetes app', 'https://docs.dynatrace.com/docs/observe/infrastructure-observability/kubernetes-app')
const CNFS = ref('Full-stack observability with Dynatrace Operator', 'https://docs.dynatrace.com/docs/ingest-from/setup-on-k8s/how-it-works/cloud-native-fullstack')
const CLASSICFS = ref('Classic Full-Stack monitoring', 'https://docs.dynatrace.com/docs/ingest-from/setup-on-k8s/how-it-works/other-deployment-modes/classic-fullstack')
const APPMON = ref('Application observability with Dynatrace Operator', 'https://docs.dynatrace.com/docs/ingest-from/setup-on-k8s/how-it-works/application-monitoring')
const HOSTMON = ref('Host monitoring with Dynatrace Operator', 'https://docs.dynatrace.com/docs/ingest-from/setup-on-k8s/how-it-works/other-deployment-modes/host-monitoring')
const K8SMON = ref('Kubernetes platform monitoring', 'https://docs.dynatrace.com/docs/ingest-from/setup-on-k8s/how-it-works/kubernetes-monitoring')
const DATABASES = ref('Databases', 'https://docs.dynatrace.com/docs/observe/infrastructure-observability/databases')
const INFRAOPS = ref('Infrastructure & Operations', 'https://docs.dynatrace.com/docs/observe/infrastructure-observability/infrastructure-and-operations')
const COVERAGE = ref('Discovery & Coverage', 'https://docs.dynatrace.com/docs/ingest-from/discovery-coverage-app')
const LIC_FS = ref('Full-Stack Monitoring (DPS)', 'https://docs.dynatrace.com/docs/license/capabilities/app-infra-observability/full-stack-monitoring')
const LIC_INFRA = ref('Infrastructure Monitoring (DPS)', 'https://docs.dynatrace.com/docs/license/capabilities/app-infra-observability/infrastructure-monitoring')
const LIC_FD = ref('Foundation & Discovery (DPS)', 'https://docs.dynatrace.com/docs/license/capabilities/app-infra-observability/foundation-and-discovery')

export const observabilitySupplement: LessonSupplement = {
  moduleId: 'observability',
  extend: {
    'oneagent-capabilities': {
      paragraphs: [
        'Algunos matices de la página de capacidades que conviene memorizar. En contenedores, basta con instalar OneAgent en los hosts que sirven las aplicaciones en contenedores: detecta la creación y terminación de contenedores y no hace falta modificar las imágenes Docker ni los comandos de arranque. En server-side service monitoring, OneAgent informa de qué aplicaciones o services usan qué otros services y de si un service hace llamadas a otros services o a bases de datos. En red, OneAgent obtiene métricas de red a nivel de proceso gracias a la monitorización proceso a proceso de las comunicaciones, más allá de las métricas agregadas de interfaz del host. En topología, aporta qué procesos se ejecutan en qué hosts y cómo se conectan entre sí. Para root cause analysis, Dynatrace aprende automáticamente el baseline de response time y failure rate de todas las requests y evalúa las desviaciones frente a ese baseline, no frente a un umbral estático global.',
        'La OneAgent support matrix indica qué capacidades soporta OneAgent en cada sistema operativo y plataforma, con cuatro estados: GA (generally available and fully supported), Preview (no está lista para producción y no tiene soporte oficial), Future (en el roadmap o bajo demanda) y Not planned (Dynatrace no prevé desarrollarla). Una capability en Preview no debe tratarse como soportada en producción.',
      ],
      reason: 'Cubre E-007, E-009, E-010, E-012, D-008 y R-OBS-40 (contenedores, llamadas a bases de datos, baseline, topología, red por proceso y estados de la support matrix).',
    },
    'oneagent-architecture': {
      paragraphs: [
        'En Linux, OneAgent se instala por defecto en non-privileged mode: los privilegios de superusuario solo se usan para iniciar la instalación, y después Dynatrace OneAgent Watchdog arranca y ejecuta todos los demás procesos de OneAgent bajo un usuario sin privilegios (dtuser), con Linux capabilities concretas y conservando el conjunto completo de funcionalidades. No depende del modo de monitorización. La herramienta oneagentctl, en cambio, sí requiere privilegios de root para ejecutarse.',
        'Además del HTTP/S habitual, si Live Debugger está habilitado OneAgent crea una sesión WebSocket saliente hacia los ActiveGates o el Cluster para la información en tiempo real; la telemetría normal sigue usando HTTP/S. OneAgent puede conectarse simultáneamente a través de varios ActiveGates y decide por cuáles comunicarse según la información que recibe del Cluster.',
      ],
      reason: 'Cubre G-038 y R-OBS-29 (Watchdog y non-privileged mode), C-005 (WebSocket de Live Debugger) y B-010 (varios ActiveGates).',
    },
    'monitoring-modes': {
      corrections: [
        { find: 'La documentación actual indica que está disponible con Dynatrace Platform Subscription', replace: 'La documentación actual indica que está disponible solo con Dynatrace Platform Subscription (DPS)' },
        { find: 'No indicado en la matriz', replace: 'No (—)' },
        { find: 'Requiere code-module injection para AppSec/Live Debugger', replace: 'No (—); code-module injection se habilita por host para AppSec y Live Debugger' },
        { find: 'No como cobertura equivalente de Full-Stack', replace: 'No (—)' },
      ],
      paragraphs: [
        'Lectura literal de la tabla oficial: Topology discovery, Host criticality (detección de external services y app dependencies) y Basic monitoring (host health, filesystem, OS Services) son GA en los tres modos. Host process details, Detailed disk analysis, Network analysis y Memory analysis son GA en Full-Stack e Infrastructure y no figuran en Discovery. Tracing and profiling solo figura en Full-Stack. Extensions es opt-in en Full-Stack e Infrastructure y no figura en Discovery. Log Management, Application Security y Live Debugger son opt-in en los tres modos.',
        'En Infrastructure, OneAgent inyecta automáticamente en procesos para monitorizar backing services Java y runtime metrics de los lenguajes soportados (process injection opt-out, es decir, activa salvo que se desactive) y admite custom metrics con un límite de 100 por host. En Full-Stack, el límite de custom metrics es 15 por cada 256 MiB de memoria del host, y Discovery no incluye custom metrics.',
      ],
      comparisonRows: [
        ['Host criticality', 'Sí', 'Sí', 'Sí'],
        ['Custom metrics', '15 / 256 MiB', '100 / host', 'No (—)'],
        ['Live Debugger', 'Opt-in', 'Opt-in', 'Opt-in'],
      ],
      reason: 'La tabla decía "No indicado" o "No equivalente" donde la oficial muestra "—"; se añaden custom metrics y host criticality (A-007, A-012, A-014, FO-002, R-OBS-01, R-OBS-37, R-OBS-38).',
    },
    'enable-modes': {
      corrections: [
        { find: 'o después desde el host, CLI o Settings API.', replace: 'o después desde el host, CLI o Settings API (schema builtin:host.monitoring).' },
        { find: 'El nivel host puede prevalecer sobre la configuración de entorno para extensiones.', replace: 'La auto-injection también se desactiva por host (en la configuración del host, Host Monitoring > Advanced settings > ProcessAgent Injection, o con --set-auto-injection-enabled=false): ese host deja de inyectar aunque el resto del entorno siga inyectando. Para extensiones JMX/PMI en Infrastructure mode, la documentación indica que el ajuste a nivel de host prevalece sobre el de entorno ("The setting at the host level takes precedence over environment settings").' },
      ],
      paragraphs: [
        'Para cambiar el modo de muchos hosts ya instalados sin entrar en cada uno, la vía documentada es la Settings API: se descarga el schema con GET a schema usando builtin:host.monitoring como schemaId y se crea la configuración con POST an object. El Default mode de Settings > Fleet management afecta a las nuevas instalaciones, no convierte los hosts existentes.',
      ],
      reason: 'Se precisa la desactivación de auto-injection por host (R-OBS-13) y se deja la precedencia host > entorno donde la documenta Dynatrace: en la sección Disable selected extensions (JMX/PMI). Se añade la Settings API (R-OBS-32).',
    },
    injection: {
      corrections: [
        { find: 'Go, PHP y web servers compatibles', replace: 'Go, PHP y web servers como Apache HTTP, NGINX o Microsoft IIS' },
      ],
      paragraphs: [
        'Significado de cada estado de Auto-injection en Deployment Status: Enabled (se habilitó correctamente), Disabled manually (se desactivó después de instalar OneAgent), Disabled on installation (se desactivó durante la instalación de OneAgent), Disabled on sanity check (no se habilitó porque falló un test) y Failed on installation (falló por un error durante la instalación).',
        'Para excluir de la inyección solo ciertos procesos, las custom process monitoring rules dan control fino sobre en qué procesos inyecta OneAgent, sin desactivar la auto-injection de todo el host. Desactivar runtime metrics (Settings > Monitoring > Monitored technologies) es otra cosa: quita esas métricas, no excluye un grupo de procesos. Tras cualquiera de estos cambios hay que reiniciar los procesos afectados.',
      ],
      reason: 'Cubre R-OBS-10 (estados de Deployment Status), R-OBS-39 (process monitoring rules) y R-OBS-42 (web servers con runtime metrics).',
    },
    'deep-oneagent-capabilities': {
      corrections: [
        { find: 'Host Monitoring mode proporciona métricas de infraestructura pero prescinde de inyección profunda en procesos.', replace: 'Infrastructure mode proporciona métricas de infraestructura y runtime metrics mediante process injection, pero no tracing and profiling.' },
      ],
      reason: '"Host Monitoring mode" no es un modo actual de OneAgent y la frase contradecía la inyección opt-out de Infrastructure.',
    },
    'deep-oneagent-architecture': {
      corrections: [
        { find: 'La comunicación desde OneAgent hacia Dynatrace es exclusivamente saliente (outbound-only) por el puerto HTTPS 443.', replace: 'La comunicación desde OneAgent hacia Dynatrace es exclusivamente saliente (outbound-only) por HTTP/S: hacia un Environment ActiveGate usa por defecto el puerto 9999 y hacia el SaaS Cluster el 443.' },
        { find: 'Outbound-only por puerto 443: sin puertos de entrada requeridos en firewalls.', replace: 'Outbound-only (9999 hacia Environment ActiveGate, 443 hacia SaaS Cluster): sin puertos de entrada requeridos en firewalls.' },
      ],
      reason: 'Error: no todo el tráfico va por 443; los Environment ActiveGates reciben conexiones en el puerto 9999 (G-028).',
    },
    'deep-oneagent-modes': {
      corrections: [
        { find: 'no indicado en la matriz', replace: 'no (—)' },
        { find: 'no estándar', replace: 'no (—)' },
        { find: 'profundo', replace: 'GA' },
        { find: 'no disponible', replace: 'no (—)' },
        { find: 'está disponible bajo Foundation & Discovery', replace: 'se licencia con Foundation & Discovery' },
        { find: 'disponible', replace: 'GA' },
      ],
      reason: 'Se alinea la tabla con la oficial: Host process details es GA en Full-Stack e Infrastructure y "—" en Discovery; tracing/profiling y process injection son "—" fuera de lo indicado.',
    },
  },
  precision: {
    corrections: [
      { topic: 'Auto-injection', find: 'Se puede desactivar globalmente o por reglas de process group con “--set-auto-injection-enabled=false” o la configuración equivalente.', replace: 'Se puede desactivar por host (configuración del host o “--set-auto-injection-enabled=false”, que afecta a todo el host) o excluir procesos concretos con custom process monitoring rules.' },
      { topic: 'Discovery', find: 'No ofrece tracing/profiling completo por defecto y no debe venderse como Full-Stack barato.', replace: 'No incluye tracing and profiling (solo Full-Stack lo tiene) y no debe venderse como Full-Stack barato.' },
      { topic: 'OneAgent CLI (oneagentctl)', find: 'Requiere privilegios de administrador local en el host para ejecutar modificaciones.', replace: 'Se ejecuta localmente desde <INSTALL_PATH>/agent/tools y requiere root en Linux/AIX o administrador en Windows.' },
    ],
    reason: 'Auditoría final: --set-auto-injection-enabled actúa a nivel de host (la exclusión de procesos va por custom process monitoring rules); Tracing and profiling es "—" en Discovery; oneagentctl exige root/administrador para ejecutarse, no solo para modificar.',
  },
  sections: [
    {
      id: 'sup-mode-licensing',
      after: 'monitoring-modes',
      title: 'Cómo consume licencia cada modo en DPS',
      lead: 'El modo no solo cambia la profundidad: también cambia la capability DPS y la unidad con la que se mide el consumo.',
      paragraphs: [
        'Cada modo consume una capability distinta de DPS. Full-Stack Monitoring se mide en GiB-hours (memory-gibibyte-hours) según la memoria del host: la RAM se redondea al siguiente múltiplo de 0,25 GiB (256 MiB) y se aplica un mínimo de 4 GiB a hosts físicos y virtuales. Infrastructure Monitoring se mide en host hours, con independencia de la memoria del host: cada host monitorizado aporta una host hour por hora tenga la RAM que tenga.',
        'Foundation & Discovery, la capability de Discovery mode, también se mide en host hours, independientes de la memoria, e incluye las métricas básicas integradas; no incluye la ingesta de custom metrics, que requiere Infrastructure o Full-Stack, y los logs se cobran aparte en Log Management and Analytics. En todos los casos el consumo se calcula en intervalos de 15 minutos: un host monitorizado menos de 15 minutos en un intervalo cuenta como 15 minutos.',
      ],
      comparison: {
        headers: ['Modo', 'Capability DPS', 'Unidad de consumo'],
        rows: [
          ['Full-Stack', 'Full-Stack Monitoring', 'GiB-hours según la RAM (mínimo 4 GiB por host)'],
          ['Infrastructure', 'Infrastructure Monitoring', 'Host hours, independientes de la memoria'],
          ['Discovery', 'Foundation & Discovery', 'Host hours, independientes de la memoria'],
        ],
      },
      warning: 'Desactivar la auto-injection en un host Full-Stack no lo convierte en Infrastructure: sigue consumiendo Full-Stack Monitoring.',
      sourceRefs: [LIC_FS, LIC_INFRA, LIC_FD, MODES],
    },
    {
      id: 'sup-activegate-routing',
      after: 'activegate',
      title: 'ActiveGate: tipos, puertos, fallback y network zones',
      lead: 'ActiveGate es a la vez proxy seguro de OneAgent y motor de monitorización remota por API; las network zones deciden por qué ActiveGates sale el tráfico.',
      paragraphs: [
        'ActiveGate es un proxy seguro entre OneAgents y Dynatrace Clusters (o entre OneAgents y otros ActiveGates), y además puede realizar tareas de monitorización usando API para consultar y monitorizar tecnologías donde no se instala OneAgent: AWS, Azure, Google Cloud, VMware, Kubernetes, OpenShift, Cloud Foundry, Oracle, SNMP, WMI o Prometheus. Hay Environment ActiveGates y Cluster ActiveGates; en SaaS solo se necesita un Environment ActiveGate (los Cluster ActiveGates y el embedded ActiveGate de los nodos del cluster son propios de Dynatrace Managed).',
        'En VMware vSphere monitoring, ActiveGate recibe los datos de VMware y los envía al Cluster usando un Environment ActiveGate con acceso de solo lectura a vCenter o a un host ESXi standalone; no se instala OneAgent en el hipervisor. OneAgent en cada máquina virtual aporta datos complementarios de la salud del sistema invitado y de cómo se comportan y comunican sus procesos. La integración detecta migraciones vMotion y la creación de nuevas VMs.',
        'Conectividad por defecto en SaaS: OneAgent abre conexiones salientes HTTPS; el Environment ActiveGate recibe conexiones en el puerto 9999 y el SaaS Cluster en el 443. OneAgent se conecta a un Environment ActiveGate si existe, pero se conecta directamente al SaaS Cluster si no es posible ninguna conexión con un Environment ActiveGate. Dynatrace nunca inicia la conexión hacia OneAgent y un OneAgent no hace de ActiveGate para otros.',
        'Las network zones agrupan OneAgents y ActiveGates por ubicación de red. OneAgent prefiere los ActiveGates de su propia zona; si no hay ninguno disponible, prueba las alternative zones configuradas y después aplica el fallback mode: Any ActiveGate (por defecto, cualquier ActiveGate disponible, incluida la default zone), Only default zone (solo ActiveGates de la default zone) o None (el tráfico permanece dentro de la zona principal y las alternative zones). Los nombres de network zone no distinguen mayúsculas (Dynatrace los guarda en minúsculas) y la función se activa en Settings > Preferences > Network zones con Enable network zones in this environment.',
      ],
      comparison: {
        headers: ['Fallback mode', 'Adónde va el tráfico si no hay ActiveGate en la zona ni en las alternative zones', 'Cuándo encaja'],
        rows: [
          ['Any ActiveGate (default)', 'A cualquier ActiveGate disponible, incluida la default zone', 'Priorizar que los datos lleguen'],
          ['Only default zone', 'Solo a ActiveGates de la default zone', 'Hay una zona central de respaldo'],
          ['None', 'No sale de la zona principal ni de las alternative zones', 'La política prohíbe cruzar zonas'],
        ],
      },
      warning: 'Una cosa es el puerto (9999 hacia Environment ActiveGate, 443 hacia SaaS Cluster) y otra el sentido: siempre es OneAgent quien inicia la conexión.',
      sourceRefs: [AG, CONNECT, NETZONES, VSPHERE, AGENT],
    },
    {
      id: 'sup-process-groups',
      after: 'topology',
      title: 'Host groups, process groups y process group instances',
      lead: 'El modo en que se agrupan hosts y procesos decide en qué entidad analizas y dónde aplicas configuración.',
      paragraphs: [
        'Un process group agrupa procesos que pertenecen juntos (por ejemplo, los nodos de un cluster Tomcat), y cada process group instance (PGI) representa una instancia concreta: para aislar el nodo que consume más memoria se analiza su PGI, no el process group. Un service es una unidad lógica que puede ejecutarse en varias instancias.',
        'Cada host pertenece como máximo a un host group. Los host groups permiten configurar a escala alerting y anomaly detection, políticas de actualización de OneAgent y configuración de process groups y services. Si el mismo proceso se ejecuta en dos host groups distintos, Dynatrace crea un process group por cada host group, y la separación se extiende a los services. El host group se asigna con --set-host-group en la instalación o después con oneagentctl, Deployment Status o configuración remota; cambiarlo reinicia OneAgent. Su nombre solo admite caracteres alfanuméricos, guiones, guiones bajos y puntos, no puede empezar por dt. y tiene un máximo de 100 caracteres.',
        'Para ajustar la agrupación hay variables de entorno que se definen proceso a proceso: con DT_CLUSTER_ID, todos los procesos que comparten el mismo cluster ID se tratan como miembros del mismo process group (la documentación advierte de no definirla a nivel de sistema); con DT_NODE_ID indicas qué procesos deben tratarse como process group instances separadas. Las reglas y ajustes de process group detection requieren reiniciar los procesos para afectar a cómo se identifican y agrupan; esperar o reiniciar solo OneAgent no basta.',
      ],
      comparison: {
        headers: ['Necesidad', 'Mecanismo', 'Efecto'],
        rows: [
          ['Separar staging y producción del mismo proceso', 'Host groups distintos', 'Un process group por host group'],
          ['Unir procesos en un mismo process group', 'DT_CLUSTER_ID con el mismo valor', 'Mismo process group'],
          ['Ver instancias separadas dentro del process group', 'DT_NODE_ID con valores distintos', 'Process group instances separadas'],
          ['Aplicar una regla de detección nueva', 'Regla + reinicio de los procesos', 'Nueva identificación y agrupación'],
        ],
      },
      sourceRefs: [HOSTGROUPS, PGDETECT, CLI],
    },
    {
      id: 'sup-davis-problems',
      after: 'sup-process-groups',
      title: 'Cómo construye Dynatrace un Problem',
      lead: 'Un Problem no es una alerta por síntoma: es la correlación de Davis events con la misma root cause sobre la topología.',
      paragraphs: [
        'Dynatrace correlaciona todos los Davis events con la misma root cause en un único Problem. Para ello sigue un enfoque context-aware: detecta Davis events interdependientes a lo largo del tiempo, procesos, hosts, services y aplicaciones, combinando las perspectivas topológicas vertical y horizontal. La vertical va del service al proceso y al host que lo ejecuta; la horizontal sigue las llamadas entre services. Si una base de datos lenta degrada tres services dependientes, verás un único Problem cuya root cause es la base de datos, no tres Problems ni el service más afectado como causa.',
        'Hay límites temporales: si el inicio de los primeros Davis events se separa más de 5 minutos, no se fusionan en el mismo Problem; y si un Problem dura más de 90 minutos, no se fusionan más Davis events después de ese punto y se abre un nuevo Problem. Un Problem permanece activo mientras alguna entidad afectada siga en estado unhealthy o abnormal, normalmente indicado por un Davis event activo.',
        'El impact analysis identifica qué entry-point services de las aplicaciones se ven afectados y el tamaño del blast radius en número total de entidades afectadas, lo que ayuda a priorizar. Es distinto de la root cause (qué lo provocó) y del baseline aprendido (que sirve para detectar la anomalía).',
      ],
      bullets: [
        'Correlación: Davis events con la misma root cause → un único Problem.',
        'Topología: vertical (service → proceso → host) y horizontal (service → service).',
        'Tiempo: 5 minutos entre los primeros eventos; nada se fusiona tras 90 minutos.',
        'Impacto: entry-point services afectados y blast radius.',
      ],
      sourceRefs: [RCA, CAPS],
    },
    {
      id: 'sup-oneagentctl',
      after: 'deep-oneagent-change-control',
      title: 'oneagentctl: parámetros y reinicios que exige cada cambio',
      lead: 'La CLI local cambia configuración del host, pero cada parámetro tiene su propio requisito de reinicio.',
      paragraphs: [
        'oneagentctl está en <INSTALL_PATH>/agent/tools: por defecto /opt/dynatrace/oneagent/agent/tools en Linux y AIX, donde necesitas privilegios de root, y %PROGRAMFILES%\\dynatrace\\oneagent\\agent\\tools en Windows, donde necesitas privilegios de administrador. Se ejecuta localmente en el host; no depende de API tokens ni del modo de monitorización.',
        'Los parámetros de lectura siguen el patrón --get-… (--get-monitoring-mode, --get-auto-injection-enabled, --get-host-id, --get-server). Los valores de --set-monitoring-mode son fullstack, infra-only y discovery. --set-auto-injection-enabled=true o false activa o desactiva la auto-injection; tras activarla hay que reiniciar los procesos monitorizados para que carguen el code module. Cambiar el modo con --set-monitoring-mode requiere reiniciar OneAgent y también todos los services monitorizados, igual que --set-host-group. --set-proxy configura el proxy (con valor vacío lo elimina) y requiere reiniciar OneAgent; --set-no-proxy excluye dominios o IPs. --set-host-tag y --set-host-property no exigen reiniciar los services monitorizados; como con todo parámetro --set ("When you use the set parameters, you need to restart OneAgent service to apply changes"), el cambio se aplica al reiniciar el servicio OneAgent. Para que ese reinicio de OneAgent se haga automáticamente puedes añadir --restart-service.',
        'En la instalación desatendida se usan los mismos parámetros (por ejemplo --set-monitoring-mode=infra-only, --set-host-group y --set-host-tag con formato clave=valor). Si el host no aparece en el host group esperado, revisa las reglas de nombre: alfanuméricos, guiones, guiones bajos y puntos, sin empezar por dt. y con un máximo de 100 caracteres. El orden de los parámetros no importa.',
      ],
      comparison: {
        headers: ['Parámetro', 'Qué hace', 'Reinicio que requiere'],
        rows: [
          ['--set-monitoring-mode', 'fullstack, infra-only o discovery', 'OneAgent y todos los services monitorizados'],
          ['--set-host-group', 'Asigna el host a un host group', 'OneAgent y todos los services monitorizados'],
          ['--set-auto-injection-enabled', 'Activa o desactiva la auto-injection', 'Reiniciar los procesos para que cambie su inyección'],
          ['--set-proxy / --set-no-proxy', 'Proxy y exclusiones', 'OneAgent'],
          ['--set-host-tag / --set-host-property', 'Tags y propiedades del host', 'OneAgent (no los services monitorizados)'],
        ],
      },
      code: 'oneagentctl --get-monitoring-mode\noneagentctl --set-monitoring-mode=fullstack --restart-service\noneagentctl --set-proxy=my-proxy.com --restart-service\noneagentctl --set-auto-injection-enabled=true',
      codeNote: 'Ejemplos con la sintaxis de la documentación oficial; --restart-service reinicia OneAgent, no los procesos monitorizados.',
      sourceRefs: [CLI, ENABLE],
    },
    {
      id: 'sup-dynakube-modes',
      after: 'deep-infrastructure-connectors',
      title: 'Kubernetes con Dynatrace Operator: modos de DynaKube',
      lead: 'Cada modo de DynaKube decide si hay monitorización de nodos, de aplicación o de la plataforma Kubernetes.',
      paragraphs: [
        'cloudNativeFullStack usa mutating webhooks para inyectar code modules en los Pods de aplicación y combina monitorización de infraestructura y de aplicación. Sus componentes: Dynatrace Operator (rollout y ciclo de vida), el webhook (valida configuraciones e inyecta configuración en los Pods), el CSI driver (DaemonSet que proporciona almacenamiento para los binarios de OneAgent; no inyecta), OneAgent (recoge métricas de host de los nodos) y ActiveGate, que enruta los datos de observabilidad al cluster de Dynatrace y monitoriza la Kubernetes API.',
        'classicFullStack requiere acceso de escritura desde el Pod de OneAgent al sistema de archivos del nodo y no está soportado cuando se usa un platform token. applicationMonitoring inyecta code modules en los Pods y monitoriza los procesos del contenedor (disco, CPU y red), pero no monitoriza métricas de host y, sin Kubernetes platform monitoring, la topología se limita a Pods y contenedores; el CSI driver es opcional. hostMonitoring recoge métricas de host y datos de procesos de los nodos con OneAgent, sin monitorización a nivel de aplicación. Kubernetes platform monitoring usa la Kubernetes API y cAdvisor para obtener métricas de nodos y contenedores y eventos de Kubernetes; no incluye OneAgent ni monitorización de aplicación por defecto, aunque se combina con los demás modos.',
      ],
      comparison: {
        headers: ['Modo', 'Qué aporta', 'Qué no aporta o qué exige'],
        rows: [
          ['cloudNativeFullStack', 'Inyección por mutating webhooks + métricas de nodos', 'Es la opción full-stack con platform token'],
          ['classicFullStack', 'Full-stack inyectando desde el Pod de OneAgent', 'Escritura en el filesystem del nodo; sin platform token'],
          ['applicationMonitoring', 'Code modules en los Pods y procesos del contenedor', 'Sin métricas de host; topología limitada'],
          ['hostMonitoring', 'Métricas de host y procesos de los nodos', 'Sin monitorización de aplicación'],
          ['Kubernetes platform monitoring', 'Kubernetes API + cAdvisor: nodos, contenedores y eventos', 'Sin OneAgent ni aplicación por defecto'],
        ],
      },
      sourceRefs: [CNFS, CLASSICFS, APPMON, HOSTMON, K8SMON],
    },
    {
      id: 'sup-kubernetes-app',
      after: 'sup-dynakube-modes',
      title: 'La app Kubernetes y Enhanced Object Visibility',
      lead: 'La nueva experiencia Kubernetes vive sobre Grail y AppEngine y añade objetos, YAML y alertas de buenas prácticas.',
      paragraphs: [
        'Requisitos: un entorno Dynatrace SaaS con Grail y AppEngine, licencia DPS con la capability Kubernetes Platform Monitoring y permisos suficientes. La nueva experiencia no está disponible para Managed ni para SaaS sin Grail; en esos entornos se sigue usando Kubernetes Classic. Como las métricas, eventos y logs están en Grail, el mismo análisis puede hacerse con DQL y reutilizarse en Notebooks, Dashboards o Workflows.',
        'Enhanced Object Visibility (desde el 19 de enero de 2026) añade objetos como Ingress, NetworkPolicies, CRDs, PVCs, PVs y ConfigMaps, da acceso a sus definiciones YAML para depurar y validar configuraciones en tiempo real y permite consultar los YAML de todos los clusters y namespaces con DQL para detectar misconfigurations. Requiere ActiveGate 1.327 o superior. Con ActiveGates anteriores, el cluster funciona en modo de compatibilidad y aparece una pestaña adicional Explorer (Classic); al actualizar ActiveGate pasa al Explorer nuevo sin pérdida de datos de monitorización. Desde junio de 2026, Explorer (Classic) pasa a soporte de solo mantenimiento (maintenance only): los clusters con ActiveGates antiguos siguen visibles ahí, pero sin acceso a las funciones nuevas.',
        'Salud y alertas: para eventos críticos se genera un Health alert, que inicia una investigación de Problems; para situaciones no críticas, un Warning signal informa de un posible problema. Un objeto de Kubernetes (por ejemplo, un cluster) se considera unhealthy si cualquiera de sus custom alert configurations asociadas está unhealthy. La pestaña Recommendations presenta alertas de buenas prácticas para clusters, nodes, namespaces, persistent volume claims y workloads, y resalta cuáles están active, partially active o inactive. Al seleccionar un objeto en el Explorer se abre una vista de detalle con pestañas de health y utilization, logs, events, ownership y vulnerabilities.',
      ],
      bullets: [
        'Prerrequisitos: SaaS + Grail + AppEngine, DPS con Kubernetes Platform Monitoring, permisos.',
        'Enhanced Object Visibility: ActiveGate 1.327+; antes, Explorer (Classic), en maintenance only desde junio de 2026.',
        'Health alert (crítico, inicia Problems) frente a Warning signal (no crítico).',
        'Recommendations: alertas de buenas prácticas active, partially active o inactive.',
      ],
      sourceRefs: [K8SAPP],
    },
    {
      id: 'sup-infra-apps',
      after: 'sup-kubernetes-app',
      title: 'Databases, Infrastructure & Operations y Discovery & Coverage',
      lead: 'Tres apps de Infrastructure Observability con preguntas distintas: bases de datos, salud de infraestructura y huecos de cobertura.',
      paragraphs: [
        'La app Databases ofrece un health score compuesto que resume la salud de cada instancia de base de datos, análisis de SQL statements y execution plans, y vistas como Overview, Explorer, Databases, Tables e Indexes. Se alimenta de extensiones de base de datos (Extensions Framework 2.0) ejecutadas en ActiveGate, con OneAgent como fuente complementaria de métricas de host. Prerrequisitos: asignar uno o varios ActiveGate groups que conecten remotamente con los servidores de base de datos, instalar los componentes necesarios, como drivers JDBC, en esos ActiveGates, validar la conectividad directa desde ActiveGate y crear un usuario de monitorización con permisos sobre system views y schemas. Así se monitoriza también una base de datos gestionada en la que no se pueden instalar agentes.',
        'Infrastructure & Operations simplifica la monitorización de salud de la infraestructura y facilita el root cause analysis de Problems, con vistas de Hosts, Containers, Processes y Network Devices y un Explorer para filtrar entidades, revisar su salud e investigar Problems. Discovery & Coverage sirve para detectar blind spots e implementar el nivel de observabilidad adecuado a escala. En Host coverage, la columna Recommended action propone No action, Connect cloud (para clouds sin conectar) o Install OneAgents (con prioridad según el tamaño del hueco de observabilidad; con filtros, el botón indica cuántos OneAgents se instalarán). En Service coverage, la columna Enable Full-Stack permite pasar a Full-Stack monitoring mode los OneAgents de los hosts descubiertos. En Network coverage, Configure scanning, Ping all (Network Availability Monitoring) y Poll all (la extensión SNMP adecuada). Además, reglas de buenas prácticas recomiendan, por ejemplo, poner OneAgent al menos en Infrastructure Monitoring mode y configurar la extensión de base de datos adecuada si se detecta una base de datos en el host; si no sabes qué modo usar, puedes empezar por Foundation & Discovery para ver qué aplicaciones o infraestructura hay en el host y sus interdependencias. Detecta los huecos con datos de Smartscape, con el eBPF Discovery module (componente de OneAgent de bajo overhead que determina qué URLs se envían a un proceso, con qué frecuencia y si el origen es público) y con la extensión SNMP Autodiscovery, que escanea la red en busca de network devices SNMP.',
      ],
      comparison: {
        headers: ['App', 'Pregunta que responde', 'Fuente de datos clave'],
        rows: [
          ['Databases', '¿Qué instancia está degradada y qué statement la carga?', 'Extensiones de base de datos en ActiveGate'],
          ['Infrastructure & Operations', '¿Qué host, proceso o network device está degradado?', 'OneAgent, integraciones cloud y Dynatrace Intelligence'],
          ['Discovery & Coverage', '¿Qué hosts o tecnologías quedan sin monitorizar?', 'Smartscape, eBPF Discovery module, SNMP Autodiscovery'],
        ],
      },
      sourceRefs: [DATABASES, INFRAOPS, COVERAGE, LIC_FD],
    },
  ],
}
