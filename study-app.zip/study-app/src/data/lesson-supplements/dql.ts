import type { LessonSupplement } from './types'

const base = 'https://docs.dynatrace.com/docs/platform/grail/dynatrace-query-language'
const ref = (title: string, path: string) => ({ title, url: `${base}${path}`, kind: 'official-docs' as const })

const DATASRC = ref('DQL data source commands', '/commands/data-source-commands')
const FILTER = ref('DQL filter and search commands', '/commands/filtering-commands')
const SELECT = ref('DQL selection and modification commands', '/commands/selection-and-modification-commands')
const EXTRACT = ref('DQL extraction and parsing commands', '/commands/extraction-and-parsing-commands')
const ORDER = ref('DQL ordering commands', '/commands/ordering-commands')
const STRUCT = ref('DQL structuring commands', '/commands/structuring-commands')
const AGG = ref('DQL aggregation commands', '/commands/aggregation-commands')
const JOIN = ref('DQL correlation and join commands', '/commands/correlation-and-join-commands')
const SMART = ref('DQL Smartscape commands', '/commands/smartscape-commands')
const METRIC = ref('DQL metric commands', '/commands/metric-commands')
const BEST = ref('DQL best practices', '/dql-best-practices')
const TYPES = ref('DQL data types', '/data-types')
const OPS = ref('DQL operators', '/operators')
const REF = ref('DQL language reference', '/dql-reference')
const F_ARRAY = ref('DQL array functions', '/functions/array-functions')
const F_AGG = ref('DQL aggregation functions', '/functions/aggregation-functions')
const F_CONV = ref('DQL conversion and casting functions', '/functions/conversion-and-casting-functions')
const F_COND = ref('DQL conditional functions', '/functions/conditional-functions')
const F_BOOL = ref('DQL boolean functions', '/functions/boolean-functions')
const F_STRING = ref('DQL string functions', '/functions/string-functions')
const F_TIME = ref('DQL time functions', '/functions/time-functions')
const F_MATH = ref('DQL mathematical functions', '/functions/mathematical-functions')
const F_GEN = ref('DQL general functions', '/functions/general-functions')
const DPL = { title: 'Dynatrace Pattern Language', url: 'https://docs.dynatrace.com/docs/platform/grail/dynatrace-pattern-language', kind: 'official-docs' as const }
const GRAIL_PERMS = { title: 'Permissions in Grail', url: 'https://docs.dynatrace.com/docs/platform/grail/organize-data/assign-permissions-in-grail', kind: 'official-docs' as const }

export const dqlSupplement: LessonSupplement = {
  moduleId: 'dql',
  extend: {
    'metric-commands': {
      corrections: [
        { find: 'por defecto consulta los últimos 10 días y limita el resultado a 100.000 series', replace: 'está limitado a los últimos 10 días y a 100.000 series por consulta' },
        { find: '10 días por defecto y 100.000 series', replace: 'Últimos 10 días y 100.000 series' },
        {
          find: 'El metric command está pensado para consultar métricas como series y ofrece una salida orientada a registros de métricas.',
          replace: 'La categoría Metric commands de la referencia DQL incluye dos comandos: timeseries y metrics. El comando metrics recupera series de métricas para explorar metric keys, dimension keys y valores de dimensión; no devuelve timestamps ni valores de series temporales (timeseries values), así que no sirve para charting ni para cálculos.',
        },
        { find: 'metric command', replace: 'comando metrics' },
      ],
      reason: 'La referencia de metric commands no habla de un periodo por defecto: metrics está limitado a los últimos diez días (R-DQL-06). "metric commands" es la categoría (timeseries y metrics); el comando se llama metrics (auditoría final).',
    },
    'permissions-performance': {
      corrections: [
        {
          find: 'La visibilidad de un record depende de permisos, management zones y restricciones de datos.',
          replace: 'La visibilidad de un record en Grail depende de los permisos, que se asignan a nivel de bucket (storage:buckets:read), de tabla (por ejemplo storage:logs:read), de record (por ejemplo con condiciones sobre dt.security_context) y de field.',
        },
        { find: 'Permiso y management zone.', replace: 'Permisos de bucket, tabla y record (security context).' },
      ],
      reason: 'En Grail el alcance de datos lo fijan los permisos de bucket, tabla, record y field, no las management zones (auditoría final).',
    },
    'dql-troubleshooting': {
      corrections: [
        { find: 'Permiso y management zone correctos.', replace: 'Permisos de bucket, tabla y record (security context) correctos.' },
      ],
      reason: 'En Grail el alcance de datos lo fijan los permisos de bucket, tabla, record y field, no las management zones (auditoría final).',
    },
    'deep-dql-pipeline': {
      corrections: [
        {
          find: 'mediante `from:now()-2h`, `from:now()-7d` o `to:now()`.',
          replace: 'mediante from: (y, opcionalmente, to:), por ejemplo `from:now()-2h, to:now()` o `from:now()-24h, to:now()-2h`, o mediante timeframe: para un rango absoluto. to: solo marca el final de la ventana; el inicio lo fija from: (o timeframe:).',
        },
      ],
      reason: 'to:now() por sí solo no fija la ventana temporal (auditoría final; G-101).',
    },
    'deep-dql-types-records': {
      corrections: [
        { find: 'data record(payload="{"status":"ok","count":3}")', replace: 'data record(payload = "{\\"status\\":\\"ok\\",\\"count\\":3}")' },
        {
          find: 'se accede con índices o claves; un array se indexa por posición.',
          replace: 'se accede por clave (record[campo]); un array se indexa por posición (array[0]).',
        },
      ],
      reason: 'El ejemplo tenía comillas sin escapar dentro del string y no era una consulta válida. Los records se acceden por clave y solo los arrays por índice (auditoría final).',
    },
    'deep-dql-dpl': {
      corrections: [
        { find: 'matchers como `INTEGER`, `IPADDR`, `TIMESTAMP`, `STRING`, `DATA` y otros', replace: 'matchers como `INT`, `IPADDR`, `LD`, `HTTPDATE`, `JSON` y otros' },
      ],
      paragraphs: [
        'En `parse content, "IPADDR:ip LD HTTPDATE:time"`, el comando parse, el campo content y el resto de la consulta son DQL; solo el string del patrón es DPL. Cada matcher reconoce un tipo de dato (IPADDR una dirección IPv4 o IPv6, INT un entero, LD datos de línea, HTTPDATE un timestamp con formato de log HTTP) y el nombre tras los dos puntos es el campo que se exporta.',
      ],
      reason: 'Se sustituyen matchers no verificados por los de la referencia DPL y se explica qué parte de una consulta es DPL (R-DQL-21).',
    },
  },
  sections: [
    {
      id: 'sup-dql-sources',
      after: 'deep-dql-pipeline',
      title: 'Comandos de inicio, data objects y permisos',
      lead: 'El primer comando decide qué datos se cargan; el resto solo transforma lo recibido.',
      paragraphs: [
        'Solo algunos comandos pueden iniciar una consulta. `fetch` es un data source command que carga registros de un data object de Grail, por ejemplo `fetch logs`, `fetch events`, `fetch bizevents` o `fetch spans`. `timeseries` es un metric command de inicio que combina carga, filtrado y agregación de métricas en una serie temporal. Comandos como `filter`, `fields` o `summarize` procesan los registros que reciben por el pipe: no cargan datos y no pueden ser el primer comando.',
        'Otros comandos de inicio: `data` genera registros de ejemplo en tiempo de consulta a partir de expresiones record o de un string JSON (por ejemplo `data record(a = "DQL", b = 1), record()`), ideal para probar un patrón de parse sin leer datos de Grail; `describe` devuelve la definición de esquema de un data object, con sus campos y tipos, sin cargar sus registros; `load` carga un archivo tabular de lookup; `metrics` explora series de métricas; `smartscapeNodes` y `smartscapeEdges` cargan nodos y aristas de Smartscape.',
        'fetch admite parámetros que acotan la lectura: `from:` y `to:` (duraciones relativas como `-24h` o timestamps absolutos), `timeframe:` (rango absoluto), `bucket:` (uno o varios buckets, con comodines), `samplingRatio` y `scanLimitGBytes`. samplingRatio admite 1 (valor por defecto, sin muestreo), 10, 100, 1000 o 10000 y devuelve 1/samplingRatio de los registros, así que el resultado es aproximado. scanLimitGBytes limita los datos escaneados: 500 GB por defecto, y -1 analiza todos los datos del timeframe. interval: y shift: no son parámetros de fetch, sino de timeseries.',
        'Si no especificas limit, la consulta muestra 1000 resultados: ese limit se añade por defecto como última línea. Ver 1000 filas no significa que existan 1000 registros; para conocer el total hay que agregar con `summarize count()`.',
        'Sin permisos, un usuario no puede consultar datos de Grail. Hacen falta dos niveles: el permiso de bucket `storage:buckets:read` y el permiso de tabla del data object, como `storage:logs:read` para logs, `storage:bizevents:read`, `storage:spans:read`, `storage:events:read`, `storage:metrics:read` o `storage:entities:read`. Una consulta válida puede fallar o devolver menos datos por autorización.',
      ],
      comparison: {
        headers: ['Comando de inicio', 'Qué carga o genera', 'Ejemplo'],
        rows: [
          ['fetch', 'Registros de un data object de Grail', 'fetch logs, from:-2h'],
          ['timeseries', 'Series temporales de métricas agregadas', 'timeseries avg(dt.host.cpu.usage)'],
          ['data', 'Registros de ejemplo en tiempo de consulta', 'data record(a = "DQL", b = 1)'],
          ['describe', 'Definición de esquema de un data object', 'describe logs'],
          ['smartscapeNodes / smartscapeEdges', 'Nodos o aristas de Smartscape', 'smartscapeNodes HOST'],
        ],
      },
      code: 'fetch logs, from:now()-2h, to:now(), bucket:{"default_logs"}\n| filter loglevel == "ERROR"\n| summarize errors = count()',
      codeNote: 'from:, to: y bucket: acotan qué lee fetch; summarize count() da el total real, no las 1000 filas que se muestran sin limit.',
      sourceRefs: [DATASRC, METRIC, ORDER, GRAIL_PERMS],
    },
    {
      id: 'sup-dql-filtering',
      after: 'sup-dql-sources',
      title: 'Filtros, búsqueda y lógica con null',
      lead: 'DQL usa lógica de tres estados: true, false y null.',
      paragraphs: [
        'filter conserva solo los registros cuya condición es true. Los operadores de comparación devuelven null si uno de los operandos es null; incluso null == null devuelve null. Como filter descarta todo lo que no es true, `filter log.source != "nginx"` pierde los registros sin log.source, y añadir `or log.source == null` no los recupera porque esa comparación también es null. La negación tampoco ayuda: not null = null.',
        'filterOut elimina los registros cuya condición es true y conserva el resto, incluidos los null: filterOut x conserva un registro con x = null, mientras que filter not x lo elimina. Para incluir los null de forma explícita existe isTrueOrNull(expresión), que devuelve true si la expresión es true o null. isNull(expresión) devuelve true para valores null y campos ausentes, e isNotNull hace lo contrario. if(condición, then, else) devuelve then solo si la condición es true y devuelve else cuando la condición es false o null: con `if(duration > 1s, "slow", else:"fast")`, un registro sin duration obtiene "fast". coalesce(a, b, …) devuelve el primer argumento no null, útil para sustituir un null por un valor como "unknown".',
        'Para comparar strings, la guía de buenas prácticas recomienda == o != cuando conoces el valor exacto (`filter k8s.container.name == "coredns"`) y ~ para coincidencias parciales con comodines (`filter k8s.container.name ~ "core*"`). El operador ~ es insensible a mayúsculas y, sin comodines, busca el valor como token dentro del string: "Hello World" ~ "world" es true, pero "HelloWorld" ~ "world" es false porque no hay separador entre tokens. Con comodines basta con que un token coincida con el patrón, así que "*timeout*" encuentra "connectionTimeout".',
        'search conserva los registros que coinciden con una condición de búsqueda, con coincidencia de strings insensible a mayúsculas y basada en tokens. `search "error"` busca el término en todos los campos; `search content ~ "error"` limita la búsqueda al campo content. Entre las string functions, contains(expresión, substring, caseSensitive) distingue mayúsculas por defecto (caseSensitive es true por defecto), mientras que matchesPhrase no las distingue por defecto.',
        'in(needle, haystack, …) comprueba si un valor es miembro de un array o de una lista de valores: `filter in(loglevel, "ERROR", "FATAL")` equivale a `filter loglevel == "ERROR" or loglevel == "FATAL"`, y `filter in("production", tags)` conserva los registros cuyo array tags contiene "production". Con and, la condición loglevel == "ERROR" and loglevel == "FATAL" nunca se cumple para un único valor.',
      ],
      comparison: {
        headers: ['Expresión', 'Registro con el campo a null', 'Resultado'],
        rows: [
          ['filter x != "a"', 'x != "a" es null', 'Descartado'],
          ['filter not (x == "a")', 'not null es null', 'Descartado'],
          ['filterOut x == "a"', 'La condición no es true', 'Conservado'],
          ['filter isTrueOrNull(x != "a")', 'isTrueOrNull devuelve true', 'Conservado'],
          ['filter isNull(x)', 'isNull devuelve true', 'Conservado'],
        ],
      },
      code: 'fetch logs, from:-1h\n| filter isTrueOrNull(log.source != "nginx")\n| summarize n = count(), by:{svc = coalesce(service.name, "unknown")}',
      codeNote: 'isTrueOrNull incluye los registros sin log.source; coalesce agrupa como "unknown" los que no tienen service.name.',
      sourceRefs: [FILTER, OPS, F_BOOL, F_COND, F_STRING, F_GEN, BEST],
    },
    {
      id: 'sup-dql-fields',
      after: 'deep-dql-command-contract',
      title: 'Selección y modificación de campos, dedup y sort',
      lead: 'Cada comando fields* cambia el esquema de una forma distinta.',
      paragraphs: [
        'fields conserva solo los campos indicados, en el orden indicado, y puede crear campos a partir de expresiones. fieldsAdd evalúa una expresión y añade o reemplaza un campo, conservando todos los demás (`| fieldsAdd uid = upper(k8s.pod.uid)`). fieldsKeep conserva los campos seleccionados y, a diferencia de fields, no crea campos nuevos; admite patrones con comodín (`| fieldsKeep event, "dt.smartscape.*"`). fieldsRemove elimina campos del resultado y también admite patrones (`| fieldsRemove loglevel, "k8s.cluster.*"`).',
        'fieldsRename usa la sintaxis fieldName = originalName: primero el nombre nuevo y después el original, y el campo original deja de existir (`| fieldsRename host = dt.smartscape.host, severity = loglevel`). fieldsMove reúne los campos de nivel raíz que coinciden con include: (menos los de exclude:) en un campo nuevo de tipo record anidado (`| fieldsMove k8s, include: {"k8s.*"}, exclude: {k8s.namespace.name}`). fieldsFlatten hace lo contrario: extrae los campos de un record anidado a campos de nivel raíz, con el nombre del campo como prefijo y un parámetro depth (por defecto 1, entre 1 y 10). fieldsSummary calcula la cardinalidad de los valores de los campos indicados, útil para conocer los datos antes de diseñar filtros.',
        'dedup elimina duplicados según la combinación de campos indicada y conserva un registro completo por combinación (`dedup service.name, status`), a diferencia de summarize, que devuelve solo los grupos y sus agregaciones. Sin el parámetro sort:, el registro que se conserva de cada grupo es aleatorio; con `dedup location, sort: { timestamp desc }` se conserva el más reciente de cada location.',
        'sort ordena de forma ascendente por defecto y distingue mayúsculas: los valores que empiezan por mayúscula (por ejemplo K) se listan antes que los que empiezan por minúscula (por ejemplo d). Por eso `sort server asc` sobre apache, Nginx y envoy devuelve Nginx, apache, envoy.',
      ],
      comparison: {
        headers: ['Comando', 'Efecto en el esquema', 'Ejemplo'],
        rows: [
          ['fields', 'Conserva solo los campos indicados; puede calcular campos', 'fields timestamp, content'],
          ['fieldsAdd', 'Añade o reemplaza un campo y conserva el resto', 'fieldsAdd uid = upper(k8s.pod.uid)'],
          ['fieldsKeep', 'Conserva campos o patrones; no crea campos', 'fieldsKeep event, "dt.smartscape.*"'],
          ['fieldsRemove', 'Elimina campos o patrones', 'fieldsRemove loglevel, "k8s.cluster.*"'],
          ['fieldsRename', 'Renombra: nombre nuevo = nombre original', 'fieldsRename severity = loglevel'],
          ['fieldsMove', 'Mueve campos raíz a un record anidado', 'fieldsMove k8s, include: {"k8s.*"}'],
          ['fieldsFlatten', 'Saca a la raíz los campos de un record', 'fieldsFlatten r, depth: 2'],
          ['fieldsSummary', 'Calcula la cardinalidad de los valores', 'fieldsSummary loglevel'],
        ],
      },
      sourceRefs: [SELECT, STRUCT, AGG, FILTER, ORDER],
    },
    {
      id: 'sup-dql-structure-parse',
      after: 'sup-dql-fields',
      title: 'expand, parse y jsonExtract',
      lead: 'Antes de analizar, convierte arrays, texto y JSON en campos utilizables.',
      paragraphs: [
        'expand crea un registro independiente por cada elemento de un array (`expand [alias =] expresión [, limit]`); sin alias, el campo expandido sustituye al array. Si el array está vacío, no se produce ningún registro, de modo que esa fila desaparece del resultado. El parámetro limit: restringe cuántos elementos se expanden de cada array: se toman desde el principio del array hasta el final o hasta el límite.',
        'parse aplica un patrón DPL a un campo de texto y coloca los resultados en uno o varios campos (`parse content, "LD \'status=\' INT:status"`). Si el patrón no coincide, el registro se conserva y los campos del patrón quedan null; con preserveFieldsOnFailure:true se conservan los valores existentes de esos campos. parsingPrerequisite determina si un registro debe parsearse. Los campos que añade parse sobrescriben los existentes con el mismo nombre.',
        'jsonExtract analiza un string JSON y extrae sus claves de nivel raíz como campos de nivel raíz del registro. Nunca sobrescribe campos existentes: si hay colisiones, las claves en conflicto se guardan en el campo indicado en conflicts: o se descartan. No hay que confundirlo con fieldsFlatten, que trabaja sobre un record ya estructurado, ni con expand, que trabaja sobre arrays.',
      ],
      code: 'data record(id = 1, tags = array("a", "b", "c")),\n     record(id = 2, tags = array())\n| expand tags, limit: 2',
      codeNote: 'id=1 produce dos registros (tags "a" y "b"); id=2 tiene un array vacío y no produce ningún registro.',
      sourceRefs: [STRUCT, EXTRACT, DPL],
    },
    {
      id: 'sup-dql-join',
      after: 'sup-dql-structure-parse',
      title: 'join, lookup, joinNested y append',
      lead: 'Elige el comando según qué filas deben sobrevivir y cómo se representan las coincidencias.',
      paragraphs: [
        'join combina los registros de la consulta (lado left) con los de una subconsulta (lado right) según on:. kind admite inner (valor por defecto), leftOuter y outer. inner devuelve solo los registros que coinciden en ambos lados; leftOuter devuelve todos los registros de la izquierda y solo los coincidentes de la derecha, de modo que un registro de la izquierda sin coincidencia se mantiene; outer devuelve los registros coincidentes y los no coincidentes de cualquiera de los dos lados. Los campos añadidos desde la subconsulta llevan por defecto el prefijo right.',
        'Si la clave tiene el mismo nombre en ambos lados basta con on:{id}; si los nombres son distintos se indica el lado de cada campo: on:{left[dt.entity.host] == right[id]}. Varias condiciones separadas por comas se combinan con AND. Cuando las claves de ambos lados son null, los registros no se emparejan, sea cual sea el kind; para tratarlos como iguales hay que sustituir antes el null, por ejemplo con coalesce.',
        'lookup enriquece cada registro de origen con los campos de un registro coincidente de una subconsulta y conserva todas las filas de origen. Necesita sourceField (campo de la tabla de origen) y lookupField (campo de la subconsulta), como en `lookup [fetch dt.entity.kubernetes_cluster], sourceField: dt.entity.kubernetes_cluster, lookupField: id`. Si hay varias coincidencias, solo se recupera el primer registro coincidente, y los campos añadidos llevan por defecto el prefijo lookup. Los prefijos por defecto son, por tanto, right. en join y lookup. en lookup; ambos se cambian con el parámetro prefix.',
        'joinNested funciona como una variante de leftOuter que, en lugar de duplicar filas, añade los resultados coincidentes de la subconsulta como un array de records anidados en un campo nuevo (`joinNested nestedRecords = [ … ], on: { key }`). append combina los registros de dos fuentes de forma similar a UNION ALL de SQL: añade los registros de la subconsulta a los del stream sin emparejarlos por clave, sin deduplicar y sin modificar los campos.',
      ],
      comparison: {
        headers: ['Comando', 'Filas de origen sin coincidencia', 'Varias coincidencias', 'Prefijo por defecto'],
        rows: [
          ['join (kind:inner, por defecto)', 'Se descartan', 'Una fila por coincidencia', 'right.'],
          ['join kind:leftOuter', 'Se conservan', 'Una fila por coincidencia', 'right.'],
          ['join kind:outer', 'Se conservan, también las de la subconsulta', 'Una fila por coincidencia', 'right.'],
          ['lookup', 'Se conservan', 'Solo la primera coincidencia', 'lookup.'],
          ['joinNested', 'Se conservan', 'Array de records en un campo nuevo', 'Nombre del campo nuevo'],
          ['append', 'No empareja: concatena registros', 'No aplica', 'Sin prefijo'],
        ],
      },
      code: 'fetch logs, from:-1h\n| join [fetch dt.entity.host | fields id, entity.name],\n    kind:leftOuter,\n    on:{left[dt.entity.host] == right[id]}',
      codeNote: 'leftOuter conserva todos los logs; el nombre del host llega como right.entity.name.',
      sourceRefs: [JOIN, BEST],
    },
    {
      id: 'sup-dql-smartscape',
      after: 'sup-dql-join',
      title: 'Consultas Smartscape: smartscapeNodes, smartscapeEdges y traverse',
      lead: 'Los nodos se cargan; las relaciones se recorren.',
      paragraphs: [
        'smartscapeNodes carga nodos de Smartscape de un tipo: el tipo se escribe sin comillas cuando es concreto (`smartscapeNodes HOST`), entre comillas dobles cuando es un patrón con comodines (`smartscapeNodes "*EC2*"`) o como * para todos los tipos. smartscapeEdges carga aristas, es decir, relaciones entre nodos, filtradas por su tipo, por ejemplo `smartscapeEdges runs_on`.',
        'traverse no inicia una consulta: recibe nodos de un comando anterior y sigue un tipo de arista hasta un tipo de nodo destino, con la sintaxis traverse edgeType, targetType. Por ejemplo, `smartscapeNodes PROCESS | traverse runs_on, HOST` va de los procesos a los hosts en los que se ejecutan. direction admite forward (valor por defecto) y backward: partiendo de HOST, `smartscapeNodes HOST | traverse runs_on, PROCESS, direction: backward` recorre runs_on en sentido contrario y devuelve los procesos.',
        'traverse devuelve los nodos destino con un campo adicional, dt.traverse.history, un array de records con información del nodo de origen. Para conservar en ese historial campos del nodo de origen se usa el parámetro fieldsKeep: (`traverse runs_on, HOST, fieldsKeep: name`). nodeId indica el campo identificador del nodo de origen (id por defecto). Un comando fieldsKeep posterior solo ve los campos de los nodos destino.',
      ],
      code: 'smartscapeNodes PROCESS\n| traverse runs_on, HOST, fieldsKeep: name',
      codeNote: 'Devuelve nodos HOST; el name del PROCESS de origen queda en dt.traverse.history.',
      sourceRefs: [SMART],
    },
    {
      id: 'sup-dql-aggregation-functions',
      after: 'deep-dql-aggregation',
      title: 'Funciones de agregación y agrupación temporal',
      lead: 'La agregación correcta depende de qué representa cada fila.',
      paragraphs: [
        'summarize agrupa los registros con valores idénticos en los campos de by:{…} y calcula agregaciones por grupo. Si el campo de agrupación no existe en todos los registros, summarize añade un grupo null al resultado. Sin by:, summarize devuelve un único registro, incluso si no recibe ningún registro de entrada: en ese caso count() vale 0 y agregaciones como sum() valen null. summarize no tiene parámetro interval:; para agrupar por tiempo en formato tabla se usa by:{bin(timestamp, 1h)}, donde bin redondea hacia abajo al múltiplo del tamaño indicado.',
        'count() cuenta registros y no recibe condición. countIf(condición) cuenta los registros que cumplen la condición dentro de cada grupo, sin filtrar el resto, lo que permite calcular total y errores en la misma agregación. countDistinct es un alias de countDistinctApprox, que estima la cardinalidad de forma estocástica (algoritmo UltraLogLog); countDistinctExact calcula la cardinalidad exacta, hasta 1 millón de valores distintos. sum y avg trabajan con long, double o duration. percentile(expresión, percentil) devuelve el valor bajo el que queda ese porcentaje y revela colas que la media oculta; median equivale a percentile(expresión, 50) y takeFirst/takeLast devuelven el primer o el último valor.',
        'makeTimeseries construye series temporales a partir de los registros que ya están en el stream, por ejemplo logs filtrados, y admite interval: o bins:, by:, default: y nonempty:; toma el tiempo del campo timestamp (o start_time) salvo que se indique time:. Para agrupar por la hora del día, getHour(timestamp) extrae la hora: en 7 días produce 24 grupos, mientras que bin(timestamp, 1h) crea un grupo por cada hora real (168). getDayOfWeek devuelve el día de la semana (1 = lunes, 7 = domingo).',
        'Para mostrar el nombre de una entidad a partir de su ID, entityName(expresión) devuelve el nombre, por ejemplo `fieldsAdd entityName(dt.entity.host)`; renombrar el campo o convertirlo a string conserva el ID. La documentación de general functions sugiere usar getNodeName en lugar de entityName.',
      ],
      code: 'fetch logs, from:-2h\n| summarize total = count(), errors = countIf(loglevel == "ERROR"), by:{service.name}\n| fieldsAdd error_rate = errors * 100.0 / total',
      codeNote: 'countIf cuenta los ERROR de cada servicio sin perder el total, que filtrar antes eliminaría.',
      sourceRefs: [AGG, F_AGG, F_TIME, F_MATH, F_GEN],
    },
    {
      id: 'sup-dql-timeseries',
      after: 'sup-dql-aggregation-functions',
      title: 'timeseries en detalle y el comando metrics',
      lead: 'Una salida homogénea: mismas fechas, mismo intervalo, un array por agregación.',
      paragraphs: [
        'timeseries es un comando de inicio que combina carga, filtrado y agregación de métricas en una salida de series temporales. Admite varias agregaciones separadas por comas en el mismo comando (`timeseries cpu_avg = avg(dt.host.cpu.usage), cpu_max = max(dt.host.cpu.usage), interval:1h`), y todas comparten timeframe e interval. by:{dt.entity.host} devuelve una serie por valor de la dimensión. filter: aplica una condición sobre los registros de origen antes de la agregación (`timeseries http_503 = sum(http_requests), filter:{code == 503}`).',
        'La salida es homogénea: todas las series tienen el mismo inicio y fin, el mismo intervalo y el mismo número de elementos. Cada agregación es una columna de tipo array con un valor por time slot, y el resultado incluye además los campos timeframe e interval. Para obtener un único valor por serie se aplica una array function como arrayMax(cpu) al array, o el parámetro scalar:true de la agregación, que calcula un único valor para todo el timeframe.',
        'interval: fija la duración de cada time slot y bins: el número de slots; son excluyentes y una serie admite como máximo 1.500 time slots. shift: desplaza el timeframe (valores negativos hacia el pasado), útil para comparar con la semana anterior mediante append. Los slots sin datos valen null salvo que la agregación indique default: (`sum(http_requests, default:0)`). nonempty:true devuelve registros aunque no haya datos que coincidan, union:true combina las series con outer join en lugar del inner join por defecto y rollup: indica la agregación del rollup temporal.',
        'El comando metrics recupera series de métricas para explorar metric keys, dimension keys y valores de dimensión; no devuelve timestamps ni valores de series temporales, por eso no sirve para charting ni cálculos. Está limitado a los últimos diez días y a 100.000 metric series por consulta. Para analizar la evolución de una métrica se usa timeseries.',
      ],
      code: 'timeseries avail = avg(dt.host.disk.avail), by:{dt.entity.host}, from:-24h\n| append [\n  timeseries avail.7d = avg(dt.host.disk.avail), by:{dt.entity.host}, shift:-7d\n]',
      codeNote: 'shift:-7d desplaza el timeframe una semana al pasado para superponer el mismo periodo de la semana anterior.',
      sourceRefs: [METRIC, F_ARRAY],
    },
    {
      id: 'sup-dql-types-conversion',
      after: 'deep-dql-types-records',
      title: 'Acceso a records, identificadores y conversiones',
      lead: 'Corchetes para acceder, backticks para nombres especiales y to* para convertir.',
      paragraphs: [
        'DQL opera con datos strongly typed: las funciones y operadores aceptan solo los tipos declarados. Además de boolean, long, double, string, timestamp y duration, hay tipos como timeframe, ip address y UID, y los tipos complejos array y record.',
        'Los campos de un record se leen con corchetes: person[name], y los anidados con person[address][pcode]. Los elementos de un array se leen por posición empezando en 0: int_array[0] es el primero. Un timeframe expone sus límites con tf[start] y tf[end], y las time functions getStart(timeframe) y getEnd(timeframe) devuelven los mismos timestamps. Un punto no es un operador de acceso: tf.start o json_data.status se interpretan como nombres de campo que contienen un punto.',
        'Los nombres de campo que usan caracteres distintos de a-zA-Z0-9_. o que empiezan por un carácter distinto de a-zA-Z_ deben ir entre backticks, es decir, con un acento grave delante y otro detrás del nombre: un campo llamado http status (con espacio) se escribe en la consulta con un backtick antes de http y otro después de status, como muestra el bloque de código de este apartado. Entre comillas dobles sería un literal string, no un campo, y http_status sería otro campo distinto.',
        'Las funciones as* solo garantizan el tipo: asLong devuelve el valor si ya es long y null en otro caso, y asString devuelve el valor si es string y null en otro caso. Las funciones to* convierten: toLong convierte a long un valor de un tipo adecuado, como el string "1532", y toString devuelve la representación string de un valor. Por eso, para sumar bytes extraídos como string se usa sum(toLong(bytes)).',
        'Array functions útiles: arraySize(array) devuelve el número de elementos; arrayMax(array) el elemento máximo; arrayIndexOf(array, value) devuelve la posición (empezando en 0) del primer elemento igual al valor, o -1 si no está. No existen arrayContains ni arrayLength: la pertenencia se comprueba con in(value, array).',
      ],
      code: 'fetch logs\n| fields `http status`, `my host*`',
      codeNote: 'Cada nombre lleva un backtick (acento grave) delante y otro detrás; "http status" entre comillas dobles sería un string literal.',
      sourceRefs: [TYPES, REF, F_CONV, F_ARRAY, F_TIME, F_GEN],
    },
    {
      id: 'sup-dql-best-practices',
      after: 'deep-dql-performance',
      title: 'Buenas prácticas oficiales de DQL',
      lead: 'Menos datos leídos, menos registros procesados y el orden al final.',
      paragraphs: [
        'La guía de buenas prácticas propone este orden: filtrar primero para reducir registros (mejor con filtros inclusivos que con negaciones), seleccionar pronto los campos con fields, fieldsKeep o fieldsRemove, procesar los datos, agregar con summarize o makeTimeseries y ordenar al final. Ordenar justo después de fetch empeora el rendimiento, y join y lookup deben evitarse para filtrar salvo que sean necesarios.',
        'Para reducir los datos leídos, acota el timeframe con el selector o directamente en fetch (`fetch bizevents, from:-10m`), limita los buckets (`fetch logs, bucket:{"default_logs", "logs_365_*"}`) y, si basta una aproximación, usa samplingRatio (`fetch spans, samplingRatio:100`); scanLimitGBytes (`fetch logs, scanLimitGBytes:100`) limita el escaneo. Filtrar por timestamp después de leer siete días no reduce lo leído, y samplingRatio da resultados aproximados, incompatibles con un conteo exacto.',
        'Filtra directamente sobre el campo: en lugar de `filter matchesValue(lower(k8s.namespace.name), "astro*")`, usa `filter k8s.namespace.name ~ "astro*"`. Recuerda que cada comando procesa la salida del anterior: un limit antes de summarize hace que la agregación cuente solo los registros que limit deja pasar. Para quedarte con los N grupos mayores, filtra, agrega con summarize, ordena el resultado y aplica limit al final.',
      ],
      bullets: [
        '1. filter: reduce registros cuanto antes.',
        '2. fields, fieldsKeep o fieldsRemove: selecciona pronto los campos.',
        '3. Procesa los datos.',
        '4. summarize o makeTimeseries: agrega.',
        '5. sort: ordena al final.',
      ],
      code: 'fetch logs, from:-24h\n| filter loglevel == "ERROR"\n| summarize errors = count(), by:{service.name}\n| sort errors desc\n| limit 5',
      codeNote: 'Top 5 de servicios por errores: filtrar, contar todos los grupos, ordenar y solo entonces limitar.',
      sourceRefs: [BEST, DATASRC],
    },
  ],
  precision: {
    corrections: [
      {
        topic: 'Filtros Temporales Explícitos',
        find: 'En DQL se define el rango temporal con `from:now()-2h`, `from:now()-7d` o `to:now()`;',
        replace: 'En DQL se define el rango temporal en el comando de inicio con from: (y, opcionalmente, to:), por ejemplo `from:now()-2h, to:now()`, o con timeframe:;',
      },
      {
        topic: 'Funciones sobre Arrays en DQL',
        find: 'El operador `expand` es imprescindible cuando una entidad contiene una lista de subelementos que deseas filtrar.',
        replace: 'El comando expand es necesario cuando quieres una fila por cada elemento del array; para comprobar pertenencia basta in(value, array).',
      },
    ],
    reason: 'to:now() por sí solo no fija la ventana temporal; expand es un comando (structuring command) y no hace falta para filtrar por pertenencia (auditoría final).',
  },
}
