import type { LessonSupplement } from './types'

const doc = (title: string, url: string) => ({ title, url, kind: 'official-docs' as const })

export const businessSupplement: LessonSupplement = {
  moduleId: 'business-dem',
  extend: {
    'deep-rum-session-semantics': {
      paragraphs: [
        'Las dos tablas se relacionan con dt.rum.session.id: cada user event lleva el identificador de su sesión, el campo documentado para unir user events con user sessions en DQL. Por eso contar valores distintos de dt.rum.session.id en user.events (countDistinct) da un recuento válido de sesiones; lo que solo está en user.sessions es lo que se calcula por sesión, como la duración, el bounce y las session properties.',
      ],
      corrections: [
        { find: 'Intentar calcular visitas únicas consultando solo esta tabla', replace: 'Buscar la duración o el bounce de la sesión en esta tabla (están en user.sessions)' },
        {
          find: 'El ciclo de vida de una sesión web RUM se rige por reglas estrictas de finalización: se cierra tras 30 minutos continuados de inactividad del usuario, al cerrar el navegador o pestaña, al alcanzar un tiempo máximo absoluto de 6 horas continuas, o de forma programática mediante la llamada a `dtrum.endSession()` en la JavaScript API.',
          replace: 'En web frontends, una user session termina tras 30 minutos de inactividad del navegador, al cerrar el navegador, al alcanzar 6 horas de duración o de forma programática con `dtrum.endSession()` de la RUM JavaScript API; son las condiciones que documenta la página User sessions in web frontends, tanto en la nueva experiencia RUM como en RUM Classic. El modelo de datos de la nueva experiencia RUM las resume de forma genérica (una sesión termina tras un periodo de inactividad o al alcanzar la duración máxima), y en Grail la tabla user.sessions guarda el motivo en el campo end_reason, cuyos valores documentados son timeout (la sesión expiró), duration (alcanzó la duración máxima) y synthetic_execution_finished (terminó una ejecución sintética).',
        },
      ],
      comparisonRows: [
        ['Campo end_reason (user.sessions)', 'Motivo de fin registrado: timeout, duration o synthetic_execution_finished', 'Buscar en end_reason un valor propio para el cierre del navegador o para dtrum.endSession()'],
      ],
      reason: 'La documentación de user sessions web cita el cierre del navegador, no el de una pestaña (G-063, G-064, G-065). v4: dt.rum.session.id permite contar sesiones desde user.events (R-BIZ-27), así que no es un error de examen. v5: se aclara a qué nivel aplica cada regla: las cuatro condiciones de web frontends (documentadas igual en la nueva experiencia RUM y en RUM Classic) frente a los valores de end_reason de user.sessions.',
    },
    'deep-synthetic-semantics': {
      corrections: [
        { find: 'Esto detiene el monitor inmediatamente y marca la ejecución como fallida con la causa documentada en el reporte.', replace: 'Esto marca el paso y la ejecución del monitor como fallidos, con ese mensaje como motivo visible en los resultados.' },
        { find: 'api.fail("mensaje"): detiene y marca el test sintético como fallido en código JavaScript.', replace: 'api.fail("mensaje"): marca como fallida la ejecución desde un paso JavaScript, con un motivo legible.' },
      ],
      reason: 'Precisión sobre api.fail(): la doc indica que marca la ejecución como fallida (D-014).',
    },
    'journeys': {
      corrections: [
        { find: 'DQL consulta Business Events en Notebooks, Logs and event viewer o Dashboards.', replace: 'DQL consulta Business Events en Notebooks, Dashboards o apps como Business Flow.' },
      ],
      reason: 'v4: el Logs and events viewer es de Dynatrace Classic; en Latest los Business Events se exploran con DQL en Notebooks, Dashboards y apps como Business Flow.',
    },
  },
  sections: [
    {
      id: 'sup-rum-data-model',
      after: 'deep-rum-session-semantics',
      title: 'Modelo de datos RUM: user events, views y user actions',
      lead: 'En la nueva experiencia RUM todo se registra como user events; las user actions y las sesiones los relacionan.',
      paragraphs: [
        'RUM captura los datos como user events, que se guardan en la tabla user.events con atributos básicos y contexto como sistema operativo, geolocalización, dispositivo y navegador. Las user sessions, en la tabla user.sessions, resumen los user events del mismo usuario dentro de un periodo limitado. Hay varias clases de user events: los navigation events describen la transición de una view a otra o de una page a otra; los page summary y view summary agregan métricas de rendimiento y recuentos de errores; los user interaction events recogen clics, scroll o mouseover en web y toques, gestos o rotaciones en mobile; los request events describen llamadas HTTP con URL (url.full), método (http.request.method), código de estado (http.response.status_code) y tiempos W3C; y los error events recogen requests fallidas, excepciones no capturadas, violaciones CSP en web, y crashes y ANR en mobile.',
        'Las pages solo existen en web y corresponden a cargas completas de documento HTML. Una view es el contenido que se muestra al usuario en cada momento, en web y en mobile; en web una nueva view puede aparecer sin una carga completa de página, como ocurre al cambiar de pantalla en una SPA.',
        'Una user action es una interacción significativa iniciada por el usuario que conecta los eventos relacionados: interacciones, requests, navegaciones y errores. Su duración va desde la interacción hasta el resultado visible para el usuario, aunque intervengan varias llamadas. Los eventos de una misma acción se agrupan con user_action.instance_id, un identificador generado para cada instancia, y user_action.name describe la acción (por ejemplo, click on order on /cart). A diferencia de RUM Classic, las interacciones se capturan con independencia de que lancen una request.',
        'Las propiedades personalizadas tienen dos ámbitos: las event properties describen un user event individual y se guardan en el namespace event_properties; las session properties se agregan a nivel de sesión en el namespace session_properties de user.sessions. Las event properties se recogen con capture rules (solo web) o con las RUM APIs; las session properties, con las RUM APIs o agregándolas en OpenPipeline a partir de event properties durante la ingesta. El user identifier de la sesión se puebla con la RUM API o enriqueciéndolo en OpenPipeline a partir de una event property.',
      ],
      comparison: {
        headers: ['Concepto', 'Qué representa', 'Campo o tabla'],
        rows: [
          ['Navigation', 'Transición entre views o pages', 'user.events'],
          ['Request', 'Llamada HTTP con URL, método, status y W3C timing', 'url.full, http.request.method, http.response.status_code'],
          ['Error', 'Request fallida, excepción, CSP violation, crash o ANR', 'user.events (characteristics.has_error)'],
          ['User action', 'Interacción significativa y sus eventos relacionados', 'user_action.instance_id, user_action.name'],
          ['Event property', 'Dato de un user event individual', 'event_properties'],
          ['Session property', 'Dato agregado a la sesión', 'session_properties en user.sessions'],
        ],
      },
      warning: 'characteristics.has_error vale true cuando el user event contiene al menos un error; contar valores distintos de dt.rum.session.id sobre esos eventos da sesiones con al menos un error, no el total de sesiones.',
      sourceRefs: [
        doc('RUM data model', 'https://docs.dynatrace.com/docs/observe/digital-experience/new-rum-experience/concepts/data-model'),
        doc('Real User Monitoring semantic dictionary', 'https://docs.dynatrace.com/docs/semantic-dictionary/model/rum'),
        doc('Request user events', 'https://docs.dynatrace.com/docs/semantic-dictionary/model/rum/user-events/requests'),
      ],
    },
    {
      id: 'sup-rum-sessions-web',
      after: 'sup-rum-data-model',
      title: 'User sessions web: cierre, bounce, duración e identificadores',
      lead: 'Una user session resume los user events del mismo usuario dentro de un periodo limitado.',
      paragraphs: [
        'Una user session web termina tras 30 minutos de inactividad del navegador, cuando el usuario cierra el navegador, cuando la duración de la sesión alcanza 6 horas o de forma programática con dtrum.endSession(), que termina inmediatamente la sesión actual. Otros métodos de la RUM JavaScript API tienen funciones distintas: dtrum.identifyUser() asigna el user tag que identifica a un usuario entre navegadores, dispositivos y sesiones; dtrum.leaveAction() cierra una acción creada con enterAction; dtrum.disableSessionReplay() desactiva Session Replay.',
        'Una sesión con una sola user action o navegación se marca como bounced. Para que una sesión se registre debe capturarse al menos un evento que indique actividad del usuario: una user action o una navegación. La duración de la sesión es el tiempo entre el primer evento y la última user action o navegación; la extended duration abarca todos los eventos, incluidas las requests del navegador posteriores a que el usuario deje de usar la página. Una sesión puede recorrer varios frontends.',
        'dt.rum.session.id identifica la sesión a la que pertenece cada evento; dt.rum.instance.id identifica el navegador del usuario y, salvo que se desactive Use persistent cookies for user tracking, se guarda en una cookie persistente, por lo que sirve para reconocer usuarios recurrentes entre sesiones. RUM no impone ningún límite al número de user actions o eventos por sesión; RUM Classic tenía un límite de 200 user actions por sesión.',
      ],
      bullets: [
        'Inactividad del navegador: 30 minutos.',
        'Duración máxima: 6 horas.',
        'Bounce: una sola user action o navegación.',
        'dt.rum.session.id: sesión; dt.rum.instance.id: navegador, persistente entre sesiones.',
      ],
      sourceRefs: [
        doc('User sessions in web frontends', 'https://docs.dynatrace.com/docs/observe/digital-experience/new-rum-experience/web-frontends/concepts/user-sessions-web'),
        doc('RUM data model', 'https://docs.dynatrace.com/docs/observe/digital-experience/new-rum-experience/concepts/data-model'),
      ],
    },
    {
      id: 'sup-rum-classic',
      after: 'sup-rum-sessions-web',
      title: 'RUM Classic: tipos de user action, Apdex y key user actions',
      lead: 'Algunas preguntas usan todavía el modelo Classic; conviene reconocer sus conceptos propios.',
      paragraphs: [
        'En RUM Classic hay tres tipos de user action. Una load action es una carga real de página en el navegador, por ejemplo al introducir una URL, durante la que se cargan HTML, CSS e imágenes. Una XHR action se produce cuando la interacción del usuario lanza XMLHttpRequests o llamadas fetch(); Dynatrace vigila las peticiones en cascada y las modificaciones del DOM antes de cerrar la acción. Una custom action la define el equipo de desarrollo con la RUM JavaScript API para medir interacciones que la detección automática no recoge.',
        'Apdex valora la satisfacción comparando la duración de cada user action con umbrales configurables (Satisfactory, Tolerable y Frustrating), con un umbral global de 3 segundos; las acciones con errores JavaScript se valoran como Frustrated. Las interacciones importantes para el negocio, como signup, checkout o búsqueda, pueden marcarse como key user actions y recibir su propio umbral Apdex, distinto del global de la aplicación.',
      ],
      bullets: [
        'Load action: carga de página completa.',
        'XHR action: interacción que lanza XHR o fetch() sin recargar la página.',
        'Custom action: definida con la RUM JavaScript API.',
        'Key user action: Apdex propio para una acción crítica.',
      ],
      sourceRefs: [
        doc('User actions in RUM Classic', 'https://docs.dynatrace.com/docs/observe/digital-experience/rum-classic/rum-concepts/user-actions'),
        doc('Apdex ratings', 'https://docs.dynatrace.com/docs/observe/digital-experience/rum-classic/rum-concepts/scores-and-ratings/apdex-ratings'),
      ],
    },
    {
      id: 'sup-synthetic-monitors',
      after: 'deep-synthetic-semantics',
      title: 'Tipos de monitor, locations y control de ejecuciones',
      lead: 'Synthetic ofrece tres tipos de monitor y varias formas de decidir cuándo se ejecutan y cuándo alertan.',
      paragraphs: [
        'Un HTTP monitor consiste en una o varias HTTP requests y funciona sin navegador; su tiempo de respuesta es la suma de DNS lookup time, TCP connect time, TLS handshake time, Waiting y Download. Un browser monitor usa un navegador: el single-URL monitor prueba una sola página y el clickpath reproduce un recorrido de usuario con varios pasos. Los NAM monitors comprueban la disponibilidad de hosts, dispositivos y servicios sin interfaz HTTP mediante checks ICMP, TCP y DNS, con frecuencias de 1 min a 1 h, y se ejecutan solo desde private locations.',
        'Las private Synthetic locations ejecutan HTTP, browser y NAM monitors dentro de redes corporativas sin acceso público. Pueden ser classic locations, sobre ActiveGates con Synthetic habilitado, o containerized locations sobre Kubernetes u OpenShift. Las public locations gestionadas por Dynatrace no alcanzan recursos internos.',
        'Un browser monitor se programa cada 5, 10, 15 o 30 minutos, o cada 1, 2 o 4 horas, o con la frecuencia On demand only. Una on-demand execution lanza el monitor al momento, fuera de su programación, en las locations elegidas, desde la UI, por API o desde un pipeline de CI/CD. Su processing mode decide cómo cuenta: Standard (por defecto) cuenta para disponibilidad, rendimiento y detección de Problems; Disable problem detection cuenta para disponibilidad y rendimiento, pero no para Problems; con Execution details only, las ejecuciones no cuentan en las estadísticas de disponibilidad y rendimiento ni en la detección de Problems.',
        'El outage handling define cuándo se abre un Problem: Global outage se dispara cuando fallan todas las locations; Local outage solo está disponible con al menos dos locations y alerta con fallos consecutivos en una o varias locations. El automatic retry está activado por defecto: una ejecución fallida se reintenta una vez de inmediato y solo cuenta el resultado del segundo intento, para evitar falsos positivos. Una maintenance window con Disable synthetic monitor execution impide que se ejecuten los HTTP y browser monitors de su scope. Por seguridad, Dynatrace bloquea que los monitores envíen requests a localhost.',
      ],
      comparison: {
        headers: ['Necesidad', 'Mecanismo', 'Detalle'],
        rows: [
          ['Probar endpoints sin navegador', 'HTTP monitor', 'Una o varias requests; DNS, TCP, TLS, Waiting, Download'],
          ['Recorrido de usuario en navegador', 'Browser clickpath', 'Pasos Navigate, Click, Keystroke…'],
          ['Host o servicio sin HTTP', 'NAM monitor', 'ICMP, TCP y DNS desde private locations'],
          ['Red interna', 'Private location', 'ActiveGate con Synthetic o Kubernetes/OpenShift'],
          ['Validar un despliegue', 'On-demand execution', 'UI o API; processing mode elegible'],
          ['Mantenimiento planificado', 'Maintenance window', 'Disable synthetic monitor execution'],
        ],
      },
      sourceRefs: [
        doc('Create and configure browser monitors', 'https://docs.dynatrace.com/docs/observe/digital-experience/synthetic/synthetic-app/create-configure-browser-monitors'),
        doc('HTTP monitors in the Synthetic app', 'https://docs.dynatrace.com/docs/observe/digital-experience/synthetic/synthetic-app/synthetic-details-for-http-monitors'),
        doc('Create a NAM monitor', 'https://docs.dynatrace.com/docs/observe/digital-experience/synthetic/synthetic-app/create-a-nam-monitor-synthetic-app'),
        doc('Private Synthetic locations', 'https://docs.dynatrace.com/docs/observe/digital-experience/synthetic/synthetic-app/private-locations'),
        doc('On-demand executions', 'https://docs.dynatrace.com/docs/observe/digital-experience/synthetic/synthetic-app/on-demand-executions'),
        doc('Define a maintenance window', 'https://docs.dynatrace.com/docs/analyze-explore-automate/notifications-and-alerting/maintenance-windows/define-maintenance-window'),
      ],
    },
    {
      id: 'sup-clickpath-steps',
      after: 'sup-synthetic-monitors',
      title: 'Pasos del clickpath, esperas, validaciones y JavaScript API',
      lead: 'Cada paso del clickpath tiene un propósito; elegir bien el paso, el locator y la espera evita falsos fallos.',
      paragraphs: [
        'Los tipos de paso son Navigate, que simula escribir una URL en la barra de direcciones y cargar la página; Click, que define dónde se hace clic; Tap, su equivalente mobile; Keystroke, que captura el texto escrito en un campo; Select option, que registra la posición (Index, desde 0) y el valor de la opción elegida en una lista; JavaScript, que ejecuta fragmentos de código; y Cookie, que fija estado del navegador. Todo clickpath necesita al menos un paso Navigate y solo los pasos JavaScript pueden precederlo. En escritorio, pulsar un enlace dentro de la página crea un paso Click, no Navigate.',
        'Keystroke guarda por defecto el texto como plain text; las contraseñas deben guardarse en Credential Vault, como username/password o token, y referenciarse como credentials. Los pasos que actúan sobre un elemento (Click, Tap, Keystroke, Select option) usan locators DOM o CSS que se evalúan en orden; si un cambio de frontend modifica el DOM, el locator deja de encontrar el elemento.',
        'La wait strategy decide cuándo se considera terminado un paso: No condition, Page loads completely, A specific amount of time has passed, Any of the elements from the next step appears, Network activity is complete o The next step begins. Page loads completely espera a que termine la actividad de red tras la carga de la página; Any of the elements from the next step appears espera a que aparezca, según su locator CSS o DOM, un elemento del paso siguiente, lo que encaja cuando un script lo inserta tarde. Las content validations comprueban Visible text, un Element que contiene un texto concreto o un texto en el DOM o en cualquier recurso; si no se cumple el criterio, el paso falla y la ejecución se aborta. Cada paso puede tener además un umbral de rendimiento que genera un Problem al superarse. El browser monitor también permite bloquear requests por URL completa o patrón, por ejemplo http:*://*/*.png.',
        'En un paso JavaScript, api.fail(message) marca la ejecución como fallida con ese motivo; api.finish() completa el paso JavaScript para que continúe el siguiente; api.skipNextSyntheticEvent() omite el paso siguiente; api.setValue(key, value) y api.getValue(key) guardan y recuperan valores entre pasos; y api.getCredential(id, type) lee un credential de Credential Vault.',
      ],
      comparison: {
        headers: ['Necesidad', 'Paso o ajuste', 'No confundir con'],
        rows: [
          ['Abrir una URL', 'Navigate', 'Click en un enlace (escritorio)'],
          ['Escribir una contraseña', 'Keystroke con credentials de Credential Vault', 'Keystroke en plain text'],
          ['Elegir en un desplegable', 'Select option (Index y valor)', 'Click o Keystroke'],
          ['Esperar a un elemento tardío', 'Any of the elements from the next step appears', 'Aumentar el umbral de rendimiento'],
          ['Exigir un texto en la página', 'Content validation', 'Wait strategy'],
          ['Fallar por una regla de negocio', 'api.fail(message)', 'api.finish()'],
        ],
      },
      sourceRefs: [
        doc('Browser clickpath steps', 'https://docs.dynatrace.com/docs/observe/digital-experience/synthetic/synthetic-app/create-configure-browser-monitors/browser-clickpath-steps'),
        doc('Steps: waiting time, validation and thresholds', 'https://docs.dynatrace.com/docs/observe/digital-experience/synthetic/synthetic-app/create-configure-browser-monitors/steps-waiting-time-validation-thresholds'),
        doc('Create and configure browser monitors', 'https://docs.dynatrace.com/docs/observe/digital-experience/synthetic/synthetic-app/create-configure-browser-monitors'),
      ],
    },
    {
      id: 'sup-bizevents-api',
      after: 'deep-business-capture',
      title: 'Business events API y Workflows',
      lead: 'Las fuentes externas envían Business Events por API; un Workflow puede generarlos con una acción.',
      paragraphs: [
        'Los sistemas externos sin OneAgent, como un ERP o una pasarela de pago, envían Business Events por POST a /api/v2/bizevents/ingest. El endpoint admite JSON puro (application/json), CloudEvents (application/cloudevent+json o application/cloudevents+json) y lotes de CloudEvents (application/cloudevents-batch+json). La Business events API limita el payload a 5 MB por petición. Con un access token Classic, la autenticación exige el scope Ingest bizevents (bizevents.ingest); con un platform token, el scope openpipeline:bizevents:ingest. events.ingest es el scope de los eventos genéricos de /api/v2/events/ingest.',
        'En CloudEvents, source se convierte en event.provider, type en event.type e id en event.id. En JSON puro no hay campos obligatorios: si faltan, event.provider y event.type toman el valor Unknown y event.category el valor Other. El campo event.kind se fija siempre en BIZ_EVENT, sea cual sea el valor recibido. Dynatrace guarda los campos de primer nivel como campos de primer nivel en Grail, pero convierte los objetos JSON complejos (por ejemplo, un objeto customer anidado) en strings.',
        'Un Workflow puede generar Business Events con la acción Ingest business event, por ejemplo para ingerir a diario tipos de cambio de divisa o datos de un sistema no monitorizado. La acción necesita el permiso storage:events:write en los authorization settings del Workflow.',
      ],
      code: 'POST https://{environment-id}.live.dynatrace.com/api/v2/bizevents/ingest\nContent-Type: application/cloudevent+json\nAuthorization: Api-Token <token con bizevents.ingest>\n\n{ "specversion": "1.0", "source": "erp.billing", "type": "com.acme.invoice.created", "id": "inv-7781", "data": { "amount": 129.9 } }',
      codeNote: 'source → event.provider, type → event.type, id → event.id.',
      sourceRefs: [
        doc('Business events API (external sources)', 'https://docs.dynatrace.com/docs/observe/business-observability/bo-events-capturing/bo-events-capturing-external-sources'),
        doc('Business event enrichment', 'https://docs.dynatrace.com/docs/observe/business-observability/bo-events-enrichment'),
        doc('Business events from Workflows', 'https://docs.dynatrace.com/docs/observe/business-observability/bo-events-capturing/bo-events-capturing-workflows-overview'),
      ],
    },
    {
      id: 'sup-bizevents-capture-sources',
      after: 'sup-bizevents-api',
      title: 'Capture rules, RUM y OpenPipeline como fuentes de Business Events',
      lead: 'Sin tocar el código se pueden obtener Business Events de requests de servicios, de logs y de spans.',
      paragraphs: [
        'OneAgent captura Business Events de servicios backend (Java, .NET, Node.js, Go y webservers como Apache, NGINX o IIS) con capture rules, sin modificar el código. Cada regla define event.provider, event.type y, opcionalmente, event.category; los triggers indican cuándo se crea el evento (path, método, headers, query, body o status de la request) y se combinan con lógica AND, de modo que deben cumplirse todas las condiciones; los data fields extraen atributos del payload JSON o XML, como accountId o amount. Hay que reiniciar el proceso de la aplicación antes de poder capturar Business Events de él, y la captura de request/response body está limitada por defecto a unos 64 KiB.',
        'En el frontend, dynatrace.sendBizEvent() envía Business Events desde la RUM JavaScript API. Los Business Events de RUM solo se capturan en sesiones monitorizadas: si el RUM JavaScript está desactivado, por un método específico o por cost and traffic control, esos eventos no se reportan. Los Business Events de RUM se enriquecen con dispositivo, navegador, aplicación, geolocalización (geo.country.name, geo.city.name…) y campos dt.rum.* como dt.rum.session.id; los capturados por OneAgent reciben en cambio dt.entity.host, dt.entity.process_group_instance, trace_id y span_id.',
        'Para logs y spans ya ingeridos se añade un procesador Business event en un pipeline de OpenPipeline, con event.type y event.provider estáticos y una condición de coincidencia. En el caso de los spans hay que configurar además dynamic routing para que los spans correctos lleguen a ese pipeline, por ejemplo con matchesPhrase(service.name, "payment.service").',
      ],
      bullets: [
        'Las capture rules de OneAgent y el procesador Business event de OpenPipeline obtienen Business Events sin modificar el código de la aplicación.',
        'dynatrace.sendBizEvent() y la Business events API requieren añadir llamadas en el código que emite el evento.',
      ],
      comparison: {
        headers: ['Origen', 'Mecanismo', 'Requisito clave'],
        rows: [
          ['Servicio con OneAgent', 'Capture rules', 'Reiniciar el proceso; triggers con AND'],
          ['Frontend web o mobile', 'dynatrace.sendBizEvent()', 'Solo en sesiones monitorizadas'],
          ['Logs', 'Procesador Business event en OpenPipeline', 'Pipeline de logs con el procesador'],
          ['Spans', 'Procesador Business event en OpenPipeline', 'Dynamic routing hacia ese pipeline'],
          ['Sistema externo', '/api/v2/bizevents/ingest', 'bizevents.ingest; 5 MB por petición'],
        ],
      },
      sourceRefs: [
        doc('Get business events via OneAgent', 'https://docs.dynatrace.com/docs/observe/business-observability/bo-events-capturing/bo-events-capturing-oneagent'),
        doc('Business events from web and mobile RUM', 'https://docs.dynatrace.com/docs/observe/business-observability/bo-events-capturing/web-and-mobile-rum'),
        doc('Business event enrichment', 'https://docs.dynatrace.com/docs/observe/business-observability/bo-events-enrichment'),
        doc('Business events from logs and spans', 'https://docs.dynatrace.com/docs/observe/business-observability/bo-events-capturing/bo-events-capturing-logs-and-spans'),
      ],
    },
    {
      id: 'sup-business-flow',
      after: 'deep-business-journeys',
      title: 'Business Flow: correlation ID, KPI y entidad BIZ_FLOW',
      lead: 'Business Flow modela los pasos de un proceso con Business Events y los une por un identificador común.',
      paragraphs: [
        'La app Business Flow define los pasos de un proceso de negocio (por ejemplo Place order y Ship order) a partir de Business Events y permite analizar su avance, sus business exceptions y un KPI. Los eventos de distintos pasos se unen como una instancia del flujo mediante un correlation ID: el correlation ID por defecto se aplica a todos los pasos, y los correlation IDs locales opcionales lo sobrescriben en los pasos donde el identificador tiene otro nombre. En cada paso se pueden designar eventos como Business exception, por ejemplo un evento de falta de stock.',
        'Al mapear el KPI del flujo, como el importe de cada pedido, solo se muestran los atributos de tipo long o double. Para ingerir la configuración como entidad BIZ_FLOW en Smartscape on Grail hace falta un flujo de al menos dos pasos con un correlation ID; así el flujo se relaciona con entidades de topología y la app Problems puede mostrar el proceso de negocio afectado y abrirlo en modo de investigación. Si se seleccionan buckets para una configuración, ese alcance se aplica a las consultas del modo de edición (selección de event types), a las consultas de análisis y al DQL de Anomaly Detection de las alertas KPI.',
      ],
      bullets: [
        'Correlation ID por defecto: se aplica a todos los pasos.',
        'Correlation ID local: sobrescribe el valor por defecto en un paso.',
        'KPI: solo atributos long o double.',
        'BIZ_FLOW: al menos dos pasos y un correlation ID.',
      ],
      sourceRefs: [
        doc('Set up Business Flow', 'https://docs.dynatrace.com/docs/observe/business-observability/business-flow/set-up-business-flow'),
      ],
    },
    {
      id: 'sup-bizevents-governance',
      after: 'business-quality',
      title: 'Business-grade data, metadatos, buckets y privacidad',
      lead: 'La definición oficial de business-grade data y la retención en Grail condicionan cómo se diseña el almacenamiento.',
      paragraphs: [
        'La documentación define business-grade data con nueve rasgos: complete (todos los eventos se capturan sin sampling), fully accessible (se consultan sin extrapolación), real-time (los eventos están disponibles inmediatamente después de producirse), unconstrained (sin límite al número de eventos), granular (los eventos no se agregan con el tiempo), long-term (retención de hasta diez años), topology-aware (se guardan con contexto de topología), available from multiple sources (OneAgent, RUM, logs y fuentes externas) y unified (en un único almacén, Grail, consultable con un solo lenguaje de consulta). Sus metadatos son event.provider, obligatorio, que indica la fuente del evento (el componente o sistema que lo generó); event.type, obligatorio, el identificador único del tipo de evento; y event.category, opcional, una categorización estándar basada en ITIL.',
        'Los Business Events se guardan por defecto en el bucket default_bizevents, con 35 días de retención, y se consultan con fetch bizevents; los user events de RUM van al bucket default_user_events (también 35 días) y se consultan en user.events. default_logs retiene 35 días y default_spans 10 días. Los buckets custom admiten retenciones de 1 a 3657 días (unos diez años) y el procesador Bucket assignment de OpenPipeline enruta los registros elegidos a ellos.',
        'Si un dato sensible, como el email de un cliente, no es necesario para el análisis, lo correcto es no capturarlo en la capture rule o editarlo y enmascararlo en la etapa de processing de OpenPipeline antes de que se almacene. Limitar quién ve un Dashboard o filtrarlo en DQL deja el dato guardado en Grail.',
      ],
      sourceRefs: [
        doc('Basic concepts of Business Observability', 'https://docs.dynatrace.com/docs/observe/business-observability/bo-basic-concepts'),
        doc('Organize data in Grail', 'https://docs.dynatrace.com/docs/platform/grail/organize-data'),
        doc('Processing in OpenPipeline', 'https://docs.dynatrace.com/docs/platform/openpipeline/concepts/processing'),
      ],
    },
  ],
  precision: {
    corrections: [
      {
        topic: 'Tablas DEM en Grail: user.events vs user.sessions',
        find: 'Consultar duraciones y recuentos de visita requiere consultar `user.sessions`; acciones puntuales van a `user.events`.',
        replace: 'La duración, el bounce y las session properties están en `user.sessions`; los eventos individuales, en `user.events`, donde `dt.rum.session.id` permite contar sesiones o unir ambas tablas.',
      },
      {
        topic: 'Session lifecycle',
        find: 'En web RUM, una session termina tras 30 minutos de inactividad, al cerrar el navegador, al llegar a 6 horas o con “dtrum.endSession()”.',
        replace: 'En web frontends (nueva experiencia RUM y RUM Classic), una session termina tras 30 minutos de inactividad, al cerrar el navegador, al llegar a 6 horas o con “dtrum.endSession()”. En Grail, user.sessions registra el motivo en end_reason: timeout, duration o synthetic_execution_finished.',
      },
    ],
    reason: 'v5: Session lifecycle distingue las condiciones de fin de web frontends del campo end_reason de user.sessions. v4: los recuentos de sesiones también se obtienen desde user.events con countDistinct(dt.rum.session.id), el campo documentado para unir user events y user sessions (R-BIZ-27).',
  },
}
