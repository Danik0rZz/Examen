import type { Draft } from './bank-core'

export const bankA: Draft[] = [
  {
    "id": "A-001",
    "source": "problems",
    "objective": "problem-impact",
    "bucket": "scenario",
    "difficulty": "intermediate",
    "prompt": "Un Problem afecta al frontend de checkout y a dos servicios. Necesitas distinguir causa propuesta de alcance del incidente. ¿Qué vista aporta cada dato?",
    "choices": [
      "Root cause indica la entidad causal propuesta; Impact enumera las entidades afectadas.",
      "Root cause enumera los servicios degradados; Impact calcula la prioridad del Problem.",
      "Impact muestra sólo la entidad inicialmente alertada; Root cause incluye todas las entidades relacionadas.",
      "Root cause presenta la primera entidad afectada cronológicamente; Impact muestra únicamente usuarios finales."
    ],
    "correct": [
      0
    ],
    "explanation": "Problems separa entidades impactadas de la causa identificada y muestra la ruta de resolución."
  },
  {
    "id": "A-002",
    "source": "problems",
    "objective": "resolution-path",
    "bucket": "precision",
    "difficulty": "advanced",
    "prompt": "En el Visual resolution path, una entidad aparece en gris junto a varios servicios degradados. ¿Qué interpretación es correcta?",
    "choices": [
      "Es una entidad relacionada usada en el análisis, sin impacto directo detectado.",
      "Es una entidad afectada cuya señal aún no cumple el umbral de alerta.",
      "Es una entidad incluida en la topología, pero su estado no permite inferir si está impactada.",
      "Es la entidad causal propuesta, a la espera de validación con los eventos correlacionados."
    ],
    "correct": [
      0
    ],
    "explanation": "Los nodos grises representan entidades relacionadas que no figuran como impactadas directamente."
  },
  {
    "id": "A-003",
    "source": "platform",
    "objective": "grail-organization",
    "bucket": "knowledge",
    "difficulty": "intermediate",
    "prompt": "Una consulta fetch logs debe leer registros repartidos entre el bucket predeterminado y uno personalizado. ¿Qué representa la tabla logs?",
    "choices": [
      "La vista de todos los registros de tipo log de sus buckets accesibles.",
      "Una tabla lógica que consulta sólo el bucket de logs configurado como predeterminado.",
      "Un conjunto de registros que requiere nombrar explícitamente cada bucket en todo fetch.",
      "Una vista física cuya retención es independiente de la de los buckets que contiene."
    ],
    "correct": [
      0
    ],
    "explanation": "En Grail, las tablas agrupan registros por tipo y un fetch de la tabla abarca los buckets correspondientes autorizados."
  },
  {
    "id": "A-004",
    "source": "platform",
    "objective": "bucket-retention",
    "bucket": "scenario",
    "difficulty": "intermediate",
    "prompt": "Un equipo necesita retener un subconjunto de logs más tiempo que el resto. ¿Qué decisión de almacenamiento responde directamente a ese requisito?",
    "choices": [
      "Crear un bucket de logs con retención adecuada y asignar allí esos registros.",
      "Definir un timeframe mayor en la consulta DQL usada por todos los analistas.",
      "Crear una tabla de logs adicional y consultar únicamente esa tabla.",
      "Asignar una política de retención distinta al dashboard que consulta los logs."
    ],
    "correct": [
      0
    ],
    "explanation": "La retención se configura en el bucket; una consulta no prolonga la vida de los datos."
  },
  {
    "id": "A-005",
    "source": "smartscape",
    "objective": "topology-relations",
    "bucket": "scenario",
    "difficulty": "intermediate",
    "prompt": "Una degradación se observa en un servicio y necesitas seguir la dependencia hacia otro servicio y el proceso que lo ejecuta. ¿Qué información buscas en Smartscape?",
    "choices": [
      "Entidades y relaciones topológicas entre servicios, procesos y hosts.",
      "La secuencia temporal de todos los Davis events del servicio, sin relaciones entre entidades.",
      "Las relaciones entre servicios, pero no los procesos o hosts que los alojan.",
      "La lista de procesos con sus métricas, sin la relación de dependencia entre servicios."
    ],
    "correct": [
      0
    ],
    "explanation": "Smartscape modela entidades y relaciones para navegar dependencias técnicas."
  },
  {
    "id": "A-006",
    "source": "modes",
    "objective": "infra-injection",
    "bucket": "precision",
    "difficulty": "advanced",
    "prompt": "Un host Java está en Infrastructure mode. Aparecen métricas runtime del proceso, pero no trazas distribuidas profundas. ¿Qué conclusión se sostiene?",
    "choices": [
      "Infrastructure puede inyectar en procesos compatibles, pero tracing y profiling profundos corresponden a Full-Stack.",
      "Infrastructure ofrece tracing distribuido, pero exige activar profiling por separado.",
      "La presencia de métricas runtime demuestra que code-module injection está deshabilitada.",
      "Infrastructure y Full-Stack ofrecen el mismo tracing; sólo cambia la retención."
    ],
    "correct": [
      0
    ],
    "explanation": "Infrastructure mantiene auto-injection para ciertas métricas y backing services, pero no ofrece la profundidad de Full-Stack."
  },
  {
    "id": "A-007",
    "source": "modes",
    "objective": "discovery-license",
    "bucket": "precision",
    "difficulty": "intermediate",
    "prompt": "Quieres desplegar Discovery mode en un entorno sin Dynatrace Platform Subscription. ¿Qué condición debes revisar antes de diseñar el despliegue?",
    "choices": [
      "Discovery sólo está disponible con el modelo DPS.",
      "Discovery está disponible en cualquier modelo de licencia si se desactiva la inyección.",
      "Discovery requiere una licencia de RUM además de la licencia de host.",
      "Discovery se habilita únicamente cuando Infrastructure ya monitoriza el host."
    ],
    "correct": [
      0
    ],
    "explanation": "La disponibilidad de Discovery mode depende del modelo Dynatrace Platform Subscription."
  },
  {
    "id": "A-008",
    "source": "modes",
    "objective": "mode-depth",
    "bucket": "scenario",
    "difficulty": "intermediate",
    "prompt": "Necesitas trazas y profiling de una aplicación crítica y también métricas de host. La tecnología figura como soportada. ¿Qué modo de OneAgent se ajusta mejor?",
    "choices": [
      "Full-Stack monitoring.",
      "Infrastructure con inyección de procesos, porque ofrece el mismo tracing que Full-Stack.",
      "Discovery con log collection, porque los logs generan automáticamente trazas profundas.",
      "Full-Stack sin code-module injection, porque el profiling no depende de ella."
    ],
    "correct": [
      0
    ],
    "explanation": "Full-Stack incluye la visibilidad de aplicación profunda junto con infraestructura."
  },
  {
    "id": "A-009",
    "source": "modes",
    "objective": "injection-lifecycle",
    "bucket": "troubleshooting",
    "difficulty": "advanced",
    "prompt": "Se desactiva code-module injection, pero un proceso ya iniciado sigue mostrando el módulo de Dynatrace cargado. ¿Qué explica el estado?",
    "choices": [
      "El módulo enlazado permanece hasta reiniciar ese proceso.",
      "La desactivación descarga el módulo al finalizar la siguiente consulta del proceso.",
      "El cambio sólo se aplica cuando el proceso envía un nuevo conjunto de métricas.",
      "El módulo permanece hasta que se reinicia OneAgent, sin necesidad de reiniciar el proceso."
    ],
    "correct": [
      0
    ],
    "explanation": "La inyección se decide al arrancar el proceso; un módulo ya enlazado requiere reinicio para retirarse."
  },
  {
    "id": "A-010",
    "source": "agentcli",
    "objective": "monitoring-mode-cli",
    "bucket": "practical",
    "difficulty": "intermediate",
    "prompt": "Un host debe pasar de Full-Stack a Infrastructure mediante oneagentctl. ¿Qué valor corresponde al parámetro --set-monitoring-mode?",
    "choices": [
      "infra-only",
      "infrastructure",
      "infra",
      "infrastructure-only"
    ],
    "correct": [
      0
    ],
    "explanation": "El valor CLI documentado para Infrastructure monitoring es infra-only.",
    "stimulus": {
      "kind": "code",
      "title": "Comando a completar",
      "content": "oneagentctl --set-monitoring-mode=<valor>"
    }
  },
  {
    "id": "A-011",
    "source": "agent",
    "objective": "agent-communication",
    "bucket": "precision",
    "difficulty": "intermediate",
    "prompt": "Un equipo diseña reglas de red para OneAgent. Selecciona las dos afirmaciones compatibles con su comunicación.",
    "choices": [
      "OneAgent inicia conexiones salientes hacia Dynatrace o ActiveGate.",
      "El envío requiere abrir una conexión entrante desde ActiveGate a cada OneAgent.",
      "ActiveGate puede actuar como punto de comunicación intermedio.",
      "Cada OneAgent debe hablar directamente con Dynatrace aunque exista ActiveGate."
    ],
    "correct": [
      0,
      2
    ],
    "explanation": "OneAgent inicia la comunicación; ActiveGate puede intermediar según la topología de despliegue."
  },
  {
    "id": "A-012",
    "source": "modes",
    "objective": "discovery-detail",
    "bucket": "precision",
    "difficulty": "intermediate",
    "prompt": "En Discovery mode aparece el host, pero faltan host process details y análisis detallado de disco. ¿Qué indica la matriz de capacidades?",
    "choices": [
      "Son capacidades de Full-Stack e Infrastructure, no de Discovery.",
      "Esas capacidades se habilitan en Discovery al activar process injection.",
      "Los detalles de proceso aparecen en Discovery, pero el análisis de disco requiere Full-Stack.",
      "El modo Discovery ofrece ambas capacidades sólo después de activar log monitoring."
    ],
    "correct": [
      0
    ],
    "explanation": "Discovery ofrece observación básica; la matriz separa esas capacidades de los otros modos."
  },
  {
    "id": "A-013",
    "source": "modes",
    "objective": "mode-logs",
    "bucket": "scenario",
    "difficulty": "intermediate",
    "prompt": "Se adopta Discovery para inventario, pero también se necesitan logs en ciertos hosts. ¿Qué matiz de la matriz evita descartarlo sin probar?",
    "choices": [
      "Log Management figura como capacidad opt-in en Discovery.",
      "Los logs sólo se admiten en Infrastructure y Full-Stack.",
      "Activar logs en Discovery habilita automáticamente tracing distribuido.",
      "Discovery ingiere logs únicamente a través de un ActiveGate dedicado."
    ],
    "correct": [
      0
    ],
    "explanation": "La tabla de modos marca Log Management como opt-in también en Discovery."
  },
  {
    "id": "A-014",
    "source": "modes",
    "objective": "mode-custom-metrics",
    "bucket": "precision",
    "difficulty": "advanced",
    "prompt": "Una arquitectura depende de custom metrics enviadas desde procesos monitorizados. ¿Qué comparación de modos es correcta según la matriz?",
    "choices": [
      "Full-Stack e Infrastructure admiten custom metrics con límites distintos; Discovery no las incluye.",
      "Los tres modos admiten custom metrics, pero con el mismo límite.",
      "Infrastructure no admite custom metrics aunque tenga inyección de procesos.",
      "Discovery admite custom metrics, pero Full-Stack no las admite."
    ],
    "correct": [
      0
    ],
    "explanation": "La matriz muestra custom metrics para Full-Stack e Infrastructure y ninguna para Discovery."
  },
  {
    "id": "A-015",
    "source": "modes",
    "objective": "discovery-appsec",
    "bucket": "troubleshooting",
    "difficulty": "advanced",
    "prompt": "En Discovery se activa Application Security, pero no aparece la información que requiere instrumentación de código. ¿Qué comprobarías primero?",
    "choices": [
      "Si code-module injection está habilitado para el proceso compatible y éste se reinició.",
      "Si el usuario tiene permiso de lectura en el bucket de eventos de seguridad.",
      "Si el host se movió a un bucket de logs con retención suficiente.",
      "Si existe una regla de routing para los eventos de vulnerabilidad."
    ],
    "correct": [
      0
    ],
    "explanation": "Application Security es opt-in y las capacidades basadas en código requieren instrumentación efectiva."
  },
  {
    "id": "A-016",
    "source": "agentcli",
    "objective": "mode-change-restart",
    "bucket": "troubleshooting",
    "difficulty": "advanced",
    "prompt": "Cambias el modo de Infrastructure a Full-Stack con oneagentctl y los servicios siguen sin nueva instrumentación. ¿Qué requisito operativo señala la CLI?",
    "choices": [
      "Reiniciar OneAgent y los servicios monitorizados para aplicar el cambio.",
      "Reiniciar únicamente OneAgent; los procesos ya iniciados reciben la nueva inyección sin reinicio.",
      "Reiniciar sólo los servicios; OneAgent aplica el nuevo modo sin reinicio.",
      "Esperar al siguiente ciclo de detección de procesos, sin reiniciar agente ni servicios."
    ],
    "correct": [
      0
    ],
    "explanation": "La guía CLI indica reinicio de OneAgent y servicios al cambiar Infrastructure monitoring mode."
  },
  {
    "id": "A-017",
    "source": "dqlbest",
    "objective": "aggregate-before-limit",
    "bucket": "practical",
    "difficulty": "advanced",
    "prompt": "Los logs tienen loglevel y service.name. Quieres los cinco servicios con más registros ERROR en 24 horas, sin truncar el conteo. ¿Qué pipeline es correcto?",
    "choices": [
      "fetch logs, from:now()-24h | filter loglevel == \"ERROR\" | summarize errors=count(), by:{service.name} | sort errors desc | limit 5",
      "fetch logs, from:now()-24h | filter loglevel == \"ERROR\" | sort timestamp desc | limit 5 | summarize errors=count(), by:{service.name}",
      "fetch logs, from:now()-24h | summarize errors=count(), by:{service.name} | sort errors desc | limit 5",
      "fetch logs, from:now()-24h | filter loglevel == \"ERROR\" | summarize errors=count(), by:{service.name} | limit 5 | sort errors desc"
    ],
    "correct": [
      0
    ],
    "explanation": "Hay que filtrar antes de contar y ordenar todos los grupos antes de tomar los cinco primeros."
  },
  {
    "id": "A-018",
    "source": "dqlmetrics",
    "objective": "metrics-vs-timeseries",
    "bucket": "scenario",
    "difficulty": "intermediate",
    "prompt": "Necesitas dibujar la evolución de una métrica de CPU durante siete días. ¿Qué comando inicial proporciona valores por intervalo?",
    "choices": [
      "timeseries con la agregación y el intervalo adecuados.",
      "fetch de la tabla de métricas seguido de summarize por service.name.",
      "summarize con count() sobre los datapoints, sin crear intervalos temporales.",
      "makeTimeseries aplicado después de limitar los registros a una muestra fija."
    ],
    "correct": [
      0
    ],
    "explanation": "timeseries devuelve series temporales; metrics sirve para explorar series y no devuelve sus valores temporales."
  },
  {
    "id": "A-019",
    "source": "dql",
    "objective": "summarize-groups",
    "bucket": "practical",
    "difficulty": "intermediate",
    "prompt": "Tres logs ERROR tienen service.name: api, api y web. ¿Qué devuelve summarize errors=count(), by:{service.name} tras filtrarlos?",
    "choices": [
      "Dos filas: api=2 y web=1.",
      "Una fila: errors=3 sin service.name.",
      "Tres filas, una por registro original.",
      "Dos filas: api=1 y web=1."
    ],
    "correct": [
      0
    ],
    "explanation": "summarize agrupa por service.name y count cuenta los registros de cada grupo.",
    "stimulus": {
      "kind": "table",
      "title": "Logs filtrados",
      "columns": [
        "loglevel",
        "service.name"
      ],
      "rows": [
        [
          "ERROR",
          "api"
        ],
        [
          "ERROR",
          "api"
        ],
        [
          "ERROR",
          "web"
        ]
      ]
    }
  },
  {
    "id": "A-020",
    "source": "dqlfilter",
    "objective": "exact-vs-pattern",
    "bucket": "precision",
    "difficulty": "intermediate",
    "prompt": "Conoces exactamente el valor de k8s.container.name: coredns. ¿Qué filtro recomienda la guía para la comparación?",
    "choices": [
      "k8s.container.name == \"coredns\"",
      "k8s.container.name ~ \"coredns\"",
      "search \"coredns\" sobre todos los campos",
      "contains(content, \"coredns\")"
    ],
    "correct": [
      0
    ],
    "explanation": "Para un valor conocido y exacto, la guía recomienda ==; ~ se reserva para coincidencia parcial o patrón."
  },
  {
    "id": "A-021",
    "source": "dqlcommands",
    "objective": "parse-fields",
    "bucket": "scenario",
    "difficulty": "intermediate",
    "prompt": "El código HTTP está dentro del texto content de cada log. Quieres agrupar por ese código. ¿Qué paso debe crear primero un campo utilizable?",
    "choices": [
      "parse sobre content con un patrón que extraiga el código.",
      "fieldsAdd code = content sin extraer ni convertir el valor.",
      "summarize count(), by:{content} para inferir automáticamente el código.",
      "search del código sobre content, porque search crea el campo code."
    ],
    "correct": [
      0
    ],
    "explanation": "parse extrae campos estructurados del texto antes de filtrarlos o agregarlos."
  },
  {
    "id": "A-022",
    "source": "dqlbest",
    "objective": "early-fields",
    "bucket": "scenario",
    "difficulty": "intermediate",
    "prompt": "Una consulta de logs transforma decenas de campos que el resultado no necesita. ¿Qué mejora recomienda DQL para reducir trabajo?",
    "choices": [
      "Seleccionar pronto los campos necesarios con fields, fieldsKeep o fieldsRemove.",
      "Filtrar por host después de expandir todos los registros.",
      "Mantener todos los campos hasta el último comando para preservar el esquema.",
      "Añadir una ordenación completa antes de seleccionar los campos."
    ],
    "correct": [
      0
    ],
    "explanation": "La guía recomienda seleccionar temprano los campos que se procesarán."
  },
  {
    "id": "A-023",
    "source": "dqlcommands",
    "objective": "source-commands",
    "bucket": "precision",
    "difficulty": "intermediate",
    "prompt": "Selecciona los dos comandos de inicio apropiados para los objetivos descritos.",
    "choices": [
      "fetch logs para leer registros de log almacenados.",
      "timeseries para obtener valores de métricas por intervalos.",
      "filter como comando inicial, sin un comando que proporcione registros.",
      "summarize como origen que carga automáticamente cualquier tabla."
    ],
    "correct": [
      0,
      1
    ],
    "explanation": "fetch carga una fuente de registros y timeseries inicia consultas de métricas temporales."
  },
  {
    "id": "A-024",
    "source": "permissions",
    "objective": "grail-two-permissions",
    "bucket": "troubleshooting",
    "difficulty": "advanced",
    "prompt": "Un usuario tiene storage:logs:read para la tabla logs, pero una consulta no puede leer el bucket donde están los registros. ¿Qué autorización adicional debe comprobarse?",
    "choices": [
      "storage:buckets:read para el bucket correspondiente.",
      "storage:bucket-definitions:read, que concede acceso a todos los datos de los buckets definidos.",
      "storage:logs:write, porque la lectura de logs hereda el permiso de escritura.",
      "storage:events:read, porque los logs se autorizan como eventos."
    ],
    "correct": [
      0
    ],
    "explanation": "Leer logs en Grail requiere permiso de tabla y acceso al bucket que contiene los registros."
  },
  {
    "id": "A-025",
    "source": "dqlbest",
    "objective": "limit-semantics",
    "bucket": "practical",
    "difficulty": "advanced",
    "prompt": "Se quiere contar todos los errores por host. Una consulta coloca limit 100 inmediatamente después de fetch logs y antes de summarize. ¿Qué problema introduce?",
    "choices": [
      "La agregación sólo considera los cien registros retenidos por limit.",
      "limit restringe sólo la tabla de salida después de la agregación.",
      "limit afecta al número de grupos finales, no a los registros de entrada.",
      "summarize recompone los registros descartados por limit."
    ],
    "correct": [
      0
    ],
    "explanation": "Un limit previo a la agregación recorta su conjunto de entrada y puede falsear los totales."
  },
  {
    "id": "A-026",
    "source": "dqlmetrics",
    "objective": "timeseries-dimension",
    "bucket": "scenario",
    "difficulty": "intermediate",
    "prompt": "Quieres comparar la CPU media de dos hosts en una gráfica temporal. ¿Qué parte de timeseries conserva series separadas?",
    "choices": [
      "by:dt.entity.host",
      "limit 2 después de la agregación.",
      "fieldsRemove dt.entity.host antes de visualizar.",
      "sort dt.entity.host asc tras timeseries."
    ],
    "correct": [
      0
    ],
    "explanation": "El parámetro by segmenta la serie agregada por host."
  },
  {
    "id": "A-027",
    "source": "dql",
    "objective": "dql-pipeline",
    "bucket": "knowledge",
    "difficulty": "intermediate",
    "prompt": "En DQL, ¿qué determina la entrada del segundo comando en fetch logs | filter loglevel == \"ERROR\"?",
    "choices": [
      "Los registros que devuelve fetch logs.",
      "El conjunto de todos los buckets, aunque fetch haya seleccionado sólo logs.",
      "El resultado de la última consulta ejecutada en el mismo Notebook.",
      "Los registros originales de logs antes de aplicar el comando fetch."
    ],
    "correct": [
      0
    ],
    "explanation": "La salida tabular de un comando se pasa al siguiente mediante el pipe."
  },
  {
    "id": "A-028",
    "source": "rum",
    "objective": "rum-interaction",
    "bucket": "precision",
    "difficulty": "advanced",
    "prompt": "En la nueva experiencia RUM, una interacción de usuario no lanza ninguna petición de red. ¿Puede capturarse como interacción?",
    "choices": [
      "Sí, si está habilitada la captura de interacciones; no requiere una petición.",
      "No; sólo las interacciones con llamadas XHR se modelan como acciones.",
      "Sí, pero únicamente si el browser monitor ejecuta el mismo recorrido.",
      "No; una interacción sin red sólo se captura si provoca navegación completa."
    ],
    "correct": [
      0
    ],
    "explanation": "El modelo RUM actual puede captar interacciones independientemente de las peticiones, a diferencia de RUM Classic."
  },
  {
    "id": "A-029",
    "source": "rumclassic",
    "objective": "classic-user-action",
    "bucket": "precision",
    "difficulty": "intermediate",
    "prompt": "En RUM Classic para web, ¿qué distingue una load action de una XHR action?",
    "choices": [
      "La load action corresponde a una carga de página; XHR representa interacción asíncrona.",
      "Load action mide el backend; XHR action mide exclusivamente el renderizado del navegador.",
      "Load action exige interacción manual; XHR action se crea sólo en una carga inicial.",
      "Ambas se diferencian sólo por el umbral Apdex asignado."
    ],
    "correct": [
      0
    ],
    "explanation": "La documentación separa tipos de user action por la forma de interacción y cálculo de duración."
  },
  {
    "id": "A-030",
    "source": "synthetic",
    "objective": "clickpath-steps",
    "bucket": "scenario",
    "difficulty": "intermediate",
    "prompt": "Un monitor debe abrir la tienda, buscar un producto, seleccionarlo y verificar el carrito. ¿Qué tipo de monitor y estructura corresponde?",
    "choices": [
      "Browser clickpath con pasos Navigate, interacción y validación.",
      "Browser single-URL con validación del contenido de la página inicial.",
      "HTTP monitor con cuatro peticiones configuradas como una secuencia de clics.",
      "Browser clickpath con un único Navigate y sin pasos de interacción ni validación."
    ],
    "correct": [
      0
    ],
    "explanation": "Un recorrido de usuario de varias acciones se modela como clickpath de navegador."
  },
  {
    "id": "A-031",
    "source": "synthetic",
    "objective": "navigate-step",
    "bucket": "troubleshooting",
    "difficulty": "intermediate",
    "prompt": "Un browser clickpath no llega al paso de login porque no carga la página inicial. ¿Qué paso revisarías primero?",
    "choices": [
      "El Navigate inicial y la URL que abre el navegador.",
      "El locator del paso de login, porque siempre se evalúa antes de Navigate.",
      "El selector del último paso Click, porque controla la carga inicial.",
      "El wait strategy del paso de validación final, porque determina la URL inicial."
    ],
    "correct": [
      0
    ],
    "explanation": "Navigate abre la URL inicial y establece el punto de partida del clickpath."
  },
  {
    "id": "A-032",
    "source": "rum",
    "objective": "rum-action-model",
    "bucket": "scenario",
    "difficulty": "advanced",
    "prompt": "Una nueva aplicación RUM recibe clics, peticiones y errores relacionados con el mismo comportamiento del usuario. ¿Qué concepto los agrupa para medir frecuencia y duración?",
    "choices": [
      "User action.",
      "User session, que equivale a una interacción individual.",
      "User event, que agrupa automáticamente todas las sesiones de la aplicación.",
      "Page view, que incluye necesariamente clics, peticiones y errores posteriores."
    ],
    "correct": [
      0
    ],
    "explanation": "Una user action conecta interacciones, peticiones, navegaciones y errores de un comportamiento significativo."
  },
  {
    "id": "A-033",
    "source": "rumclassic",
    "objective": "key-user-actions",
    "bucket": "scenario",
    "difficulty": "intermediate",
    "prompt": "En RUM Classic, checkout necesita un umbral Apdex distinto al resto de acciones. ¿Qué configuración responde a ese caso?",
    "choices": [
      "Marcar checkout como key user action y configurar su Apdex.",
      "Cambiar el Apdex general de la aplicación, conservando checkout como acción ordinaria.",
      "Crear una aplicación RUM nueva sólo para la acción checkout.",
      "Definir el umbral en un monitor Synthetic del flujo checkout."
    ],
    "correct": [
      0
    ],
    "explanation": "Las key user actions pueden tener un umbral Apdex propio."
  },
  {
    "id": "A-034",
    "source": "rum",
    "objective": "rum-vs-synthetic",
    "bucket": "precision",
    "difficulty": "intermediate",
    "prompt": "Selecciona las dos observaciones que distinguen RUM de una prueba Synthetic.",
    "choices": [
      "RUM describe interacciones de usuarios reales instrumentados.",
      "Synthetic ejecuta recorridos programados incluso sin visitas reales.",
      "RUM ejecuta clickpaths planificados aunque no haya usuarios.",
      "Synthetic necesita sesiones RUM previas para lanzar el recorrido."
    ],
    "correct": [
      0,
      1
    ],
    "explanation": "RUM observa actividad real; Synthetic simula actividad bajo una programación."
  },
  {
    "id": "A-035",
    "source": "synthetic",
    "objective": "clickpath-failure",
    "bucket": "troubleshooting",
    "difficulty": "advanced",
    "prompt": "Un clickpath abre la página, pero deja de encontrar el botón de compra tras un cambio de frontend. ¿Qué evidencia revisarías?",
    "choices": [
      "El locator del paso Click y su wait strategy frente al DOM actual.",
      "El locator del paso Navigate inicial, porque controla todos los botones posteriores.",
      "La frecuencia de ejecución del monitor, porque cambia el selector del botón.",
      "El umbral de disponibilidad, porque determina el elemento que debe pulsarse."
    ],
    "correct": [
      0
    ],
    "explanation": "Los pasos del clickpath dependen de locators y estrategia de espera para identificar elementos."
  },
  {
    "id": "A-036",
    "source": "notebooks",
    "objective": "section-choice",
    "bucket": "scenario",
    "difficulty": "intermediate",
    "prompt": "Quieres escribir DQL, visualizar el resultado y añadir una explicación narrativa en el mismo documento. ¿Qué secciones de Notebook necesitas?",
    "choices": [
      "Query y Markdown.",
      "Explore y Markdown, porque Explore acepta cualquier DQL escrito en la sección.",
      "Query y Code, porque la explicación narrativa requiere una función.",
      "Code y Explore, porque Markdown no puede acompañar resultados DQL."
    ],
    "correct": [
      0
    ],
    "explanation": "Query ejecuta DQL y Markdown aporta texto explicativo."
  },
  {
    "id": "A-037",
    "source": "notebooks",
    "objective": "query-timeframe",
    "bucket": "precision",
    "difficulty": "intermediate",
    "prompt": "Una sección Query del Notebook tiene el timeframe definido dentro de DQL. ¿Qué ocurre con el selector de timeframe de esa sección?",
    "choices": [
      "Queda deshabilitado porque manda el intervalo de la consulta.",
      "Sobrescribe siempre el intervalo escrito en DQL.",
      "Se combina con el intervalo DQL mediante una intersección automática.",
      "Sólo altera la visualización, mientras la consulta usa el intervalo de la sección."
    ],
    "correct": [
      0
    ],
    "explanation": "La documentación indica que el selector se deshabilita cuando DQL fija el timeframe."
  },
  {
    "id": "A-038",
    "source": "dashboards",
    "objective": "variable-key",
    "bucket": "practical",
    "difficulty": "intermediate",
    "prompt": "Creas en Dashboards una variable llamada Región Operativa. ¿Cómo se deriva su clave para usarla en consultas?",
    "choices": [
      "Se sustituyen caracteres no alfanuméricos por _ y se antepone $.",
      "Se conservan los espacios y se antepone $ al nombre visible.",
      "Se eliminan los espacios y se usa el nombre resultante sin prefijo.",
      "Se transforma a minúsculas y se antepone el identificador del dashboard."
    ],
    "correct": [
      0
    ],
    "explanation": "La clave se deriva del nombre y se referencia con el prefijo $."
  },
  {
    "id": "A-039",
    "source": "dashboards",
    "objective": "query-tile",
    "bucket": "scenario",
    "difficulty": "intermediate",
    "prompt": "Un tile de Dashboard debe ejecutar una consulta DQL propia. ¿Dónde defines la consulta?",
    "choices": [
      "En la pestaña Data del tile.",
      "En el panel de variables, porque cualquier tile hereda una consulta global.",
      "En el selector de visualización, que también define el origen DQL.",
      "En el apartado de Markdown del tile, que ejecuta DQL embebido."
    ],
    "correct": [
      0
    ],
    "explanation": "Los tiles de consulta usan la pestaña Data para definir DQL."
  },
  {
    "id": "A-040",
    "source": "notebooks",
    "objective": "code-section",
    "bucket": "precision",
    "difficulty": "intermediate",
    "prompt": "En un Notebook, una sección debe obtener datos mediante una Dynatrace function. ¿Qué tipo de sección corresponde?",
    "choices": [
      "Code.",
      "Query, que ejecuta automáticamente funciones mediante DQL.",
      "Custom Function tile, configurado para invocar la función desde la interfaz.",
      "Explore, que ejecuta código de funciones con la selección actual."
    ],
    "correct": [
      0
    ],
    "explanation": "La sección Code ejecuta código de funciones de Dynatrace."
  },
  {
    "id": "A-041",
    "source": "dashboards",
    "objective": "dashboard-variable-use",
    "bucket": "precision",
    "difficulty": "intermediate",
    "prompt": "Selecciona los dos usos documentados de una variable en Dashboards.",
    "choices": [
      "Filtrar contenido del dashboard.",
      "Actuar como valor en un tile Code.",
      "Modificar la retención de los registros visibles en todos los tiles.",
      "Otorgar permisos de lectura al usuario que abre el dashboard."
    ],
    "correct": [
      0,
      1
    ],
    "explanation": "Las variables alimentan filtros y valores de tiles; no administran almacenamiento ni IAM."
  },
  {
    "id": "A-042",
    "source": "notebooks",
    "objective": "reproduce-analysis",
    "bucket": "troubleshooting",
    "difficulty": "advanced",
    "prompt": "La misma DQL produce cifras distintas en un Notebook y un Dashboard. ¿Qué diferencia de contexto comprobarías antes de corregir la consulta?",
    "choices": [
      "Timeframe efectivo y valores de variables o filtros aplicados.",
      "El tipo de visualización, porque puede cambiar los registros devueltos por DQL.",
      "La posición del tile, porque altera el timeframe efectivo de la consulta.",
      "La propiedad del documento, porque cambia automáticamente la agregación DQL."
    ],
    "correct": [
      0
    ],
    "explanation": "La ejecución puede variar por intervalo y parámetros aunque el texto DQL parezca igual."
  },
  {
    "id": "A-043",
    "source": "logingest",
    "objective": "log-source",
    "bucket": "scenario",
    "difficulty": "intermediate",
    "prompt": "Debes ingerir logs de una función serverless donde no puedes instalar OneAgent. ¿Qué ruta documentada encaja?",
    "choices": [
      "Enviar los registros mediante Logs Ingestion API.",
      "Configurar una fuente de logs en otro OneAgent, aunque la función no expone sus archivos ni stdout a ese host.",
      "Definir routing en OpenPipeline para que extraiga directamente stdout de la función sin un canal de ingestión.",
      "Desplegar un ActiveGate con CloudWatch Extension para recopilar logs mediante polling de API."
    ],
    "correct": [
      0
    ],
    "explanation": "La API de ingestión permite enviar logs cuando no es posible instalar OneAgent."
  },
  {
    "id": "A-044",
    "source": "openpipeline",
    "objective": "routing-purpose",
    "bucket": "knowledge",
    "difficulty": "intermediate",
    "prompt": "En OpenPipeline, ¿qué decisión toma una regla de routing?",
    "choices": [
      "A qué pipeline se asigna el registro entrante.",
      "El bucket de destino, antes de seleccionar el pipeline de procesamiento.",
      "El orden en que se ejecutan los processors dentro de un pipeline.",
      "La tabla lógica en la que se consultará el registro después del almacenamiento."
    ],
    "correct": [
      0
    ],
    "explanation": "El routing asigna datos entrantes a un pipeline de procesamiento."
  },
  {
    "id": "A-045",
    "source": "openpipeline",
    "objective": "processor-contract",
    "bucket": "precision",
    "difficulty": "advanced",
    "prompt": "Selecciona los dos componentes que definen el comportamiento de un processor de OpenPipeline.",
    "choices": [
      "Matcher que delimita los registros objetivo.",
      "Processing definition que transforma o extrae datos.",
      "Una regla de routing que asigna usuarios a un bucket.",
      "Una consulta DQL que se ejecuta tras guardar el registro."
    ],
    "correct": [
      0,
      1
    ],
    "explanation": "Un processor combina condición de coincidencia e instrucción de procesamiento."
  },
  {
    "id": "A-046",
    "source": "logprocessing",
    "objective": "mask-before-store",
    "bucket": "scenario",
    "difficulty": "advanced",
    "prompt": "Hay que ocultar un identificador sensible en logs antes de almacenarlos en Grail. ¿Dónde corresponde aplicar la transformación?",
    "choices": [
      "En Processing stage de OpenPipeline, antes del almacenamiento.",
      "En la consulta DQL, ocultando el atributo cada vez que se consulta.",
      "En el dashboard, mediante un filtro aplicado a los tiles.",
      "En una transformación posterior sobre el dato ya almacenado."
    ],
    "correct": [
      0
    ],
    "explanation": "El procesamiento de ingestión puede editar y enmascarar campos antes de guardar el registro."
  },
  {
    "id": "A-047",
    "source": "logprocessing",
    "objective": "custom-route",
    "bucket": "troubleshooting",
    "difficulty": "advanced",
    "prompt": "Añades una ruta dinámica hacia un pipeline personalizado y dejan de aplicarse reglas del pipeline por defecto. ¿Qué explica el cambio?",
    "choices": [
      "Los logs enrutados al pipeline personalizado no pasan también por el predeterminado.",
      "El registro atraviesa primero el pipeline predeterminado y después el personalizado.",
      "El pipeline personalizado sólo recibe una copia; el original sigue por el predeterminado.",
      "La ruta dinámica cambia el orden de los processors, pero mantiene el pipeline predeterminado."
    ],
    "correct": [
      0
    ],
    "explanation": "La documentación indica que los logs dirigidos a un pipeline personalizado no son procesados por el default pipeline."
  },
  {
    "id": "A-048",
    "source": "logprocessing",
    "objective": "default-route",
    "bucket": "scenario",
    "difficulty": "intermediate",
    "prompt": "Un log no coincide con ninguna ruta personalizada de OpenPipeline. ¿Qué ruta de procesamiento esperas?",
    "choices": [
      "La ruta por defecto hacia el pipeline integrado que garantiza almacenamiento en Grail.",
      "Se descarta si no coincide con una ruta personalizada.",
      "Permanece en espera hasta que se cree una ruta que coincida.",
      "Se procesa por el último pipeline personalizado creado."
    ],
    "correct": [
      0
    ],
    "explanation": "Los logs no enrutados a pipelines personalizados pasan por el pipeline predeterminado."
  },
  {
    "id": "A-049",
    "source": "logingest",
    "objective": "oneagent-api-choice",
    "bucket": "precision",
    "difficulty": "intermediate",
    "prompt": "Selecciona dos métodos documentados para traer logs a Dynatrace según el tipo de origen.",
    "choices": [
      "OneAgent para logs descubiertos en hosts monitorizados.",
      "Logs Ingestion API para orígenes sin agente instalable.",
      "DQL fetch desde un dashboard para transmitir registros nuevos.",
      "Una sección Query de Notebook configurada como endpoint de ingestión."
    ],
    "correct": [
      0,
      1
    ],
    "explanation": "OneAgent y la API cubren estrategias de ingestión diferentes."
  },
  {
    "id": "A-050",
    "source": "logs",
    "objective": "schema-on-read",
    "bucket": "scenario",
    "difficulty": "intermediate",
    "prompt": "Un equipo recibe logs con atributos nuevos que no definió previamente como columnas. ¿Qué propiedad facilita explorarlos con DQL?",
    "choices": [
      "Schema on-read sobre los registros de Grail.",
      "Un esquema de columnas fijo que obliga a declarar cada atributo nuevo antes de almacenar.",
      "Una definición de tabla por aplicación que se reconstruye al llegar un campo.",
      "Una conversión previa de todos los atributos nuevos a métricas."
    ],
    "correct": [
      0
    ],
    "explanation": "Log Analytics y DQL permiten explorar estructura flexible al leer los datos."
  },
  {
    "id": "A-051",
    "source": "seceval",
    "objective": "library-in-use",
    "bucket": "precision",
    "difficulty": "advanced",
    "prompt": "Un escáner externo encuentra un JAR vulnerable en disco, pero el proceso no lo carga. ¿Qué criterio usa Runtime Vulnerability Analytics para reportar una vulnerabilidad third-party?",
    "choices": [
      "Que el componente afectado esté cargado y en uso en runtime.",
      "Que el componente aparezca en el inventario de paquetes del host, aunque no lo use ningún proceso.",
      "Que el CVE esté publicado y el archivo exista en el disco monitorizado.",
      "Que cualquier proceso del host utilice una librería de la misma familia, aunque no sea la vulnerable."
    ],
    "correct": [
      0
    ],
    "explanation": "La evaluación third-party usa componentes que OneAgent observa cargados por procesos."
  },
  {
    "id": "A-052",
    "source": "security",
    "objective": "code-level-risk",
    "bucket": "scenario",
    "difficulty": "advanced",
    "prompt": "Un flujo de entrada de usuario llega a una ruta de código insegura con acceso a datos sensibles. ¿Qué capacidad analiza ese recorrido?",
    "choices": [
      "Code-level vulnerability detection.",
      "Runtime Vulnerability Analytics para third-party libraries, sin análisis del flujo de datos.",
      "Inventario de paquetes instalado, sin observar entrada ni ejecución.",
      "Vulnerability evaluation basada sólo en severidad CVSS del componente."
    ],
    "correct": [
      0
    ],
    "explanation": "La detección code-level estudia el flujo de entrada y los caminos de código explotables."
  },
  {
    "id": "A-053",
    "source": "security",
    "objective": "runtime-context",
    "bucket": "precision",
    "difficulty": "advanced",
    "prompt": "Selecciona dos señales que Runtime Vulnerability Analytics utiliza para reducir ruido frente a un listado estático de paquetes.",
    "choices": [
      "Componentes efectivamente cargados por procesos.",
      "Contexto de ejecución y flujos de datos observados.",
      "Presencia de cualquier versión vulnerable en el disco, esté cargada o no.",
      "Puntuación CVSS pública, sin contexto de ejecución."
    ],
    "correct": [
      0,
      1
    ],
    "explanation": "El análisis se basa en lo que está ejecutándose y, para código, en flujos observados."
  },
  {
    "id": "A-054",
    "source": "security",
    "objective": "vulnerability-lifecycle",
    "bucket": "troubleshooting",
    "difficulty": "advanced",
    "prompt": "Una vulnerabilidad third-party deja de aparecer tras retirar la librería afectada del proceso. ¿Qué comportamiento documentado puede explicarlo?",
    "choices": [
      "Resolución automática cuando desaparece la causa raíz en runtime.",
      "El hallazgo se resuelve al retirar el archivo del disco, aunque el proceso continúe usando la librería cargada.",
      "El hallazgo permanece abierto hasta que un analista lo cierre, incluso si ningún proceso informa ya del componente.",
      "El hallazgo se resuelve cuando cambia la severidad pública del CVE, aunque el componente siga ejecutándose."
    ],
    "correct": [
      0
    ],
    "explanation": "La evaluación se actualiza y puede resolver la vulnerabilidad al desaparecer el componente afectado."
  },
  {
    "id": "A-055",
    "source": "seceval",
    "objective": "third-party-vs-code",
    "bucket": "precision",
    "difficulty": "intermediate",
    "prompt": "¿Qué par de evidencias distingue correctamente third-party de code-level vulnerabilities?",
    "choices": [
      "Third-party: componente vulnerable en uso; code-level: flujo explotable por código propio o librería.",
      "Third-party: paquete presente en disco; code-level: cualquier excepción capturada.",
      "Third-party: componente cargado; code-level: sólo puntuación CVSS de la dependencia.",
      "Third-party: cualquier CVE publicado; code-level: sólo vulnerabilidad de un paquete externo."
    ],
    "correct": [
      0
    ],
    "explanation": "Los mecanismos usan evidencia runtime diferente: uso de componentes y análisis de flujos de código."
  },
  {
    "id": "A-056",
    "source": "workflowtriggers",
    "objective": "trigger-types",
    "bucket": "knowledge",
    "difficulty": "intermediate",
    "prompt": "Un workflow debe ejecutar un informe todos los lunes sin esperar un evento. ¿Qué categoría de trigger corresponde?",
    "choices": [
      "Schedule.",
      "Event, configurado para ejecutarse al llegar el lunes.",
      "On demand con una ejecución automática implícita cada semana.",
      "Problem trigger filtrado por la fecha del calendario."
    ],
    "correct": [
      0
    ],
    "explanation": "Schedule inicia el workflow a intervalos o tiempos configurados."
  },
  {
    "id": "A-057",
    "source": "workflowtriggers",
    "objective": "disabled-trigger",
    "bucket": "precision",
    "difficulty": "advanced",
    "prompt": "Desactivas el trigger automático de un workflow live. ¿Qué posibilidad conserva la documentación?",
    "choices": [
      "Puede invocarse mediante API aunque el trigger esté desactivado.",
      "La invocación API se bloquea junto con el trigger hasta que el workflow vuelva a draft.",
      "Sólo se permite la ejecución manual desde la UI, pero no por API.",
      "La ejecución mediante API requiere convertir el workflow a un schedule activo."
    ],
    "correct": [
      0
    ],
    "explanation": "Desactivar un trigger evita ejecuciones automáticas; la invocación por API permanece disponible."
  },
  {
    "id": "A-058",
    "source": "workflowsecurity",
    "objective": "workflow-actor",
    "bucket": "troubleshooting",
    "difficulty": "advanced",
    "prompt": "Un usuario puede editar un workflow, pero una task devuelve 403 al leer eventos. Selecciona las dos comprobaciones pertinentes.",
    "choices": [
      "Permisos de lectura de eventos del actor del workflow.",
      "Autorización concedida a AutomationEngine para ejercer esos permisos.",
      "El permiso de edición del workflow por parte del usuario interactivo.",
      "El permiso de lectura del creador del workflow, aunque la task use otro actor."
    ],
    "correct": [
      0,
      1
    ],
    "explanation": "Las tasks ejecutan en el contexto del actor y necesitan sus permisos más la autorización de AutomationEngine."
  },
  {
    "id": "A-059",
    "source": "workflowsecurity",
    "objective": "service-user",
    "bucket": "scenario",
    "difficulty": "intermediate",
    "prompt": "Un workflow de producción compartido no debe depender de que permanezca activa la cuenta del creador. ¿Qué actor recomienda Dynatrace?",
    "choices": [
      "Un service user con los permisos mínimos necesarios.",
      "Un usuario individual con permiso global de administración.",
      "La cuenta del creador con una clave API renovada periódicamente.",
      "El usuario que ejecutó por última vez el workflow desde la UI."
    ],
    "correct": [
      0
    ],
    "explanation": "Dynatrace recomienda service users para workflows colaborativos de producción."
  },
  {
    "id": "A-060",
    "source": "automation",
    "objective": "workflow-scope",
    "bucket": "scenario",
    "difficulty": "intermediate",
    "prompt": "Un equipo propone usar Workflows para exportar de forma masiva todo el lago de logs cada hora. ¿Qué orientación da AutomationEngine?",
    "choices": [
      "Usar una solución de procesamiento/exportación a escala apropiada; Workflows no está pensado para exportación masiva.",
      "Aumentar el paralelismo de las tasks hasta que la exportación masiva sea estable.",
      "Cambiar el trigger a schedule, que habilita el procesamiento masivo.",
      "Dividir la exportación en un workflow por bucket sin cambiar el mecanismo de transferencia."
    ],
    "correct": [
      0
    ],
    "explanation": "AutomationEngine no está destinado a ingestión ni exportación masiva; recomienda OpenPipeline o soluciones específicas."
  }
]
