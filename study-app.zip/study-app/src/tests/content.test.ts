import { describe, expect, it } from 'vitest'
import { modulesWithQuestions, allQuestions, baseQuestions, finalQuestions, questionsByModule, questionCounts } from '../data/questions'
import { moduleRevisions } from '../data/revisions'
import { REVISION_DATE } from '../data/revisions/apply'
import { modules } from '../data/modules'
import { deepStudyContent as studyContent } from '../data/deep-study-content'
import { precisionFacts } from '../data/precision-facts'
import { sourceCatalog } from '../data/source-catalog'
import { bankB } from '../data/bank-b'
import { bankC } from '../data/bank-c'
import { bankD } from '../data/bank-d'
import { bankE } from '../data/bank-e'
import { bankWelcome } from '../data/bank-welcome'
import { bankInstructions } from '../data/bank-instructions'
import { bankExpansion } from '../data/bank-expansion'
import { evidenceSources } from '../data/bank-core'

describe('banco de preguntas de Associate Certification', () => {
  it('contiene doce módulos y preguntas revisadas', () => {
    expect(modules).toHaveLength(12)
    expect(baseQuestions).toHaveLength(816)
    expect(allQuestions.length).toBeGreaterThanOrEqual(900)
    expect(new Set(allQuestions.map((question) => question.id)).size).toBe(allQuestions.length)
    expect(new Set(allQuestions.map((question) => question.promptEs)).size).toBe(allQuestions.length)
  })

  it('mantiene al menos 75 preguntas revisadas por módulo, con variedad de formato', () => {
    for (const module of modulesWithQuestions) {
      const questions = questionsByModule[module.id]
      expect(module.questionIds).toEqual(questions.map((question) => question.id))
      expect(Object.values(questionCounts[module.id]).reduce((sum, count) => sum + count, 0)).toBe(questions.length)
      expect(questions.length, module.id).toBeGreaterThanOrEqual(75)
      expect(questions.filter((question) => question.type === 'multiple').length, module.id).toBeGreaterThanOrEqual(8)
      expect(questions.filter((question) => question.stimulus).length, module.id).toBeGreaterThanOrEqual(4)
    }
  })

  it('aplica revisiones solo sobre preguntas existentes del mismo módulo', () => {
    for (const revision of moduleRevisions) {
      for (const id of [...Object.keys(revision.replace), ...Object.keys(revision.remove)]) {
        expect(baseQuestions.some((question) => question.id === id && question.moduleId === revision.moduleId), `${revision.moduleId}:${id}`).toBe(true)
      }
      expect(revision.add.every((question) => question.moduleId === revision.moduleId && question.id.startsWith('R-'))).toBe(true)
    }
  })

  it('evita que la opción correcta se delate por ser la más larga', () => {
    for (const module of modules) {
      const single = questionsByModule[module.id].filter((question) => question.type === 'single')
      const longest = single.filter((question) => {
        const correct = question.options.find((option) => option.id === question.correctOptionIds[0])!.text.length
        return question.options.filter((option) => option.id !== question.correctOptionIds[0]).every((option) => option.text.length < correct)
      })
      expect(longest.length / single.length, module.id).toBeLessThanOrEqual(0.35)
    }
  })

  it('incluye 68 preguntas para el módulo de bienvenida y 68 para instrucciones', () => {
    expect(bankWelcome).toHaveLength(68)
    expect(new Set(bankWelcome.map((q) => q.id)).size).toBe(68)
    expect(bankWelcome.every((q) => q.id.startsWith('W-'))).toBe(true)

    expect(bankInstructions).toHaveLength(68)
    expect(new Set(bankInstructions.map((q) => q.id)).size).toBe(68)
    expect(bankInstructions.every((q) => q.id.startsWith('I-'))).toBe(true)
  })

  it('conserva el segundo bloque editorial con ocho preguntas por dominio evaluable', () => {
    expect(bankB).toHaveLength(80)
    const domains = modules.filter((module) => !['welcome', 'instructions'].includes(module.id))
    expect(domains).toHaveLength(10)
    for (const domain of domains) {
      expect(bankB.filter((question) => evidenceSources[question.source].moduleId === domain.id), domain.id).toHaveLength(8)
    }
  })

  it('conserva el tercer bloque con cuatro preguntas por dominio evaluable', () => {
    expect(bankC).toHaveLength(40)
    const domains = modules.filter((module) => !['welcome', 'instructions'].includes(module.id))
    for (const domain of domains) {
      expect(bankC.filter((question) => evidenceSources[question.source].moduleId === domain.id), domain.id).toHaveLength(4)
    }
  })

  it('conserva el cuarto bloque con cuatro preguntas por dominio evaluable', () => {
    expect(bankD).toHaveLength(40)
    const domains = modules.filter((module) => !['welcome', 'instructions'].includes(module.id))
    for (const domain of domains) {
      expect(bankD.filter((question) => evidenceSources[question.source].moduleId === domain.id), domain.id).toHaveLength(4)
    }
  })

  it('incorpora sesenta preguntas nuevas, seis por dominio evaluable', () => {
    expect(bankE).toHaveLength(60)
    const domains = modules.filter((module) => !['welcome', 'instructions'].includes(module.id))
    for (const domain of domains) {
      expect(bankE.filter((question) => evidenceSources[question.source].moduleId === domain.id), domain.id).toHaveLength(6)
    }
  })

  it('incorpora doscientas preguntas de expansión, veinte por cada uno de los diez dominios técnicos', () => {
    expect(bankExpansion).toHaveLength(200)
    expect(new Set(bankExpansion.map((q) => q.id)).size).toBe(200)
    expect(bankExpansion.every((q) => q.id.startsWith('G-'))).toBe(true)
    const domains = modules.filter((module) => !['welcome', 'instructions'].includes(module.id))
    for (const domain of domains) {
      expect(bankExpansion.filter((question) => evidenceSources[question.source].moduleId === domain.id), domain.id).toHaveLength(20)
    }
  })

  it('completa el bloque final con 194 preguntas trazables', () => {
    expect(finalQuestions).toHaveLength(194)
    expect(new Set(finalQuestions.map((question) => question.id)).size).toBe(194)
    expect(finalQuestions.every((question) => question.id.startsWith('F'))).toBe(true)
  })

  it('obliga a que cada pregunta sea trazable y evaluable', () => {
    for (const question of allQuestions) {
      expect(question.options.length).toBeGreaterThanOrEqual(3)
      expect(question.correctOptionIds.length).toBeGreaterThanOrEqual(1)
      expect(question.correctOptionIds.every((id) => question.options['ABCDEFGHIJKLMNOPQRSTUVWXYZ'.indexOf(id)] !== undefined)).toBe(true)
      expect(question.options).toHaveLength(4)
      expect(new Set(question.options.map((option) => option.text)).size).toBe(4)
      expect(question.options.every((option) => option.text.trim().length >= 2)).toBe(true)
      expect(question.type).toBe(question.correctOptionIds.length > 1 ? 'multiple' : 'single')
      expect(question.sourceRefs.length).toBeGreaterThan(0)
      expect(question.sourceRefs.every((source) => source.url.startsWith('https://'))).toBe(true)
      expect(question.objectiveId).toContain(question.moduleId)
      expect(question.chapterId).toBeTruthy()
      expect(question.versionNote).toBeTruthy()
      const revised = question.id.startsWith('R-') || moduleRevisions.some((revision) => question.id in revision.replace && revision.moduleId === question.moduleId)
      const expectedDate = revised ? REVISION_DATE : question.id.startsWith('F')
        ? '2026-09-29'
        : (question.id.startsWith('W-') || question.id.startsWith('I-') || question.id.startsWith('G-'))
          ? '2026-09-30'
          : '2026-09-28'
      expect(question.lastVerified).toBe(expectedDate)
    }
    expect(allQuestions.filter((question) => question.type === 'multiple').length).toBeGreaterThanOrEqual(6)
  })

  it('cubre cada apartado con una lección autocontenida', () => {
    for (const module of modules) {
      const chapter = studyContent[module.id]
      expect(chapter).toBeDefined()
      expect(chapter.introduction.length).toBeGreaterThan(100)
      expect(chapter.outcomes.length).toBeGreaterThanOrEqual(4)
      expect(chapter.sections.length).toBeGreaterThanOrEqual(4)
      expect(new Set(chapter.sections.map((section) => section.id)).size).toBe(chapter.sections.length)
      expect(chapter.sections.every((section) => section.title && section.lead && section.paragraphs.length >= 2)).toBe(true)
      expect(chapter.sections.every((section) => (section.sourceRefs?.length ?? 0) >= 1)).toBe(true)
      expect(chapter.masteryChecklist.length).toBeGreaterThanOrEqual(4)
      expect(module.sources.length).toBeGreaterThan(0)
      expect(module.sources.every((source) => source.url.startsWith('https://'))).toBe(true)
    }
  })

  it('mantiene profundidad reforzada en los dominios técnicos', () => {
    const minimumSections: Record<string, number> = {
      platform: 7,
      observability: 10,
      notebooks: 10,
      'business-dem': 10,
      'data-analysis': 10,
      dql: 9,
      security: 8,
      automation: 8,
      ingestion: 10,
      other: 9,
    }
    for (const [moduleId, minimum] of Object.entries(minimumSections)) {
      expect(studyContent[moduleId].sections.length, moduleId).toBeGreaterThanOrEqual(minimum)
    }
  })

  it('incluye una ficha de hechos de precisión con fuentes oficiales por módulo', () => {
    for (const module of modules) {
      const sheet = precisionFacts[module.id]
      expect(sheet).toBeDefined()
      expect(sheet.rows.length).toBeGreaterThanOrEqual(7)
      expect(sheet.rows.every((row) => row.topic && row.fact.length > 40 && row.examNote.length > 25 && row.source.url.startsWith('https://'))).toBe(true)
    }
    expect(precisionFacts.observability.rows.some((row) => row.topic === 'Discovery')).toBe(true)
    expect(precisionFacts['data-analysis'].rows.some((row) => row.topic === 'Metrics powered by Grail' && row.fact.includes('15 meses'))).toBe(true)
  })

  it('mantiene un catálogo profundo de fuentes oficiales por cada módulo', () => {
    const officialHosts = ['docs.dynatrace.com', 'university.dynatrace.com', 'community.dynatrace.com', 'support.proctoru.com', 'www.dynatrace.com']
    for (const module of modules) {
      expect(sourceCatalog[module.id].length, module.id).toBeGreaterThanOrEqual(5)
      expect(new Set(sourceCatalog[module.id].map((source) => source.url)).size, module.id).toBe(sourceCatalog[module.id].length)
      expect(sourceCatalog[module.id].every((source) => officialHosts.some((host) => new URL(source.url).hostname === host || new URL(source.url).hostname.endsWith(`.${host}`))), module.id).toBe(true)
    }
  })
})
