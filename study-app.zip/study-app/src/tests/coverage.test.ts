import { describe, expect, it } from 'vitest'
import { modules } from '../data/modules'
import { questionsByModule } from '../data/questions'
import { baseDeepStudyContentForTests, deepStudyContent } from '../data/deep-study-content'
import { lessonSupplements } from '../data/lesson-supplements'
import { basePrecisionFactsForTests, precisionFacts } from '../data/precision-facts'
import { coverageByModule } from '../data/coverage'
import { normalizeText, precisionText, sectionText } from '../data/coverage/text'

describe('cada pregunta está respaldada por la guía de estudio de su bloque', () => {
  for (const module of modules) {
    it(module.id, () => {
      const coverage = coverageByModule[module.id]
      const chapter = deepStudyContent[module.id]
      const failures: string[] = []
      for (const question of questionsByModule[module.id]) {
        const entry = coverage[question.id]
        if (!entry) { failures.push(`${question.id}: sin entrada de cobertura`); continue }
        if (entry.evidence.trim().length < 25) failures.push(`${question.id}: evidencia demasiado corta`)
        const text = entry.section === 'precision-facts'
          ? precisionText(precisionFacts[module.id])
          : (() => { const section = chapter.sections.find((candidate) => candidate.id === entry.section); return section ? sectionText(section) : null })()
        if (text === null) { failures.push(`${question.id}: apartado inexistente ${entry.section}`); continue }
        if (!normalizeText(text).includes(normalizeText(entry.evidence))) failures.push(`${question.id}: la evidencia no aparece en ${entry.section}`)
      }
      const orphan = Object.keys(coverage).filter((id) => !questionsByModule[module.id].some((question) => question.id === id))
      orphan.forEach((id) => failures.push(`${id}: entrada de cobertura de una pregunta que no existe en el módulo`))
      expect(failures, failures.slice(0, 15).join('\n')).toEqual([])
    })
  }
})


describe('las ampliaciones de lección son coherentes', () => {
  for (const supplement of lessonSupplements) {
    it(supplement.moduleId, () => {
      const base = baseDeepStudyContentForTests[supplement.moduleId]
      const failures: string[] = []
      for (const [sectionId, extension] of Object.entries(supplement.extend)) {
        const section = base.sections.find((candidate) => candidate.id === sectionId)
        if (!section) { failures.push(`extend apunta a un apartado inexistente: ${sectionId}`); continue }
        const text = sectionText(section)
        for (const correction of extension.corrections ?? []) if (!text.includes(correction.find)) failures.push(`${sectionId}: corrección sin coincidencia: ${correction.find.slice(0, 60)}`)
        for (const row of extension.comparisonRows ?? []) if (!section.comparison || row.length !== section.comparison.headers.length) failures.push(`${sectionId}: fila de tabla con columnas incorrectas`)
      }
      const sheet = basePrecisionFactsForTests[supplement.moduleId]
      for (const correction of supplement.precision?.corrections ?? []) {
        const row = sheet.rows.find((candidate) => candidate.topic === correction.topic)
        if (!row) failures.push(`precision: topic inexistente ${correction.topic}`)
        else if (!`${row.fact} ${row.examNote}`.includes(correction.find)) failures.push(`precision ${correction.topic}: corrección sin coincidencia`)
      }
      for (const topic of supplement.precision?.remove ?? []) if (!sheet.rows.some((row) => row.topic === topic)) failures.push(`precision: retirada de topic inexistente ${topic}`)
      for (const added of supplement.precision?.add ?? []) if (!added.source.url.startsWith('https://')) failures.push(`precision ${added.topic}: fuente`)
      const ids = [...base.sections.map((section) => section.id), ...supplement.sections.map((section) => section.id)]
      if (new Set(ids).size !== ids.length) failures.push('ids de apartado duplicados')
      for (const section of supplement.sections) {
        if (section.paragraphs.length < 2) failures.push(`${section.id}: menos de 2 párrafos`)
        if (!section.sourceRefs?.length || !section.sourceRefs.every((source) => source.url.startsWith('https://docs.dynatrace.com/'))) failures.push(`${section.id}: fuentes oficiales`)
      }
      expect(failures, failures.join('\n')).toEqual([])
    })
  }
})
