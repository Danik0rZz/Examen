import { useEffect, useMemo, useState } from 'react'
import { MapView } from './components/MapView'
import { InlineText } from './components/InlineText'
import { adaptiveReviewIds, fullBankIds, loadServed, mockExamIds, optionOrders, quickQuizIds, rememberServed } from './lib/selection'
import { SectionVisual } from './components/visuals/SectionVisual'
import { getSectionVisual } from './components/visuals/registry'
import { examProfile, modules } from './data/modules'
import { glossary } from './data/glossary'
import { allQuestions, modulesWithQuestions, questionsById, questionsByModule } from './data/questions'
import { practices } from './data/practices'
import { studyGuides } from './data/study-guides'
import { deepStudyContent as studyContent } from './data/deep-study-content'
import type { StudyChapter, StudySection } from './data/study-content'
import { precisionFacts, type PrecisionFactSheet } from './data/precision-facts'
import type { Attempt, Module, Question, QuestionBucket } from './data/types'
import {
  latestAttempt,
  loadProgress,
  moduleCompletion,
  moduleScore,
  dueQuestionIds,
  recordAttempt,
  saveProgress,
  scoreAttempt,
  type ProgressState,
} from './lib/progress'

type View = 'home' | 'map' | 'module' | 'quiz' | 'review' | 'practice' | 'mock' | 'errors' | 'glossary'
type QuizMode = 'quick' | 'full' | 'review' | 'mock'
type Confidence = 1 | 2 | 3 | 4 | 5
const mockDurationSeconds = 60 * 60

type Session = {
  mode: QuizMode
  title: string
  questionIds: string[]
  optionOrderByQuestionId: Record<string, string[]>
  moduleId?: string
}

const bucketLabels: Record<QuestionBucket, string> = {
  knowledge: 'Conocimiento',
  precision: 'Precisión',
  scenario: 'Escenario',
  troubleshooting: 'Troubleshooting',
  practical: 'Mini-práctica',
}

const difficultyLabels = { basic: 'Básica', intermediate: 'Intermedia', advanced: 'Avanzada' }

const navItems: { id: View; label: string; icon: string }[] = [
  { id: 'home', label: 'Inicio', icon: '⌂' },
  { id: 'map', label: 'Mapa de estudio', icon: '◈' },
  { id: 'review', label: 'Repaso adaptativo', icon: '↻' },
  { id: 'practice', label: 'Prácticas', icon: '⌁' },
  { id: 'mock', label: 'Simulacro', icon: '◷' },
  { id: 'errors', label: 'Errores', icon: '!' },
  { id: 'glossary', label: 'Glosario', icon: 'Aa' },
]

const sortByDifficulty = (left: Question, right: Question) => {
  const order = { basic: 0, intermediate: 1, advanced: 2 }
  return order[left.difficulty] - order[right.difficulty]
}

const SIDEBAR_STORAGE_KEY = 'dynatrace-associate-sidebar-collapsed'

const sourceKindLabel = (kind: string) => (kind === 'official-training' ? 'Training oficial' : kind === 'support' ? 'Support oficial' : 'Documentación oficial')

function App() {
  const [view, setView] = useState<View>('home')
  const [sidebarCollapsed, setSidebarCollapsed] = useState(() => { try { return localStorage.getItem(SIDEBAR_STORAGE_KEY) === '1' } catch { return false } })
  const [selectedModuleId, setSelectedModuleId] = useState('platform')
  const [progress, setProgress] = useState<ProgressState>(() => loadProgress())
  const [session, setSession] = useState<Session | null>(null)
  const [sessionIndex, setSessionIndex] = useState(0)
  const [sessionAnswers, setSessionAnswers] = useState<Record<string, string[]>>({})
  const [sessionConfidence, setSessionConfidence] = useState<Confidence>(3)
  const [confidenceByQuestion, setConfidenceByQuestion] = useState<Record<string, Confidence>>({})
  const [feedbackQuestionId, setFeedbackQuestionId] = useState<string | null>(null)
  const [sessionDone, setSessionDone] = useState(false)
  const [secondsLeft, setSecondsLeft] = useState(mockDurationSeconds)
  const [flagged, setFlagged] = useState<string[]>([])
  const [glossarySearch, setGlossarySearch] = useState('')
  const [practiceDone, setPracticeDone] = useState<string[]>(() => {
    if (typeof window === 'undefined') return []
    try {
      return JSON.parse(window.localStorage.getItem('dynatrace-associate-practices-v1') ?? '[]') as string[]
    } catch {
      return []
    }
  })

  useEffect(() => saveProgress(progress), [progress])
  useEffect(() => {
    if (typeof window !== 'undefined') window.localStorage.setItem('dynatrace-associate-practices-v1', JSON.stringify(practiceDone))
  }, [practiceDone])

  const selectedModule = modulesWithQuestions.find((module) => module.id === selectedModuleId) ?? modulesWithQuestions.find((module) => module.questionIds.length > 0)!
  const currentQuestion = session ? questionsById[session.questionIds[sessionIndex]] : undefined
  const routeModule = currentQuestion ? modulesWithQuestions.find((module) => module.id === currentQuestion.moduleId) ?? selectedModule : selectedModule
  const attemptedQuestionCount = allQuestions.filter((question) => (progress.attempts[question.id] ?? []).length > 0).length
  const overallScore = allQuestions.reduce((sum, question) => {
    const last = latestAttempt(progress, question.id)
    return sum + (last?.score ?? 0)
  }, 0)
  const overallPercentage = Math.round((attemptedQuestionCount / allQuestions.length) * 100)

  const scrollToTop = () => { if (typeof window !== 'undefined') window.scrollTo({ top: 0, behavior: 'auto' }) }

  const toggleSidebar = () => setSidebarCollapsed((collapsed) => {
    const next = !collapsed
    try { localStorage.setItem(SIDEBAR_STORAGE_KEY, next ? '1' : '0') } catch { /* almacenamiento no disponible */ }
    return next
  })

  const navigate = (nextView: View) => {
    scrollToTop()
    setView(nextView)
    if (nextView === 'practice') setSelectedModuleId('')
    setSession(null)
    setSessionDone(false)
    setFeedbackQuestionId(null)
  }

  const openModule = (moduleId: string) => {
    scrollToTop()
    setSelectedModuleId(moduleId)
    setView('module')
    setSession(null)
    setSessionDone(false)
  }

  const startSession = (mode: QuizMode, questionIds: string[], title: string, moduleId?: string) => {
    rememberServed(questionIds)
    setSession({ mode, questionIds, title, moduleId, optionOrderByQuestionId: optionOrders(questionIds.map((id) => questionsById[id])) })
    setSessionIndex(0)
    setSessionAnswers({})
    setFlagged([])
    setSessionConfidence(3)
    setConfidenceByQuestion({})
    setFeedbackQuestionId(null)
    setSessionDone(false)
    setSecondsLeft(mockDurationSeconds)
    setView(mode === 'mock' ? 'mock' : 'quiz')
  }

  const startModuleQuiz = (mode: 'quick' | 'full', targetModuleId?: string) => {
    const modId = targetModuleId ?? selectedModule.id
    const mod = modulesWithQuestions.find((m) => m.id === modId) ?? selectedModule
    const pool = questionsByModule[mod.id]
    const ids = mode === 'quick' ? quickQuizIds(pool, progress, loadServed()) : fullBankIds(pool)
    startSession(mode, ids, `${mode === 'quick' ? 'Quiz rápido' : 'Banco completo'} · ${mod.title}`, mod.id)
  }

  const setAnswer = (question: Question, optionId: string) => {
    const current = sessionAnswers[question.id] ?? []
    const next = question.type === 'single'
      ? [optionId]
      : current.includes(optionId) ? current.filter((id) => id !== optionId) : current.length < question.correctOptionIds.length ? [...current, optionId] : current
    setSessionAnswers((answers) => ({ ...answers, [question.id]: next }))
  }

  const persistAnswer = (question: Question, selected: string[]) => {
    setProgress((current) => recordAttempt(current, question, selected, sessionConfidence))
  }

  const completeSession = () => {
    if (!session) return
    if (session.mode === 'mock') {
      setProgress((current) => session.questionIds.reduce((next, id) => {
        const question = questionsById[id]
        return recordAttempt(next, question, sessionAnswers[id] ?? [], confidenceByQuestion[id] ?? 3)
      }, current))
    }
    setSessionDone(true)
    setFeedbackQuestionId(null)
  }

  useEffect(() => {
    if (!session || session.mode !== 'mock' || sessionDone) return undefined
    const timer = window.setInterval(() => {
      setSecondsLeft((seconds) => {
        if (seconds <= 1) {
          window.clearInterval(timer)
          window.setTimeout(completeSession, 0)
          return 0
        }
        return seconds - 1
      })
    }, 1000)
    return () => window.clearInterval(timer)
  }, [session, sessionDone, sessionAnswers, confidenceByQuestion])

  const submitQuestion = () => {
    if (!session || !currentQuestion) return
    const selected = sessionAnswers[currentQuestion.id] ?? []
    if (session.mode === 'mock') {
      if (sessionIndex === session.questionIds.length - 1) completeSession()
      else setSessionIndex((index) => index + 1)
      return
    }
    persistAnswer(currentQuestion, selected)
    setFeedbackQuestionId(currentQuestion.id)
  }

  const nextQuestion = () => {
    if (!session || !currentQuestion) return
    if (sessionIndex === session.questionIds.length - 1) completeSession()
    else {
      setSessionIndex((index) => index + 1)
      setFeedbackQuestionId(null)
      setSessionConfidence(3)
    }
  }

  const toggleFlag = (questionId: string) => setFlagged((items) => items.includes(questionId) ? items.filter((id) => id !== questionId) : [...items, questionId])

  const beginReview = () => {
    startSession('review', adaptiveReviewIds(allQuestions, progress, loadServed(), 24), 'Repaso adaptativo')
  }

  const togglePractice = (id: string) => setPracticeDone((items) => items.includes(id) ? items.filter((item) => item !== id) : [...items, id])

  return (
    <div className={`app-shell ${sidebarCollapsed ? 'sidebar-collapsed' : ''}`}>
      <aside className="sidebar">
        <div className="brand-lockup">
          <div className="brand-mark">D</div>
          <div className="brand-text">
            <p className="brand-kicker">ASSOCIATE</p>
            <p className="brand-name">Study Lab</p>
          </div>
          <button type="button" className="sidebar-toggle" onClick={toggleSidebar} aria-expanded={!sidebarCollapsed} aria-label={sidebarCollapsed ? 'Expandir menú lateral' : 'Colapsar menú lateral'} title={sidebarCollapsed ? 'Expandir menú' : 'Colapsar menú'}>{sidebarCollapsed ? '»' : '«'}</button>
        </div>
        <div className="sidebar-rule" />
        <nav className="main-nav" aria-label="Navegación principal">
          {navItems.map((item) => (
            <button className={`nav-item ${view === item.id ? 'active' : ''}`} key={item.id} title={sidebarCollapsed ? item.label : undefined} onClick={() => item.id === 'mock' ? startSession('mock', mockExamIds(allQuestions, progress, loadServed()), 'Simulacro · 60 preguntas') : navigate(item.id)}>
              <span className="nav-icon" aria-hidden="true">{item.icon}</span>
              <span className="nav-label">{item.label}</span>
            </button>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <p className="sidebar-label">Ruta actual</p>
          <button className="route-link" onClick={() => openModule(routeModule.id)} title={sidebarCollapsed ? `Ruta actual: ${routeModule.title}` : undefined}>
            <span className="route-dot" />
            <span className="route-title">{routeModule.title}</span>
            <span className="route-arrow">↗</span>
          </button>
          <p className="sidebar-note">Todo el contenido enlaza con documentación oficial para poder verificar cada decisión.</p>
        </div>
      </aside>

      <main className="main-content">
        <header className="topbar">
          <div className="breadcrumbs"><span>Dynatrace</span><span className="crumb-separator">/</span><span>Associate Certification</span><span className="crumb-separator">/</span><strong>{view === 'home' ? 'Study Lab' : navItems.find((item) => item.id === view)?.label ?? selectedModule.title}</strong></div>
          <div className="topbar-meta"><span className="status-pulse" /> Progreso guardado localmente <span className="topbar-divider" /> <span>{attemptedQuestionCount}/{allQuestions.length} revisadas</span></div>
        </header>

        <div className={`content-wrap ${view === 'map' ? 'content-wrap-wide' : ''}`}>
          {view === 'home' && <HomeView modules={modulesWithQuestions} progress={progress} overallPercentage={overallPercentage} overallScore={overallScore} attemptedQuestionCount={attemptedQuestionCount} onStart={() => openModule('platform')} onMap={() => navigate('map')} onMock={() => startSession('mock', mockExamIds(allQuestions, progress, loadServed()), 'Simulacro · 60 preguntas')} onOpenModule={openModule} />}
          {view === 'map' && <MapView progress={progress} onOpenModule={openModule} onQuickQuiz={(id) => startModuleQuiz('quick', id)} onFullQuiz={(id) => startModuleQuiz('full', id)} onPractice={(id) => { setView('practice'); setSelectedModuleId(id) }} />}
          {view === 'module' && <ModuleView module={selectedModule} progress={progress} onOpenModule={openModule} onQuick={() => startModuleQuiz('quick')} onFull={() => startModuleQuiz('full')} onPractice={() => { setView('practice'); setSelectedModuleId(selectedModule.id) }} />}
          {(view === 'quiz' || view === 'mock') && session && currentQuestion && !sessionDone && <QuizView session={session} question={currentQuestion} index={sessionIndex} selected={sessionAnswers[currentQuestion.id] ?? []} confidence={session.mode === 'mock' ? confidenceByQuestion[currentQuestion.id] ?? 3 : sessionConfidence} flagged={flagged.includes(currentQuestion.id)} secondsLeft={secondsLeft} feedbackVisible={feedbackQuestionId === currentQuestion.id} onToggleAnswer={(optionId) => setAnswer(currentQuestion, optionId)} onConfidence={(value) => { setSessionConfidence(value); setConfidenceByQuestion((current) => ({ ...current, [currentQuestion.id]: value })) }} onSubmit={submitQuestion} onNext={nextQuestion} onToggleFlag={() => toggleFlag(currentQuestion.id)} onBack={() => sessionIndex > 0 && setSessionIndex((index) => index - 1)} onJump={(index) => { setSessionIndex(index); setFeedbackQuestionId(null) }} />}
          {(view === 'quiz' || view === 'mock') && session && sessionDone && <SessionResult session={session} answers={sessionAnswers} flagged={flagged} onHome={() => navigate('home')} onReview={() => beginReview()} onModule={() => session.moduleId ? openModule(session.moduleId) : navigate('home')} />}
          {view === 'review' && !session && <ReviewView progress={progress} onStart={beginReview} onOpenModule={openModule} />}
          {view === 'errors' && <ErrorHistoryView progress={progress} onOpenModule={openModule} />}
          {view === 'practice' && <PracticeView selectedModuleId={selectedModuleId} done={practiceDone} onToggle={togglePractice} onOpenModule={openModule} />}
          {view === 'glossary' && <GlossaryView search={glossarySearch} onSearch={setGlossarySearch} onOpenModule={openModule} />}
        </div>
      </main>
    </div>
  )
}

function HomeView({ modules: moduleList, progress, overallPercentage, overallScore, attemptedQuestionCount, onStart, onMap, onMock, onOpenModule }: { modules: Module[]; progress: ProgressState; overallPercentage: number; overallScore: number; attemptedQuestionCount: number; onStart: () => void; onMap: () => void; onMock: () => void; onOpenModule: (id: string) => void }) {
  const activeModule = moduleList.find((module) => module.questionIds.length > 0 && moduleCompletion(progress, module.questionIds) < 100) ?? moduleList[moduleList.length - 1]
  return (
    <div className="page-stack">
      <section className="hero-grid">
        <div className="hero-copy">
          <p className="eyebrow">PREPARACIÓN TÉCNICA · 2026</p>
          <h1>Convierte el path en<br /><em>criterio operativo.</em></h1>
          <p className="hero-lede">Una ruta de estudio en español para dominar la certificación Associate: conceptos, precisión, escenarios y decisiones con evidencia oficial.</p>
          <div className="hero-actions"><button className="button-primary" onClick={onStart}>Continuar ruta <span>→</span></button><button className="button-quiet" onClick={onMap}>Explorar mapa <span>↗</span></button></div>
          <div className="hero-source-line"><span className="source-check">✓</span> Fuentes oficiales enlazadas por módulo y por pregunta</div>
        </div>
        <div className="hero-progress-card">
          <div className="progress-orbit" style={{ background: `conic-gradient(var(--teal) 0 ${overallPercentage}%, rgba(255,255,255,.15) ${overallPercentage}% 100%)` }}><div className="orbit-center"><strong>{overallPercentage}%</strong><span>revisado</span></div></div>
          <div className="progress-card-copy"><span className="card-label">ESTADO DE LA RUTA</span><strong>{activeModule.title}</strong><span>{attemptedQuestionCount} de {allQuestions.length} preguntas practicadas</span></div>
          <div className="progress-card-footer"><span>Score acumulado</span><strong>{attemptedQuestionCount ? `${Math.round(overallScore / attemptedQuestionCount * 100)}%` : '—'}</strong></div>
        </div>
      </section>

      <section className="metric-strip">
        <Metric value="12" label="módulos" detail="del study path" />
        <Metric value={String(allQuestions.length)} label="preguntas" detail="con explicación" />
        <Metric value="60" label="simulacro" detail="práctica local" />
        <Metric value="∞" label="fuentes" detail="documentación oficial" />
      </section>

      <section className="exam-ribbon"><div><p className="eyebrow">PERFIL DE EXAMEN · REFERENCIA</p><h2>{examProfile.label}</h2><p>{examProfile.note}</p></div><div className="exam-links">{examProfile.officialLinks.map((source) => <a href={source.url} target="_blank" rel="noreferrer" key={source.url}>{source.title} ↗</a>)}</div></section>

      <section className="section-heading"><div><p className="eyebrow">PUNTO DE PARTIDA</p><h2>Tu ruta, en una mirada</h2></div><button className="text-button" onClick={onMap}>Abrir mapa completo <span>↗</span></button></section>
      <div className="module-overview-grid">{moduleList.slice(0, 6).map((module) => <ModuleOverviewCard key={module.id} module={module} progress={progress} onOpen={() => onOpenModule(module.id)} />)}</div>
      <section className="cta-band"><div><p className="eyebrow">CUANDO QUIERAS MEDIRTE</p><h2>Un simulacro sin pistas.</h2><p>60 preguntas, feedback al final y revisión por dominio.</p></div><button className="button-dark" onClick={onMock}>Iniciar simulacro <span>→</span></button></section>
    </div>
  )
}

function Metric({ value, label, detail }: { value: string; label: string; detail: string }) {
  return <div className="metric"><strong>{value}</strong><div><span>{label}</span><small>{detail}</small></div></div>
}

function ModuleOverviewCard({ module, progress, onOpen }: { module: Module; progress: ProgressState; onOpen: () => void }) {
  const completion = moduleCompletion(progress, module.questionIds)
  return <button className="module-overview-card" onClick={onOpen}><div className="module-card-top"><span className="module-number">{String(module.order).padStart(2, '0')}</span><span className="module-status">{completion ? `${completion}%` : 'pendiente'}</span></div><h3>{module.title}</h3><p>{module.summary}</p><div className="thin-progress"><span style={{ width: `${completion}%` }} /></div></button>
}










function ModuleView({ module, progress, onOpenModule, onQuick, onFull, onPractice }: { module: Module; progress: ProgressState; onOpenModule: (moduleId: string) => void; onQuick: () => void; onFull: () => void; onPractice: () => void }) {
  const questions = questionsByModule[module.id]
  const completion = moduleCompletion(progress, module.questionIds)
  const translatedGuide = studyGuides[module.id] ?? [`${module.summary} En esta lectura, el objetivo es entender el lugar de este apartado dentro de la plataforma y poder explicarlo con vocabulario técnico preciso.`, `La documentación oficial se ha convertido aquí en una guía de estudio en español: conserva nombres de producto, aplicaciones, entidades y sintaxis en inglés, y traduce el criterio operativo que debes aplicar.`, `La práctica se concentra en ${module.focus}. Contrasta siempre la explicación con los enlaces oficiales del panel de documentación y con la variante de producto que estés utilizando.`]
  const chapter = studyContent[module.id]
  return <div className="page-stack module-page"><section className="module-hero"><div><p className="eyebrow">{module.eyebrow}</p><h1>{module.title}</h1><p className="module-summary">{module.summary}</p><div className="module-focus"><span>FOCO</span>{module.focus}</div></div><div className="module-score"><span>PROGRESO</span><strong>{completion}%</strong><div className="ring-bar"><span style={{ width: `${completion}%` }} /></div><small>{module.questionIds.filter((id) => (progress.attempts[id] ?? []).length > 0).length}/{questions.length} intentadas</small></div></section>
    <section className="module-actions">{questions.length > 0 && <><button className="button-primary" onClick={onQuick}>Quiz rápido <span>{Math.min(8, questions.length)}</span> <b>→</b></button><button className="button-outline" onClick={onFull}>Banco completo <span>{questions.length}</span> <b>→</b></button></>}<button className="button-outline" onClick={onPractice}>Abrir prácticas <b>↗</b></button></section>
    <section className="translation-panel"><div className="panel-heading"><div><p className="eyebrow">RESUMEN DE ORIENTACIÓN</p><h2>Antes de estudiar en profundidad</h2></div><span className="panel-count">{chapter?.sections.length ?? 0} bloques · {module.sources.length} fuentes</span></div><div className="translation-copy">{translatedGuide.map((paragraph) => <p key={paragraph}><InlineText text={paragraph} /></p>)}</div><p className="translation-callout">La lección completa de abajo contiene la explicación interna en español, tablas, ejemplos, límites, checklist y enlaces oficiales por bloque. Puedes estudiar el apartado sin salir de la aplicación y usar las fuentes como verificación viva.</p></section>
    {chapter && <StudyChapterView moduleId={module.id} chapter={chapter} />}
    <div className="module-detail-grid"><section className="content-panel"><div className="panel-heading"><div><p className="eyebrow">OBJETIVOS DE APRENDIZAJE</p><h2>Al terminar este módulo podrás…</h2></div><span className="panel-count">{module.objectives.length} objetivos</span></div><ol className="objective-list">{module.objectives.map((objective, index) => <li key={objective}><span>{String(index + 1).padStart(2, '0')}</span><p>{objective}</p></li>)}</ol><div className="terms-row"><span className="eyebrow">TÉRMINOS CLAVE</span><div>{module.keyTerms.map((term) => <span key={term} className="term-chip">{term}</span>)}</div></div></section><OfficialSources sources={module.sources} /></div>
    <section className="question-bank-panel"><div className="panel-heading"><div><p className="eyebrow">BANCO AVANZADO</p><h2>Qué vas a practicar</h2></div><span className="panel-count">{questions.length} preguntas</span></div><div className="bucket-grid">{(['knowledge', 'precision', 'scenario', 'troubleshooting', 'practical'] as QuestionBucket[]).map((bucket) => <div className="bucket-cell" key={bucket}><span>{bucketLabels[bucket]}</span><strong>{questions.filter((question) => question.bucket === bucket).length}</strong><small>{bucket === 'precision' ? 'distractores cercanos' : bucket === 'scenario' ? 'decisiones operativas' : bucket === 'troubleshooting' ? 'límites y diagnóstico' : bucket === 'practical' ? 'interpretación' : 'base conceptual'}</small></div>)}</div></section>
    <ModulePager current={module} onOpenModule={onOpenModule} />
  </div>
}

function ModulePager({ current, onOpenModule }: { current: Module; onOpenModule: (moduleId: string) => void }) {
  const ordered = [...modulesWithQuestions].sort((a, b) => a.order - b.order)
  const index = ordered.findIndex((module) => module.id === current.id)
  const previous = index > 0 ? ordered[index - 1] : undefined
  const next = index >= 0 && index < ordered.length - 1 ? ordered[index + 1] : undefined
  return <nav className="module-pager" aria-label="Navegación entre bloques">
    {previous ? <button type="button" className="pager-link pager-prev" onClick={() => onOpenModule(previous.id)}><span className="pager-arrow">←</span><span><small>Bloque anterior · {String(previous.order).padStart(2, '0')}</small><strong>{previous.title}</strong></span></button> : <span className="pager-spacer" />}
    <button type="button" className="pager-top" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>↑ Volver arriba</button>
    {next ? <button type="button" className="pager-link pager-next" onClick={() => onOpenModule(next.id)}><span><small>Siguiente bloque · {String(next.order).padStart(2, '0')}</small><strong>{next.title}</strong></span><span className="pager-arrow">→</span></button> : <span className="pager-end">Has llegado al último bloque. Prueba el simulacro de 60 preguntas.</span>}
  </nav>
}

function StudyChapterView({ moduleId, chapter }: { moduleId: string; chapter: StudyChapter }) {
  const storageKey = `dynatrace-associate-mastery-${moduleId}`
  const [checked, setChecked] = useState<boolean[]>(() => {
    if (typeof window === 'undefined') return []
    try {
      return JSON.parse(window.localStorage.getItem(storageKey) ?? '[]') as boolean[]
    } catch {
      return []
    }
  })
  const toggleMastery = (index: number) => {
    const next = chapter.masteryChecklist.map((_, itemIndex) => itemIndex === index ? !checked[itemIndex] : Boolean(checked[itemIndex]))
    setChecked(next)
    window.localStorage.setItem(storageKey, JSON.stringify(next))
  }
  const sourceCount = chapter.sections.reduce((total, section) => total + (section.sourceRefs?.length ?? 0), 0)
  return <section className="study-chapter"><div className="study-chapter-header"><div><p className="eyebrow">LECCIÓN COMPLETA · ESTUDIO SIN SALIR DE LA APP</p><h2>Contenido de estudio</h2><p>{chapter.introduction}</p><div className="chapter-stats"><span><strong>{chapter.sections.length}</strong> bloques internos</span><span><strong>{sourceCount}</strong> enlaces por bloque</span><span><strong>{chapter.masteryChecklist.length}</strong> criterios de dominio</span></div></div><div className="chapter-outcomes"><span className="eyebrow">AL TERMINAR</span>{chapter.outcomes.map((outcome) => <span key={outcome}>✓ {outcome}</span>)}</div></div><nav className="chapter-index" aria-label="Índice de la lección">{chapter.sections.map((section) => <a href={`#${section.id}`} key={section.id} className={getSectionVisual(moduleId, section.id) ? 'has-visual' : undefined} title={getSectionVisual(moduleId, section.id) ? 'Incluye ilustración o animación' : undefined}>{section.title}</a>)}<a href="#precision-facts">Hechos de precisión</a></nav><div className="study-sections">{chapter.sections.map((section) => <StudySectionView section={section} moduleId={moduleId} key={section.id} />)}</div>{precisionFacts[moduleId] && <PrecisionFactsView factSheet={precisionFacts[moduleId]} />}<div className="mastery-box"><div><p className="eyebrow">CHECKLIST DE DOMINIO</p><h3>Antes de pasar de módulo</h3><small>{checked.filter(Boolean).length}/{chapter.masteryChecklist.length} criterios confirmados</small></div><div className="mastery-list">{chapter.masteryChecklist.map((item, index) => <label key={item}><input type="checkbox" checked={Boolean(checked[index])} onChange={() => toggleMastery(index)} /> <span>{item}</span></label>)}</div></div></section>
}

function PrecisionFactsView({ factSheet }: { factSheet: PrecisionFactSheet }) {
  return <section className="precision-facts" id="precision-facts"><div className="precision-facts-heading"><div><p className="eyebrow">DATOS DE ALTA PRECISIÓN · MEMORIZA Y CONTRASTA</p><h3>{factSheet.title}</h3><p>{factSheet.intro}</p></div><span>{factSheet.rows.length} hechos</span></div><div className="precision-facts-table-wrap"><table className="precision-facts-table"><thead><tr><th>Área</th><th>Qué debes saber</th><th>Matiz que decide la respuesta</th><th>Fuente</th></tr></thead><tbody>{factSheet.rows.map((row) => <tr key={row.topic}><th scope="row">{row.topic}</th><td><InlineText text={row.fact} /></td><td><InlineText text={row.examNote} /></td><td><a href={row.source.url} target="_blank" rel="noreferrer">{row.source.title} ↗</a></td></tr>)}</tbody></table></div><p className="precision-facts-note">Estas cifras y comportamientos están fechados en el banco. Si el examen o tu tenant indica otra variante, manda la variante oficial vigente.</p></section>
}

function StudySectionView({ section, moduleId }: { section: StudySection; moduleId: string }) {
  const visual = getSectionVisual(moduleId, section.id)
  return <article className="study-section" id={section.id}><div className="study-section-heading"><span className="section-marker">{section.title.split('.')[0]}</span><div><h3>{section.title.replace(/^\d+\.\s*/, '')}</h3><p><InlineText text={section.lead} /></p></div></div><div className="study-prose">{section.paragraphs.map((paragraph) => <p key={paragraph}><InlineText text={paragraph} /></p>)}</div>{visual && <SectionVisual spec={visual} />}{section.bullets && <ul className="study-bullets">{section.bullets.map((bullet) => <li key={bullet}><InlineText text={bullet} /></li>)}</ul>}{section.comparison && <div className="study-table-wrap"><table><thead><tr>{section.comparison.headers.map((header) => <th key={header}>{header}</th>)}</tr></thead><tbody>{section.comparison.rows.map((row) => <tr key={row.join('-')}>{row.map((cell, index) => <td key={`${row[0]}-${index}`}><InlineText text={cell} /></td>)}</tr>)}</tbody></table></div>}{section.code && <div className="study-code"><pre><code>{section.code}</code></pre>{section.codeNote && <small><InlineText text={section.codeNote} /></small>}</div>}{section.warning && <div className="study-warning"><InlineText text={section.warning} /></div>}{section.sourceRefs?.length ? <div className="study-section-sources"><span className="eyebrow">FUENTES OFICIALES DE ESTE BLOQUE</span><div>{section.sourceRefs.map((source) => <a className="study-section-source-link" href={source.url} target="_blank" rel="noreferrer" key={source.url}><span>{source.title}</span><b>↗</b></a>)}</div></div> : null}</article>
}

function OfficialSources({ sources }: { sources: Module['sources'] }) {
  return <section className="sources-panel"><div className="panel-heading"><div><p className="eyebrow">PARA VERIFICAR</p><h2>Documentación oficial</h2></div><span className="source-link-mark">↗</span></div><p className="sources-intro">Abre la fuente antes o después de responder. La explicación de cada pregunta vuelve a enlazar aquí.</p><div className="source-list">{sources.map((source) => <a className="source-card" href={source.url} target="_blank" rel="noreferrer" key={source.url}><span className="source-kind">{sourceKindLabel(source.kind)}</span><strong>{source.title}</strong><span className="source-url">{source.url.replace(/^https:\/\//, '')}</span><span className="source-arrow">↗</span></a>)}</div><small className="verification-note">Última revisión del banco: 29 sep 2026 · Comprueba cambios de producto en la fuente viva.</small></section>
}

function QuizView({ session, question, index, selected, confidence, flagged, secondsLeft, feedbackVisible, onToggleAnswer, onConfidence, onSubmit, onNext, onToggleFlag, onBack, onJump }: { session: Session; question: Question; index: number; selected: string[]; confidence: Confidence; flagged: boolean; secondsLeft: number; feedbackVisible: boolean; onToggleAnswer: (id: string) => void; onConfidence: (value: Confidence) => void; onSubmit: () => void; onNext: () => void; onToggleFlag: () => void; onBack: () => void; onJump: (index: number) => void }) {
  const mock = session.mode === 'mock'
  const result = scoreAttempt(question, selected)
  const options = (session.optionOrderByQuestionId[question.id] ?? question.options.map((option) => option.id))
    .map((id) => question.options.find((option) => option.id === id)!)
  const moduleTitle = modulesWithQuestions.find((module) => module.id === question.moduleId)?.title ?? question.moduleId
  const minutes = Math.floor(secondsLeft / 60).toString().padStart(2, '0')
  const seconds = (secondsLeft % 60).toString().padStart(2, '0')
  return <div className="page-stack quiz-page">
    <div className="quiz-topline"><div><p className="eyebrow">{mock ? 'MODO SIMULACRO' : session.mode === 'review' ? 'REPASO ADAPTATIVO' : 'SESIÓN DE ESTUDIO'}</p><h1>{session.title}</h1></div><div className="quiz-counter"><strong>{String(index + 1).padStart(2, '0')}</strong><span>/ {session.questionIds.length}</span>{mock && <span className={`timer-readout ${secondsLeft < 300 ? 'urgent' : ''}`}>◷ {minutes}:{seconds}</span>}<div className="quiz-progress"><span style={{ width: `${((index + 1) / session.questionIds.length) * 100}%` }} /></div></div></div>
    <div className="quiz-layout"><section className="question-card">
      <div className="question-meta"><span className="module-origin">Módulo: {moduleTitle}</span><span className={`difficulty-pill ${question.difficulty}`}>{difficultyLabels[question.difficulty]}</span><span className="bucket-pill">{bucketLabels[question.bucket]}</span><span className="type-pill">{question.type === 'multiple' ? `Selecciona ${question.correctOptionIds.length}` : 'Una respuesta'}</span><button className={`flag-button ${flagged ? 'flagged' : ''}`} onClick={onToggleFlag}>{flagged ? '⚑' : '⚐'} Marcar</button></div>
      <h2><InlineText text={question.promptEs} /></h2>
      {question.stimulus && <div className="question-stimulus"><strong>{question.stimulus.title}</strong>{question.stimulus.kind === 'table' ? <table><thead><tr>{question.stimulus.columns.map((column) => <th key={column}>{column}</th>)}</tr></thead><tbody>{question.stimulus.rows.map((row, rowIndex) => <tr key={rowIndex}>{row.map((cell, cellIndex) => <td key={cellIndex}>{cell}</td>)}</tr>)}</tbody></table> : question.stimulus.kind === 'code' ? <pre><code>{question.stimulus.content}</code></pre> : <p>{question.stimulus.content}</p>}</div>}
      <p className="answer-hint">{question.type === 'multiple' ? `Selecciona exactamente ${question.correctOptionIds.length} respuestas.` : 'Selecciona la respuesta más precisa.'}</p>
      <fieldset className="options-list"><legend className="sr-only">Opciones de respuesta</legend>{options.map((option, optionIndex) => { const isSelected = selected.includes(option.id); const isCorrect = question.correctOptionIds.includes(option.id); const showState = feedbackVisible && !mock; return <label className={`answer-option ${isSelected ? 'selected' : ''} ${showState && isCorrect ? 'correct' : ''} ${showState && isSelected && !isCorrect ? 'incorrect' : ''}`} key={option.id}><input type={question.type === 'multiple' ? 'checkbox' : 'radio'} name={question.id} checked={isSelected} onChange={() => onToggleAnswer(option.id)} disabled={showState} /><span className="option-key">{String.fromCharCode(65 + optionIndex)}</span><span className="option-copy"><InlineText text={option.text} /></span>{showState && isCorrect && <span className="option-state">✓</span>}{showState && isSelected && !isCorrect && <span className="option-state">×</span>}</label> })}</fieldset>
      {feedbackVisible && !mock && <Feedback question={question} result={result} selected={selected} />}
    </section><aside className="quiz-aside"><div className="quiz-aside-card"><p className="eyebrow">CONTROL DE SESIÓN</p><div className="confidence-label"><span>Confianza</span><strong>{confidence}/5</strong></div><div className="confidence-scale">{([1, 2, 3, 4, 5] as Confidence[]).map((value) => <button className={confidence === value ? 'active' : ''} key={value} onClick={() => onConfidence(value)} aria-label={`Confianza ${value}`}>{value}</button>)}</div><p className="confidence-hint">Se usa para priorizar el repaso.</p></div><div className="quiz-aside-card source-mini"><p className="eyebrow">FUENTE OFICIAL</p><p>Consulta la documentación para contrastar el criterio.</p>{question.sourceRefs.map((source) => <a href={source.url} target="_blank" rel="noreferrer" key={source.url}>{source.title} <span>↗</span></a>)}</div><div className="quiz-aside-card question-nav"><p className="eyebrow">PREGUNTAS</p><div>{session.questionIds.map((id, questionIndex) => <button className={`${questionIndex === index ? 'active' : ''} ${questionIndex < index ? 'visited' : ''}`} key={id} onClick={() => mock && onJump(questionIndex)} disabled={!mock}>{questionIndex + 1}</button>)}</div><small>{mock ? 'Puedes volver a cualquier pregunta.' : 'Sigue el orden de la sesión.'}</small></div></aside></div>
    <div className="quiz-footer"><button className="button-quiet" onClick={onBack} disabled={!mock || index === 0}>← Anterior</button><div className="quiz-footer-actions">{feedbackVisible && !mock ? <button className="button-primary" onClick={onNext}>{index === session.questionIds.length - 1 ? 'Ver resultado' : 'Siguiente pregunta'} <span>→</span></button> : <button className="button-primary" onClick={onSubmit} disabled={!mock && selected.length !== question.correctOptionIds.length}>{mock ? (index === session.questionIds.length - 1 ? 'Finalizar simulacro' : selected.length ? 'Guardar y continuar' : 'Omitir y continuar') : 'Comprobar respuesta'} <span>→</span></button>}</div></div>
  </div>
}

function Feedback({ question, result, selected }: { question: Question; result: { score: number; correct: boolean }; selected: string[] }) {
  const answerTexts = question.options.filter((option) => question.correctOptionIds.includes(option.id)).map((option) => option.text)
  return <div className={`feedback-box ${result.correct ? 'positive' : 'negative'}`}><div className="feedback-heading"><strong>{result.correct ? 'Respuesta precisa.' : 'Revisa el matiz.'}</strong><span>{Math.round(result.score * 100)}%</span></div><p><InlineText text={question.explanationEs} /></p><div className="feedback-context"><span>Variante: <b>{question.classicOrLatest}</b></span><span>{question.versionNote}</span></div>{!result.correct && <div className="feedback-detail"><span>Tu selección: {selected.map((id) => question.options.find((option) => option.id === id)?.text).join(' / ')}</span><span>Correcta{answerTexts.length > 1 ? 's' : ''}: {answerTexts.join(' / ')}</span></div>}<div className="feedback-source"><span>Consulta oficial:</span>{question.sourceRefs.map((source) => <a href={source.url} target="_blank" rel="noreferrer" key={source.url}>{source.title} ↗</a>)}</div></div>
}

function SessionResult({ session, answers, flagged, onHome, onReview, onModule }: { session: Session; answers: Record<string, string[]>; flagged: string[]; onHome: () => void; onReview: () => void; onModule: () => void }) {
  const results = session.questionIds.map((id) => scoreAttempt(questionsById[id], answers[id] ?? []))
  const score = Math.round(results.reduce((sum, result) => sum + result.score, 0) / results.length * 100)
  const correct = results.filter((result) => result.correct).length
  const bucketResults = (Object.keys(bucketLabels) as QuestionBucket[]).map((bucket) => { const indexes = session.questionIds.map((id, index) => ({ question: questionsById[id], index })).filter(({ question }) => question.bucket === bucket).map(({ index }) => index); const value = indexes.length ? Math.round(indexes.reduce((sum, index) => sum + results[index].score, 0) / indexes.length * 100) : 0; return { bucket, value } })
  const missed = session.questionIds.filter((_, index) => !results[index].correct)
  return <div className="page-stack result-page">
    <section className="result-hero"><p className="eyebrow">SESIÓN COMPLETADA</p><h1>{session.title}</h1><div className="result-score"><strong>{score}%</strong><span>{correct} de {session.questionIds.length} respuestas exactas</span></div><p>{score >= 80 ? 'Buen nivel para consolidar y pasar al siguiente dominio.' : 'Usa los errores como guía: vuelve a la fuente y repite el repaso adaptativo.'}</p></section>
    <section className="result-grid"><div className="result-breakdown"><div className="panel-heading"><div><p className="eyebrow">LECTURA DEL RESULTADO</p><h2>Precisión por tipo</h2></div></div>{bucketResults.map(({ bucket, value }) => <div className="result-row" key={bucket}><span>{bucketLabels[bucket]}</span><div className="thin-progress"><span style={{ width: `${value}%` }} /></div><strong>{value}%</strong></div>)}<p className="result-footnote">{flagged.length ? `${flagged.length} pregunta(s) marcada(s) para revisar.` : 'No has marcado preguntas en esta sesión.'}</p></div><div className="result-actions"><p className="eyebrow">SIGUIENTE PASO</p><h2>Convierte el error en memoria.</h2><p>El repaso adaptativo prioriza respuestas incorrectas y de baja confianza.</p><button className="button-primary" onClick={onReview}>Abrir repaso <span>→</span></button><button className="button-outline" onClick={onModule}>Volver al módulo</button><button className="button-quiet" onClick={onHome}>Inicio</button></div></section>
    <section className="result-review"><div className="panel-heading"><div><p className="eyebrow">REVISIÓN DEL TEST</p><h2>{missed.length} respuestas para revisar</h2></div></div>{missed.map((id) => { const question = questionsById[id]; const selected = answers[id] ?? []; const moduleTitle = modulesWithQuestions.find((module) => module.id === question.moduleId)?.title; return <article className="result-review-item" key={id}><small>{moduleTitle} · {id}</small><h3><InlineText text={question.promptEs} /></h3><p><b>Tu respuesta:</b> <InlineText text={selected.length ? question.options.filter((option) => selected.includes(option.id)).map((option) => option.text).join(' / ') : 'Sin respuesta'} /></p><p><b>Respuesta correcta:</b> <InlineText text={question.options.filter((option) => question.correctOptionIds.includes(option.id)).map((option) => option.text).join(' / ')} /></p><p><InlineText text={question.explanationEs} /></p>{question.sourceRefs.map((source) => <a href={source.url} target="_blank" rel="noreferrer" key={source.url}>{source.title} ↗</a>)}</article> })}</section>
  </div>
}

function ReviewView({ progress, onStart, onOpenModule }: { progress: ProgressState; onStart: () => void; onOpenModule: (id: string) => void }) {
  const due = dueQuestionIds(progress, allQuestions)
  const weakModules = modulesWithQuestions.map((module) => ({ module, score: moduleScore(progress, module.questionIds), completion: moduleCompletion(progress, module.questionIds) })).filter(({ completion }) => completion > 0).sort((a, b) => a.score - b.score).slice(0, 4)
  return <div className="page-stack review-page"><section className="section-heading"><div><p className="eyebrow">MEMORIA ACTIVA</p><h1>Repaso adaptativo</h1><p>La cola combina preguntas falladas, baja confianza y conceptos todavía no practicados.</p></div><button className="button-primary" onClick={onStart}>Empezar repaso <span>{Math.min(24, due.length || 24)} →</span></button></section><div className="review-banner"><div className="review-banner-number">{due.length}</div><div><strong>preguntas que merecen otra mirada</strong><p>Tras dos aciertos consecutivos, la prioridad baja. La confianza también cuenta.</p></div></div><section className="review-grid"><div className="content-panel"><div className="panel-heading"><div><p className="eyebrow">DOMINIOS A REFORZAR</p><h2>Tu mapa de precisión</h2></div></div>{weakModules.length ? weakModules.map(({ module, score, completion }) => <button className="weak-module" key={module.id} onClick={() => onOpenModule(module.id)}><span className="weak-module-number">{String(module.order).padStart(2, '0')}</span><span><strong>{module.title}</strong><small>{completion}% completado · score {score}%</small></span><span className="weak-module-arrow">→</span></button>) : <p className="empty-state">Todavía no hay suficientes intentos para calcular dominios débiles. Empieza por el mapa.</p>}</div><div className="content-panel review-principles"><p className="eyebrow">CÓMO FUNCIONA</p><h2>Menos repetición, más precisión.</h2><ol><li><b>1</b><span>Se priorizan fallos y baja confianza.</span></li><li><b>2</b><span>La explicación vuelve a la documentación oficial.</span></li><li><b>3</b><span>Dos aciertos consecutivos reducen la prioridad.</span></li></ol></div></section></div>
}

function ErrorHistoryView({ progress, onOpenModule }: { progress: ProgressState; onOpenModule: (id: string) => void }) {
  const errors = allQuestions
    .map((question) => ({ question, attempt: latestAttempt(progress, question.id) }))
    .filter(({ attempt }) => attempt && !attempt.correct)
    .sort((left, right) => (right.attempt?.timestamp ?? '').localeCompare(left.attempt?.timestamp ?? ''))
  return <div className="page-stack errors-page"><section className="section-heading"><div><p className="eyebrow">MEMORIA DE ERRORES</p><h1>Historial de errores</h1><p>Revisa el último fallo de cada pregunta, vuelve a la fuente y retoma el módulo con una hipótesis concreta.</p></div><span className="completion-badge">{errors.length} pendientes</span></section>{errors.length ? <div className="error-list">{errors.map(({ question, attempt }) => <article className="error-card" key={question.id}><div className="error-card-top"><span className={`difficulty-pill ${question.difficulty}`}>{difficultyLabels[question.difficulty]}</span><span className="bucket-pill">{bucketLabels[question.bucket]}</span><span className="error-date">{attempt ? new Date(attempt.timestamp).toLocaleString('es-ES') : ''}</span></div><h2><InlineText text={question.promptEs} /></h2><div className="error-card-answer"><span>Tu selección: <b>{attempt?.selectedOptionIds.length ? attempt.selectedOptionIds.map((id) => question.options.find((option) => option.id === id)?.text).join(' / ') : 'sin respuesta'}</b></span><span>Respuesta correcta: <b><InlineText text={question.options.filter((option) => question.correctOptionIds.includes(option.id)).map((option) => option.text).join(' / ')} /></b></span></div><p><InlineText text={question.explanationEs} /></p><div className="error-card-links">{question.sourceRefs.slice(0, 2).map((source) => <a href={source.url} target="_blank" rel="noreferrer" key={source.url}>{source.title} ↗</a>)}<button onClick={() => onOpenModule(question.moduleId)}>Abrir módulo ↗</button></div></article>)}</div> : <section className="content-panel empty-error-state"><p className="eyebrow">TODO LIMPIO</p><h2>Aún no tienes errores registrados.</h2><p>Empieza un quiz y vuelve aquí para convertir cada fallo en una sesión de estudio trazable.</p></section>}</div>
}

function PracticeView({ selectedModuleId, done, onToggle, onOpenModule }: { selectedModuleId: string; done: string[]; onToggle: (id: string) => void; onOpenModule: (id: string) => void }) {
  const visiblePractices = selectedModuleId ? practices.filter((practice) => practice.moduleId === selectedModuleId) : practices
  return <div className="page-stack practice-page"><section className="section-heading"><div><p className="eyebrow">APRENDER HACIENDO</p><h1>Prácticas guiadas</h1><p>Ejercicios breves para transformar conceptos en decisiones explicables.</p></div><span className="completion-badge">{done.length}/{practices.length} completadas</span></section><div className="practice-grid">{(visiblePractices.length ? visiblePractices : practices).map((practice) => <article className={`practice-card ${done.includes(practice.id) ? 'done' : ''}`} key={practice.id}><div className="practice-card-top"><span className="module-number">{String(modules.find((module) => module.id === practice.moduleId)?.order ?? 0).padStart(2, '0')}</span><span className="practice-time">{practice.timebox}</span></div><h2>{practice.title}</h2><p>{practice.prompt}</p><div className="practice-checklist">{practice.checklist.map((item) => <span key={item}><i>·</i>{item}</span>)}</div><div className="practice-deliverable"><small>ENTREGABLE</small><span>{practice.deliverable}</span></div><OfficialSources sources={practice.sourceRefs} /><div className="practice-footer"><button className={`check-button ${done.includes(practice.id) ? 'checked' : ''}`} onClick={() => onToggle(practice.id)}>{done.includes(practice.id) ? '✓ Completada' : 'Marcar completada'}</button><button className="text-button" onClick={() => onOpenModule(practice.moduleId)}>Módulo ↗</button></div></article>)}</div>{selectedModuleId && <button className="button-quiet" onClick={() => onOpenModule(selectedModuleId)}>Volver al módulo seleccionado ←</button>}</div>
}

function GlossaryView({ search, onSearch, onOpenModule }: { search: string; onSearch: (value: string) => void; onOpenModule: (id: string) => void }) {
  const entries = glossary.filter((entry) => `${entry.term} ${entry.definition}`.toLowerCase().includes(search.toLowerCase()))
  return <div className="page-stack glossary-page"><section className="section-heading"><div><p className="eyebrow">REFERENCIA RÁPIDA</p><h1>Glosario</h1><p>Los términos se mantienen en inglés cuando así aparecen en Dynatrace; la explicación está en español.</p></div><label className="search-field"><span>⌕</span><input value={search} onChange={(event) => onSearch(event.target.value)} placeholder="Buscar término" aria-label="Buscar término en el glosario" /></label></section><div className="glossary-grid">{entries.map((entry) => <article className="glossary-card" key={`${entry.moduleId}-${entry.term}`}><div><span className="term-chip">{entry.term}</span><button onClick={() => onOpenModule(entry.moduleId)}>Ver módulo ↗</button></div><p>{entry.definition}</p></article>)}</div>{entries.length === 0 && <p className="empty-state">No hay términos que coincidan con “{search}”.</p>}</div>
}

export default App



