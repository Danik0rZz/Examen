# Dynatrace Associate Study Lab

Aplicación local de preparación para Dynatrace Associate Certification. Está pensada como una herramienta de estudio trazable: el contenido está en español, pero conserva la terminología de la UI, los nombres de producto y la sintaxis DQL en inglés.

## Alcance

- 12 módulos del path local de estudio.
- 12 lecciones autocontenidas en español, con capítulos explicativos, comparativas, ejemplos, límites, troubleshooting y checklist de dominio.
- Fichas de hechos de alta precisión por módulo: retención, límites, permisos, modos, sintaxis, estados y condiciones con enlace oficial fila a fila.
- 959 preguntas tipo test (entre 78 y 82 por bloque, según la amplitud de su temario) tras la revisión editorial de octubre de 2026, con respuesta múltiple y estímulos (consulta DQL, tabla o caso) en todos los bloques.
- Cada pregunta está respaldada por un fragmento literal de la guía de estudio de su bloque (`src/data/coverage/`); un test automático falla si alguna pregunta no tiene respaldo o si la guía cambia y deja de contenerlo.
- Selección aleatoria con rotación: los quiz rápidos, el simulacro (60 preguntas repartidas por bloque) y el repaso priorizan lo no respondido ni servido recientemente (`src/lib/selection.ts`).
- Enunciado, módulo de origen, cuatro alternativas temáticas, solución, explicación, dificultad, objetivo, variante y fuente oficial por pregunta. La selección múltiple indica cuántas opciones marcar.
- Quiz rápido de hasta 8 preguntas, banco completo del módulo, repaso adaptativo y simulacro de 60 preguntas con revisión de fallos al terminar.
- Ilustraciones y animaciones integradas en los apartados que más se benefician de una explicación visual (marcados con ▶ en el índice de cada lección).
- Prácticas guiadas, glosario, mapa visual con React Flow y persistencia local.
- Los enlaces oficiales aparecen en el módulo, en el contexto de cada pregunta y en el feedback.

El formato del examen se presenta como referencia versionada. La aplicación no promete que las reglas futuras sean idénticas: verifica siempre Dynatrace University y el proveedor de proctoring antes de reservar.

## Requisitos para otro PC

La aplicación es completamente local y no necesita tenant de Dynatrace, API tokens, backend, base de datos ni variables de entorno.

El progreso de este banco se guarda con la clave `dynatrace-associate-progress-v3`. Los intentos del banco anterior permanecen en el navegador, pero no se mezclan con las puntuaciones de las preguntas nuevas.

- Windows 10/11, macOS o Linux.
- Node.js `20.19+` o `22.12+`. Se recomienda instalar Node.js 22 LTS desde [nodejs.org](https://nodejs.org/).
- npm, incluido con Node.js.
- Un navegador moderno: Edge, Chrome, Firefox o Safari.
- Conexión a internet únicamente para instalar dependencias y abrir los enlaces oficiales de estudio.

No es necesario instalar React, TypeScript, Vite ni React Flow por separado: `npm ci` instala las versiones fijadas en `package-lock.json`.

## Ejecutar

```powershell
cd "ruta\a\study-app"
npm.cmd ci
npm.cmd run dev
```

Abre la dirección que indique Vite, normalmente `http://localhost:5173/`. Si ese puerto está ocupado, Vite elegirá otro, como `5174`.

Validaciones disponibles:

```powershell
npm.cmd run lint
npm.cmd test
npm.cmd run build
```

## Estructura de contenido

- `src/data/modules.ts`: alcance, objetivos, términos y fuentes de cada módulo.
- `src/data/study-guides.ts`: lectura guiada breve por módulo.
- `src/data/study-content.ts`: lecciones completas de estudio por módulo, tablas, ejemplos y checklist.
- `src/data/precision-facts.ts`: hechos memorizables y verificables por módulo; incluye retenciones de Metrics, logs, traces, RUM, Davis y Key Requests, además de los detalles de OneAgent, DQL, Security y Automation.
- `src/data/bank-a.ts`, `src/data/bank-extra.ts`, `src/data/bank-b.ts`, `src/data/bank-c.ts`, `src/data/bank-d.ts`, `src/data/bank-e.ts` y `src/data/bank-final-*.ts`: enunciados, claves y alternativas revisadas.
- `src/data/questions.ts`: asociación de preguntas y metadatos con los módulos. `baseQuestions` es el banco original y `allQuestions` el vigente tras aplicar las revisiones.
- `src/data/lesson-supplements/`: ampliaciones y correcciones de la guía de estudio y de la ficha de precisión por bloque (apartados `sup-*`), verificadas contra docs.dynatrace.com.
- `src/data/coverage/`: trazabilidad pregunta → apartado de la guía → fragmento literal que la respalda.
- `src/data/revisions/`: revisión editorial por módulo (octubre de 2026): correcciones verificadas contra docs.dynatrace.com, preguntas retiradas con su motivo y preguntas nuevas (`R-<módulo>-NN`). Los ficheros `bank-*.ts` originales no se modifican.
- `src/data/practices.ts`: prácticas separadas por módulo y sus fuentes.
- `src/data/glossary.ts`: referencia terminológica.
- `src/components/visuals/`: ilustraciones y animaciones SVG por apartado (66 en total). `kit.tsx` contiene las primitivas, `SectionVisual.tsx` el marco con reproducir/pausar/reiniciar y pasos, y cada módulo tiene su fichero (`welcome.tsx`, `dql.tsx`…) indexado por el `id` del apartado en `registry.ts`. Se pausan fuera de pantalla y respetan `prefers-reduced-motion`.
- `src/lib/progress.ts`: scoring exacto, scoring parcial de respuesta múltiple y `localStorage` versionado.
- `src/tests/content.test.ts`: conteos, distribución, unicidad, fuentes y trazabilidad.
- `src/tests/progress.test.ts`: scoring y registro de intentos.

## Política de calidad

Las alternativas incorrectas tratan el mismo concepto que la respuesta correcta y el orden se mezcla en cada sesión. La validación automática comprueba estructura, respuesta, unicidad, fuente y trazabilidad. La explicación técnica y el enlace oficial aparecen tras responder o al finalizar el simulacro. Es un banco de preparación propio, no preguntas oficiales ni una predicción del examen. El número de preguntas por dominio refleja la cobertura disponible del banco, no los pesos oficiales.

## Fuentes base

- [Learning Plan oficial](https://university.dynatrace.com/learn/public/learning_plan/view/47/dynatrace-associate-certification-learning-plan)
- [Associate Certification Learning Path 2025](https://community.dynatrace.com/pssft35649/attachments/pssft35649/GetStarted/1351/1/Associate_Certification_Learning_Path_2025.pdf)
- [What is Dynatrace?](https://docs.dynatrace.com/docs/discover-dynatrace/what-is-dynatrace)
- [DQL](https://docs.dynatrace.com/docs/platform/grail/dynatrace-query-language)
- [Real User and Synthetic Monitoring](https://docs.dynatrace.com/docs/license/capabilities/real-user-synthetic-monitoring)
- [Application Security](https://docs.dynatrace.com/docs/secure/application-security)
- [AutomationEngine](https://docs.dynatrace.com/docs/platform/automationengine)
- [Log ingestion](https://docs.dynatrace.com/docs/analyze-explore-automate/logs/lma-log-ingestion)
